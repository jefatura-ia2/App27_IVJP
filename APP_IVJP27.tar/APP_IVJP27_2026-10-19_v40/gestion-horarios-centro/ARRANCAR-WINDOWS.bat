@echo off
chcp 65001 >nul
title Gestion de horarios - arranque local
cd /d "%~dp0"

echo.
echo  === Gestion de horarios IES Valle del Jerte: arranque en este ordenador ===
echo.

where node >nul 2>nul || (echo  [X] No encuentro Node.js. Instalalo desde https://nodejs.org y vuelve a abrir este archivo. & pause & exit /b 1)

rem --- Configuracion del servidor: si no hay backend\.env se crea a partir del ejemplo ---
if not exist "backend\.env" (
  copy "backend\.env.example" "backend\.env" >nul
  echo  [i] He creado backend\.env con los valores de ejemplo.
)

rem --- Dependencias (solo la primera vez o tras actualizar) ---
if not exist "backend\node_modules" (
  echo  [i] Instalando dependencias del servidor, espera...
  pushd backend & call npm install & popd
)
if not exist "frontend\node_modules" (
  echo  [i] Instalando dependencias de la app, espera...
  pushd frontend & call npm install & popd
)

rem --- Arranque: dos ventanas. NO las cierres mientras uses la app ---
start "SERVIDOR (backend) - no cerrar" /D "%~dp0backend" cmd /k npm start
timeout /t 5 /nobreak >nul
start "APP (frontend) - no cerrar" /D "%~dp0frontend" cmd /k npm run dev
timeout /t 5 /nobreak >nul
start "" http://localhost:5173

echo.
echo  Listo. Se han abierto dos ventanas negras: SERVIDOR y APP.
echo  Si la de SERVIDOR muestra un mensaje con *** es que algo falla (casi siempre PostgreSQL).
echo  Primer acceso: usuario  jefatura   contrasena  la de ADMIN_PASSWORD en backend\.env
echo.
pause
