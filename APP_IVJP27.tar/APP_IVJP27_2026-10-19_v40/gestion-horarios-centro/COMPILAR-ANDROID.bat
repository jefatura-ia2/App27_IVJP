@echo off
chcp 65001 >nul
setlocal
title Gestion de horarios - compilar app Android (APK)
cd /d "%~dp0"
echo.
echo  === App Android de Horarios IES Valle del Jerte ===
echo.
echo  Requisito: tener instalado Android Studio (https://developer.android.com/studio)
echo  y haberlo abierto una vez para que descargue el SDK de Android.
echo.

where node >nul 2>nul || (echo  [X] No encuentro Node.js. & pause & exit /b 1)

rem --- Java: se usa el que trae Android Studio si no hay otro configurado ---
if not defined JAVA_HOME (
  if exist "%ProgramFiles%\Android\Android Studio\jbr\bin\java.exe" set "JAVA_HOME=%ProgramFiles%\Android\Android Studio\jbr"
)
if not defined JAVA_HOME (echo  [X] No encuentro Java. Instala Android Studio en su carpeta por defecto. & pause & exit /b 1)

rem --- SDK de Android ---
if not defined ANDROID_HOME set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
if not exist "%ANDROID_HOME%\platforms" (echo  [X] No encuentro el SDK de Android en %ANDROID_HOME%. Abre Android Studio una vez y deja que lo instale. & pause & exit /b 1)
> "frontend\android\local.properties" echo sdk.dir=%ANDROID_HOME:\=\\%

rem --- Direccion del servidor (opcional: si se deja vacia, la app la pregunta al abrirse) ---
echo  Escribe la direccion del servidor del centro, por ejemplo  horarios.iesvalledeljerte.es
echo  (o pulsa Intro para que cada profesor/a la escriba la primera vez que abra la app)
set "SERVIDOR="
set /p "SERVIDOR=  Direccion: "
if defined SERVIDOR (
  echo %SERVIDOR% | findstr /b /i "http" >nul || set "SERVIDOR=https://%SERVIDOR%"
)
if defined SERVIDOR (set "VITE_API_URL=%SERVIDOR%/api") else (set "VITE_API_URL=")

pushd frontend
if not exist node_modules call npm install
echo.
echo  [1/3] Compilando la app...
call npm run build || goto fallo
echo  [2/3] Copiando la app al proyecto Android...
call npx cap sync android || goto fallo
echo  [3/3] Generando el APK (la primera vez tarda varios minutos)...
pushd android
call gradlew.bat assembleDebug || (popd & goto fallo)
popd
popd
copy /y "frontend\android\app\build\outputs\apk\debug\app-debug.apk" "Horarios-IVJ.apk" >nul
echo.
echo  ============================================================
echo   LISTO:  Horarios-IVJ.apk  (en la carpeta de la app)
echo   Copialo al movil e instalalo (Android pedira permitir
echo   "instalar apps de origen desconocido").
echo  ============================================================
echo.
explorer /select,"%~dp0Horarios-IVJ.apk"
pause
exit /b 0

:fallo
popd
echo.
echo  [X] Algo ha fallado. Haz una captura de esta ventana y enviala.
pause
exit /b 1
