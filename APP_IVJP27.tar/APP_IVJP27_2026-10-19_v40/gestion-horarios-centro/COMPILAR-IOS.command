#!/bin/bash
# App iOS de Horarios IES Valle del Jerte. Se ejecuta en un Mac con Xcode (doble clic en Finder).
cd "$(dirname "$0")"
echo; echo "=== App iOS de Horarios IES Valle del Jerte ==="; echo
command -v node >/dev/null || { echo "[X] Instala Node.js desde https://nodejs.org"; read -r; exit 1; }
command -v xcodebuild >/dev/null || { echo "[X] Instala Xcode desde la App Store y ábrelo una vez"; read -r; exit 1; }
command -v pod >/dev/null || { echo "Instalando CocoaPods (pide la contraseña del Mac)..."; sudo gem install cocoapods || { read -r; exit 1; }; }
echo "Dirección del servidor del centro (p. ej. horarios.iesvalledeljerte.es)."
read -r -p "Intro = que la app la pregunte al abrirse: " S
if [ -n "$S" ]; then [[ "$S" == http* ]] || S="https://$S"; export VITE_API_URL="${S%/}/api"; fi
cd frontend
[ -d node_modules ] || npm install
npm run build && npx cap sync ios && npx cap open ios || { echo "[X] Ha fallado: haz una captura"; read -r; exit 1; }
echo
echo "Se ha abierto Xcode. Para probarlo en tu iPhone: conéctalo por cable, elígelo arriba"
echo "y pulsa ▶. Para repartirlo al claustro: Product → Archive → TestFlight (cuenta Apple Developer)."
read -r -p "Pulsa Intro para cerrar"
