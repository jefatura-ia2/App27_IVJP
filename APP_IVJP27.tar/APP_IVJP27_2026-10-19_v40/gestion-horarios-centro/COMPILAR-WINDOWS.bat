@echo off
chcp 65001 >nul
title Gestion de horarios - compilar y arrancar
cd /d "%~dp0"

echo.
echo  === Compilar la version final de la app ===
echo.
where node >nul 2>nul || (echo  [X] No encuentro Node.js. Instalalo desde https://nodejs.org & pause & exit /b 1)

if not exist "backend\.env" if exist "backend\.env.example" copy "backend\.env.example" "backend\.env" >nul
if not exist "backend\node_modules"  (pushd backend  & call npm install & popd)
if not exist "frontend\node_modules" (pushd frontend & call npm install & popd)

echo  [1/2] Compilando la app (tarda un minuto)...
pushd frontend
call npm run build
if errorlevel 1 (popd & echo. & echo  [X] La compilacion ha fallado. Manda una captura de esta ventana. & pause & exit /b 1)
popd
echo.
echo  [2/2] Compilada en frontend\dist. Arrancando el servidor...
echo.
echo  Abre en este ordenador:   http://localhost:3000
echo  Desde otros equipos de la red:  http://IP-DE-ESTE-ORDENADOR:3000
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4"') do echo     IP de este ordenador:%%a
echo.
echo  NO cierres esta ventana mientras se use la app.
echo.
start "" http://localhost:3000
cd backend
call npm start
pause
