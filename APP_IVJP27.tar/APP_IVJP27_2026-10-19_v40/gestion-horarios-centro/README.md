# Gestión de horarios del centro · IES Valle del Jerte

Horarios del profesorado, consultas de grupos y aulas, y guardias en tiempo real.
Curso 2026-27 · Jefatura de Estudios.

```
gestion-horarios-centro/
├── backend/                     API Node.js + PostgreSQL
│   ├── src/
│   │   ├── ingestors/           csvHorarios.js (CSV del horario)
│   │   ├── controllers/         horarios · aulas · guardias · sync · programaciones
│   │   ├── models/              Tramo · Profesor · Grupo · Aula · Clase · Ausencia · Departamento · Documento
│   │   └── services/            horarioService (consultas, buscador, aulas libres) · guardiasService · tiempo · programacionesService
│   ├── cron/                    Tareas programadas de sincronización (node-cron)
│   ├── scripts/                 migrate · ingest-csv · sync-ausencias
│   ├── data/                    datos_horarios_2026-27.csv
│   ├── uploads/                 PDF de las programaciones subidas (se crea solo; no se versiona)
│   └── test/                    pruebas unitarias y de integración (node --test)
├── frontend/                    React + Vite + Tailwind, instalable (PWA) y empaquetable (Capacitor)
│   ├── public/                  cronologia.html (Cronograma + Programaciones) · datos_horarios.csv (respaldo sin conexión)
│   │                            manifest.json · sw.js · icons/
│   ├── src/
│   │   ├── original/            AppOriginal.jsx + original.css: la interfaz de APP_IVJP_27.html, idéntica
│   │   ├── components/          AgendaDiaria · MatrizSemanal · BuscadorGlobal · EstadoGuardias (+ VistaHorario, Icono)
│   │   └── views/               MiHorario · Consultas · Guardias (vistas sobre la API, no enlazadas en la portada)
│   └── capacitor.config.json
├── docs/                        arquitectura.html (diagrama interactivo) · arquitectura.archify.json (su fuente)
├── deploy/                      instalar.sh · actualizar.sh · copias · HTTPS · systemd · nginx · Docker · GUIA-DESPLIEGUE.md
└── docker-compose.yml           PostgreSQL para pruebas en tu ordenador (opcional)
```

## Arquitectura

Diagrama interactivo en **[docs/arquitectura.html](docs/arquitectura.html)** (ábrelo en el navegador).

## Instalación en el servidor del centro

Guía completa (recursos, pasos, HTTPS, copias y actualizaciones) en **[deploy/GUIA-DESPLIEGUE.md](deploy/GUIA-DESPLIEGUE.md)**.
Resumen en Ubuntu/Debian: `sudo DOMINIO=ip-o-nombre bash deploy/instalar.sh`.


> **Servidor Linux con Apache (sin Docker):** `sudo bash deploy/instalar-apache.sh` deja la app en `http://servidor/horarios/` sin tocar las otras webs del Apache. Ver `deploy/GUIA-APACHE.md`.

> **Apps de móvil:** `COMPILAR-ANDROID.bat` (Windows con Android Studio) genera `Horarios-IVJ.apk`; `COMPILAR-IOS.command` (Mac con Xcode) abre el proyecto de iPhone. Todo explicado en `deploy/GUIA-APPS-MOVIL.md`.

> **Versión final (compilada) en Windows:** doble clic en `COMPILAR-WINDOWS.bat`. Compila la app en `frontend/dist` y arranca un único servidor: se abre en `http://localhost:3000` y, desde otros equipos de la red del centro, en `http://IP-del-ordenador:3000`. Tras cualquier cambio en el frontend hay que volver a compilar.

> **En Windows, lo más fácil:** doble clic en `ARRANCAR-WINDOWS.bat`. Instala lo necesario la primera vez, crea `backend/.env` si falta y abre dos ventanas (SERVIDOR y APP) más el navegador. Si al entrar ves «Error 500» o «No hay conexión con el servidor», mira la ventana SERVIDOR: estará cerrada o mostrará un mensaje con `***` que dice qué falla (casi siempre PostgreSQL parado o la contraseña de `DATABASE_URL`).

## Puesta en marcha (pruebas en tu ordenador)

Necesitas Node.js 20 o superior y PostgreSQL 14 o superior.

```bash
# 1. Base de datos (si no tienes PostgreSQL, con Docker):
docker compose up -d db

# 2. Backend
cd backend
cp .env.example .env          # revisa DATABASE_URL, SHEETS_SERVICE_URL, ADMIN_TOKEN y ADMIN_PASSWORD
npm install
npm run migrate               # crea las tablas
npm run ingest:csv            # carga el horario desde data/datos_horarios_2026-27.csv
npm start                     # API en http://localhost:3000/api
npm run cron                  # (otra terminal o servicio) sincronización automática

# 3. Frontend
cd ../frontend
npm install
npm run dev                   # http://localhost:5173 (redirige /api al backend)
npm run build                 # versión de producción en dist/
```

## Flujo de datos

1. **Horario** → `ingestors/csvHorarios.js` sustituye en una transacción todo el horario semanal
   (si el CSV falla, no se toca nada). Tarea programada: cada mañana laborable a las 6:30.
2. **Ausencias, avisos y calendarios** → viven en la base de datos de la app (tablas `ausencia`, `aviso` y el
   ajuste `calendarios`); `services/servicioService.js` los sirve en `/api/servicio` con la misma interfaz que tenía
   el antiguo servicio de la hoja de Google. Ya no se usa la hoja «Ausencias 2026-27»: la primera vez que arranca,
   el servidor copia lo que había en ella (`services/importacionInicial.js`).
3. **Guardias** → `services/guardiasService.js` cruza el horario del día con las ausencias:
   profesorado de guardia disponible, de guardia pero ausente, y grupos sin profesor con su tarea.

## Interfaz

La app que ven profesorado y Jefatura es **la misma que APP_IVJP_27.html**: portada «¿Qué necesitas consultar?»
con los 10 mosaicos (Profesores, Grupos, Aulas, Guardias de aula, Guardias de recreo, Biblioteca, Calendarios,
Notificar ausencia, Avisos importantes, Cronología), misma cabecera con el candado de administración, mismo
botón de volver y mismos iconos y colores. El código está en `frontend/src/original/` sin cambios de diseño.

Lo que cambia por dentro:

- **Horario**: ya no va incrustado en el HTML; al abrir la app se descarga de `GET /api/horario.csv`
  (lo que cargó `npm run ingest:csv`). Sin conexión usa la última copia guardada o `public/datos_horarios.csv`.
- **Avisos, calendarios, notificar ausencia, guardias y biblioteca** siguen usando los servicios de Google Apps
  Script, exactamente como antes (la contraseña de administración se comprueba allí).
- **Cronología** se sirve como `public/cronologia.html` dentro de la sección, y su pestaña **Programaciones**
  guarda ahora en este backend (ver abajo).

## Acceso con usuario y contraseña

Para entrar en la app hace falta **usuario y contraseña**. Sin sesión no se ve nada y la API responde 401
(lo único público es `/api/salud` y el inicio de sesión).

- **Primera vez**: existe la cuenta `jefatura` (administración) con la contraseña de `ADMIN_PASSWORD`;
  al entrar pide elegir una propia.
- **Mosaico «Usuarios»** (solo lo ven las cuentas de administración): «Crear cuentas del profesorado» crea
  de una vez una cuenta por cada profesor/a del horario (usuario = inicial del nombre + primer apellido,
  p. ej. `mamor`) con contraseña provisional, y deja imprimir o descargar las credenciales. También: nueva
  cuenta suelta, restablecer contraseña, activar/desactivar, dar o quitar administración y borrar.
- Con contraseña provisional solo se puede cambiar la contraseña (mín. 8 caracteres, letras y números).
- La sesión dura 30 días desde el último uso (cookie `HttpOnly`, `Secure` con HTTPS). Desactivar una cuenta
  o restablecer su contraseña cierra sus sesiones. 5 intentos fallidos bloquean 15 min ese usuario en ese equipo.
- «Mi cuenta» (botón con el nombre, arriba): cambiar la contraseña y cerrar sesión (borra también lo guardado
  en el dispositivo).
- El candado sigue siendo aparte: activa el modo administración de horarios, ausencias, avisos, etc.
- Contraseñas guardadas con scrypt y sal; nunca se pueden consultar, solo restablecer.

## Notificar ausencias: cada profesor/a solo las suyas

- La pantalla «Notificar ausencia» muestra fijo el nombre del profesor/a de la cuenta: no se puede elegir otro.
  La cuenta se vincula al horario por su **nombre** (Apellidos, Nombre); las creadas con «Crear cuentas del
  profesorado» ya coinciden. En «Usuarios», las cuentas sin vincular aparecen marcadas y se corrigen con «Nombre».
- Las **cuentas de administración** y quien tenga activo el **candado** pueden notificar la de cualquier profesor/a.
- La regla se comprueba en el servidor: la app envía la ausencia a `POST /api/ausencias/notificar`, que decide el
  profesor/a y la guarda en la base de datos como **Pendiente**. Jefatura la graba (o la corrige o elimina) en
  Guardias de aula con el modo administrador; solo las grabadas aparecen en las guardias y cuentan en los informes.

## Informes mensuales de ausencias (PDF)

En **Ausencias → Informes y dossier** (pestaña visible solo con el modo administrador de una cuenta de Jefatura):
se elige el mes, se ve el resumen y se descarga el PDF (`POST /api/ausencias/informe`, generado en el servidor con
PDFKit). Incluye cifras del mes, resumen por profesor/a (días lectivos, días completos, sesiones de clase y guardias
afectadas según el horario), ausencias por motivo (opcional) y el detalle de cada ausencia. Cuenta solo las grabadas;
las pendientes aparecen en el detalle. Los días lectivos son de lunes a viernes (no descuenta festivos).

## Justificación de ausencias (módulo Ausencias)

El mosaico **Ausencias** tiene dos pestañas: **Notificar ausencia** (como antes: queda pendiente hasta que Jefatura la
graba y entonces aparece en Guardias de aula) y **Justificar ausencia**:

1. El docente elige sus ausencias sin justificar (las que notificó y las que registró Jefatura).
2. Se despliega su cuadrante semanal con las horas ya marcadas; puede marcar o desmarcar. La app computa las horas
   **lectivas** (docencia y tutoría con alumnado) y **complementarias** (resto del horario) de cada día; se pueden corregir.
3. Elige el motivo en un desplegable con los artículos de la **Orden de 29 de agosto de 2024 (DOE n.º 169, de
   30/08/2024)** (`backend/src/services/articulosPermisos.js`).
4. Sube los justificantes, **solo en PDF** (se comprueba la cabecera `%PDF-`; hasta 10 por justificación).

Los PDF se guardan en `JUSTIFICANTES_DIR` (por defecto, junto a los de programaciones: `/var/lib/gestion-horarios/uploads/justificantes`).
**Alerta:** del día 1 al 5 de cada mes, quien tenga ausencias de meses anteriores sin justificar ve un aviso al entrar
(una vez al día) y una franja en el inicio; pasado el día 5 el aviso indica que el plazo ha vencido.
**Jefatura** (Ausencias → Informes y dossier, modo administrador) descarga el **dossier del mes**: informe, hoja de
cada justificación y todos sus PDF en un único documento numerado (`POST /api/ausencias/dossier`).

## Cambiar el horario desde la app

Con el candado de administración (la misma contraseña de siempre) la pantalla **Profesores** pasa a
**modo edición**:

- Toca cualquier casilla del horario de un profesor/a para cambiar día, hora, tipo (Docencia, Guardia de Aula,
  Guardia de Recreo, Biblioteca…), materia, grupos o aula, o para quitarla (papelera).
- El botón «+» de cada hueco añade una sesión nueva; «Nuevo profesor/a» empieza un horario desde cero.
- «Descargar horario (Excel/CSV)» baja el horario completo; lo puedes editar en Excel y volver a cargarlo con
  «Subir horario completo (CSV)» (sustituye todo el horario, pide confirmación).

Cada cambio se guarda al momento en la base de datos y se ve enseguida en Grupos, Aulas y Guardias, en todos
los dispositivos que abran la app. Además se reescribe `backend/data/datos_horarios_2026-27.csv`, así que la
recarga automática de cada mañana (cron) no deshace nada. Todos los cambios quedan anotados en la tabla
`sincronizacion` (origen `edicion-app` o `importacion-app`).

Importante: la contraseña que comprueba el servidor es `ADMIN_PASSWORD` del `.env`; debe coincidir con la del
candado (la del servicio de Google, `rafael2025`).

## Guardia de recreo en biblioteca

En **Guardias de recreo**, con el candado de administración, eliges el día y tocas el nombre del profesor/a
que hace esa guardia de recreo en la biblioteca: queda marcado en marrón con el icono del libro (vuelve a
tocarlo para quitarlo). Es una asignación semanal fija (se repite cada semana ese día y recreo) y se guarda en
el servidor (tabla `guardia_biblioteca`).

En **Biblioteca** aparece en la fila del 1º o 2º recreo como «Recreo · Guardia de recreo en biblioteca»,
cuenta en las pestañas de los días, sale en el aviso «Ahora en la biblioteca» durante el recreo y se incluye
en las hojas de firmas. Se cambia solo desde Guardias de recreo.

## Pantalla de la sala de profesores

En *Guardias → Pantalla sala de profesores* (modo administrador de una cuenta de Jefatura) está el enlace
secreto `…/?panel=<código>` para el ordenador de la TV: no pide sesión, no caduca y se refresca cada minuto
(la página se recarga sola al cambiar de día). Muestra el parte de guardias del turno con el tramo en curso
destacado (los tramos terminados se ocultan si no cabe todo), grupos sin profesor con aula y tarea, ausentes
de hoy y del siguiente día lectivo (sin motivos), avisos vigentes en rotación, próximas actividades de la
Cronología (30 días) y hasta 3 enlaces con código QR. «Crear enlace nuevo» invalida el anterior.
API: `GET /api/panel/datos?t=…` (pública con el código), `GET|PUT /api/panel/config` (administración).

Actividades extraescolares en la pantalla: el servidor lee el calendario de Google «Actividades extraescolares»
(el enlazado en *Calendarios*) en su versión pública `.ics`, cada 10 minutos. Las de hoy salen en un recuadro
propio («Extraescolares hoy», con hora y lugar) y las de los próximos 30 días se mezclan con las de la Cronología
en «Próximas actividades», marcadas como «Extraescolar». El calendario debe ser público en Google Calendar
(Configuración → Permisos de acceso → «Hacer disponible públicamente») y el servidor debe poder salir a
`calendar.google.com`.

## Biblioteca (G.B. y MAY55) en el servidor del centro

Los registros de Atención a Biblioteca y Mayores de 55 están en la base de datos (tabla `biblioteca_registro`);
ya no se usa la hoja de Google «Registros G.B. y MAY55». La primera vez que arranca, el servidor copia lo que
hubiera en esa hoja (si no responde, carga la copia del horario y lo reintenta en cada arranque hasta que alguien
edite desde la app). Botón «Traer de la hoja anterior» para repetirlo a mano.

- **Perfil Biblioteca**: Jefatura lo asigna en *Usuarios* con el botón «Biblioteca» de cada cuenta.
- **Clave de la biblioteca**: Jefatura la fija en *Usuarios → Perfil Biblioteca* (mín. 8 caracteres, letras y números).
- Para editar, la cuenta con el perfil pulsa «Gestionar» en Biblioteca y escribe esa clave. Las cuentas de
  administración también pueden, con esa clave o con la contraseña de administración.
- El resto del claustro solo consulta. Sin conexión se ve la última copia guardada en el navegador (solo lectura).

## Cronograma de la Cronología en el servidor

Las evaluaciones, reuniones y entregas de notas que Jefatura edita en la Cronología (modo administrador) se graban
solas en el servidor (`GET|PUT /api/cronologia`, ajuste `cronologia_eventos`) al segundo y medio de cada cambio;
el botón «Guardar en el servidor» fuerza el guardado. Todo el claustro y la pantalla de la sala de profesores ven
esa versión. Ya no hace falta descargar el HTML y publicarlo. La primera vez que Jefatura entra, si el servidor aún
no tiene cronograma, se sube el que tenga su navegador. Solo graba una cuenta de administración o quien entre con
la contraseña de administración.

## Información para las familias en las reuniones de la Cronología

Cada reunión de la Cronología tiene el bloque «Información para las familias»: «Ver aquí», «Abrir en pestaña
nueva» e «⬇ Imagen para redes». La publicación para redes (botón de la imagen, descarga y texto) solo la ven Jefatura
y las cuentas de administración (modo administración de la Cronología o sesión de la app con rol admin); las
familias ven el cartel, el plano y la tabla. Lo genera `frontend/public/reunion-familias.html?ev=<id>` con los datos que
Jefatura graba en la reunión (título, fecha, y en cada grupo hora, aula y tutor/a): cartel, aula de cada grupo
sobre el plano, tabla y texto para publicar. La imagen (PNG 1080 × 1350, 4:5 para Instagram/Facebook) se dibuja en
el navegador al pulsar el botón; `&descargar=1` la descarga directamente. La página es pública (la lee
`GET /api/cronologia/reunion/:id`, sin sesión, solo con los datos de esa reunión), así que su enlace se puede poner
en la publicación. Si el aula del grupo lleva un número de 3 cifras («Aula 101»), se marca en el plano. Sin grupos,
la página muestra solo el cartel y el texto. Para usar una página propia, pon su nombre .html en el enlace de la
reunión.

## Datos del profesorado al entrar

Al entrar con su usuario, a cada docente (cuentas de profesorado) que no los tenga se le piden su cuenta de correo
de Educarex (…@educarex.es), su teléfono móvil de contacto y sus años trabajados, con la nota «El dato de años
trabajados es imprescindible para el cálculo de los DAP de cada profesor». No puede seguir sin completarlos
(`PUT /api/auth/mis-datos`; columnas `email`, `movil`, `anios_servicio`, `datos_fecha` de `usuario`). Los corrige
cuando quiera en «Mi cuenta». Jefatura los ve en Usuarios.

## Pantalla de entrada: grupos y formas de los mosaicos

Los mosaicos se agrupan y cada grupo tiene su forma (campo `forma` de `TILES`): «Horarios y espacios» en
hexágonos (Profesores, Grupos, Aulas, Biblioteca y, en administración, Usuarios); «El día a día» en cuadrados
redondeados (Guardias, Ausencias, Calendarios); «El centro» en círculos (Cronología, Reunión con familias) con
Avisos importantes en un triángulo redondeado en medio. «Reunión con familias» solo la ve el profesorado tutor desde
14 días antes de una reunión con familias de la Cronología hasta su último día (con las del 20 y 21 de octubre,
desaparece el 22); la administración la ve siempre.

## Cuadrante del día en Guardias y en Biblioteca

En Biblioteca no aparece el parte de guardias de aula: se ve el «Cuadrante de la biblioteca de hoy» con la misma
estructura (cabecera con reloj, tramo en curso destacado, «Ahora»/«Siguiente»): por tramo, Atención a biblioteca (G.B.)
y Mayores de 55 (MAY55) con su departamento, y en los recreos la guardia de recreo en biblioteca; a la derecha, quién
está ahora en la biblioteca y quién con turno hoy está ausente (`?panel=biblioteca`, `GET /api/panel/biblioteca-hoy`,
con sesión). En Guardias → Guardias de recreo se ve el «Cuadrante de guardias de recreo de hoy», con la misma
estructura: cada recreo con quién está de guardia en el patio y quién en la biblioteca, el recreo en curso o el
siguiente destacado y, a la derecha, quién está ahora de guardia y quién de guardia de recreo está ausente
(`?panel=recreo`). En Guardias de aula, el profesorado ve arriba el «Cuadrante de guardias de hoy»: la misma
pantalla que se proyecta en la sala de profesores, a escala, actualizada cada minuto. «Pantalla completa» la abre
en otra pestaña; «Ocultar» la pliega (se recuerda en ese navegador). Se abre como `?panel=sesion` y lee
`GET /api/panel/hoy`, que exige sesión en la app (no usa el enlace secreto de la TV).

## Departamento en la cabecera del horario

La cabecera del horario de cada docente muestra su departamento con un icono y color propios (lo ve todo el
claustro). Como el horario no trae el departamento, se decide así (`services/departamentoProfesor.js`): lo fijado
por Jefatura a mano (ajuste `profesor_departamento`); si es jefe/a de un departamento, ese; si no, el departamento
con más horas de clase según sus materias. Con una cuenta de administración aparece «Cambiar» / «Asignar» junto al
departamento para corregirlo (la opción «Automático» vuelve a deducirlo de las materias).

## Ficha del docente y contador de DAP

En Profesores, la cabecera del horario de cada docente muestra su correo, móvil, años trabajados y el contador de
días de asuntos propios (DAP) del curso, pero solo al propio docente y a la administración (`GET /api/dap/ficha`;
el servidor no la da a nadie más). Días retribuidos según los años trabajados: menos de 18 → 4; de 18 a 22 → 5;
23 o más → 6 (los años declarados más los años completos pasados desde que los declaró). Usados: días de lunes a
viernes de las ausencias grabadas con motivo «Asuntos propios (DAP)» del curso (1 sep – 31 ago), vengan del
calendario DAP o grabadas a mano; se indican también los ya solicitados para fechas futuras
(`services/contadorDap.js`). En Usuarios, Jefatura ve «DAP usados/derecho · quedan N» de cada cuenta.

## Calendario de asuntos propios (DAP) → ausencias

El servidor lee el calendario de Google «Asuntos propios (DAP)» enlazado en Calendarios (tiene que estar en «Hacer
disponible públicamente») al arrancar y cada 15 minutos, y graba cada evento como ausencia confirmada con motivo
«Asuntos propios (DAP)» (`services/dapService.js`, ids `dap-…`, registrada por «calendario DAP»). Evento de día
completo → todo el día; con hora → solo los tramos que abarca; varios días → ausencia con «hasta». Si el evento
cambia o se borra del calendario, la ausencia se actualiza o se quita (la tarea y el aula anotadas se conservan).
El profesor/a se reconoce por el nombre del título (nombre + apellido, dos apellidos o un apellido único). Los
títulos que no se reconocen aparecen en Ausencias → «Confirmar y registrar (Jefatura)» → tarjeta «Calendario de
asuntos propios (DAP)», donde Jefatura elige de quién son (se recuerda en el ajuste `dap_alias`) o los ignora.
Si Jefatura ya grabó a mano esa ausencia, no se duplica. Botón «Sincronizar ahora» para no esperar.

Las ausencias por asuntos propios (motivo «Asuntos propios (DAP)», vengan del calendario o grabadas a mano) no
necesitan justificante (`services/motivos.js`): no aparecen en «Justificar ausencia» ni en el aviso del 1 al 5, y en
el informe mensual cuentan como justificadas («Justificada (DAP)» en el detalle y «Asuntos propios (DAP)
(justificada)» en el resumen por motivo).

## Registro de ausencias por semana (Guardias · administración)

En Guardias de aula, con el modo administración, «Registrar ausencia» abre la rejilla semanal del profesor/a:
se elige el docente y una fecha cualquiera de la semana y aparece su horario de lunes a viernes (verde: hora
lectiva; ámbar: guardia u otra complementaria). En cada hora se marca la ausencia y se anotan el aula donde se
queda el grupo, las observaciones (tarea para la guardia) y el tipo. En la cabecera de cada día, «Día completo»
marca todas sus horas y «Tipo» se aplica a toda la columna. «Guardar semana» graba la semana de una vez (una
ausencia por día y tipo; el aula y la tarea de cada hora van en `ausencia.detalle`) y quita lo que se haya
desmarcado. El lápiz de una ausencia de un día abre la rejilla; las de varios días se siguen editando con el
formulario («Ausencia de varios días…»). Guardias de aula y la pantalla de la sala usan el aula y la tarea
anotadas en cada hora.

## Programaciones didácticas

Cronología → pestaña **Programaciones**, con la misma pantalla de siempre. Los 19 departamentos y sus
contraseñas se siembran solos con `npm run migrate` la primera vez (si luego editas o borras alguno, no se tocan).

- **Jefe/a de departamento**: botón «Acceso jefe/a» junto a su nombre → contraseña del departamento
  (p. ej. `ING2627`). Sube uno o varios PDF, los quita, edita observaciones, cambia su contraseña o elimina la entrega.
- **Administrador/a**: botón «Admin» de la Cronología (usuario `VJerte2026`, contraseña `rafael2025`).
  El backend comprueba esa misma contraseña con `ADMIN_PASSWORD`; si la cambias en `.env`, cámbiala también
  en `ADMIN_CRED` de `public/cronologia.html`. Puede crear departamentos, marcar estados y eliminar entregas.
- Los PDF se guardan en `backend/uploads/programaciones/<id>/` (no en Drive). `MAX_PDF_MB` limita el tamaño y
  `FECHA_LIMITE_PROG` marca «Fuera de plazo». Haz copia de esa carpeta junto con la base de datos.

## API

| Método | Ruta | Descripción |
|---|---|---|
| POST | `/api/auth/login` | Iniciar sesión (`{usuario, clave}`) → cookie de sesión |
| GET | `/api/auth/yo` · POST `/api/auth/logout` · POST `/api/auth/cambiar-clave` | Sesión actual · salir · cambiar contraseña (`{actual, nueva}`) |
| GET/POST | `/api/usuarios` · `/api/usuarios/lote` | Cuentas (solo administración): listar, crear una, crear las del profesorado |
| PUT/DELETE | `/api/usuarios/:id` · POST `/api/usuarios/:id/restablecer` | Cambiar rol/activo, borrar, contraseña provisional nueva |
| GET | `/api/tramos` | Tramos horarios del centro |
| GET | `/api/buscar?q=texto` | Buscador global (profesorado, grupos, aulas), sin tildes |
| GET | `/api/horarios/:tipo/:id` | Horario semanal de un `profesor`, `grupo` o `aula` |
| GET | `/api/aulas/libres?dia=1-5&tramo=3` | Aulas sin clase en ese tramo |
| GET | `/api/aulas/:id/ocupacion?dia=1-5` | Ocupación de un aula en un día |
| GET | `/api/guardias/ahora` | Guardias del tramo en curso y del siguiente |
| GET | `/api/guardias?fecha=AAAA-MM-DD` | Guardias de todos los tramos de un día |
| GET | `/api/sync/estado` | Última sincronización de cada origen |
| POST | `/api/sync` | Sincronizar ya (`{"origen":"ausencias"|"horarios"|"todo"}`, cabecera `X-Admin-Token`) |
| GET | `/api/programaciones` | Todos los departamentos con su estado, observaciones y documentos |
| POST | `/api/programaciones` | Crear departamento (`{nombre,jefe,claveDep,clave}`, `clave` = admin) |
| POST | `/api/programaciones/login-admin` | Comprobar contraseña de administrador/a (`{clave}`) |
| POST | `/api/programaciones/:id/login` | Comprobar contraseña del departamento (`{clave}`) |
| POST | `/api/programaciones/:id/documentos` | Subir un PDF (multipart: `archivo`, `clave`) |
| GET | `/api/programaciones/:id/documentos/:docId/archivo` | Ver/descargar un PDF |
| DELETE | `/api/programaciones/:id/documentos/:docId` | Quitar un documento (`{clave}`) |
| PUT | `/api/programaciones/:id/observaciones` | Guardar observaciones (`{obs,clave}`) |
| PUT | `/api/programaciones/:id/jefe` | Cambiar el nombre del jefe/a (`{jefe,clave}`) |
| PUT | `/api/programaciones/:id/clave` | Cambiar la contraseña del departamento (`{claveDep,clave}`) |
| PUT | `/api/programaciones/:id/estado` | Marcar entregado/pendiente a mano (`{estado,clave}`, solo admin) |
| POST | `/api/programaciones/:id/anular` | Eliminar la entrega completa (`{clave}`) |
| GET | `/api/horario.csv` | Horario completo en formato CSV (lo usa la interfaz) |
| POST | `/api/sesiones/cambiar` | Añadir/cambiar/quitar una sesión (`{clave, antes, despues}`, solo admin) |
| GET | `/api/biblioteca/recreos` | Guardias de recreo que se hacen en la biblioteca |
| POST | `/api/biblioteca/recreos` | Marcar/desmarcar (`{clave, dia, tramo, profesor, marcado}`, solo admin) |
| POST | `/api/ausencias/notificar` | Notificar una ausencia (`{ausencia, clave?}`): la propia, o cualquiera para administración/candado |
| POST | `/api/horario/importar` | Sustituir el horario completo por un CSV (`{clave, csv}`, solo admin) |

## App móvil

- **PWA**: al abrir la web en el móvil, «Añadir a pantalla de inicio». Funciona sin conexión con los últimos datos.
- **Android / iOS** (Capacitor): en `frontend/`, crea `.env.production` con `VITE_API_URL=https://tu-servidor/api`
  y ejecuta `npx cap add android` (o `ios`) la primera vez; después `npm run cap:android` / `npm run cap:ios`.


## Actualizar el horario con un CSV

La app no lee `backend/data/*.csv` en cada momento: el horario vive en la base de datos y el CSV se *carga* en ella.

- **Desde la app (recomendado):** icono **Actualizar horario** de la barra superior (flecha hacia arriba; solo cuentas de administración): eliges el CSV, ves un resumen de cambios (sesiones, profesores nuevos y que desaparecen, filas erróneas) y confirmas. Antes de cada carga se guarda una copia en `backend/data/copias/` y desde la misma pantalla se puede volver a cualquiera.
- **Desde el fichero:** edita `backend/data/datos_horarios_2026-27.csv` y, en la carpeta `backend`, ejecuta `npm run ingest:csv`. En el servidor también se recarga solo de lunes a viernes a las 6:30.

Columnas: `Profesor ("Apellidos, Nombre"), día (1-5), hora (1-13, R1, R2), materia, grupo, aula, tipo`. Se admite coma o punto y coma (Excel en español). La carga sustituye el horario completo; si el fichero está mal formado, se rechaza y no cambia nada.

## Reunión con familias (tutores/as)

Mosaico **Reunión con familias**: solo lo ven los tutores/as de grupo y las cuentas de administración. Abre el generador de presentaciones (`frontend/public/presentacion.html`) con los datos del grupo ya puestos: nombre del grupo, tutor/a, horario del grupo (como imagen), materias con su profesorado, hora de tutoría semanal, hora de atención a familias y la fecha y hora de la reunión.

- **Jefatura** (botón *Fecha y tutores*): fija el día, la hora y el lugar de la reunión, y asigna o cambia el tutor/a de cada grupo. El listado se cargó del PDF de tutores (tabla `tutoria`, versión `2027-1` en `models/Tutoria.js`; al subir de versión se vuelve a aplicar conservando los delegados).
- El tutor/a escribe el **delegado/a y subdelegado/a** de su grupo (se guardan en el servidor, Jefatura los ve en *Fecha y tutores* y salen en la diapositiva «El grupo»).
- Cada tutor/a solo accede a la presentación de **su** grupo (el servidor rechaza los demás). Puede **personalizar los colores** (temas o color a color; el logo del centro, con fondo transparente, se mantiene). El generador se ve siempre en modo claro.
- El tutor/a completa el resto (correo, nº de alumnos, desdobles…) y descarga el PowerPoint. Lo que escribe se guarda en su navegador, por grupo.

## Reserva de espacios (dentro de Aulas)

En **Aulas** hay dos pestañas: *Horario de las aulas* (como siempre) y **Reserva de espacios**.

- Espacios iniciales: Biblioteca, SUM, 106 (Infolab II), 118 (Infolab I), A100 (Armario de portátiles) y JJEE (tablas `espacio`, `bloqueo_espacio`, `reserva`).
- **Profesorado** (con su usuario): elige espacio, día de inicio y fin (misma semana, de hoy en adelante), docente y materia, y marca los periodos libres en el cuadrante. Lo reservado se ve en la casilla para todos. Cada uno anula solo sus reservas (un periodo o la reserva completa).
- **Jefatura** (cuenta de administración), con *Gestionar espacios*: añadir, renombrar o retirar espacios; **marcar periodos fijos** (nunca reservables); *Fijar las clases del horario* si el espacio tiene aula asociada (106, 118); reservar **varias semanas** (el patrón se repite cada semana hasta el día de fin) y anular cualquier reserva.

## Reuniones de Meet en las evaluaciones (Cronología)

Cada tarjeta de **evaluación** de la Cronología tiene el botón **Unirse a la reunión de Meet**. Mientras no haya enlace, muestra «Enlace de Meet pendiente de publicar».
Jefatura lo pone desde el modo administrador de la Cronología (*Añadir el enlace de Meet* en la tarjeta) o con una cuenta de administración. El enlace se guarda en el servidor (ajuste `meet_eventos`), así que lo ve todo el profesorado al momento; debe empezar por `https://`.

## Zonas de vigilancia del recreo (Guardias → Guardias de recreo)

Cada recreo tiene 4 coberturas: **Zona 1** (amarillo), **Zona 2** (verde aguamarina), **Zona 3** (rojo) y **Biblioteca** (marrón).
- Cada profesor/a de guardia de recreo toca **su nombre** y elige la zona (o «Quitar zona»). Solo puede cambiar la suya.
- Jefatura/administradores pueden asignar la zona de cualquiera.
- Bajo cada recreo se ve qué zonas están cubiertas y cuáles quedan «sin cubrir». La asignación se repite cada semana ese día.
- Tareas: Zona 1 puerta de acceso y entrada principal; Zona 2 porche interior y aledaños (prohibido a los alumnos la zona de los pinos tras los contenedores); Zona 3 acceso a las pistas y actividades; Biblioteca atención a la biblioteca. Se ven en la tarjeta del mapa, en el selector y en el cuadrante.
- El mapa (`frontend/public/zonas-recreo.jpg`) se muestra en la pantalla y se puede ocultar.
- La pantalla de la sala de profesores cambia sola al cuadrante de recreo durante cada recreo y vuelve al parte de guardias al terminar. El cuadrante de recreo incluye el mapa de zonas con el nombre de quien vigila cada una (en rojo parpadeante si está sin cubrir).
- El cuadrante (`?panel=recreo`) muestra una columna por zona; Biblioteca solo cuenta a quien eligió la zona Biblioteca.
- API: `POST /api/recreo/zona {dia, tramo, profesor, zona}` (zona vacía = quitar). Columna `guardia_biblioteca.zona`.

## Disciplina (partes de conductas contrarias · Decreto 50/2007)

Mosaico **Disciplina** («El día a día»). Pestañas:
- **Nuevo parte**: el profesor/a rellena el impreso del centro (alumno/a, grupo, curso, materia, día y hora, conductas
  contrarias del art. 37 y gravemente perjudiciales del art. 40, aclaraciones). Al registrarlo recibe un **código de
  registro interno** (`DIS-2627-0001`…) y descarga **su ejemplar en PDF**.
- **Mis partes**: sus partes con el estado (pendiente / recibido).
- **Partes recibidos (Jefatura)**: solo para los Jefes/as de Estudios adjuntos (y la cuenta de Jefatura, que ve todos).
  Botón **✓ Recibido (OK)**; al pulsarlo, el profesor/a ve el «Recibido» en la cabecera de su horario (Profesores → su nombre).

Reparto por grupo (`backend/src/services/disciplinaService.js`, constante `ETAPAS`):
ESO y PDC → Delia Esther Páramo Vicente · Bachillerato → Fernando Calderón de Arriba ·
FP con todas sus clases por la mañana → Francisco Javier Rufo Mendo · resto de FP (tarde y a distancia) → Fátima Hontiveros Almaraz.

El **ejemplar de Jefatura** se guarda en la carpeta `disciplina` (junto a `uploads/programaciones`; en el servidor
`/var/lib/gestion-horarios/uploads/disciplina`), con una subcarpeta por Jefe/a adjunto. Se puede cambiar con `DISCIPLINA_DIR`.
Al marcar «Recibido» el PDF se vuelve a guardar con el sello verde de recibido.
**Tutor/a del grupo**: cada parte se notifica también al tutor/a (tabla de tutorías, «Reunión con familias → Tutores»).
Lo ve en un aviso de la entrada, en la cabecera de su horario y en la pestaña **Partes de mi tutoría**, con su ejemplar en
PDF («Ejemplar para el tutor/a») y el botón **✓ Leído**. Si el parte lo pone el propio tutor/a, no se le avisa.
Pestaña **Carpeta de partes** (solo Jefes/as adjuntos y Jefatura): cada Jefe/a adjunto ve y descarga los PDF de **su**
subcarpeta; la cuenta de Jefatura ve las cuatro. Buscador por alumno/a, grupo o código.

## Ausencias que no necesitan justificación

`backend/src/services/motivos.js`: **Asuntos propios (DAP)** y **Actividad complementaria / Actividad extraescolar**.
No aparecen en «Justificar ausencia», no cuentan para el aviso del día 1 al 5 y en el informe mensual figuran como
justificadas («Justificada · actividad» / «Actividad complementaria o extraescolar (justificada)»).

## Videotutorial

`frontend/public/tutorial/videotutorial.mp4` (y su portada `portada.jpg`). Se abre con el botón **Tutorial** (icono de vídeo)
de la barra superior y desde el enlace «¿Primera vez? Mira el videotutorial» de la pantalla de acceso. Para cambiarlo, basta
con sustituir el fichero MP4 (H.264) con el mismo nombre.

## Ausencias: días anteriores y tareas para la guardia

- **Notificar días anteriores (excepcional)**: casilla «Ausencia de días anteriores» en Notificar ausencia; hasta 30 días
  atrás. Jefatura la ve como «notificada fuera de plazo» (`canal = 'fuera de plazo'`).
- **Tareas por clase**: al notificar, la app lista las clases que se pierden cada día (de hoy en adelante) y el profesor/a
  deja una tarea para cada una. Se guardan en `ausencia.detalle` con clave `AAAA-MM-DD|tramo` y salen en Guardias de aula
  y en el panel de la sala de profesores. En «Mis próximas ausencias» se pueden añadir o cambiar después
  (`GET /api/ausencias/mias`, `PUT /api/ausencias/:id/tareas`). Las ediciones de Jefatura conservan estas tareas.
