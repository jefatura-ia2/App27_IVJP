/**
 * Tareas programadas de sincronización (proceso aparte: `npm run cron`).
 *  (Las ausencias ya no se sincronizan: viven en la base de datos de la app.)
 *  · Horarios: cada mañana laborable (CRON_HORARIOS) desde el CSV.
 * Se ejecuta al arrancar para dejar la base de datos al día.
 */
import cron from 'node-cron';
import { config } from '../src/config.js';
import { pool } from '../src/db.js';
import { migrar } from '../src/models/index.js';
import { sincronizarHorarios } from '../src/ingestors/index.js';

const log = (...a) => console.log(new Date().toISOString(), ...a);
const tarea = (nombre, fn) => async () => {
  try { log(nombre, JSON.stringify(await fn())); } catch (e) { log(nombre, 'ERROR', e.message); }
};

const horarios = tarea('[horarios]', () => sincronizarHorarios());

await migrar(pool);
await horarios();
cron.schedule(config.cronHorarios, horarios, { timezone: config.tz });
log(`Tarea programada: horarios «${config.cronHorarios}» (${config.tz})`);
