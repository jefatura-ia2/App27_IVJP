import { pool } from '../src/db.js';
import { config } from '../src/config.js';
import { migrar } from '../src/models/index.js';
import { sincronizarHorarios } from '../src/ingestors/index.js';
await migrar(pool);
const ruta = process.argv[2] || config.horariosCsv;
console.log(ruta, await sincronizarHorarios(ruta));
await pool.end();
