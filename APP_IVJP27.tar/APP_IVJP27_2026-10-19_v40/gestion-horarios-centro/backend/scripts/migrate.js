import { pool } from '../src/db.js';
import { migrar } from '../src/models/index.js';
await migrar(pool);
console.log('Base de datos lista.');
await pool.end();
