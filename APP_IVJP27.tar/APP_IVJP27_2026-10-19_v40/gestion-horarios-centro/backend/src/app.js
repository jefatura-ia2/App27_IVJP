import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import cors from 'cors';
import { config } from './config.js';
import { rutas } from './routes.js';

export function crearApp() {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', 'loopback');   /* detrás de nginx: IP real y HTTPS (cookie Secure) */
  /* además de los orígenes configurados, se admiten siempre los de la app de móvil (Capacitor) */
  const ORIGENES_APP = ['capacitor://localhost', 'ionic://localhost', 'https://localhost', 'http://localhost'];
  const origenes = config.corsOrigin === '*' ? true : [...config.corsOrigin.split(',').map(s => s.trim()), ...ORIGENES_APP];
  app.use(cors({ origin: origenes, credentials: true }));
  app.use(express.json({ limit: '5mb' }));
  app.use('/api', rutas);

  /* Versión compilada de la app (frontend/dist, creada con «npm run build»): si existe, la sirve
     este mismo servidor, de modo que basta abrir http://<este-ordenador>:3000 */
  const dist = config.frontendDist;
  if (dist && fs.existsSync(path.join(dist, 'index.html'))) {
    app.use(express.static(dist, {
      index: false,
      setHeaders: (res, f) => {
        if (/[\\/]assets[\\/]/.test(f)) res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
        else res.setHeader('Cache-Control', 'no-cache');
      },
    }));
    app.get(/^\/(?!api\/).*/, (req, res) => { res.setHeader('Cache-Control', 'no-cache'); res.sendFile(path.join(dist, 'index.html')); });
    console.log(`App compilada servida desde ${dist}`);
  }

  app.use((req, res) => res.status(404).json({ error: 'Ruta no encontrada' }));
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    console.error(err);
    res.status(err.status || 500).json({ error: err.status ? err.message : 'Error interno' });
  });
  return app;
}
