import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

/* Se busca la configuración en backend/.env. En Windows es fácil que el Bloc de notas lo guarde
   como «.env.txt» o «env»: también se aceptan esos nombres. Si no hay ninguno, se usa .env.example. */
const DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const ficheroEnv = ['.env', '.env.txt', 'env', 'env.txt', '.env.example'].map(n => path.join(DIR, n)).find(f => fs.existsSync(f)) || null;
if (ficheroEnv) dotenv.config({ path: ficheroEnv });

export const config = {
  databaseUrl: process.env.DATABASE_URL || 'postgres://horarios:horarios@localhost:5432/horarios',
  port: Number(process.env.PORT || 3000),
  corsOrigin: process.env.CORS_ORIGIN || '*',
  /* Script de Google de la hoja «Ausencias 2026-27». Si .env no lo trae, se usa el del centro */
  sheetsServiceUrl: (process.env.SHEETS_SERVICE_URL || '').trim() || 'https://script.google.com/macros/s/AKfycbwk0GaPJgnPCO7KTtirRDX4tcMdTDf1RBfgAP91C3Wml-UAdw9kPZNX6PVWfrJkUe0m/exec',
  horariosCsv: process.env.HORARIOS_CSV || './data/datos_horarios_2026-27.csv',
  adminToken: process.env.ADMIN_TOKEN || '',
  tz: process.env.TZ_CENTRO || 'Europe/Madrid',
  cronAusencias: process.env.CRON_AUSENCIAS || '*/5 7-21 * * 1-5',
  cronHorarios: process.env.CRON_HORARIOS || '30 6 * * 1-5',

  /* Programaciones didácticas: acceso de administrador (Jefatura) y de jefes/as de departamento */
  adminPasswords: (process.env.ADMIN_PASSWORD || 'rafael2025').split(',').map(s => s.trim()).filter(Boolean),
  fechaLimiteProg: process.env.FECHA_LIMITE_PROG || '2026-10-14',
  maxPdfMb: Number(process.env.MAX_PDF_MB || 15),
  /* Notificación de ausencias: el servidor la reenvía a la hoja de Google con este token (propiedad TOKEN_NOTIF del script) */
  notifToken: process.env.NOTIF_TOKEN || '',
  /* Carpeta de la app compilada; vacío = no servirla (p. ej. en el servidor con nginx) */
  frontendDist: process.env.FRONTEND_DIST !== undefined ? process.env.FRONTEND_DIST : path.join(DIR, '..', 'frontend', 'dist'),
  uploadsDir: process.env.UPLOADS_DIR || './uploads/programaciones',
  /* PDF justificantes de ausencias (junto a los de programaciones, salvo que se indique otra carpeta) */
  /* Partes de disciplina: carpeta «disciplina» con una subcarpeta por Jefe/a de Estudios adjunto */
  disciplinaDir: process.env.DISCIPLINA_DIR || path.join(path.dirname(process.env.UPLOADS_DIR || './uploads/programaciones'), 'disciplina'),
  justificantesDir: process.env.JUSTIFICANTES_DIR || path.join(path.dirname(process.env.UPLOADS_DIR || './uploads/programaciones'), 'justificantes'),
};
