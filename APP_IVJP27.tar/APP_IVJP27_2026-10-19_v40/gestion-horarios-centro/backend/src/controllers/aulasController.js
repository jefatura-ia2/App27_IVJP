import { query } from '../db.js';
import { Aula, Tramo } from '../models/index.js';
import * as horarios from '../services/horarioService.js';

const TRAMOS = new Set(Tramo.TRAMOS_CENTRO.map(t => t.codigo));

export async function listar(req, res) { res.json(await Aula.listar({ query })); }

/** GET /api/aulas/libres?dia=1..5&tramo=3 */
export async function libres(req, res) {
  const dia = Number(req.query.dia), tramo = String(req.query.tramo || '').toUpperCase();
  if (!(dia >= 1 && dia <= 5) || !TRAMOS.has(tramo)) return res.status(400).json({ error: 'Indica dia (1-5) y tramo' });
  res.json(await horarios.aulasLibres(dia, tramo));
}

/** GET /api/aulas/:id/ocupacion?dia=1..5 */
export async function ocupacion(req, res) {
  const dia = Number(req.query.dia);
  if (!(dia >= 1 && dia <= 5)) return res.status(400).json({ error: 'Indica dia (1-5)' });
  res.json(await horarios.ocupacionAula(Number(req.params.id), dia));
}
