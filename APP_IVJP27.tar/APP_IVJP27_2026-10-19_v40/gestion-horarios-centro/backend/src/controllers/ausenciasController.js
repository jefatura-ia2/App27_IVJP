/**
 * Notificación de ausencias por el profesorado e informes mensuales (administración).
 * Regla: cada profesor/a solo puede notificar SUS PROPIAS ausencias (la de la cuenta con la que ha
 * entrado). Las cuentas de administración, o quien tenga activo el candado, pueden notificar la de
 * cualquier profesor/a del horario. La notificación se guarda en la base de datos como «Pendiente»
 * hasta que Jefatura la graba (Guardias de aula, modo administrador).
 */
import { config } from '../config.js';
import { query } from '../db.js';
import { profesorDeCuenta } from '../services/authService.js';
import { claveAdminOk } from '../services/programacionesService.js';
import * as S from '../services/servicioService.js';
import { datosInforme } from '../services/informeAusencias.js';
import { generarPDF } from '../services/pdfInforme.js';
import { marcarImportada } from '../services/importacionInicial.js';
import { generarDossier } from '../services/dossier.js';

const err = (msg, status = 400) => Object.assign(new Error(msg), { status });
const ISO = /^\d{4}-\d{2}-\d{2}$/;
const hoyCentro = () => new Date().toLocaleDateString('sv-SE', { timeZone: config.tz });
const sumarDias = (iso, n) => { const d = new Date(iso + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };

export async function notificar(req, res) {
  const { ausencia = {}, clave } = req.body || {};
  const esAdmin = req.usuario.rol === 'admin' || claveAdminOk(clave);
  let prof;
  if (esAdmin) {
    prof = String(ausencia.prof || '').trim();
    if (!prof) throw err('Elige el profesor/a que se ausenta');
    const { rowCount } = await query('SELECT 1 FROM profesor WHERE nombre = $1 AND activo', [prof]);
    if (!rowCount) throw err('Ese nombre no está en el horario');
  } else {
    prof = await profesorDeCuenta(req.usuario.nombre);
    if (!prof) throw err('Tu cuenta no está vinculada a ningún profesor/a del horario. Pide a Jefatura que revise el nombre de tu cuenta.', 400);
    if (ausencia.prof && String(ausencia.prof).trim() !== prof) throw err('Solo puedes notificar tus propias ausencias', 400);
  }
  if (!ISO.test(String(ausencia.fecha || ''))) throw err('Fecha no válida');
  if (ausencia.hasta && !ISO.test(String(ausencia.hasta))) throw err('Fecha final no válida');
  /* de forma excepcional se pueden notificar días ya pasados (hasta 30 días atrás); Jefatura la ve como «fuera de plazo» */
  const hoy = hoyCentro();
  let canal = esAdmin ? (ausencia.canal || '') : '';
  if (ausencia.fecha < hoy) {
    if (!esAdmin && ausencia.fecha < sumarDias(hoy, -30)) throw err('Solo se pueden notificar ausencias de los últimos 30 días. Para fechas anteriores, habla con Jefatura de Estudios.');
    if (!esAdmin) canal = 'fuera de plazo';
  }
  const id = await S.notificar({ ...ausencia, prof, canal }, req.usuario.usuario);
  res.json({ ok: true, prof, id });
}

/** GET /api/ausencias/mias — ausencias propias de hoy en adelante (con sus tareas) */
export async function mias(req, res) {
  const prof = await profesorDeCuenta(req.usuario.nombre);
  if (!prof) return res.json({ ok: true, profesor: null, ausencias: [] });
  const lista = (await S.ausenciasDe(prof, hoyCentro())).map(({ motivo, registrado_por, canal, justificacion_id, ...a }) => a);
  res.json({ ok: true, profesor: prof, hoy: hoyCentro(), ausencias: lista });
}
/** PUT /api/ausencias/:id/tareas { detalle, obs } — tareas para la guardia de una ausencia propia */
export async function tareas(req, res) {
  const prof = await profesorDeCuenta(req.usuario.nombre);
  if (!prof) throw err('Tu cuenta no está vinculada a ningún profesor/a del horario');
  await S.guardarTareas(req.params.id, prof, req.body || {});
  res.json({ ok: true, ausencias: (await S.ausenciasDe(prof, hoyCentro())).map(({ motivo, registrado_por, canal, justificacion_id, ...a }) => a) });
}

/** Informe mensual: POST {mes:'AAAA-MM', clave, formato:'json'|'pdf', motivo:true|false} — solo administración */
export async function informe(req, res) {
  const { mes, clave, formato = 'json', motivo = true } = req.body || {};
  if (!(req.usuario.rol === 'admin' && claveAdminOk(clave))) throw err('Los informes son solo para Jefatura en modo administrador', 400);
  const inf = await datosInforme(mes);
  if (formato !== 'pdf') return res.json({ ok: true, ...inf });
  const pdf = await generarPDF(inf, { conMotivo: motivo !== false });
  res.set({ 'Content-Type': 'application/pdf', 'Content-Disposition': `attachment; filename="Informe_ausencias_${inf.mes.desde.slice(0, 7)}.pdf"`, 'Cache-Control': 'no-store' });
  res.send(pdf);
}

/** Importación única de lo que había en la hoja de Google — solo administración */
export async function importarHoja(req, res) {
  const { clave } = req.body || {};
  if (!(req.usuario.rol === 'admin' && claveAdminOk(clave))) throw err('Solo Jefatura en modo administrador', 400);
  const r = await S.importarDeHoja(config.sheetsServiceUrl, clave);
  await marcarImportada(r);
  res.json({ ok: true, ...r });
}

/** Dossier del mes: informe + justificaciones con sus PDF — POST {mes, clave, motivo} — solo administración */
export async function dossier(req, res) {
  const { mes, clave, motivo = true } = req.body || {};
  if (!(req.usuario.rol === 'admin' && claveAdminOk(clave))) throw err('Solo Jefatura en modo administrador', 400);
  const d = await generarDossier(mes, { conMotivo: motivo !== false });
  res.set({ 'Content-Type': 'application/pdf', 'Content-Disposition': `attachment; filename="Ausencias_y_justificantes_${String(mes).slice(0, 7)}.pdf"`, 'Cache-Control': 'no-store' });
  res.send(d.pdf);
}
