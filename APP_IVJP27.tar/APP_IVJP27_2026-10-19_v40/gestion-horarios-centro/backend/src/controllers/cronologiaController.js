import * as C from '../services/cronologiaService.js';
import { claveAdminOk } from '../services/programacionesService.js';

/** GET /api/cronologia — el cronograma guardado (cualquier docente con sesión) */
export async function leer(req, res) {
  const v = await C.leer();
  res.json({ ok: true, eventos: v ? v.eventos : null, actualizado: v ? v.actualizado : '' });
}
/** PUT /api/cronologia { eventos, clave } — solo Jefatura (cuenta de administración o su contraseña) */
export async function guardar(req, res) {
  const { eventos, clave } = req.body || {};
  if (req.usuario.rol !== 'admin' && !claveAdminOk(clave))
    return res.status(400).json({ ok: false, error: 'Solo Jefatura de Estudios puede grabar el cronograma' });
  const v = await C.guardar(eventos, req.usuario.usuario);
  res.json({ ok: true, eventos: v.eventos, actualizado: v.actualizado });
}
/** GET /api/cronologia/reunion/:id — pública (sin sesión): solo los datos de una reunión, para la página de las familias */
export async function reunion(req, res) {
  const v = await C.leer();
  const ev = (v ? v.eventos : []).find(e => String(e.id) === String(req.params.id) && e.subtipo === 'reunion');
  if (!ev) return res.json({ ok: false, evento: null, guardado: !!v });
  const { id, titulo, desc, inicio, fin, subtipo } = ev;
  res.json({ ok: true, guardado: true, evento: { id, titulo, desc, inicio, fin, subtipo,
    grupos: (ev.grupos || []).map(g => ({ code: g.code, lugar: g.lugar, fechaHora: g.fechaHora, fecha: g.fecha, tutor: g.tutor })) } });
}
