import { claveAdminOk } from '../services/programacionesService.js';
import * as Edicion from '../services/edicionService.js';

/** Solo administración: cuenta con rol de administración, o la contraseña del candado (ADMIN_PASSWORD) */
export function soloAdmin(req, res, next) {
  if ((req.usuario && req.usuario.rol === 'admin') || claveAdminOk(req.body && req.body.clave)) return next();
  res.status(401).json({ ok: false, error: 'Contraseña de administración no válida' });
}

/** POST /api/sesiones/cambiar  { clave, antes, despues }  (antes=null → añadir · despues=null → borrar) */
export async function cambiar(req, res) {
  const csv = await Edicion.cambiarSesion(req.body);
  res.json({ ok: true, csv });
}

/** POST /api/horario/importar  { clave, csv } — sustituye el horario completo */
export async function importar(req, res) {
  const r = await Edicion.importarCSV(req.body.csv);
  res.json({ ok: true, ...r });
}

/** GET /api/horario/carga — estado del horario, última carga y copias de seguridad */
export async function estado(req, res) { res.json({ ok: true, ...(await Edicion.estadoCarga()) }); }

/** POST /api/horario/previa  { csv } — comprueba el fichero y resume los cambios, sin aplicarlos */
export async function previa(req, res) { res.json({ ok: true, ...(await Edicion.previsualizarCSV(req.body.csv)) }); }

/** POST /api/horario/restaurar  { copia } — vuelve a un horario anterior */
export async function restaurar(req, res) { res.json({ ok: true, ...(await Edicion.restaurarCopia(req.body.copia)) }); }
