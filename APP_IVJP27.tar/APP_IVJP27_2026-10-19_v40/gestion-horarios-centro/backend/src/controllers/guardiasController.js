import * as guardias from '../services/guardiasService.js';
import { esFechaISO } from '../services/tiempo.js';

/** GET /api/guardias/ahora — tramo en curso y siguiente */
export async function ahora(req, res) { res.json(await guardias.estadoAhora()); }

/** GET /api/guardias?fecha=YYYY-MM-DD — todos los tramos del día */
export async function delDia(req, res) {
  const fecha = String(req.query.fecha || '');
  if (!esFechaISO(fecha)) return res.status(400).json({ error: 'Indica fecha=AAAA-MM-DD' });
  res.json(await guardias.estadoDelDia(fecha));
}
