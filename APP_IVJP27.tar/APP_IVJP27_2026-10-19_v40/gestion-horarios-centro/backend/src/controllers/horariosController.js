import { query } from '../db.js';
import { Tramo, Profesor, Grupo } from '../models/index.js';
import * as horarios from '../services/horarioService.js';
import { exportarCSV } from '../services/edicionService.js';

const idValido = v => Number.isInteger(Number(v)) && Number(v) > 0;

export async function tramos(req, res) { res.json(await Tramo.listar({ query })); }
export async function profesores(req, res) { res.json(await Profesor.listar({ query })); }
export async function grupos(req, res) { res.json(await Grupo.listar({ query })); }

/** GET /api/horarios/:tipo/:id   (tipo = profesor | grupo | aula) */
export async function horarioDe(req, res) {
  const { tipo, id } = req.params;
  if (!['profesor', 'grupo', 'aula'].includes(tipo) || !idValido(id)) return res.status(400).json({ error: 'Parámetros no válidos' });
  const ent = await horarios.entidad(tipo, Number(id));
  if (!ent) return res.status(404).json({ error: 'No encontrado' });
  res.json({ tipo, ...ent, sesiones: await horarios.sesionesDe(tipo, Number(id)) });
}

/** GET /api/buscar?q=texto */
export async function buscar(req, res) {
  const q = String(req.query.q || '').slice(0, 60);
  res.json(q.trim().length < 1 ? [] : await horarios.buscar(q));
}

/** GET /api/horario.csv — el horario completo en el formato del CSV original. Lo usa la interfaz de la app. */
export async function csv(req, res) {
  res.type('text/csv; charset=utf-8').send(await exportarCSV());
}
