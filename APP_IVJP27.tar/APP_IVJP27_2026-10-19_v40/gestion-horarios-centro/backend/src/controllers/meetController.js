/**
 * Enlaces de Meet de las tarjetas de evaluación de la Cronología.
 * Los ve cualquier docente con sesión; solo administración (cuenta de administración o contraseña
 * de Jefatura, la misma que se usa en el modo administrador de la Cronología) los pone o los quita.
 */
import { query } from '../db.js';
import * as Ajuste from '../models/Ajuste.js';
import { claveAdminOk } from '../services/programacionesService.js';

const db = { query };
const CLAVE = 'meet_eventos';
const leer = async () => { try { return JSON.parse(await Ajuste.leer(db, CLAVE) || '{}'); } catch { return {}; } };

export async function listar(req, res) { res.json({ ok: true, enlaces: await leer() }); }

export async function guardar(req, res) {
  const { url, clave } = req.body || {};
  if (req.usuario.rol !== 'admin' && !claveAdminOk(clave))
    return res.status(403).json({ ok: false, error: 'Solo Jefatura de Estudios puede cambiar el enlace de la reunión' });
  const id = String(req.params.evento || '').slice(0, 40);
  if (!id) return res.status(400).json({ ok: false, error: 'Falta la reunión' });
  const enlaces = await leer();
  const u = String(url || '').trim();
  if (!u) delete enlaces[id];
  else {
    let ok = false; try { ok = new URL(u).protocol === 'https:'; } catch { /* no es URL */ }
    if (!ok) return res.status(400).json({ ok: false, error: 'El enlace debe empezar por https:// (p. ej. https://meet.google.com/abc-defg-hij)' });
    enlaces[id] = u.slice(0, 300);
  }
  await Ajuste.guardar(db, CLAVE, JSON.stringify(enlaces));
  res.json({ ok: true, enlaces });
}
