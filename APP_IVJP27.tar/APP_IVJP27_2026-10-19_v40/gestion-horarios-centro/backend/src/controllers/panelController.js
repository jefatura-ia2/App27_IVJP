import * as P from '../services/panelService.js';

/** GET /api/panel/datos?t=… — sin sesión, con el enlace secreto del panel (respuesta 200 siempre) */
export async function datos(req, res) {
  if (!(await P.tokenValido(req.query.t))) return res.json({ ok: false, error: 'Enlace del panel no válido o cambiado. Pide el nuevo a Jefatura de Estudios.' });
  res.set('Cache-Control', 'no-store');
  res.json(await P.datos());
}
/** GET /api/panel/config — (administración) enlace y ajustes del panel */
export async function config(req, res) {
  res.json({ ok: true, token: await P.token(), config: await P.leerConfig() });
}
/** PUT /api/panel/config { mensaje, enlaces, segundosAviso, regenerar } */
export async function guardar(req, res) {
  const b = req.body || {};
  res.json({ ok: true, ...(await P.guardarConfig(b, { regenerar: !!b.regenerar })) });
}
