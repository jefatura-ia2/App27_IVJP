import path from 'node:path';
import multer from 'multer';
import { config } from '../config.js';
import * as Servicio from '../services/programacionesService.js';

export const subirMiddleware = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: config.maxPdfMb * 1024 * 1024 },
}).single('archivo');

export async function listar(req, res) {
  res.json({ ok: true, fechaLimite: config.fechaLimiteProg, departamentos: await Servicio.listar() });
}

/** POST /api/programaciones/login-admin  { clave } */
export async function loginAdmin(req, res) {
  const ok = Servicio.claveAdminOk(req.body && req.body.clave);
  if (!ok) return res.status(401).json({ ok: false });
  res.json({ ok: true });
}

/** POST /api/programaciones/:id/login  { clave } — acceso de jefe/a de departamento */
export async function loginJefe(req, res) {
  const r = await Servicio.loginJefe(Number(req.params.id), req.body && req.body.clave);
  if (!r.ok) return res.status(401).json(r);
  res.json(r);
}

/** POST /api/programaciones  { nombre, jefe, claveDep, clave } — solo admin */
export async function crear(req, res) {
  res.json({ ok: true, ...(await Servicio.crear(req.body || {})) });
}

/** POST /api/programaciones/:id/documentos  (multipart: archivo) + campos clave */
export async function subir(req, res) {
  if (!req.file) return res.status(400).json({ ok: false, error: 'No se ha recibido ningún archivo' });
  const doc = await Servicio.subir(Number(req.params.id), req.body.clave, req.file.originalname, req.file.buffer);
  res.json({ ok: true, doc });
}

/** GET /api/programaciones/:id/documentos/:docId/archivo — descarga/visualización del PDF */
export async function archivo(req, res) {
  const { ruta, nombre } = await Servicio.rutaArchivo(Number(req.params.id), Number(req.params.docId));
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `inline; filename="${nombre.replace(/"/g, '')}"`);
  res.sendFile(path.resolve(ruta));
}

export async function borrarDoc(req, res) {
  await Servicio.borrarDocumento(Number(req.params.id), Number(req.params.docId), req.body && req.body.clave);
  res.json({ ok: true });
}

export async function anular(req, res) {
  await Servicio.anular(Number(req.params.id), req.body && req.body.clave);
  res.json({ ok: true });
}

export async function obs(req, res) {
  await Servicio.guardarObs(Number(req.params.id), req.body && req.body.obs, req.body && req.body.clave);
  res.json({ ok: true });
}

export async function jefe(req, res) {
  await Servicio.guardarJefe(Number(req.params.id), req.body && req.body.jefe, req.body && req.body.clave);
  res.json({ ok: true });
}

export async function clave(req, res) {
  await Servicio.cambiarClave(Number(req.params.id), req.body && req.body.claveDep, req.body && req.body.clave);
  res.json({ ok: true });
}

export async function estado(req, res) {
  await Servicio.cambiarEstado(Number(req.params.id), req.body && req.body.estado, req.body && req.body.clave);
  res.json({ ok: true });
}
