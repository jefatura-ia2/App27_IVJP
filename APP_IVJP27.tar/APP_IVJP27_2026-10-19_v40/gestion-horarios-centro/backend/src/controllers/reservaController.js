import * as R from '../services/reservaService.js';
import { profesorDeCuenta } from '../services/authService.js';

const esAdmin = req => req.usuario.rol === 'admin';

/** GET /api/reservas/espacios — espacios, tramos y datos para rellenar el formulario */
export async function inicio(req, res) {
  res.json({ ok: true, espacios: await R.espacios(esAdmin(req)), tramos: R.tramos(), admin: esAdmin(req),
    docente: await profesorDeCuenta(req.usuario.nombre) || req.usuario.nombre || '' });
}
/** GET /api/reservas?espacio=biblioteca&desde=2026-10-19 */
export async function semana(req, res) {
  res.json({ ok: true, ...(await R.semana(String(req.query.espacio || ''), req.query.desde, req.usuario.id)) });
}
export async function reservar(req, res) {
  try { res.json({ ok: true, ...(await R.reservar(req.usuario, req.body || {}, esAdmin(req))) }); }
  catch (e) { if (e.conflictos) return res.status(e.status).json({ ok: false, error: e.message, conflictos: e.conflictos }); throw e; }
}
export async function anular(req, res) {
  res.json({ ok: true, ...(await R.anular(req.usuario, Number(req.params.id), req.query.lote === '1', esAdmin(req))) });
}
/* administración */
export async function crearEspacio(req, res) { res.json({ ok: true, ...(await R.crearEspacio(req.body || {})) }); }
export async function cambiarEspacio(req, res) { await R.cambiarEspacio(req.params.id, req.body || {}); res.json({ ok: true }); }
export async function bloquear(req, res) { await R.bloquear(req.params.id, req.body || {}); res.json({ ok: true }); }
export async function bloquearDesdeHorario(req, res) { res.json({ ok: true, ...(await R.bloquearDesdeHorario(req.params.id)) }); }
