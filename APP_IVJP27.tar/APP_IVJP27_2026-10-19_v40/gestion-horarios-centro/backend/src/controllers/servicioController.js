/**
 * Avisos, calendarios y ausencias con la misma interfaz que tenía el servicio de Apps Script
 * (GET ?accion=datos · POST {accion, clave, …}), ahora resuelta con la base de datos de la app.
 * Las respuestas de error van con estado 200 y {error}, como antes, para que la app no cierre la sesión.
 */
import { claveAdminOk } from '../services/programacionesService.js';
import * as S from '../services/servicioService.js';
import * as DAP from '../services/dapService.js';


export async function get(req, res) {
  const accion = req.query.accion || 'datos';
  if (accion === 'ping') return res.json({ ok: true, version: 'base de datos de la app' });
  if (accion !== 'datos') return res.json({ error: 'Acción no válida' });
  res.json(await S.datosPublicos());
}

export async function post(req, res) {
  const p = req.body || {};
  if (p.accion === 'login') return res.json({ ok: claveAdminOk(p.clave) });
  if (!claveAdminOk(p.clave)) return res.json({ error: 'Contraseña incorrecta' });
  const por = req.usuario ? req.usuario.usuario : '';
  const conDatos = async extra => res.json({ ok: true, datos: await S.datosPublicos(), ...extra });
  try {
    switch (p.accion) {
      case 'ausencias_admin': return res.json({ ok: true, ausencias: await S.ausenciasAdmin() });
      case 'ausencia_guardar': await S.guardarAusencia(p.ausencia, por); return conDatos({ ausencias: await S.ausenciasAdmin() });
      case 'ausencias_semana': await S.guardarSemana(p, por); return conDatos({ ausencias: await S.ausenciasAdmin() });
      case 'ausencia_grabar': await S.grabarAusencias(p.ids || [p.id]); return conDatos({ ausencias: await S.ausenciasAdmin() });
      case 'ausencia_borrar': await S.borrarAusencias(p.ids || [p.id]); return conDatos({ ausencias: await S.ausenciasAdmin() });
      case 'aviso_guardar': await S.guardarAviso(p.aviso); return conDatos();
      case 'aviso_borrar': await S.borrarAviso(p.id); return conDatos();
      case 'calendario_guardar': {
        await S.guardarCalendario(p.clave_cal, p.calendario);
        if (p.clave_cal === 'dap') await DAP.sincronizar({ forzar: true }).catch(() => {});
        return conDatos();
      }
      /* calendario de asuntos propios → ausencias */
      case 'dap_estado': return res.json({ ok: true, dap: await DAP.leerEstado() });
      case 'dap_sincronizar': await DAP.sincronizar({ forzar: true }); return conDatos({ dap: await DAP.leerEstado(), ausencias: await S.ausenciasAdmin() });
      case 'dap_asignar': await DAP.asignar(p.titulo, p.profesor); return conDatos({ dap: await DAP.leerEstado(), ausencias: await S.ausenciasAdmin() });
    }
  } catch (e) { return res.json({ error: e.message }); }
  res.json({ error: 'Acción no válida' });
}
