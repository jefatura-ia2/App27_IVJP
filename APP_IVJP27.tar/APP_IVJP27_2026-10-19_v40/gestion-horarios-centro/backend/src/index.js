import { config, ficheroEnv } from './config.js';
console.log(ficheroEnv ? `Configuración leída de: ${ficheroEnv}` : '*** No encuentro backend/.env: se usan los valores por defecto ***');
import { pool } from './db.js';
import { migrar } from './models/index.js';
import { crearApp } from './app.js';
import { importacionInicial } from './services/importacionInicial.js';
import { iniciar as iniciarBiblioteca } from './services/bibliotecaService.js';
import { programar as programarDap } from './services/dapService.js';
import { prepararCarpetas as carpetasDisciplina, carpetaBase as carpetaDisciplina } from './services/disciplinaService.js';

try {
  await migrar(pool);
} catch (e) {
  console.error('\n*** No se pudo arrancar: fallo al conectar o preparar la base de datos ***');
  console.error('Motivo:', e.message);
  if (e.code === 'ECONNREFUSED') console.error('-> PostgreSQL no está en marcha. Arráncalo (Servicios de Windows: «postgresql») y vuelve a intentarlo.');
  else if (e.code === '28P01') console.error('-> La contraseña de DATABASE_URL en backend/.env no es la del usuario de PostgreSQL.');
  else if (e.code === '3D000') console.error('-> La base de datos de DATABASE_URL no existe. Créala en SQL Shell: CREATE DATABASE horarios OWNER horarios;');
  else if (e.code === '42501') console.error('-> El usuario de la base de datos no tiene permisos. En SQL Shell: ALTER DATABASE horarios OWNER TO horarios;');
  console.error('Revisa la línea DATABASE_URL de backend/.env\n');
  process.exit(1);
}
importacionInicial().catch(() => {});   /* una sola vez: trae a la base de datos lo que había en la hoja de Google */
iniciarBiblioteca().catch(e => console.log('Biblioteca:', e.message));   /* una sola vez: trae los registros G.B./MAY55 de su hoja */
try { carpetasDisciplina(); console.log('Partes de disciplina en:', carpetaDisciplina()); } catch (e) { console.log('Disciplina: no se pudo crear la carpeta:', e.message); }
programarDap();   /* calendario de asuntos propios (DAP) → ausencias, al arrancar y cada 15 minutos */
const server = crearApp().listen(config.port, () => console.log(`API de horarios en http://localhost:${config.port}/api`));
server.on('error', e => {
  if (e.code === 'EADDRINUSE') console.error(`\n*** El puerto ${config.port} ya está ocupado: ¿hay otra ventana con el servidor abierta? Ciérrala o cambia PORT en backend/.env ***\n`);
  else console.error(e);
  process.exit(1);
});

const parar = async () => { server.close(); await pool.end(); process.exit(0); };
process.on('SIGINT', parar);
process.on('SIGTERM', parar);
