/**
 * Ingestor del CSV de horarios (el mismo que usa horario.html):
 *   "Apellidos, Nombre",dia,hora,materia,grupo,aula,tipo
 *   dia: 1-5 (lunes-viernes) · hora: 1..13 o R1/R2
 * Sustituye todo el horario semanal en una transacción: si algo falla, no se toca nada.
 */
import fs from 'node:fs/promises';
import { transaccion } from '../db.js';
import { Profesor, Grupo, Aula, Clase, Tramo } from '../models/index.js';

const TRAMOS_VALIDOS = new Set(Tramo.TRAMOS_CENTRO.map(t => t.codigo));

/** Separador del fichero: coma, o punto y coma (lo que usa Excel en español al guardar como CSV) */
export function detectarSeparador(t) {
  const linea = (t.split(/\r?\n/).find(l => l.trim()) || '').replace(/"[^"]*"/g, '');
  return (linea.match(/;/g) || []).length > (linea.match(/,/g) || []).length ? ';' : ',';
}

/** Parser CSV con comillas (RFC 4180 básico); admite coma o punto y coma */
export function parsearCSV(texto) {
  const filas = []; let campo = '', fila = [], q = false;
  const t = texto.replace(/^﻿/, '');
  const sep = detectarSeparador(t);
  for (let i = 0; i < t.length; i++) {
    const ch = t[i];
    if (ch === '"') { if (q && t[i + 1] === '"') { campo += '"'; i++; } else q = !q; }
    else if (ch === sep && !q) { fila.push(campo); campo = ''; }
    else if ((ch === '\n' || ch === '\r') && !q) {
      if (campo !== '' || fila.length) { fila.push(campo); filas.push(fila); fila = []; campo = ''; }
    } else campo += ch;
  }
  if (campo !== '' || fila.length) { fila.push(campo); filas.push(fila); }
  return filas;
}

/** Convierte filas CSV en sesiones válidas y devuelve también las descartadas */
export function normalizarFilas(filas) {
  const sesiones = [], descartadas = [];
  filas.forEach((f, i) => {
    const [profesor, dia, hora, materia, grupo, aula, tipo] = f.map(x => (x ?? '').trim());
    /* fila de títulos (p. ej. la del fichero descargado de la app): se salta sin contarla */
    if (i === 0 && /prof/i.test(profesor) && !(Number(dia) >= 1)) return;
    const tramo = String(hora || '').toUpperCase();
    const d = Number(dia);
    if (!profesor || !(d >= 1 && d <= 5) || !TRAMOS_VALIDOS.has(tramo)) {
      if (f.join('').trim()) descartadas.push({ linea: i + 1, fila: f });
      return;
    }
    sesiones.push({ profesor, dia: d, tramo, materia: materia || '', grupo: grupo || '', aula: aula || '',
      tipo: tipo || '', categoria: Clase.clasificar(tipo) });
  });
  return { sesiones, descartadas };
}

/** Lee y comprueba el CSV sin tocar la base de datos. Lanza un error si no sirve. */
export function validarTexto(texto) {
  const { sesiones, descartadas } = normalizarFilas(parsearCSV(texto));
  if (!sesiones.length) throw new Error('El CSV no contiene sesiones válidas');
  /* protección: un fichero mal formado no debe sustituir el horario bueno */
  if (descartadas.length > sesiones.length) {
    const d = descartadas[0];
    throw new Error(`El CSV parece mal formado: ${descartadas.length} filas no válidas frente a ${sesiones.length} válidas `
      + `(primera, línea ${d.linea}: «${d.fila.join(',').slice(0, 80)}»). No se ha cambiado nada.`);
  }
  return { sesiones, descartadas };
}

export async function ingerirTexto(texto) {
  const { sesiones, descartadas } = validarTexto(texto);
  return transaccion(async db => {
    await db.query('DELETE FROM clase');
    await db.query('UPDATE profesor SET activo = FALSE');
    const ids = { p: new Map(), g: new Map(), a: new Map() };
    const id = async (mapa, clave, fn) => {
      if (!clave) return null;
      if (!mapa.has(clave)) mapa.set(clave, await fn(db, clave));
      return mapa.get(clave);
    };
    for (const s of sesiones) {
      const pid = await id(ids.p, s.profesor, Profesor.upsert);
      const gid = await id(ids.g, s.grupo, Grupo.upsert);
      const aid = await id(ids.a, s.aula, Aula.upsert);
      await db.query(
        `INSERT INTO clase (profesor_id, dia, tramo, materia, grupo_id, aula_id, tipo, categoria)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
        [pid, s.dia, s.tramo, s.materia, gid, aid, s.tipo, s.categoria]);
    }
    /* volver a enlazar las ausencias con los profesores (por si cambian los ids) */
    const { rows: aus } = await db.query('SELECT id, profesor FROM ausencia');
    for (const a of aus) {
      const p = await Profesor.buscarPorNombre(db, a.profesor);
      await db.query('UPDATE ausencia SET profesor_id = $2 WHERE id = $1', [a.id, p ? p.id : null]);
    }
    return { sesiones: sesiones.length, profesores: ids.p.size, grupos: ids.g.size, aulas: ids.a.size,
      descartadas: descartadas.length };
  });
}

export async function ingerirFichero(ruta) {
  return ingerirTexto(await fs.readFile(ruta, 'utf8'));
}
