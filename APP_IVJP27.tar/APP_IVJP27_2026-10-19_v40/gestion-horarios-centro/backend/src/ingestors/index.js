import { query } from '../db.js';
import { config } from '../config.js';
import * as csvHorarios from './csvHorarios.js';

export { csvHorarios };

/** Ejecuta un ingestor dejando constancia en la tabla `sincronizacion` */
async function registrar(origen, fn) {
  const { rows } = await query(`INSERT INTO sincronizacion (origen) VALUES ($1) RETURNING id`, [origen]);
  try {
    const detalle = await fn();
    await query(`UPDATE sincronizacion SET fin = now(), ok = TRUE, detalle = $2 WHERE id = $1`, [rows[0].id, detalle]);
    return { ok: true, ...detalle };
  } catch (e) {
    await query(`UPDATE sincronizacion SET fin = now(), ok = FALSE, detalle = $2 WHERE id = $1`,
      [rows[0].id, { error: e.message }]);
    throw e;
  }
}

export const sincronizarHorarios = (ruta = config.horariosCsv) =>
  registrar('csv-horarios', () => csvHorarios.ingerirFichero(ruta));

export async function ultimasSincronizaciones() {
  const { rows } = await query(
    `SELECT DISTINCT ON (origen) origen, inicio, fin, ok, detalle FROM sincronizacion ORDER BY origen, inicio DESC`);
  return rows;
}
