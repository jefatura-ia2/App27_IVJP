/** Ajustes internos que el servidor guarda por sí solo (p. ej. el token de notificación de ausencias). */
export const DDL = `
CREATE TABLE IF NOT EXISTS ajuste (
  clave       TEXT PRIMARY KEY,
  valor       TEXT NOT NULL,
  actualizado TIMESTAMPTZ NOT NULL DEFAULT now()
);`;
export async function leer(db, clave) {
  const { rows } = await db.query('SELECT valor FROM ajuste WHERE clave = $1', [clave]);
  return rows[0] ? rows[0].valor : null;
}
export async function guardar(db, clave, valor) {
  await db.query(`INSERT INTO ajuste (clave, valor) VALUES ($1,$2)
    ON CONFLICT (clave) DO UPDATE SET valor = EXCLUDED.valor, actualizado = now()`, [clave, valor]);
}
