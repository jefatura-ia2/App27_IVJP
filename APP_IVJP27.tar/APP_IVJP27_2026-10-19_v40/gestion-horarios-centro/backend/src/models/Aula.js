/** Aula o espacio del centro */
export const DDL = `
CREATE TABLE IF NOT EXISTS aula (
  id     SERIAL PRIMARY KEY,
  codigo TEXT NOT NULL UNIQUE
);`;

export async function upsert(db, codigo) {
  const { rows } = await db.query(
    `INSERT INTO aula (codigo) VALUES ($1) ON CONFLICT (codigo) DO UPDATE SET codigo = EXCLUDED.codigo RETURNING id`, [codigo]);
  return rows[0].id;
}

export async function listar(db) {
  const { rows } = await db.query(`SELECT id, codigo FROM aula ORDER BY codigo`);
  return rows;
}
