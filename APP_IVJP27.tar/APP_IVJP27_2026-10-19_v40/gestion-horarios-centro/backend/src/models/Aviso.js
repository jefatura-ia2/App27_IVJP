/** Avisos importantes que publica Jefatura (antes, pestaña «Avisos» de la hoja de Google). */
export const DDL = `
CREATE TABLE IF NOT EXISTS aviso (
  id        TEXT PRIMARY KEY,
  titulo    TEXT NOT NULL DEFAULT '',
  texto     TEXT NOT NULL DEFAULT '',
  nivel     TEXT NOT NULL DEFAULT 'info',
  caduca    DATE,
  enlace    TEXT NOT NULL DEFAULT '',
  publicado DATE NOT NULL DEFAULT CURRENT_DATE
);`;
