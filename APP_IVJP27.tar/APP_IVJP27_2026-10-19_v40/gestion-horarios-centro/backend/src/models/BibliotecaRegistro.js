/**
 * Biblioteca: profesorado de Atención a Biblioteca (G.B.) y Mayores de 55 (MAY55) por día y tramo.
 * Antes estaba en la hoja de Google «Registros G.B. y MAY55 2026-27»; ahora en la base de datos.
 * dia: 0 = lunes … 4 = viernes (como en la app). slot: «1ª Diurno», «1º Recreo»…
 */
export const DDL = `
CREATE TABLE IF NOT EXISTS biblioteca_registro (
  id      SERIAL PRIMARY KEY,
  nombre  TEXT NOT NULL,
  dept    TEXT NOT NULL DEFAULT '',
  act     TEXT NOT NULL CHECK (act IN ('GB','MAY')),
  dia     SMALLINT NOT NULL CHECK (dia BETWEEN 0 AND 4),
  slot    TEXT NOT NULL
);
ALTER TABLE usuario ADD COLUMN IF NOT EXISTS perfiles TEXT[] NOT NULL DEFAULT '{}';`;
