/**
 * Clase = una sesión del horario semanal: quién, qué día, en qué tramo, con qué grupo y dónde.
 * `categoria` clasifica el tipo (docencia, guardia, recreo, tutoria, biblioteca…).
 */
export const CATEGORIAS = ['docencia', 'guardia', 'recreo', 'tutoria', 'biblioteca', 'jefatura', 'comision', 'reunion', 'otro'];

export const DDL = `
CREATE TABLE IF NOT EXISTS clase (
  id          SERIAL PRIMARY KEY,
  profesor_id INT  NOT NULL REFERENCES profesor(id) ON DELETE CASCADE,
  dia         SMALLINT NOT NULL CHECK (dia BETWEEN 1 AND 5),   -- 1 = lunes … 5 = viernes
  tramo       TEXT NOT NULL REFERENCES tramo(codigo),
  materia     TEXT NOT NULL DEFAULT '',
  grupo_id    INT  REFERENCES grupo(id) ON DELETE SET NULL,
  aula_id     INT  REFERENCES aula(id)  ON DELETE SET NULL,
  tipo        TEXT NOT NULL DEFAULT '',                         -- texto original ("Guardia de Aula")
  categoria   TEXT NOT NULL DEFAULT 'docencia'
);
CREATE INDEX IF NOT EXISTS clase_prof_idx  ON clase (profesor_id, dia);
CREATE INDEX IF NOT EXISTS clase_grupo_idx ON clase (grupo_id, dia);
CREATE INDEX IF NOT EXISTS clase_aula_idx  ON clase (aula_id, dia);
CREATE INDEX IF NOT EXISTS clase_slot_idx  ON clase (dia, tramo, categoria);`;

/** Clasifica el texto de tipo del horario en una categoría */
export function clasificar(tipo) {
  const k = String(tipo || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
  if (k.includes('recreo')) return 'recreo';
  if (k.includes('guardia')) return 'guardia';
  if (k.includes('biblioteca')) return 'biblioteca';
  if (k.includes('jefatura')) return 'jefatura';
  if (k.startsWith('tut') || k.includes('tutoria')) return 'tutoria';
  if (k.includes('reunion')) return 'reunion';
  if (k.includes('comision') || k.includes('coordinacion') || k.includes('participacion')) return 'comision';
  if (k.startsWith('otras')) return 'otro';
  return 'docencia';
}

/** Consulta base: sesiones con nombres resueltos */
export const SELECT_SESIONES = `
SELECT c.id, c.dia, c.tramo, t.orden, to_char(t.inicio,'HH24:MI') AS inicio, to_char(t.fin,'HH24:MI') AS fin,
       c.materia, c.tipo, c.categoria,
       p.id AS profesor_id, p.nombre AS profesor,
       g.id AS grupo_id, g.codigo AS grupo,
       a.id AS aula_id, a.codigo AS aula
FROM clase c
JOIN tramo t    ON t.codigo = c.tramo
JOIN profesor p ON p.id = c.profesor_id
LEFT JOIN grupo g ON g.id = c.grupo_id
LEFT JOIN aula a  ON a.id = c.aula_id`;
