/**
 * Departamentos didácticos: entrega de la programación anual.
 * `clave` es la contraseña propia del departamento (acceso de jefe/a);
 * las contraseñas de administrador son aparte (ver config.adminPasswords).
 */
export const DDL = `
CREATE TABLE IF NOT EXISTS departamento (
  id      SERIAL PRIMARY KEY,
  nombre  TEXT NOT NULL UNIQUE,
  jefe    TEXT NOT NULL DEFAULT '',
  clave   TEXT NOT NULL,
  estado  TEXT NOT NULL DEFAULT 'pendiente' CHECK (estado IN ('pendiente','entregado')),
  fecha   TIMESTAMPTZ,
  obs     TEXT NOT NULL DEFAULT ''
);`;

/* [nombre, jefe, clave, obs] — mismos departamentos y claves que la hoja de Programaciones */
const INICIALES = [
  ['Actividades Complementarias y Extraescolares', 'Castillo Trenado, Jorge', 'ACE2627', 'Plan anual aprobado en claustro. Incluye salidas a Cáceres y Madrid.'],
  ['Artes Plásticas', 'Pérez Martín, Máxima', 'APL2627', 'Incluye materiales específicos por nivel y proyecto de murales.'],
  ['Ciencias Naturales', 'Cosano León, Francisco J.', 'CNT2627', 'En revisión final. Pendiente de incorporar criterios LOMLOE en 1º ESO.'],
  ['Economía', 'Pérez Borrego, Narbella', 'ECO2627', 'Adaptada a LOMLOE en 1º y 2º Bachillerato.'],
  ['Educación Física', 'Ramos Calle, Marco Antonio', 'EFI2627', 'Incluye actividades al aire libre y pruebas de condición física.'],
  ['Filosofía', 'Sánchez Bravo, Eugenio', 'FIL2627', 'Coordinando con Griego y Latín para proyecto interdisciplinar.'],
  ['Física y Química', 'Ramos Sánchez, Ángel Custodio', 'FQU2627', 'Prácticas de laboratorio calendarizadas por trimestre.'],
  ['Formación y orientación laboral', 'Pérez Visus, Marta', 'FOL2627', 'Convenios con empresas locales actualizados.'],
  ['Francés', 'Chendea Boroica, Adriana Daniela', 'FRA2627', 'Pendiente de revisión de criterios de evaluación oral.'],
  ['Geografía e Historia', 'Álvarez Salcedo, Gema', 'GHI2627', 'Incluye proyecto de patrimonio local con el museo de Plasencia.'],
  ['Griego', '', 'GRI2627', 'Falta incorporar la nueva normativa de la EBAU.'],
  ['Inglés', 'Amor Rodríguez, María del Carmen', 'ING2627', 'Programación bilingüe completa. Certificación Cambridge integrada.'],
  ['Latín', 'Fernández Carmona, Pedro Manuel', 'LAT2627', 'Revisando textos clásicos para 2º Bachillerato.'],
  ['Lengua Castellana y Literatura', 'Moreno Rama, Francisco Javier', 'LCL2627', 'Incluye plan lector y club de lectura interdepartamental.'],
  ['Matemáticas', 'García-Miguel Gago, Ana María', 'MAT2627', 'Pendiente de revisión de criterios de calificación en ESO.'],
  ['Música', 'García Aranzabal, Miriam', 'MUS2627', 'Concierto de Navidad y audiciones trimestrales programadas.'],
  ['Orientación', 'Mordillo Serrano, María Luz', 'ORI2627', 'Plan de acción tutorial y orientación académica actualizado.'],
  ['Tecnología', 'Orantos Míguez, M.Puerto', 'TEC2627', 'Adaptando proyectos a los nuevos talleres del centro.'],
  ['Fam. Prof. Informática y Comunicaciones', 'Laguna García, Óscar', 'INF2627', 'Módulos de FCT coordinados con empresas de la comarca.'],
];

/** Siembra los departamentos solo si la tabla está vacía (no pisa datos ya editados) */
export async function sembrar(db) {
  const { rows } = await db.query('SELECT COUNT(*)::int AS n FROM departamento');
  if (rows[0].n > 0) return;
  for (const [nombre, jefe, clave, obs] of INICIALES) {
    await db.query('INSERT INTO departamento (nombre, jefe, clave, obs) VALUES ($1,$2,$3,$4)', [nombre, jefe, clave, obs]);
  }
}
