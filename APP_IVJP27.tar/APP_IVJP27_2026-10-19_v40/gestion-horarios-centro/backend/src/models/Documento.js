/** Un PDF subido por un departamento. El fichero en sí vive en disco (config.uploadsDir); aquí solo el registro. */
export const DDL = `
CREATE TABLE IF NOT EXISTS documento (
  id               SERIAL PRIMARY KEY,
  departamento_id  INT NOT NULL REFERENCES departamento(id) ON DELETE CASCADE,
  nombre           TEXT NOT NULL,
  archivo          TEXT NOT NULL,
  fecha            TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS documento_dep_idx ON documento (departamento_id);`;
