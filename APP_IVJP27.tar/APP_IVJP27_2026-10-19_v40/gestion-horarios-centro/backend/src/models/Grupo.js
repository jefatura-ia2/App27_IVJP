/** Grupo de alumnado (E1A, B2B, 1º CFGB…) */
export const DDL = `
CREATE TABLE IF NOT EXISTS grupo (
  id     SERIAL PRIMARY KEY,
  codigo TEXT NOT NULL UNIQUE
);`;

export async function upsert(db, codigo) {
  const { rows } = await db.query(
    `INSERT INTO grupo (codigo) VALUES ($1) ON CONFLICT (codigo) DO UPDATE SET codigo = EXCLUDED.codigo RETURNING id`, [codigo]);
  return rows[0].id;
}

export async function listar(db) {
  const { rows } = await db.query(`SELECT id, codigo FROM grupo ORDER BY codigo`);
  return rows;
}
