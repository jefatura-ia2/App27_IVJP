/**
 * Guardia de recreo en biblioteca: qué profesor/a de guardia de recreo la hace en la biblioteca.
 * Es una asignación semanal fija (día de la semana + recreo), igual que el resto del horario.
 */
export const DDL = `
CREATE TABLE IF NOT EXISTS guardia_biblioteca (
  dia       SMALLINT NOT NULL CHECK (dia BETWEEN 1 AND 5),
  tramo     TEXT NOT NULL CHECK (tramo IN ('R1','R2')),
  profesor  TEXT NOT NULL,
  creado    TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (dia, tramo, profesor)
);
-- zona de vigilancia del recreo que cubre cada profesor/a de guardia: zona1 (amarilla), zona2 (aguamarina), zona3 (roja) o biblioteca
ALTER TABLE guardia_biblioteca ADD COLUMN IF NOT EXISTS zona TEXT NOT NULL DEFAULT 'biblioteca';`;
export const ZONAS = ['zona1', 'zona2', 'zona3', 'biblioteca'];

export async function listar(db) {
  const { rows } = await db.query('SELECT dia, tramo, profesor, zona FROM guardia_biblioteca ORDER BY dia, tramo, profesor');
  return rows;
}
/** Solo los de la biblioteca (lo que ya usaban la pantalla y el módulo Biblioteca) */
export async function listarBiblioteca(db) {
  return (await listar(db)).filter(r => r.zona === 'biblioteca');
}
