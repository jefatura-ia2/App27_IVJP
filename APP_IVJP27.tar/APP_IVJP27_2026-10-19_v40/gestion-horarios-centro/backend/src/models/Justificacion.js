/**
 * Justificación de ausencias por el propio docente (módulo Ausencias → Justificar ausencia).
 * Una justificación cubre una o varias ausencias del mismo profesor/a: horas marcadas en su cuadrante
 * semanal, horas lectivas y complementarias de cada día, artículo de la Orden de 29/08/2024 y PDF justificantes.
 */
export const DDL = `
CREATE TABLE IF NOT EXISTS justificacion (
  id            SERIAL PRIMARY KEY,
  profesor      TEXT NOT NULL,
  articulo      INT  NOT NULL,
  detalle       JSONB NOT NULL DEFAULT '[]',     -- [{fecha, tramos:[…], lectivas, complementarias}]
  lectivas      INT  NOT NULL DEFAULT 0,
  complementarias INT NOT NULL DEFAULT 0,
  observaciones TEXT NOT NULL DEFAULT '',
  usuario       TEXT NOT NULL DEFAULT '',
  creado        TIMESTAMPTZ NOT NULL DEFAULT now(),
  actualizado   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS justificante (
  id             SERIAL PRIMARY KEY,
  justificacion_id INT NOT NULL REFERENCES justificacion(id) ON DELETE CASCADE,
  nombre         TEXT NOT NULL,
  archivo        TEXT NOT NULL,
  bytes          INT  NOT NULL DEFAULT 0,
  subido         TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE ausencia ADD COLUMN IF NOT EXISTS justificacion_id INT REFERENCES justificacion(id) ON DELETE SET NULL;`;
