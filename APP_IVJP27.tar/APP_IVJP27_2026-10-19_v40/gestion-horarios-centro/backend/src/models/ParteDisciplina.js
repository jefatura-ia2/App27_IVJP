/** Comunicación a Jefatura de Estudios de faltas de disciplina (conductas del Decreto 50/2007) */
export const DDL = `
CREATE TABLE IF NOT EXISTS parte_disciplina (
  id             SERIAL PRIMARY KEY,
  codigo         TEXT UNIQUE,
  profesor       TEXT NOT NULL,             -- «Apellidos, Nombre» de quien comunica
  usuario        TEXT NOT NULL DEFAULT '',  -- cuenta con la que se registró
  materia        TEXT NOT NULL DEFAULT '',
  alumno         TEXT NOT NULL,
  grupo          TEXT NOT NULL,             -- código del horario (E1A, B2B_GEN, 1º DAM…)
  curso          TEXT NOT NULL DEFAULT '',  -- como se escribe en el parte («1º ESO»)
  grupo_letra    TEXT NOT NULL DEFAULT '',  -- como se escribe en el parte («A»)
  fecha          DATE NOT NULL,
  hora           TEXT NOT NULL DEFAULT '',
  contrarias     TEXT[] NOT NULL DEFAULT '{}',   -- claves de las conductas del art. 37
  graves         TEXT[] NOT NULL DEFAULT '{}',   -- claves de las conductas del art. 40
  observaciones  TEXT NOT NULL DEFAULT '',
  etapa          TEXT NOT NULL,             -- eso | bach | fpd | fp
  responsable    TEXT NOT NULL,             -- Jefe/a de Estudios adjunto que lo recibe
  archivo        TEXT NOT NULL DEFAULT '',  -- PDF guardado en la carpeta «disciplina»
  creado         TIMESTAMPTZ NOT NULL DEFAULT now(),
  recibido       TIMESTAMPTZ,
  recibido_por   TEXT NOT NULL DEFAULT '',
  visto          BOOLEAN NOT NULL DEFAULT false   -- el profesor/a ya vio el «recibido»
);
-- copia al tutor/a del grupo (se le notifica en la app)
ALTER TABLE parte_disciplina ADD COLUMN IF NOT EXISTS tutor TEXT NOT NULL DEFAULT '';
ALTER TABLE parte_disciplina ADD COLUMN IF NOT EXISTS tutor_visto TIMESTAMPTZ;
CREATE INDEX IF NOT EXISTS parte_disciplina_prof_idx ON parte_disciplina (profesor);
CREATE INDEX IF NOT EXISTS parte_disciplina_resp_idx ON parte_disciplina (responsable, recibido);`;
