/** Profesor/a. `nombre_norm` permite buscar sin tildes ni mayúsculas. */
export const DDL = `
CREATE TABLE IF NOT EXISTS profesor (
  id          SERIAL PRIMARY KEY,
  nombre      TEXT NOT NULL UNIQUE,          -- "Apellidos, Nombre" tal como viene del horario
  nombre_norm TEXT NOT NULL,
  activo      BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE INDEX IF NOT EXISTS profesor_norm_idx ON profesor (nombre_norm);`;

export const normalizar = s => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '')
  .toLowerCase().replace(/\s+/g, ' ').trim();

export async function upsert(db, nombre) {
  const { rows } = await db.query(
    `INSERT INTO profesor (nombre, nombre_norm, activo) VALUES ($1, $2, TRUE)
     ON CONFLICT (nombre) DO UPDATE SET activo = TRUE, nombre_norm = EXCLUDED.nombre_norm
     RETURNING id`, [nombre, normalizar(nombre)]);
  return rows[0].id;
}

export async function listar(db) {
  const { rows } = await db.query(`SELECT id, nombre FROM profesor WHERE activo ORDER BY nombre_norm`);
  return rows;
}

/** Busca por nombre exacto o normalizado (para casar nombres escritos a mano en la hoja) */
export async function buscarPorNombre(db, nombre) {
  const { rows } = await db.query(
    `SELECT id, nombre FROM profesor WHERE nombre = $1 OR nombre_norm = $2 LIMIT 1`, [nombre, normalizar(nombre)]);
  return rows[0] || null;
}
