/**
 * Reserva de espacios (pestaña «Reserva de espacios» dentro de Aulas).
 *  · espacio: lo que se puede reservar (Jefatura añade, renombra o retira espacios)
 *  · bloqueo_espacio: periodos fijos semanales que nadie puede reservar (los marca Jefatura)
 *  · reserva: una fila por día y tramo reservado; `lote` agrupa las celdas de una misma reserva
 */
export const DDL = `
CREATE TABLE IF NOT EXISTS espacio (
  id      TEXT PRIMARY KEY,
  nombre  TEXT NOT NULL,
  aula    TEXT NOT NULL DEFAULT '',        -- código del aula en el horario (para importar sus clases fijas)
  orden   INT  NOT NULL DEFAULT 100,
  activo  BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE TABLE IF NOT EXISTS bloqueo_espacio (
  espacio  TEXT NOT NULL REFERENCES espacio(id) ON DELETE CASCADE,
  dia      INT  NOT NULL CHECK (dia BETWEEN 1 AND 5),
  tramo    TEXT NOT NULL,
  etiqueta TEXT NOT NULL DEFAULT 'Clase fija',
  PRIMARY KEY (espacio, dia, tramo)
);
CREATE TABLE IF NOT EXISTS reserva (
  id         SERIAL PRIMARY KEY,
  espacio    TEXT NOT NULL REFERENCES espacio(id) ON DELETE CASCADE,
  fecha      DATE NOT NULL,
  tramo      TEXT NOT NULL,
  docente    TEXT NOT NULL,
  materia    TEXT NOT NULL,
  usuario_id INT  REFERENCES usuario(id) ON DELETE SET NULL,
  lote       TEXT NOT NULL,
  creada     TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (espacio, fecha, tramo)
);
CREATE INDEX IF NOT EXISTS reserva_fecha_idx ON reserva (espacio, fecha);`;

export const INICIALES = [
  ['biblioteca', 'Biblioteca', '', 1],
  ['sum', 'SUM (Sala de Usos Múltiples)', '', 2],
  ['a106', '106 (Infolab II)', '106', 3],
  ['a118', '118 (Infolab I)', '118', 4],
  ['a100', 'A100 (Armario de portátiles)', '', 5],
  ['jjee', 'JJEE', '', 6],
];

export async function sembrar(db) {
  const { rows } = await db.query('SELECT COUNT(*)::int AS n FROM espacio');
  if (rows[0].n) return;
  for (const [id, nombre, aula, orden] of INICIALES)
    await db.query('INSERT INTO espacio (id, nombre, aula, orden) VALUES ($1,$2,$3,$4) ON CONFLICT DO NOTHING', [id, nombre, aula, orden]);
}
