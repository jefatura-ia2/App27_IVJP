/**
 * Tramo horario del centro (1ª…13ª hora y recreos R1/R2).
 * La tabla se rellena con TRAMOS_CENTRO al migrar.
 */
export const TRAMOS_CENTRO = [
  { codigo: '1',  inicio: '08:25', fin: '09:20', tipo: 'clase',  turno: 'mañana', orden: 1 },
  { codigo: '2',  inicio: '09:20', fin: '10:15', tipo: 'clase',  turno: 'mañana', orden: 2 },
  { codigo: 'R1', inicio: '10:15', fin: '10:30', tipo: 'recreo', turno: 'mañana', orden: 3 },
  { codigo: '3',  inicio: '10:30', fin: '11:25', tipo: 'clase',  turno: 'mañana', orden: 4 },
  { codigo: '4',  inicio: '11:25', fin: '12:20', tipo: 'clase',  turno: 'mañana', orden: 5 },
  { codigo: 'R2', inicio: '12:20', fin: '12:35', tipo: 'recreo', turno: 'mañana', orden: 6 },
  { codigo: '5',  inicio: '12:35', fin: '13:30', tipo: 'clase',  turno: 'mañana', orden: 7 },
  { codigo: '6',  inicio: '13:30', fin: '14:25', tipo: 'clase',  turno: 'mañana', orden: 8 },
  { codigo: '7',  inicio: '14:25', fin: '15:20', tipo: 'clase',  turno: 'tarde',  orden: 9 },
  { codigo: '8',  inicio: '15:20', fin: '16:15', tipo: 'clase',  turno: 'tarde',  orden: 10 },
  { codigo: '9',  inicio: '16:15', fin: '17:10', tipo: 'clase',  turno: 'tarde',  orden: 11 },
  { codigo: '10', inicio: '17:10', fin: '18:05', tipo: 'clase',  turno: 'tarde',  orden: 12 },
  { codigo: '11', inicio: '18:25', fin: '19:20', tipo: 'clase',  turno: 'tarde',  orden: 13 },
  { codigo: '12', inicio: '19:20', fin: '20:15', tipo: 'clase',  turno: 'tarde',  orden: 14 },
  { codigo: '13', inicio: '20:15', fin: '21:10', tipo: 'clase',  turno: 'tarde',  orden: 15 },
];

export const DDL = `
CREATE TABLE IF NOT EXISTS tramo (
  codigo  TEXT PRIMARY KEY,
  inicio  TIME NOT NULL,
  fin     TIME NOT NULL,
  tipo    TEXT NOT NULL CHECK (tipo IN ('clase','recreo')),
  turno   TEXT NOT NULL,
  orden   INT  NOT NULL UNIQUE
);`;

export async function sembrar(db) {
  for (const t of TRAMOS_CENTRO) {
    await db.query(
      `INSERT INTO tramo (codigo, inicio, fin, tipo, turno, orden) VALUES ($1,$2,$3,$4,$5,$6)
       ON CONFLICT (codigo) DO UPDATE SET inicio=EXCLUDED.inicio, fin=EXCLUDED.fin, tipo=EXCLUDED.tipo,
         turno=EXCLUDED.turno, orden=EXCLUDED.orden`,
      [t.codigo, t.inicio, t.fin, t.tipo, t.turno, t.orden]);
  }
}

export async function listar(db) {
  const { rows } = await db.query(
    `SELECT codigo, to_char(inicio,'HH24:MI') AS inicio, to_char(fin,'HH24:MI') AS fin, tipo, turno, orden
     FROM tramo ORDER BY orden`);
  return rows;
}
