/**
 * Tutorías de grupo: qué profesor/a es tutor/a de cada grupo del horario.
 * Se rellena una vez con el listado oficial de tutores (Tutores_2027.pdf) y luego
 * Jefatura lo mantiene desde la app (Reunión con familias → Tutores).
 */
export const DDL = `
CREATE TABLE IF NOT EXISTS tutoria (
  grupo     TEXT PRIMARY KEY,           -- código del grupo en el horario (E1A, B1B_GEN, 1º SMRD…)
  profesor  TEXT NOT NULL,              -- nombre como en el horario: "Apellidos, Nombre"
  nombre_grupo TEXT NOT NULL DEFAULT '' -- cómo se llama en el listado oficial (opcional)
);
-- delegado/a y subdelegado/a del grupo: los escribe el tutor/a desde la app
ALTER TABLE tutoria ADD COLUMN IF NOT EXISTS delegado    TEXT NOT NULL DEFAULT '';
ALTER TABLE tutoria ADD COLUMN IF NOT EXISTS subdelegado TEXT NOT NULL DEFAULT '';`;

/* Listado de tutores (PDF «Tutores_2027_1», versión actualizada), casado con los nombres y códigos
   del horario. Cambios respecto a la primera versión: E3A ya no figura y se añade B1C
   (en el PDF aparece como segunda línea de «B1D»: José Mª Jiménez, tutor de B1C en el horario). */
export const VERSION_LISTADO = '2027-1';
export const LISTADO = [
  ['E1A', 'Muriel Criado, M. Antonia', '1º ESO A'],
  ['E1B', 'Sánchez Herguijuela, Amelia', '1º ESO B'],
  ['E2A', 'Villamon Blanco, María Eugenia', '2º ESO A'],
  ['E2B', 'Sánchez Bravo, Eugenio', '2º ESO B'],
  ['E3B', 'Ramos Calle, Marco Antonio', '3º ESO B'],
  ['1ºPDC', 'Márquez Blázquez, Pablo', '1º Diversificación (PDC)'],
  ['E4A', 'Castillo Trenado, Jorge', '4º ESO A'],
  ['E4B', 'Mendoza Albalat, Almudena', '4º ESO B'],
  ['2ºPDC', 'Gil Calero, Gregorio Miguel', '2º Diversificación (PDC)'],
  ['1º IOF', 'Pablos Lamas, Antonio Felipe', 'CFGB I'],
  ['2º IOF', 'Donoso Gamero, Juan Pedro', 'CFGB II'],
  ['1º SMRD', 'Fernández Abujeta, Álvaro', '1º SMR diurno'],
  ['2º SMRD', 'Asperilla Moreno, Hugo', '2º SMR diurno'],
  ['1º SMRV', 'Expósito Palomo, Pablo', '1º SMR vespertino'],
  ['2º SMRV', 'Medina Cuadrado, José Miguel', '2º SMR vespertino'],
  ['B1A', 'Amor Rodríguez, María del Carmen', '1º Bachillerato A'],
  ['B1B_GEN', 'Sánchez Riaño, Rosa María', '1º Bachillerato B'],
  ['B1C', 'Jiménez Quijada, José María', '1º Bachillerato C'],
  ['B1D', 'Sánchez Pérez, Amalia', '1º Bachillerato D'],
  ['B2A', 'Moreno Rama, Francisco Javier', '2º Bachillerato A'],
  ['B2B_GEN', 'Barba García, Vicente', '2º Bachillerato B'],
  ['B2C', 'Sánchez Iglesias, Carolina', '2º Bachillerato C'],
  ['B2D', 'Curiel Arroyo, Manuel J.', '2º Bachillerato D'],
  ['1º ASIR', 'Bueno Timón, Amelia', '1º ASIR'],
  ['2º ASIR', 'Mera Ortiz, David', '2º ASIR'],
  ['1º DAM', 'Martín Moriano, Francisco Javier', '1º DAM'],
  ['2º DAM', 'Carretero García, Pablo', '2º DAM'],
  ['1º DAW', 'Sánchez García, Raúl', '1º DAW'],
  ['2º DAW', 'Larios Benítez, David', '2º DAW'],
  ['CECETI', 'Jordán Álvarez, José Alberto', 'CETI'],
  ['DVRV', 'Jarones Bueno, José', 'DVRV'],
];

/* Se aplica el listado oficial una vez por cada versión nueva (después lo mantiene Jefatura).
   Se conservan el delegado/a y el subdelegado/a ya escritos de los grupos que siguen. */
export async function sembrar(db) {
  const { rows } = await db.query("SELECT valor FROM ajuste WHERE clave = 'tutorias_listado'");
  if (rows[0] && rows[0].valor === VERSION_LISTADO) return;
  const grupos = LISTADO.map(x => x[0]);
  await db.query('DELETE FROM tutoria WHERE NOT (grupo = ANY($1))', [grupos]);
  for (const [g, p, n] of LISTADO)
    await db.query(`INSERT INTO tutoria (grupo, profesor, nombre_grupo) VALUES ($1,$2,$3)
      ON CONFLICT (grupo) DO UPDATE SET profesor = EXCLUDED.profesor, nombre_grupo = EXCLUDED.nombre_grupo`, [g, p, n]);
  await db.query(`INSERT INTO ajuste (clave, valor) VALUES ('tutorias_listado', $1)
    ON CONFLICT (clave) DO UPDATE SET valor = EXCLUDED.valor, actualizado = now()`, [VERSION_LISTADO]);
}
