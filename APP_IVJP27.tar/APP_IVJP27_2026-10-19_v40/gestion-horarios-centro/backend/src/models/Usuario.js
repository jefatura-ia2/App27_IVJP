/**
 * Cuentas de acceso a la app (profesorado y administración) y sus sesiones.
 * Las contraseñas se guardan con scrypt + sal; las sesiones, como hash SHA-256 del token
 * (el token solo viaja en una cookie HttpOnly).
 */
export const DDL = `
CREATE TABLE IF NOT EXISTS usuario (
  id             SERIAL PRIMARY KEY,
  usuario        TEXT NOT NULL UNIQUE,
  nombre         TEXT NOT NULL DEFAULT '',
  rol            TEXT NOT NULL DEFAULT 'profesor' CHECK (rol IN ('profesor','admin')),
  clave_hash     TEXT NOT NULL,
  cambiar_clave  BOOLEAN NOT NULL DEFAULT TRUE,
  activo         BOOLEAN NOT NULL DEFAULT TRUE,
  creado         TIMESTAMPTZ NOT NULL DEFAULT now(),
  ultimo_acceso  TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS sesion (
  token_hash  TEXT PRIMARY KEY,
  usuario_id  INT NOT NULL REFERENCES usuario(id) ON DELETE CASCADE,
  creada      TIMESTAMPTZ NOT NULL DEFAULT now(),
  caduca      TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS sesion_usuario_idx ON sesion (usuario_id);
-- datos de contacto que cada docente rellena al entrar; los años trabajados sirven para calcular sus días de asuntos propios
ALTER TABLE usuario ADD COLUMN IF NOT EXISTS email TEXT NOT NULL DEFAULT '';
ALTER TABLE usuario ADD COLUMN IF NOT EXISTS movil TEXT NOT NULL DEFAULT '';
ALTER TABLE usuario ADD COLUMN IF NOT EXISTS anios_servicio INT;
ALTER TABLE usuario ADD COLUMN IF NOT EXISTS datos_fecha DATE;`;
