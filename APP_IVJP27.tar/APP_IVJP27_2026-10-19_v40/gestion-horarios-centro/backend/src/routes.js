import { Router } from 'express';
import * as horarios from './controllers/horariosController.js';
import * as aulas from './controllers/aulasController.js';
import * as guardias from './controllers/guardiasController.js';
import * as sync from './controllers/syncController.js';
import * as prog from './controllers/programacionesController.js';
import * as edicion from './controllers/edicionController.js';
import * as biblioteca from './controllers/bibliotecaController.js';
import * as auth from './controllers/authController.js';
import * as ausencias from './controllers/ausenciasController.js';
import * as tutoria from './controllers/tutoriaController.js';
import * as reserva from './controllers/reservaController.js';
import * as meet from './controllers/meetController.js';
import * as servicio from './controllers/servicioController.js';
import * as justif from './controllers/justificacionController.js';
import * as panel from './controllers/panelController.js';
import * as crono from './controllers/cronologiaController.js';
import * as disciplina from './controllers/disciplinaController.js';
import { validarDoc } from './services/firma.js';

/* Express 4 no captura promesas rechazadas: este envoltorio las pasa al manejador de errores */
const a = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

export const rutas = Router();
rutas.get('/salud', (req, res) => res.json({ ok: true }));

/* Acceso: lo único público es /salud y el inicio de sesión; todo lo demás exige sesión */
rutas.post('/auth/login', a(auth.login));
rutas.post('/sync', sync.soloAdmin, a(sync.sincronizar));   /* para scripts: protegido con X-Admin-Token */
/* PDF de programaciones con enlace firmado (?f=…): se abren sin sesión desde el navegador del móvil */
rutas.get('/programaciones/:id/documentos/:docId/archivo', a(async (req, res, next) => {
  if (req.query.f && await validarDoc(Number(req.params.docId), req.query.f)) return prog.archivo(req, res);
  next();
}));
/* Panel de la sala de profesores: pantalla sin sesión con enlace secreto (solo lectura) */
rutas.get('/panel/datos', a(panel.datos));
rutas.get('/panel/hoy', a(auth.panelHoy));
rutas.get('/panel/biblioteca-hoy', a(auth.panelBibliotecaHoy));   /* cuadrante de la Biblioteca (módulo Biblioteca) */   /* cuadrante del día para el profesorado con sesión (Guardias y Biblioteca) */
rutas.get('/cronologia/reunion/:id', a(crono.reunion));   /* pública: página de las familias */
rutas.use(auth.requiereSesion);
rutas.get('/auth/yo', a(auth.yo));
rutas.post('/auth/logout', a(auth.logout));
rutas.post('/auth/cambiar-clave', a(auth.cambiarClave));
rutas.put('/auth/mis-datos', a(auth.misDatos));
rutas.get('/dap/ficha', a(auth.fichaDap));
rutas.get('/departamento-de', a(auth.departamentoDe));
rutas.put('/departamento-de', auth.soloAdminCuenta, a(auth.asignarDepartamento));
rutas.get('/dap/contadores', auth.soloAdminCuenta, a(auth.contadoresDap));

/* Disciplina: partes de conductas contrarias (profesorado) y bandeja de los Jefes/as de Estudios adjuntos */
rutas.get('/disciplina/config', a(disciplina.config));
rutas.get('/disciplina/mios', a(disciplina.mios));
rutas.get('/disciplina/bandeja', a(disciplina.bandeja));
rutas.get('/disciplina/resumen', a(disciplina.resumen));
rutas.get('/disciplina/carpeta', a(disciplina.carpeta));
rutas.get('/disciplina/tutoria', a(disciplina.tutoria));
rutas.post('/disciplina/:id/leido-tutor', a(disciplina.leidoTutor));
rutas.get('/disciplina/carpeta/archivo', a(disciplina.archivoCarpeta));
rutas.post('/disciplina', a(disciplina.crear));
rutas.post('/disciplina/:id/recibido', a(disciplina.recibido));
rutas.post('/disciplina/:id/visto', a(disciplina.visto));
rutas.get('/disciplina/:id/pdf', a(disciplina.pdf));

/* Cuentas de usuario (solo cuentas con rol administración) */
rutas.get('/usuarios', auth.soloAdminCuenta, a(auth.listar));
rutas.post('/usuarios', auth.soloAdminCuenta, a(auth.crear));
rutas.post('/usuarios/lote', auth.soloAdminCuenta, a(auth.lote));
rutas.put('/usuarios/:id', auth.soloAdminCuenta, a(auth.actualizar));
rutas.post('/usuarios/:id/restablecer', auth.soloAdminCuenta, a(auth.restablecer));
rutas.delete('/usuarios/:id', auth.soloAdminCuenta, a(auth.borrar));

rutas.get('/tramos', a(horarios.tramos));
rutas.get('/profesores', a(horarios.profesores));
rutas.get('/grupos', a(horarios.grupos));
rutas.get('/buscar', a(horarios.buscar));
rutas.get('/horario.csv', a(horarios.csv));
rutas.get('/horarios/:tipo/:id', a(horarios.horarioDe));

rutas.get('/aulas', a(aulas.listar));
rutas.get('/aulas/libres', a(aulas.libres));
rutas.get('/aulas/:id/ocupacion', a(aulas.ocupacion));

rutas.get('/guardias/ahora', a(guardias.ahora));
rutas.get('/guardias', a(guardias.delDia));
rutas.get('/panel/config', auth.soloAdminCuenta, a(panel.config));
rutas.put('/panel/config', auth.soloAdminCuenta, a(panel.guardar));

rutas.get('/sync/estado', a(sync.estado));

/* Programaciones didácticas: login de admin y de jefes/as de departamento, subida de PDF */
rutas.get('/programaciones', a(prog.listar));
rutas.post('/programaciones', a(prog.crear));
rutas.post('/programaciones/login-admin', a(prog.loginAdmin));
rutas.post('/programaciones/:id/login', a(prog.loginJefe));
rutas.post('/programaciones/:id/documentos', prog.subirMiddleware, a(prog.subir));
rutas.get('/programaciones/:id/documentos/:docId/archivo', a(prog.archivo));
rutas.delete('/programaciones/:id/documentos/:docId', a(prog.borrarDoc));
rutas.put('/programaciones/:id/observaciones', a(prog.obs));
rutas.put('/programaciones/:id/jefe', a(prog.jefe));
rutas.put('/programaciones/:id/clave', a(prog.clave));
rutas.put('/programaciones/:id/estado', a(prog.estado));
rutas.post('/programaciones/:id/anular', a(prog.anular));

/* Edición del horario desde la app (administración) */
rutas.post('/sesiones/cambiar', edicion.soloAdmin, a(edicion.cambiar));
rutas.post('/horario/importar', edicion.soloAdmin, a(edicion.importar));
/* Enlaces de Meet de las evaluaciones (Cronología) */
/* Cronograma de la Cronología (evaluaciones, reuniones…): lo graba Jefatura, lo ve todo el claustro */
rutas.get('/cronologia', a(crono.leer));
rutas.put('/cronologia', a(crono.guardar));
rutas.get('/meet', a(meet.listar));
rutas.put('/meet/:evento', a(meet.guardar));

/* Reserva de espacios (pestaña de Aulas) */
rutas.get('/reservas/espacios', a(reserva.inicio));
rutas.get('/reservas', a(reserva.semana));
rutas.post('/reservas', a(reserva.reservar));
rutas.delete('/reservas/:id', a(reserva.anular));
rutas.post('/reservas/espacios', auth.soloAdminCuenta, a(reserva.crearEspacio));
rutas.put('/reservas/espacios/:id', auth.soloAdminCuenta, a(reserva.cambiarEspacio));
rutas.put('/reservas/espacios/:id/bloqueo', auth.soloAdminCuenta, a(reserva.bloquear));
rutas.post('/reservas/espacios/:id/bloqueo-horario', auth.soloAdminCuenta, a(reserva.bloquearDesdeHorario));

/* Reunión con familias: presentación del tutor/a con los datos de su grupo */
rutas.get('/tutoria/mia', a(tutoria.mia));
rutas.get('/tutoria/grupo/:grupo', a(tutoria.grupo));
rutas.put('/tutoria/grupo/:grupo/delegados', a(tutoria.delegados));
rutas.get('/tutorias', auth.soloAdminCuenta, a(tutoria.listar));
rutas.put('/tutorias/:grupo', auth.soloAdminCuenta, a(tutoria.asignar));
rutas.put('/tutoria/reunion', auth.soloAdminCuenta, a(tutoria.guardarReunion));
rutas.get('/horario/carga', auth.soloAdminCuenta, a(edicion.estado));
rutas.post('/horario/previa', edicion.soloAdmin, a(edicion.previa));
rutas.post('/horario/restaurar', edicion.soloAdmin, a(edicion.restaurar));

/* Guardia de recreo en biblioteca (se marca en Guardias de recreo, se ve en Biblioteca) */
rutas.get('/biblioteca/recreos', a(biblioteca.listar));
rutas.post('/biblioteca/recreos', edicion.soloAdmin, a(biblioteca.marcar));
rutas.post('/recreo/zona', a(biblioteca.zonaRecreo));   /* zonas de vigilancia del recreo: cada docente se apunta */
/* G.B. y MAY55: lo ve todo el claustro; lo editan las cuentas con perfil Biblioteca (y Jefatura) con la clave */
rutas.get('/biblioteca/registros', a(biblioteca.registros));
rutas.put('/biblioteca/registros', a(biblioteca.guardar));
rutas.post('/biblioteca/acceso', a(biblioteca.acceso));
rutas.post('/biblioteca/importar-hoja', a(biblioteca.importarHoja));
rutas.get('/biblioteca/clave', auth.soloAdminCuenta, a(biblioteca.estadoClave));
rutas.put('/biblioteca/clave', auth.soloAdminCuenta, a(biblioteca.fijarClave));

/* Notificar ausencia: cada profesor/a solo las suyas; administración, de cualquiera */
rutas.post('/ausencias/notificar', a(ausencias.notificar));
rutas.get('/ausencias/mias', a(ausencias.mias));
rutas.put('/ausencias/:id/tareas', a(ausencias.tareas));
rutas.post('/ausencias/informe', a(ausencias.informe));
rutas.post('/ausencias/importar-hoja', a(ausencias.importarHoja));
rutas.post('/ausencias/dossier', a(ausencias.dossier));
/* Justificación de ausencias (cada docente, las suyas) */
rutas.get('/justificaciones/mias', a(justif.mias));
rutas.post('/justificaciones', justif.subirPDFs, a(justif.crear));
rutas.post('/justificaciones/:id/documentos', justif.subirPDFs, a(justif.añadirDocs));
rutas.delete('/justificaciones/:id/documentos/:docId', a(justif.borrarDoc));
rutas.delete('/justificaciones/:id', a(justif.borrar));
rutas.get('/justificaciones/:id/documentos/:docId/archivo', a(justif.archivo));
/* Avisos, calendarios y ausencias (antes en la hoja de Google, ahora en la base de datos) */
rutas.get('/servicio', a(servicio.get));
rutas.post('/servicio', a(servicio.post));
