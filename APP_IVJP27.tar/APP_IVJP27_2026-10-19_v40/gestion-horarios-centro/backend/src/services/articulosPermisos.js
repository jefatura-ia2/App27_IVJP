/**
 * Motivos de ausencia según la ORDEN de 29 de agosto de 2024 por la que se regula el régimen de permisos del
 * personal docente (Consejería de Educación, Junta de Extremadura) — DOE núm. 169, de 30 de agosto de 2024.
 * Solo los artículos que regulan permisos, licencias o reducciones (quedan fuera el 1, 19 y 33 a 36, que son
 * de objeto, efectos y procedimiento). `doc` es una orientación de la documentación justificativa que cita la
 * orden; la referencia válida es siempre el texto publicado en el DOE.
 */
export const ORDEN = 'Orden de 29 de agosto de 2024 (DOE n.º 169, de 30/08/2024)';
export const ARTICULOS = [
  { n: 2, t: 'Permiso por fallecimiento, accidente o enfermedad grave, por hospitalización o intervención quirúrgica de un familiar', doc: 'Libro de familia o registro de parejas y certificado de defunción, hospitalización o documento médico, según el caso.' },
  { n: 3, t: 'Permiso por enfermedad propia', doc: 'Parte de baja y confirmación; para menos de cuatro días, justificante de la consulta (el primer día admite declaración responsable).' },
  { n: 4, t: 'Permiso por traslado de domicilio', doc: 'Justificante de la mudanza, contrato de alquiler o compraventa y certificado de empadronamiento.' },
  { n: 5, t: 'Permiso por lactancia', doc: 'Libro de familia o inscripción del nacimiento en el Registro Civil.' },
  { n: 6, t: 'Permiso por nacimientos prematuros o menores que por cualquier otra causa deban permanecer hospitalizados a continuación del parto', doc: 'Inscripción del nacimiento y documento que acredite la hospitalización o la prematuridad.' },
  { n: 7, t: 'Permiso para la realización de exámenes prenatales y técnicas de preparación al parto', doc: 'Documento que justifique la necesidad dentro de la jornada y justificante de asistencia.' },
  { n: 8, t: 'Permiso para técnicas de fecundación o reproducción asistida', doc: 'Documento que justifique la necesidad del tratamiento dentro de la jornada.' },
  { n: 9, t: 'Permiso por interrupción voluntaria del embarazo', doc: 'Documentación acreditativa del hecho causante.' },
  { n: 10, t: 'Permiso por matrimonio o pareja de hecho', doc: 'Libro de familia o inscripción en el registro de parejas de hecho.' },
  { n: 11, t: 'Permiso para el cumplimiento de un deber inexcusable de carácter público o personal y por deberes relacionados con la conciliación de la vida familiar y laboral', doc: 'Citación o convocatoria oficial; para conciliación, justificante de la cita o reunión.' },
  { n: 12, t: 'Permiso por causa de fuerza mayor', doc: 'Documento que acredite la causa o, en su defecto, declaración responsable.' },
  { n: 13, t: 'Permiso por asuntos particulares', doc: 'Justificación de la circunstancia sobrevenida o, excepcionalmente, declaración responsable.' },
  { n: 14, t: 'Permiso para realización de funciones sindicales, de formación sindical o de representación del personal', doc: 'Acreditación de la actividad sindical o de representación.' },
  { n: 15, t: 'Permiso para concurrir a exámenes finales, pruebas obligatorias de aptitud, evaluación en centros oficiales y pruebas selectivas en el ámbito del empleo público', doc: 'Certificado de asistencia con lugar, fecha y centro.' },
  { n: 16, t: 'Permiso por nacimiento para la madre biológica', doc: 'Certificado de nacimiento, informe de maternidad o libro de familia.' },
  { n: 17, t: 'Permiso por adopción, por guarda con fines de adopción, o acogimiento de un menor, tanto temporal como permanente', doc: 'Resolución administrativa o judicial de adopción, guarda o acogimiento.' },
  { n: 18, t: 'Permiso de la persona progenitora diferente de la madre biológica por nacimiento, guarda con fines de adopción, acogimiento o adopción de un hijo o hija menor', doc: 'Documentación del nacimiento, adopción, guarda o acogimiento.' },
  { n: 20, t: 'Permiso por asuntos propios no retribuidos', doc: 'Resolución o autorización del permiso.' },
  { n: 21, t: 'Permiso parental para el cuidado de hijo, hija o menor acogido por tiempo superior a un año, hasta el momento en que el menor cumpla ocho años', doc: 'Resolución del permiso y certificado de no haberlo disfrutado antes (o del tiempo disfrutado).' },
  { n: 22, t: 'Permisos por razón de violencia de género', doc: 'Acreditación por alguna de las fórmulas de la Ley 11/2007.' },
  { n: 23, t: 'Permisos para las víctimas de terrorismo y sus familiares directos', doc: 'Acreditación de la condición de víctima o de persona amenazada.' },
  { n: 24, t: 'Licencia por estudios', doc: 'Resolución de concesión de la licencia.' },
  { n: 25, t: 'Permisos para la asistencia a actividades de formación del profesorado', doc: 'Autorización previa y certificado de asistencia a la actividad.' },
  { n: 26, t: 'Permisos parcialmente retribuidos del personal docente no universitario', doc: 'Resolución de concesión del permiso.' },
  { n: 27, t: 'Adaptación de jornada por proceso de recuperación de enfermedad grave', doc: 'Documento médico que acredite la enfermedad grave.' },
  { n: 28, t: 'Reducción de jornada de trabajo por interés particular', doc: 'Resolución de concesión de la reducción.' },
  { n: 29, t: 'Reducción de jornada por guarda legal', doc: 'Resolución de la reducción y documentación de la guarda legal.' },
  { n: 30, t: 'Reducción de jornada por cuidado de un familiar', doc: 'Libro de familia y documento médico del familiar.' },
  { n: 31, t: 'Reducción de jornada para atender el cuidado de hija o hijo de hasta 23 años que padezca cáncer u otra enfermedad grave', doc: 'Informe médico del menor y libro de familia.' },
  { n: 32, t: 'Reducción de jornada para mayores de 55 años', doc: 'Resolución de concesión de la reducción.' },
];
export const articulo = n => ARTICULOS.find(a => a.n === Number(n)) || null;
export const etiqueta = a => `Art. ${a.n}. ${a.t}`;
