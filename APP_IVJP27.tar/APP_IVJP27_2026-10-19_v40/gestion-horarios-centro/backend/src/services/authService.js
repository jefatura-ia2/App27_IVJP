/**
 * Acceso a la app con usuario y contraseña (cuentas creadas por la administración).
 */
import crypto from 'node:crypto';
import { promisify } from 'node:util';
import { query } from '../db.js';
import { config } from '../config.js';

const scrypt = promisify(crypto.scrypt);
const err = (msg, status = 400) => Object.assign(new Error(msg), { status });
const sha = t => crypto.createHash('sha256').update(t).digest('hex');
export const DIAS_SESION = 30;

/* ---------- contraseñas ---------- */
export async function hashClave(clave) {
  const sal = crypto.randomBytes(16);
  const h = await scrypt(String(clave), sal, 64);
  return 'scrypt$' + sal.toString('hex') + '$' + h.toString('hex');
}
export async function verificarClave(clave, guardado) {
  const [tipo, salHex, hHex] = String(guardado || '').split('$');
  if (tipo !== 'scrypt' || !salHex || !hHex) return false;
  const h = await scrypt(String(clave), Buffer.from(salHex, 'hex'), 64);
  const esperado = Buffer.from(hHex, 'hex');
  return esperado.length === h.length && crypto.timingSafeEqual(esperado, h);
}
/** Contraseña fácil de dictar: sin 0/O ni 1/l/I */
export function claveAleatoria(n = 8) {
  const abc = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  return Array.from(crypto.randomBytes(n), b => abc[b % abc.length]).join('');
}
export function validarClaveNueva(c) {
  c = String(c || '');
  if (c.length < 8) throw err('La contraseña debe tener al menos 8 caracteres');
  if (!/[A-Za-z]/.test(c) || !/[0-9]/.test(c)) throw err('La contraseña debe tener letras y números');
}
const normUsuario = u => String(u || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9._-]/g, '');

/* ---------- freno a los intentos fallidos (por usuario+IP, en memoria) ---------- */
const fallos = new Map();
const MAX_FALLOS = 5, BLOQUEO_MS = 15 * 60 * 1000;
function comprobarBloqueo(k) {
  const f = fallos.get(k);
  if (f && f.n >= MAX_FALLOS && Date.now() - f.t < BLOQUEO_MS) throw err('Demasiados intentos. Espera 15 minutos o pide a Jefatura que restablezca tu contraseña.', 429);
}
function anotarFallo(k) { const f = fallos.get(k); const n = f && Date.now() - f.t < BLOQUEO_MS ? f.n + 1 : 1; fallos.set(k, { n, t: Date.now() }); }

/* ---------- sesiones ---------- */
const faltanDatos = u => u.rol !== 'admin' && (!u.email || !u.movil || u.anios_servicio === null || u.anios_servicio === undefined);
const publico = u => ({ id: u.id, usuario: u.usuario, nombre: u.nombre, rol: u.rol, cambiarClave: u.cambiar_clave, perfiles: u.perfiles || [],
  email: u.email || '', movil: u.movil || '', aniosServicio: u.anios_servicio ?? null, datosPendientes: faltanDatos(u) });

/* ---------- datos del docente: correo de Educarex, móvil y años trabajados ---------- */
export function limpiarDatos({ email, movil, anios } = {}) {
  const e = String(email || '').trim().toLowerCase();
  if (!/^[a-z0-9._%+-]+@educarex\.es$/.test(e)) throw err('Escribe tu cuenta de correo de Educarex (termina en @educarex.es)');
  let m = String(movil || '').replace(/[\s.()-]/g, '').replace(/^(\+|00)34/, '');
  if (!/^[67]\d{8}$/.test(m)) throw err('Escribe un teléfono móvil de 9 cifras (empieza por 6 o 7)');
  const a = String(anios ?? '').trim();
  if (!/^\d{1,2}$/.test(a) || +a > 50) throw err('Escribe los años trabajados (un número entre 0 y 50)');
  return { email: e, movil: m.replace(/(\d{3})(\d{3})(\d{3})/, '$1 $2 $3'), anios: +a };
}
export async function guardarDatos(id, datos) {
  const d = limpiarDatos(datos);
  const { rows } = await query(`UPDATE usuario SET email = $2, movil = $3, anios_servicio = $4, datos_fecha = CURRENT_DATE WHERE id = $1 RETURNING *`,
    [id, d.email, d.movil, d.anios]);
  if (!rows[0]) throw err('Usuario no encontrado', 404);
  return publico(rows[0]);
}
/** Perfiles extra que Jefatura puede dar a una cuenta */
export const PERFILES = ['biblioteca'];

export async function login(usuario, clave, ip) {
  const u0 = normUsuario(usuario);
  const k = u0 + '|' + ip;
  comprobarBloqueo(k);
  const { rows } = await query('SELECT * FROM usuario WHERE usuario = $1', [u0]);
  const u = rows[0];
  if (!u || !u.activo || !(await verificarClave(clave, u.clave_hash))) { anotarFallo(k); throw err('Usuario o contraseña incorrectos', 401); }
  fallos.delete(k);
  const token = crypto.randomBytes(32).toString('base64url');
  await query(`INSERT INTO sesion (token_hash, usuario_id, caduca) VALUES ($1,$2, now() + ($3 || ' days')::interval)`, [sha(token), u.id, String(DIAS_SESION)]);
  await query('UPDATE usuario SET ultimo_acceso = now() WHERE id = $1', [u.id]);
  await query('DELETE FROM sesion WHERE caduca < now()');
  return { token, usuario: publico(u) };
}

/** Usuario de la sesión (o null). Renueva la caducidad al usarse. */
export async function deSesion(token) {
  if (!token) return null;
  const { rows } = await query(
    `UPDATE sesion s SET caduca = now() + ($2 || ' days')::interval
     FROM usuario u WHERE s.token_hash = $1 AND s.usuario_id = u.id AND s.caduca > now() AND u.activo
     RETURNING u.*`, [sha(token), String(DIAS_SESION)]);
  return rows[0] ? publico(rows[0]) : null;
}
export async function logout(token) { if (token) await query('DELETE FROM sesion WHERE token_hash = $1', [sha(token)]); }

export async function cambiarClave(id, actual, nueva) {
  const { rows } = await query('SELECT clave_hash FROM usuario WHERE id = $1', [id]);
  if (!rows[0] || !(await verificarClave(actual, rows[0].clave_hash))) throw err('La contraseña actual no es correcta', 401);
  validarClaveNueva(nueva);
  if (actual === nueva) throw err('La nueva contraseña debe ser distinta de la actual');
  await query('UPDATE usuario SET clave_hash = $2, cambiar_clave = FALSE WHERE id = $1', [id, await hashClave(nueva)]);
}

/** Nombre del profesor/a del horario que corresponde a la cuenta (por su nombre, sin tildes ni mayúsculas) */
const normProf = t => String(t || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
export async function profesorDeCuenta(nombre) {
  const n = normProf(nombre);
  if (!n) return null;
  const { rows } = await query('SELECT nombre FROM profesor WHERE nombre_norm = $1 AND activo', [n]);
  return rows[0] ? rows[0].nombre : null;
}

/* ---------- administración de cuentas ---------- */
export async function listar() {
  const { rows } = await query(
    `SELECT id, usuario, nombre, rol, activo, cambiar_clave AS "cambiarClave", perfiles, email, movil, anios_servicio AS "aniosServicio",
            COALESCE(to_char(datos_fecha, 'DD/MM/YYYY'), '') AS "datosFecha",
            to_char(ultimo_acceso AT TIME ZONE $1, 'DD/MM/YYYY HH24:MI') AS "ultimoAcceso"
     FROM usuario ORDER BY (rol = 'admin') DESC, nombre, usuario`, [config.tz]);
  const { rows: profs } = await query('SELECT nombre, nombre_norm FROM profesor WHERE activo');
  const mapa = new Map(profs.map(p => [p.nombre_norm, p.nombre]));
  return rows.map(u => ({ ...u, profesor: mapa.get(normProf(u.nombre)) || null }));
}

/** Propone un nombre de usuario a partir de «Apellidos, Nombre»: inicial del nombre + primer apellido */
export function proponerUsuario(nombre) {
  const [ap, no] = String(nombre).split(',').map(s => s.trim());
  const base = normUsuario(((no || '')[0] || '') + (ap || nombre).split(/\s+/)[0]);
  return base || 'usuario';
}
async function libre(base) {
  let u = base, i = 2;
  while ((await query('SELECT 1 FROM usuario WHERE usuario = $1', [u])).rowCount) u = base + i++;
  return u;
}

export async function crear({ usuario, nombre, rol, clave }) {
  nombre = String(nombre || '').trim();
  let u = normUsuario(usuario) || proponerUsuario(nombre);
  if (normUsuario(usuario)) {
    if ((await query('SELECT 1 FROM usuario WHERE usuario = $1', [u])).rowCount) throw err('Ya existe el usuario «' + u + '»');
  } else u = await libre(u);
  const c = clave ? String(clave) : claveAleatoria();
  if (clave) validarClaveNueva(c);
  const r = rol === 'admin' ? 'admin' : 'profesor';
  const { rows } = await query(
    'INSERT INTO usuario (usuario, nombre, rol, clave_hash, cambiar_clave) VALUES ($1,$2,$3,$4,TRUE) RETURNING id',
    [u, nombre, r, await hashClave(c)]);
  return { id: rows[0].id, usuario: u, nombre, rol: r, clave: c };
}

/** Crea de una vez las cuentas del profesorado que aún no tiene (por nombre) */
export async function crearLote(nombres) {
  const { rows } = await query('SELECT nombre FROM usuario');
  const ya = new Set(rows.map(r => r.nombre));
  const hechas = [];
  for (const n of [...new Set((nombres || []).map(s => String(s).trim()).filter(Boolean))]) {
    if (ya.has(n)) continue;
    hechas.push(await crear({ nombre: n, rol: 'profesor' }));
  }
  return hechas;
}

export async function actualizar(id, { nombre, rol, activo, perfiles }, yo) {
  const { rows } = await query('SELECT * FROM usuario WHERE id = $1', [id]);
  const u = rows[0];
  if (!u) throw err('Usuario no encontrado', 404);
  const nRol = rol === undefined ? u.rol : (rol === 'admin' ? 'admin' : 'profesor');
  const nAct = activo === undefined ? u.activo : !!activo;
  if (u.id === yo.id && (nRol !== 'admin' || !nAct)) throw err('No puedes quitarte a ti mismo el acceso de administración');
  const nPerf = Array.isArray(perfiles) ? PERFILES.filter(p => perfiles.includes(p)) : (u.perfiles || []);
  await query('UPDATE usuario SET nombre = $2, rol = $3, activo = $4, perfiles = $5 WHERE id = $1', [id, nombre === undefined ? u.nombre : String(nombre).trim(), nRol, nAct, nPerf]);
  if (!nAct) await query('DELETE FROM sesion WHERE usuario_id = $1', [id]);
}

export async function restablecer(id) {
  const { rows: r0 } = await query('SELECT usuario FROM usuario WHERE id = $1', [id]);
  if (r0[0]) for (const k of fallos.keys()) if (k.startsWith(r0[0].usuario + '|')) fallos.delete(k);   /* desbloquea */
  const c = claveAleatoria();
  const { rowCount } = await query('UPDATE usuario SET clave_hash = $2, cambiar_clave = TRUE WHERE id = $1', [id, await hashClave(c)]);
  if (!rowCount) throw err('Usuario no encontrado', 404);
  await query('DELETE FROM sesion WHERE usuario_id = $1', [id]);
  return { clave: c };
}

export async function borrar(id, yo) {
  if (Number(id) === yo.id) throw err('No puedes borrar tu propia cuenta');
  await query('DELETE FROM usuario WHERE id = $1', [id]);
}

/** Primera instalación: si no hay ninguna cuenta, crea «jefatura» (admin) con ADMIN_PASSWORD */
export async function sembrar(db) {
  const { rows } = await db.query('SELECT COUNT(*)::int AS n FROM usuario');
  if (rows[0].n > 0) return;
  await db.query(
    "INSERT INTO usuario (usuario, nombre, rol, clave_hash, cambiar_clave) VALUES ('jefatura','Jefatura de Estudios','admin',$1,TRUE)",
    [await hashClave(config.adminPasswords[0] || 'cambiar-ya-2026')]);
  console.log('Creada la cuenta inicial «jefatura» (contraseña = ADMIN_PASSWORD; se pedirá cambiarla al entrar).');
}
