/**
 * Calendario de asuntos propios (DAP) → ausencias.
 * Jefatura apunta los días de asuntos propios en el calendario de Google «Asuntos propios (DAP)» (el que se enlaza
 * en Calendarios). El servidor lo lee y crea, para cada evento, la ausencia GRABADA del profesor/a con motivo
 * «Asuntos propios (DAP)». Si el evento cambia o se borra del calendario, la ausencia se actualiza o se quita.
 *  · El profesor/a se reconoce por el nombre escrito en el título (o la descripción) del evento.
 *    Los eventos que no se reconocen quedan en una lista para que Jefatura diga de quién son (se recuerda).
 *  · Evento de día completo → ausencia de todo el día; evento con hora → solo los tramos que abarca.
 *  · Las ausencias que vienen del calendario tienen id «dap-…»; si Jefatura ya grabó a mano una ausencia de ese
 *    profesor/a para ese día, no se duplica.
 */
import crypto from 'node:crypto';
import { query, transaccion } from '../db.js';
import { Ajuste, Profesor, Tramo } from '../models/index.js';
import { leerCalendario } from './extraescolaresService.js';
import { ahora } from './tiempo.js';
const hoy = () => ahora().fecha;

export const MOTIVO_DAP = 'Asuntos propios (DAP)';
const ALIAS = 'dap_alias';            /* { "texto normalizado del título": "Apellidos, Nombre" | "-" (ignorar) } */
const ESTADO = 'dap_estado';
const PREFIJO = 'dap-';
const DIAS_ATRAS = 120, DIAS_ADELANTE = 300;

const norm = Profesor.normalizar;
const sumarDias = (iso, n) => { const d = new Date(iso + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const palabras = t => norm(t).replace(/[^a-zñ0-9 ]/g, ' ').split(' ').filter(w => w.length > 1);
/* lo que no forma parte del nombre en un título típico: «DAP - Pérez García», «Asuntos propios: Ana López (1ª-3ª)» */
const RUIDO = new Set(['dap', 'dia', 'dias', 'asunto', 'asuntos', 'propio', 'propios', 'particular', 'particulares', 'de', 'del', 'la', 'el', 'los', 'las', 'y', 'prof', 'profe', 'profesor', 'profesora', 'd', 'don', 'dona', 'hora', 'horas', 'todo', 'manana', 'tarde']);
export const claveTitulo = t => palabras(t).filter(w => !RUIDO.has(w) && !/^\d/.test(w)).join(' ');

/**
 * Reconoce al profesor/a del texto. Cada profesor/a ("Apellidos, Nombre") puntúa por las palabras de su nombre
 * que aparecen: hacen falta al menos dos (p. ej. nombre + primer apellido, o los dos apellidos), o el primer
 * apellido si es único en el claustro. Gana el de más puntos solo si no hay empate.
 */
export function reconocer(texto, profesores) {
  const w = new Set(palabras(texto));
  if (!w.size) return null;
  const cand = profesores.map(p => {
    const [ap = '', nom = ''] = String(p.nombre).split(',');
    const aps = palabras(ap), noms = palabras(nom);
    const hitsAp = aps.filter(x => w.has(x)).length, hitsNom = noms.filter(x => w.has(x)).length;
    return { p, aps, puntos: hitsAp * 2 + hitsNom, hitsAp, hitsNom };
  }).filter(c => c.hitsAp && (c.hitsAp + c.hitsNom >= 2 || c.hitsAp === c.aps.length));
  if (!cand.length) return null;
  cand.sort((a, b) => b.puntos - a.puntos);
  if (cand[1] && cand[1].puntos === cand[0].puntos) {
    /* empate: vale el primer apellido solo si únicamente uno de ellos lo tiene */
    const conPrimero = cand.filter(c => c.puntos === cand[0].puntos && w.has(c.aps[0]));
    return conPrimero.length === 1 ? conPrimero[0].p : null;
  }
  return cand[0].p;
}

/** Tramos (códigos) que solapa un intervalo HH:MM–HH:MM; sin hora → [] (todo el día) */
export function tramosEntre(ini, fin, tramos) {
  if (!ini) return [];
  const m = h => { const [a, b] = String(h).split(':').map(Number); return a * 60 + (b || 0); };
  const a = m(ini), b = fin ? m(fin) : a + 1;
  return tramos.filter(t => t.tipo !== 'recreo' && m(t.inicio) < b && m(t.fin) > a).map(t => String(t.codigo));
}

const idDe = (uid, fecha, titulo) => PREFIJO + crypto.createHash('sha1').update((uid || titulo) + '|' + fecha).digest('hex').slice(0, 16);

async function leerAlias() { try { return JSON.parse(await Ajuste.leer({ query }, ALIAS) || '{}'); } catch { return {}; } }

/**
 * Lee el calendario y deja las ausencias DAP al día. Devuelve el resumen (también se guarda para la pantalla).
 * `fetchImpl` y `hoyIso` se pueden pasar en las pruebas.
 */
export async function sincronizar({ fetchImpl = fetch, hoyIso = hoy(), forzar = false } = {}) {
  const desde = sumarDias(hoyIso, -DIAS_ATRAS), hasta = sumarDias(hoyIso, DIAS_ADELANTE);
  const cal = await leerCalendario('dap', desde, hasta, fetchImpl, { forzar });
  const estado = { fecha: new Date().toISOString(), configurado: cal.configurado, error: cal.error || '',
    eventos: 0, creadas: 0, actualizadas: 0, quitadas: 0, duplicadas: 0, sinReconocer: [] };
  if (!cal.configurado || cal.error) { await guardarEstado(estado); return estado; }

  const [profesores, tramos, alias] = await Promise.all([Profesor.listar({ query }), Tramo.listar({ query }), leerAlias()]);
  const porNombre = new Map(profesores.map(p => [p.nombre, p]));
  const deseadas = [];
  for (const ev of cal.eventos) {
    estado.eventos++;
    const k = claveTitulo(ev.titulo) || norm(ev.titulo);
    let p = null;
    if (alias[k] === '-') continue;                                   /* Jefatura dijo «no es una ausencia» */
    if (alias[k]) p = porNombre.get(alias[k]) || null;
    if (!p) p = reconocer(ev.titulo, profesores) || reconocer(ev.desc, profesores);
    if (!p) {
      if (!estado.sinReconocer.some(x => x.clave === k))
        estado.sinReconocer.push({ clave: k, titulo: ev.titulo, fecha: ev.inicio, hasta: ev.fin !== ev.inicio ? ev.fin : '' });
      continue;
    }
    const horas = ev.todoElDia ? [] : tramosEntre(ev.hora, ev.horaFin, tramos);
    deseadas.push({ id: idDe(ev.uid, ev.inicio, ev.titulo), profesor: p.nombre, profesor_id: p.id, fecha: ev.inicio,
      hasta: ev.fin && ev.fin > ev.inicio ? ev.fin : null, modo: horas.length ? 'horas' : 'dia', horas });
  }

  await transaccion(async db => {
    const { rows: previas } = await db.query(
      `SELECT id FROM ausencia WHERE id LIKE $1 AND COALESCE(hasta, fecha) >= $2::date AND fecha <= $3::date`, [PREFIJO + '%', desde, hasta]);
    const quedan = new Set();
    for (const a of deseadas) {
      /* ¿Jefatura ya la grabó a mano (no viene del calendario) para ese profesor/a y día? */
      const { rowCount: manual } = await db.query(
        `SELECT 1 FROM ausencia WHERE id NOT LIKE $1 AND estado = 'Grabada' AND (profesor_id = $2 OR profesor = $3)
           AND fecha <= $4::date AND COALESCE(hasta, fecha) >= $4::date`, [PREFIJO + '%', a.profesor_id, a.profesor, a.fecha]);
      if (manual) { estado.duplicadas++; continue; }
      quedan.add(a.id);
      const r = await db.query(
        `INSERT INTO ausencia (id, profesor, profesor_id, fecha, hasta, modo, horas, tarea, motivo, estado, registrado_por)
         VALUES ($1,$2,$3,$4,$5,$6,$7,'',$8,'Grabada','calendario DAP')
         ON CONFLICT (id) DO UPDATE SET profesor=EXCLUDED.profesor, profesor_id=EXCLUDED.profesor_id, fecha=EXCLUDED.fecha,
           hasta=EXCLUDED.hasta, modo=EXCLUDED.modo, horas=EXCLUDED.horas, motivo=EXCLUDED.motivo, estado='Grabada', sincronizado=now()
         RETURNING (xmax = 0) AS nueva`,   /* la tarea y el aula que anote Jefatura se conservan */
        [a.id, a.profesor, a.profesor_id, a.fecha, a.hasta, a.modo, a.horas, MOTIVO_DAP]);
      if (r.rows[0].nueva) estado.creadas++; else estado.actualizadas++;
    }
    const quitar = previas.map(x => x.id).filter(id => !quedan.has(id));
    if (quitar.length) await db.query(`DELETE FROM ausencia WHERE id = ANY($1::text[])`, [quitar]);
    estado.quitadas = quitar.length;
  });
  await guardarEstado(estado);
  return estado;
}

async function guardarEstado(e) { await Ajuste.guardar({ query }, ESTADO, JSON.stringify(e)); }
export async function leerEstado() {
  let e = {}; try { e = JSON.parse(await Ajuste.leer({ query }, ESTADO) || '{}'); } catch { /* vacío */ }
  return { ...e, alias: await leerAlias() };
}

/** Jefatura dice de quién es un título no reconocido (o «-» para ignorarlo) y se vuelve a sincronizar */
export async function asignar(clave, profesor) {
  const k = claveTitulo(clave) || norm(clave);
  if (!k) throw Object.assign(new Error('Falta el título del evento'), { status: 400 });
  const alias = await leerAlias();
  if (!profesor) delete alias[k];
  else if (profesor === '-') alias[k] = '-';
  else {
    const p = await Profesor.buscarPorNombre({ query }, profesor);
    if (!p) throw Object.assign(new Error('No encuentro a ese profesor/a'), { status: 400 });
    alias[k] = p.nombre;
  }
  await Ajuste.guardar({ query }, ALIAS, JSON.stringify(alias));
  return sincronizar({ forzar: false });
}

/** Al arrancar y cada 15 minutos */
let reloj = null;
export function programar() {
  const vuelta = () => sincronizar().then(e => {
    if (e.configurado && !e.error && (e.creadas || e.quitadas)) console.log(`Calendario DAP: ${e.creadas} ausencias nuevas, ${e.quitadas} quitadas`);
    if (e.error) console.log('Calendario DAP:', e.error);
  }).catch(e => console.log('Calendario DAP:', e.message));
  setTimeout(vuelta, 5000);
  if (!reloj) { reloj = setInterval(vuelta, 15 * 60 * 1000); reloj.unref?.(); }
}
