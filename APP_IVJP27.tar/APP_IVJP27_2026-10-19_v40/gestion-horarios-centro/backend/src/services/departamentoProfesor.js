/**
 * Departamento de cada docente (para la cabecera de su horario).
 * El horario no trae el departamento, así que se decide así, por orden:
 *   1. lo que haya fijado Jefatura a mano (ajuste «profesor_departamento»);
 *   2. si es jefe/a de un departamento (tabla departamento);
 *   3. por las materias que imparte: el departamento con más horas de clase.
 */
import { query } from '../db.js';
import { Ajuste } from '../models/index.js';

const CLAVE = 'profesor_departamento';
const norm = t => String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();

/* materia → departamento (la primera regla que encaje) */
const REGLAS = [
  [/pedagogia terapeutica|audicion y lenguaje|^ambito|refuerzo ambito/, 'Orientación'],
  [/itinerario personal para la empleabilidad|formacion y orientacion/, 'Formación y orientación laboral'],
  [/ingles profesional|lengua extranjera ingles|^ingles/, 'Inglés'],
  [/frances/, 'Francés'],
  [/ciencias aplicadas/, 'Matemáticas'],
  [/comunicacion y ciencias sociales/, 'Lengua Castellana y Literatura'],
  [/acceso a datos|administracion de sistemas|analisis forense|aplicaciones (ofimaticas|web)|bases de datos|bastionado|desarrollo (web|de interfaces)|despl[ie]+gue|diseno de interfaces|entornos de desarrollo|fundamentos de hardware|hacking|implantacion|incidentes de ciberseguridad|instalacion y mantenimiento de redes|lenguajes de marcas|montaje y mantenimiento|normativa de ciberseguridad|ofimatica y archivo|operaciones auxiliares|administracion de redes|programacion|proyecto intermodular|puesta en produccion|realidad virtual|redes locales|seguridad (informatica|y alta)|servicios (de red|en red)|sistemas (de gestion|informaticos|operativos)|diseno grafico|diseno, gestion|digitalizacion aplicada|sostenibilidad aplicada|digitalizacion basica/, 'Fam. Prof. Informática y Comunicaciones'],
  [/filosofia|valores civicos|psicologia/, 'Filosofía'],
  [/griego/, 'Griego'],
  [/latin/, 'Latín'],
  [/biologia|geologia|ciencias generales|ecologia|a ciencia cierta|ciencias ambientales/, 'Ciencias Naturales'],
  [/fisica y quimica|^fisica$|^quimica$|practicas de laboratorio/, 'Física y Química'],
  [/educacion fisica|actividad fisica/, 'Educación Física'],
  [/matematicas/, 'Matemáticas'],
  [/lengua castellana|literatura universal/, 'Lengua Castellana y Literatura'],
  [/geografia|historia|union europea/, 'Geografía e Historia'],
  [/musica|artes escenicas/, 'Música'],
  [/plastica|dibujo|expresion artistica|arte digital/, 'Artes Plásticas'],
  [/tecnologia|digitalizacion|^inteligencia artificial$/, 'Tecnología'],
  [/economia|emprendimiento|empresa/, 'Economía'],
  [/religion/, 'Religión'],
];
export function departamentoDeMateria(m) {
  const n = norm(m);
  for (const [re, d] of REGLAS) if (re.test(n)) return d;
  return null;
}

async function manuales() { try { return JSON.parse(await Ajuste.leer({ query }, CLAVE) || '{}'); } catch { return {}; } }

/** { departamento, origen: 'manual'|'jefatura'|'materias'|'' } */
export async function departamentoDe(nombre) {
  const n = norm(nombre);
  if (!n) return { departamento: '', origen: '' };
  const man = await manuales();
  const k = Object.keys(man).find(x => norm(x) === n);
  if (k) return { departamento: man[k], origen: 'manual' };
  const { rows: deps } = await query('SELECT nombre, jefe FROM departamento');
  const jefe = deps.find(d => norm(d.jefe) === n);
  if (jefe) return { departamento: jefe.nombre, origen: 'jefatura' };
  const { rows } = await query(`SELECT c.materia, count(*)::int AS n FROM clase c JOIN profesor p ON p.id = c.profesor_id
    WHERE p.nombre_norm = $1 AND c.categoria = 'docencia' GROUP BY c.materia`, [n]);
  const horas = {};
  for (const r of rows) { const d = departamentoDeMateria(r.materia); if (d) horas[d] = (horas[d] || 0) + r.n; }
  const mejor = Object.entries(horas).sort((a, b) => b[1] - a[1])[0];
  return mejor ? { departamento: mejor[0], origen: 'materias' } : { departamento: '', origen: '' };
}

export async function listaDepartamentos() {
  const { rows } = await query('SELECT nombre FROM departamento ORDER BY nombre');
  const l = rows.map(r => r.nombre);
  if (!l.includes('Religión')) l.push('Religión');
  return l.sort((a, b) => a.localeCompare(b, 'es'));
}

/** Jefatura fija (o quita, con departamento vacío) el departamento de un docente */
export async function asignar(nombre, departamento) {
  if (!String(nombre || '').trim()) throw Object.assign(new Error('Falta el profesor/a'), { status: 400 });
  const man = await manuales();
  for (const k of Object.keys(man)) if (norm(k) === norm(nombre)) delete man[k];
  if (departamento) {
    if (!(await listaDepartamentos()).includes(departamento)) throw Object.assign(new Error('Departamento no válido'), { status: 400 });
    man[nombre] = departamento;
  }
  await Ajuste.guardar({ query }, CLAVE, JSON.stringify(man));
  return departamentoDe(nombre);
}
