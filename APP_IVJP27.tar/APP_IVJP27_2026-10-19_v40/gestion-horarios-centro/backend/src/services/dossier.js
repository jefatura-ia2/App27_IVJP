/**
 * Dossier mensual para Jefatura: informe del mes + una hoja por cada justificación con sus PDF justificantes
 * a continuación, todo en un único PDF numerado.
 */
import fs from 'node:fs/promises';
import { PDFDocument, StandardFonts, rgb } from 'pdf-lib';
import { query } from '../db.js';
import { datosInforme } from './informeAusencias.js';
import { generarPDF, generarHojaJustificacion } from './pdfInforme.js';
import { justificaciones, rutaJustificante } from './justificacionService.js';
import { ORDEN } from './articulosPermisos.js';

async function añadir(destino, bytes) {
  const src = await PDFDocument.load(bytes, { ignoreEncryption: true });
  const paginas = await destino.copyPages(src, src.getPageIndices());
  paginas.forEach(p => destino.addPage(p));
}

export async function generarDossier(mes, { conMotivo = true } = {}) {
  const inf = await datosInforme(mes);
  const final = await PDFDocument.create();
  final.setTitle('Ausencias y justificantes · ' + inf.mes.nombre);
  final.setAuthor('Jefatura de Estudios · IES Valle del Jerte');
  await añadir(final, await generarPDF(inf, { conMotivo, numerar: false }));

  /* justificaciones de las ausencias del mes, por profesor/a y fecha */
  const jids = [...new Set(inf.detalle.map(a => a.justificacion_id).filter(Boolean))];
  const lista = jids.length ? await justificaciones('WHERE id = ANY($1::int[])', [jids]) : [];
  const { rows: aus } = jids.length ? await query(`SELECT id, justificacion_id, to_char(fecha,'YYYY-MM-DD') AS fecha, COALESCE(to_char(hasta,'YYYY-MM-DD'),'') AS hasta, modo, horas
    FROM ausencia WHERE justificacion_id = ANY($1::int[]) ORDER BY fecha`, [jids]) : { rows: [] };
  lista.sort((a, b) => a.profesor.localeCompare(b.profesor, 'es') || ((a.detalle[0] || {}).fecha || '').localeCompare((b.detalle[0] || {}).fecha || ''));
  const avisos = [];
  for (const j of lista) {
    await añadir(final, await generarHojaJustificacion(j, { ausencias: aus.filter(a => a.justificacion_id === j.id), orden: ORDEN }));
    for (const d of j.documentos) {
      try {
        const { rows } = await query('SELECT archivo FROM justificante WHERE id = $1', [d.id]);
        await añadir(final, await fs.readFile(rutaJustificante(j.id, rows[0].archivo)));
      } catch (e) {
        avisos.push(`${j.profesor}: «${d.nombre}»`);
        const p = final.addPage([595.28, 841.89]);
        const f = await final.embedFont(StandardFonts.Helvetica);
        p.drawText(`No se pudo incluir el justificante «${d.nombre}» de ${j.profesor}.`, { x: 50, y: 780, size: 11, font: f, color: rgb(0.7, 0.07, 0.24) });
        p.drawText('Ábrelo desde la app (Guardias → Informes de ausencias) o pide al docente que lo suba de nuevo.', { x: 50, y: 760, size: 9, font: f });
      }
    }
  }

  /* numeración de todo el dossier, en la esquina inferior derecha */
  const f = await final.embedFont(StandardFonts.Helvetica);
  const total = final.getPageCount();
  final.getPages().forEach((p, i) => {
    const { width } = p.getSize();
    const txt = `${inf.mes.nombre} · ${i + 1} / ${total}`;
    const w = f.widthOfTextAtSize(txt, 7.5);
    p.drawRectangle({ x: width - w - 50, y: 14, width: w + 12, height: 13, color: rgb(1, 1, 1), opacity: 0.85 });
    p.drawText(txt, { x: width - w - 44, y: 18, size: 7.5, font: f, color: rgb(0.29, 0.33, 0.39) });
  });
  return { pdf: Buffer.from(await final.save()), justificaciones: lista.length, avisos };
}
