/**
 * Edición del horario desde la app (solo administración).
 *
 * Una «sesión» es lo que se ve en una casilla del horario de un profesor/a:
 *   { profesor, dia, slot, materia, aula, tipo, grupos: [...] }
 * En la base de datos son una o varias filas de `clase` (una por grupo).
 *
 * Tras cada cambio se reescribe el CSV de datos (config.horariosCsv) para que la carga
 * automática de cada mañana (cron) no deshaga lo editado.
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { query, transaccion } from '../db.js';
import { config } from '../config.js';
import { Profesor, Grupo, Aula, Clase, Tramo } from '../models/index.js';
import { ingerirTexto, validarTexto } from '../ingestors/csvHorarios.js';

const TRAMOS = new Set(Tramo.TRAMOS_CENTRO.map(t => t.codigo));
const txt = v => String(v ?? '').trim();

function error(msg, status = 400) { const e = new Error(msg); e.status = status; return e; }

/** Horario completo en el formato del CSV original (profesor,dia,tramo,materia,grupo,aula,tipo) */
export async function exportarCSV(db = { query }) {
  const { rows } = await db.query(
    `SELECT p.nombre AS profesor, c.dia, c.tramo, c.materia, COALESCE(g.codigo,'') AS grupo, COALESCE(a.codigo,'') AS aula, c.tipo
     FROM clase c JOIN profesor p ON p.id = c.profesor_id JOIN tramo t ON t.codigo = c.tramo
     LEFT JOIN grupo g ON g.id = c.grupo_id LEFT JOIN aula a ON a.id = c.aula_id
     WHERE p.activo ORDER BY p.nombre, c.dia, t.orden, c.id`);
  const campo = v => { const s = String(v ?? ''); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
  return rows.map(r => [r.profesor, r.dia, r.tramo, r.materia, r.grupo, r.aula, r.tipo].map(campo).join(',')).join('\n');
}

async function guardarFichero(csv) {
  try { await fs.writeFile(config.horariosCsv, csv + '\n', 'utf8'); }
  catch (e) { console.error('No se pudo reescribir', config.horariosCsv, e.message); }
}

function limpiar(s, campoObligatorio = true) {
  if (!s) return null;
  const o = {
    profesor: txt(s.profesor), dia: Number(s.dia), slot: txt(s.slot).toUpperCase(),
    materia: txt(s.materia), aula: txt(s.aula), tipo: txt(s.tipo),
    grupos: [...new Set((Array.isArray(s.grupos) ? s.grupos : String(s.grupos || '').split(/[,;]/)).map(txt).filter(Boolean))],
  };
  if (campoObligatorio) {
    if (!o.profesor) throw error('Falta el profesor/a');
    if (!(o.dia >= 1 && o.dia <= 5)) throw error('Día no válido');
    if (!TRAMOS.has(o.slot)) throw error('Tramo horario no válido');
    if (!o.tipo) throw error('Indica el tipo de sesión (Docencia, Guardia de Aula…)');
  }
  return o;
}

/**
 * Cambia una sesión: `antes` (la casilla tal como estaba, o null para añadir)
 * por `despues` (la nueva, o null para borrar). Todo en una transacción.
 * Devuelve el CSV completo actualizado para que la app se refresque sin recargar.
 */
export async function cambiarSesion({ antes, despues }) {
  const a = limpiar(antes), d = limpiar(despues);
  if (!a && !d) throw error('No hay ningún cambio');
  const csv = await transaccion(async db => {
    if (a) {
      const { rows: p } = await db.query('SELECT id FROM profesor WHERE nombre = $1', [a.profesor]);
      if (!p.length) throw error('Profesor/a no encontrado', 404);
      const { rowCount } = await db.query(
        `DELETE FROM clase c
         USING (SELECT c2.id FROM clase c2
                LEFT JOIN grupo g ON g.id = c2.grupo_id LEFT JOIN aula au ON au.id = c2.aula_id
                WHERE c2.profesor_id = $1 AND c2.dia = $2 AND c2.tramo = $3 AND c2.materia = $4
                  AND COALESCE(au.codigo,'') = $5 AND c2.tipo = $6
                  AND (COALESCE(g.codigo,'') = ANY($7::text[]))) x
         WHERE c.id = x.id`,
        [p[0].id, a.dia, a.slot, a.materia, a.aula, a.tipo, a.grupos.length ? a.grupos : ['']]);
      if (!rowCount) throw error('Esa sesión ya no existe: puede que otra persona la haya cambiado. Recarga la página.', 409);
    }
    if (d) {
      const pid = await Profesor.upsert(db, d.profesor);
      const aid = d.aula ? await Aula.upsert(db, d.aula) : null;
      for (const g of (d.grupos.length ? d.grupos : [''])) {
        const gid = g ? await Grupo.upsert(db, g) : null;
        await db.query(
          `INSERT INTO clase (profesor_id, dia, tramo, materia, grupo_id, aula_id, tipo, categoria)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
          [pid, d.dia, d.slot, d.materia, gid, aid, d.tipo, Clase.clasificar(d.tipo)]);
      }
    }
    return exportarCSV(db);
  });
  await guardarFichero(csv);
  await query(`INSERT INTO sincronizacion (origen, fin, ok, detalle) VALUES ('edicion-app', now(), TRUE, $1)`,
    [{ antes: a, despues: d }]);
  return csv;
}

/** Sustituye el horario entero por un CSV subido desde la app */
/* ── Carga de un horario completo desde un CSV (pantalla «Actualizar horario» de administración) ── */

const DIR_COPIAS = () => path.join(path.dirname(path.resolve(config.horariosCsv)), 'copias');
const MAX_COPIAS = 30;
const esCabecera = d => d.linea === 1 && /prof/i.test(d.fila.join(' '));

/** Guarda el horario actual en data/copias antes de sustituirlo. Devuelve el nombre de la copia. */
async function copiaPrevia(motivo) {
  const csv = await exportarCSV();
  if (!csv.trim()) return null;
  const dir = DIR_COPIAS();
  await fs.mkdir(dir, { recursive: true });
  const sello = new Date().toISOString().replace(/[-:]/g, '').replace('T', '_').slice(0, 15);
  const nombre = `horario_${sello}_${motivo}.csv`;
  await fs.writeFile(path.join(dir, nombre), csv + '\n', 'utf8');
  const todas = (await fs.readdir(dir)).filter(f => f.endsWith('.csv')).sort();
  for (const f of todas.slice(0, Math.max(0, todas.length - MAX_COPIAS))) await fs.unlink(path.join(dir, f)).catch(() => {});
  return nombre;
}

/** Estado actual del horario, última carga y copias disponibles */
export async function estadoCarga() {
  const { rows: [n] } = await query(`SELECT COUNT(*)::int AS sesiones, COUNT(DISTINCT c.profesor_id)::int AS profesores,
      COUNT(DISTINCT c.grupo_id)::int AS grupos, COUNT(DISTINCT c.aula_id)::int AS aulas
    FROM clase c JOIN profesor p ON p.id = c.profesor_id WHERE p.activo`);
  const { rows: ult } = await query(`SELECT origen, to_char(fin AT TIME ZONE $1, 'DD/MM/YYYY HH24:MI') AS fecha, detalle
    FROM sincronizacion WHERE ok AND origen IN ('importacion-app','csv-horarios','restauracion-app') ORDER BY fin DESC LIMIT 1`, [config.tz]);
  let copias = [];
  try {
    const dir = DIR_COPIAS();
    copias = (await fs.readdir(dir)).filter(f => f.endsWith('.csv')).sort().reverse().slice(0, 10);
    copias = await Promise.all(copias.map(async f => {
      const ruta = path.join(dir, f);
      const lineas = (await fs.readFile(ruta, 'utf8')).trim().split('\n').length;
      const fecha = (await fs.stat(ruta)).mtime.toLocaleString('es-ES', { timeZone: config.tz, day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
      return { nombre: f, fecha, sesiones: lineas };
    }));
  } catch { /* aún no hay copias */ }
  return { ...n, ultima: ult[0] || null, copias };
}

/** Comprueba un CSV y resume qué cambiaría, SIN tocar la base de datos */
export async function previsualizarCSV(texto) {
  if (!txt(texto)) throw error('El fichero está vacío');
  let v;
  try { v = validarTexto(texto); } catch (e) { return { valido: false, error: e.message }; }
  const descartadas = v.descartadas.filter(d => !esCabecera(d));
  const nuevos = new Set(v.sesiones.map(x => x.profesor));
  const { rows } = await query(`SELECT DISTINCT p.nombre FROM clase c JOIN profesor p ON p.id = c.profesor_id WHERE p.activo`);
  const actuales = new Set(rows.map(r => r.nombre));
  const { rows: [{ n }] } = await query(`SELECT COUNT(*)::int AS n FROM clase c JOIN profesor p ON p.id = c.profesor_id WHERE p.activo`);
  const orden = a => [...a].sort((x, y) => x.localeCompare(y, 'es'));
  return {
    valido: true,
    sesiones: v.sesiones.length,
    profesores: nuevos.size,
    grupos: new Set(v.sesiones.map(x => x.grupo).filter(Boolean)).size,
    aulas: new Set(v.sesiones.map(x => x.aula).filter(Boolean)).size,
    antes: { sesiones: n, profesores: actuales.size },
    altas: orden([...nuevos].filter(p => !actuales.has(p))),
    bajas: orden([...actuales].filter(p => !nuevos.has(p))),
    descartadas: descartadas.length,
    ejemplosDescartadas: descartadas.slice(0, 8).map(d => ({ linea: d.linea, texto: d.fila.join(' | ').slice(0, 120) })),
  };
}

async function sustituir(texto, origen, motivoCopia) {
  if (!txt(texto)) throw error('El fichero está vacío');
  try { validarTexto(texto); } catch (e) { throw error(e.message); }   /* se valida ANTES de hacer la copia */
  const copia = await copiaPrevia(motivoCopia);
  let r;
  try { r = await ingerirTexto(texto); } catch (e) { throw error(e.message); }
  const csv = await exportarCSV();
  await guardarFichero(csv);
  await query(`INSERT INTO sincronizacion (origen, fin, ok, detalle) VALUES ($1, now(), TRUE, $2)`, [origen, { ...r, copia }]);
  return { ...r, copia, csv };
}

/** Sustituye el horario completo por el del CSV (con copia de seguridad previa) */
export const importarCSV = texto => sustituir(texto, 'importacion-app', 'antes-de-carga');

/** Vuelve a un horario guardado en data/copias */
export async function restaurarCopia(nombre) {
  if (!/^horario_[\w-]+\.csv$/.test(String(nombre || ''))) throw error('Copia no válida');
  let texto;
  try { texto = await fs.readFile(path.join(DIR_COPIAS(), nombre), 'utf8'); } catch { throw error('No existe esa copia', 404); }
  return sustituir(texto, 'restauracion-app', 'antes-de-restaurar');
}
