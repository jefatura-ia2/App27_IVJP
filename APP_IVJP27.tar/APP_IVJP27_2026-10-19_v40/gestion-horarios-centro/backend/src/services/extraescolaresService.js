/**
 * Actividades extraescolares del calendario de Google «Actividades extraescolares» (el que Jefatura enlaza en
 * Calendarios). El servidor descarga su versión pública en formato iCalendar (.ics), la interpreta y la guarda
 * 10 minutos en memoria. Se usa en la pantalla de la sala de profesores.
 * Requisito: en Google Calendar → Configuración del calendario → Permisos de acceso → «Hacer disponible públicamente».
 */
import { config } from '../config.js';
import { leerCalendarios } from './servicioService.js';

const CACHE_MS = 10 * 60 * 1000;
const caches = new Map();   /* url del .ics → { t, eventos, error } */

/** De la dirección guardada (enlace de incrustación o .ics) a la dirección del .ics público */
export function urlIcs(url) {
  const u = String(url || '').trim();
  if (!u) return '';
  if (/\.ics(\?|$)/i.test(u) || /^webcal:/i.test(u)) return u.replace(/^webcal:/i, 'https:');
  try {
    const x = new URL(u);
    const id = x.searchParams.get('src') || x.searchParams.get('cid');
    if (id) return 'https://calendar.google.com/calendar/ical/' + encodeURIComponent(decodeURIComponent(id)) + '/public/basic.ics';
  } catch { /* no es una URL */ }
  return '';
}

/* ---------- lectura de iCalendar (RFC 5545, lo necesario para Google Calendar) ---------- */
const desescapar = t => String(t || '').replace(/\\n/gi, ' ').replace(/\\([,;\\])/g, '$1').replace(/\s+/g, ' ').trim();
const fechaIso = (y, m, d) => `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
function partesEnZona(date, tz) {
  const p = Object.fromEntries(new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false })
    .formatToParts(date).map(x => [x.type, x.value]));
  return { fecha: `${p.year}-${p.month}-${p.day}`, hora: `${p.hour === '24' ? '00' : p.hour}:${p.minute}` };
}
/** «20261020», «20261020T090000», «20261020T070000Z» → { fecha, hora, dia } en la hora del centro */
function leerFecha(valor, params, tz) {
  const m = /^(\d{4})(\d{2})(\d{2})(?:T(\d{2})(\d{2})(\d{2})(Z)?)?$/.exec(String(valor).trim());
  if (!m) return null;
  if (!m[4] || /VALUE=DATE(?!-)/i.test(params || '')) return { fecha: fechaIso(m[1], m[2], m[3]), hora: '', dia: true };
  if (m[7]) return { ...partesEnZona(new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6])), tz), dia: false };
  return { fecha: fechaIso(m[1], m[2], m[3]), hora: `${m[4]}:${m[5]}`, dia: false };   /* TZID: hora local tal cual */
}
const sumarDias = (iso, n) => { const d = new Date(iso + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };

export function interpretarIcs(texto, tz = config.tz) {
  const lineas = String(texto || '').replace(/\r\n/g, '\n').replace(/\n[ \t]/g, '').split('\n');
  const eventos = [];
  let ev = null;
  for (const l of lineas) {
    if (l === 'BEGIN:VEVENT') { ev = { exdates: [] }; continue; }
    if (l === 'END:VEVENT') { if (ev) eventos.push(ev); ev = null; continue; }
    if (!ev) continue;
    const i = l.indexOf(':'); if (i < 0) continue;
    const [nombre, ...params] = l.slice(0, i).split(';');
    const valor = l.slice(i + 1), p = params.join(';');
    switch (nombre.toUpperCase()) {
      case 'SUMMARY': ev.titulo = desescapar(valor); break;
      case 'LOCATION': ev.lugar = desescapar(valor); break;
      case 'DESCRIPTION': ev.desc = desescapar(valor).slice(0, 300); break;
      case 'DTSTART': ev.ini = leerFecha(valor, p, tz); break;
      case 'DTEND': ev.fin = leerFecha(valor, p, tz); break;
      case 'RRULE': ev.rrule = Object.fromEntries(valor.split(';').map(x => x.split('='))); break;
      case 'EXDATE': valor.split(',').forEach(v => { const f = leerFecha(v, p, tz); if (f) ev.exdates.push(f.fecha); }); break;
      case 'STATUS': ev.estado = valor.trim().toUpperCase(); break;
      case 'RECURRENCE-ID': ev.recId = leerFecha(valor, p, tz); break;
      case 'UID': ev.uid = valor.trim(); break;
    }
  }
  return eventos.filter(e => e.ini && e.estado !== 'CANCELLED');
}

/** Ocurrencias entre «desde» y «hasta» (incluidos), con repeticiones diarias, semanales o mensuales sencillas */
export function ocurrencias(eventos, desde, hasta) {
  const out = [];
  const cambiadas = new Set(eventos.filter(e => e.recId).map(e => e.uid + '|' + e.recId.fecha));
  for (const e of eventos) {
    const diaCompleto = e.ini.dia;
    /* en los de día completo, DTEND es el día siguiente al último */
    const finFecha = e.fin ? (diaCompleto ? sumarDias(e.fin.fecha, -1) : e.fin.fecha) : e.ini.fecha;
    const dur = Math.max(0, Math.round((new Date(finFecha + 'T12:00:00Z') - new Date(e.ini.fecha + 'T12:00:00Z')) / 864e5));
    const una = ini => {
      const fin = sumarDias(ini, dur);
      if (fin < desde || ini > hasta || e.exdates.includes(ini) || (!e.recId && cambiadas.has(e.uid + '|' + ini))) return;
      out.push({ titulo: e.titulo || 'Actividad extraescolar', inicio: ini, fin, todoElDia: diaCompleto,
        hora: diaCompleto ? '' : e.ini.hora, horaFin: diaCompleto || !e.fin ? '' : e.fin.hora, lugar: e.lugar || '',
        uid: e.uid || '', desc: e.desc || '' });
    };
    const r = e.rrule;
    if (!r || e.recId) { una(e.ini.fecha); continue; }
    const paso = Math.max(1, +r.INTERVAL || 1), max = +r.COUNT || 500;
    const limite = r.UNTIL ? (leerFecha(r.UNTIL, '', config.tz) || {}).fecha || hasta : hasta;
    let f = e.ini.fecha;
    for (let n = 0; n < max && f <= limite && f <= hasta; n++) {
      una(f);
      if (r.FREQ === 'DAILY') f = sumarDias(f, paso);
      else if (r.FREQ === 'WEEKLY') f = sumarDias(f, 7 * paso);
      else if (r.FREQ === 'MONTHLY') { const d = new Date(f + 'T12:00:00Z'); d.setUTCMonth(d.getUTCMonth() + paso); f = d.toISOString().slice(0, 10); }
      else if (r.FREQ === 'YEARLY') { const d = new Date(f + 'T12:00:00Z'); d.setUTCFullYear(d.getUTCFullYear() + paso); f = d.toISOString().slice(0, 10); }
      else break;
    }
  }
  return out.sort((a, b) => (a.inicio + (a.hora || '00:00')).localeCompare(b.inicio + (b.hora || '00:00')));
}

/** Eventos de uno de los calendarios de Google enlazados en Calendarios ('extra', 'dap'…) entre dos fechas.
 *  Nunca lanza error: devuelve { eventos, error, configurado }. */
export async function leerCalendario(clave, desde, hasta, fetchImpl = fetch, { forzar = false } = {}) {
  const cal = (await leerCalendarios())[clave] || {};
  const ics = urlIcs(cal.url);
  if (!ics) return { eventos: [], configurado: false, error: cal.url ? 'El enlace del calendario no es de Google Calendar' : '' };
  let c = caches.get(ics) || { t: 0, eventos: [], error: '' };
  if (forzar || Date.now() - c.t > CACHE_MS) {
    try {
      const r = await fetchImpl(ics, { redirect: 'follow', signal: AbortSignal.timeout(15000) });
      const t = await r.text();
      if (!r.ok || !/BEGIN:VCALENDAR/.test(t)) throw new Error(r.status === 404 || !r.ok ? 'el calendario no es público' : 'respuesta no válida');
      c = { t: Date.now(), eventos: interpretarIcs(t), error: '' };
    } catch (e) {
      /* se mantiene lo último que se leyó y se reintenta en 1 minuto */
      c = { ...c, t: Date.now() - CACHE_MS + 60000, error: 'No se pudo leer el calendario (' + e.message + ')' };
    }
    caches.set(ics, c);
  }
  return { eventos: ocurrencias(c.eventos, desde, hasta), error: c.error, configurado: true };
}

/** Actividades extraescolares entre dos fechas; nunca lanza error (la pantalla debe seguir funcionando) */
export async function extraescolares(desde, hasta, fetchImpl = fetch) {
  const r = await leerCalendario('extra', desde, hasta, fetchImpl);
  return { eventos: r.eventos, error: r.error ? r.error.replace('el calendario', 'el calendario de extraescolares') : '' };
}
export const _vaciarCache = () => { caches.clear(); };
