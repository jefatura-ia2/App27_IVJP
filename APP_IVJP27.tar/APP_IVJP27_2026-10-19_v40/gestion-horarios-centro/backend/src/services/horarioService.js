/** Consultas de horario por profesor, grupo o aula, buscador global y aulas libres */
import { query } from '../db.js';
import { Clase, Profesor } from '../models/index.js';

const FILTRO = { profesor: 'p.id', grupo: 'g.id', aula: 'a.id' };

export async function sesionesDe(tipo, id) {
  if (!FILTRO[tipo]) throw Object.assign(new Error('Tipo no válido'), { status: 400 });
  const { rows } = await query(`${Clase.SELECT_SESIONES} WHERE ${FILTRO[tipo]} = $1 ORDER BY c.dia, t.orden, g.codigo`, [id]);
  return rows;
}

export async function entidad(tipo, id) {
  const sql = {
    profesor: 'SELECT id, nombre FROM profesor WHERE id = $1',
    grupo: 'SELECT id, codigo AS nombre FROM grupo WHERE id = $1',
    aula: 'SELECT id, codigo AS nombre FROM aula WHERE id = $1',
  }[tipo];
  if (!sql) return null;
  const { rows } = await query(sql, [id]);
  return rows[0] || null;
}

/** Buscador global: profesores, grupos y aulas que contienen el texto (sin tildes) */
export async function buscar(texto, limite = 20) {
  const q = Profesor.normalizar(texto);
  if (!q) return [];
  const like = `%${q.replace(/[%_]/g, m => '\\' + m)}%`;
  const { rows } = await query(`
    (SELECT 'profesor' AS tipo, id, nombre, position($1 in nombre_norm) AS pos FROM profesor WHERE activo AND nombre_norm LIKE $2)
    UNION ALL
    (SELECT 'grupo', id, codigo, position($1 in lower(codigo)) FROM grupo WHERE lower(codigo) LIKE $2)
    UNION ALL
    (SELECT 'aula', id, codigo, position($1 in lower(codigo)) FROM aula WHERE lower(codigo) LIKE $2)
    ORDER BY pos, nombre LIMIT $3`, [q, like, limite]);
  return rows.map(({ pos, ...r }) => r);
}

/** Aulas sin ninguna sesión en un día y tramo */
export async function aulasLibres(dia, tramo) {
  const { rows } = await query(`
    SELECT a.id, a.codigo FROM aula a
    WHERE NOT EXISTS (SELECT 1 FROM clase c WHERE c.aula_id = a.id AND c.dia = $1 AND c.tramo = $2)
    ORDER BY a.codigo`, [dia, tramo]);
  return rows;
}

/** Ocupación de un aula en un día (todas las sesiones de ese día) */
export async function ocupacionAula(aulaId, dia) {
  const { rows } = await query(`${Clase.SELECT_SESIONES} WHERE a.id = $1 AND c.dia = $2 ORDER BY t.orden`, [aulaId, dia]);
  return rows;
}
