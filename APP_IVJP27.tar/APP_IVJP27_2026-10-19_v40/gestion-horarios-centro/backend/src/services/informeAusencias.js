/**
 * Informe mensual de ausencias del profesorado (modo administrador).
 * Para cada ausencia del mes se cuentan los días lectivos (lunes a viernes) que caen dentro del mes y,
 * con el horario cargado, las sesiones afectadas: de clase (docencia) y de guardia (aula y recreo).
 * Las estadísticas usan solo las ausencias GRABADAS; las pendientes se listan aparte.
 */
import { query } from '../db.js';
import { PENDIENTE, GRABADA } from '../models/Ausencia.js';
import { articulo as articuloDe } from './articulosPermisos.js';

export const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
const err = (msg, status = 400) => Object.assign(new Error(msg), { status });
const iso = d => d.toISOString().slice(0, 10);
const fecha = s => new Date(s + 'T12:00:00Z');

export function rangoMes(mes) {
  const m = /^(\d{4})-(\d{2})$/.exec(String(mes || ''));
  if (!m || +m[2] < 1 || +m[2] > 12) throw err('Mes no válido (formato AAAA-MM)');
  const desde = `${m[1]}-${m[2]}`;
  const fin = new Date(Date.UTC(+m[1], +m[2], 0, 12));
  return { desde: desde + '-01', hasta: iso(fin), nombre: MESES[+m[2] - 1] + ' ' + m[1], anio: +m[1], num: +m[2] };
}

/** Días de lunes a viernes de [a, b] (ambos incluidos), como {iso, dia 1..5} */
export function diasLectivos(a, b) {
  const out = [];
  for (let d = fecha(a); iso(d) <= b; d = new Date(d.getTime() + 864e5)) {
    const w = d.getUTCDay();
    if (w >= 1 && w <= 5) out.push({ iso: iso(d), dia: w });
  }
  return out;
}

import { esDAP, sinJustificante, motivoExento } from './motivos.js';

export async function datosInforme(mes) {
  const r = rangoMes(mes);
  const { rows } = await query(
    `SELECT a.id, a.profesor, a.profesor_id, to_char(a.fecha,'YYYY-MM-DD') AS fecha, COALESCE(to_char(a.hasta,'YYYY-MM-DD'),'') AS hasta,
            a.modo, a.horas, a.motivo, a.tarea, a.estado, a.justificacion_id, j.articulo
     FROM ausencia a LEFT JOIN justificacion j ON j.id = a.justificacion_id
     WHERE a.fecha <= $2::date AND COALESCE(a.hasta, a.fecha) >= $1::date ORDER BY a.fecha, a.profesor`, [r.desde, r.hasta]);
  /* sesiones del horario de cada profesor/a afectado: dia → tramo → categorías */
  const ids = [...new Set(rows.map(a => a.profesor_id).filter(Boolean))];
  const ses = ids.length ? (await query(`SELECT profesor_id, dia, tramo, categoria FROM clase WHERE profesor_id = ANY($1::int[])`, [ids])).rows : [];
  const horario = {};
  for (const s of ses) ((horario[s.profesor_id] ||= {})[s.dia] ||= []).push(s);

  const detalle = rows.map(a => {
    const ini = a.fecha < r.desde ? r.desde : a.fecha;
    const finA = a.hasta || a.fecha;
    const fin = finA > r.hasta ? r.hasta : finA;
    const dias = diasLectivos(ini, fin);
    let clases = 0, guardias = 0;
    for (const d of dias) {
      for (const s of ((horario[a.profesor_id] || {})[d.dia] || [])) {
        if (a.modo === 'horas' && !a.horas.includes(s.tramo)) continue;
        if (s.categoria === 'docencia') clases++;
        else if (s.categoria === 'guardia' || s.categoria === 'recreo') guardias++;
      }
    }
    /* asuntos propios (DAP) y actividades complementarias o extraescolares: sin justificante, cuentan como justificadas */
    const exenta = !a.justificacion_id && sinJustificante(a.motivo);
    return { ...a, dias: dias.length, clases, guardias, sinHorario: !a.profesor_id, dap: exenta && esDAP(a.motivo),
      actividad: exenta && !esDAP(a.motivo), exenta, exentaMotivo: exenta ? motivoExento(a.motivo) : '' };
  });

  const grabadas = detalle.filter(a => a.estado === GRABADA);
  const porProf = {};
  for (const a of grabadas) {
    const p = (porProf[a.profesor] ||= { profesor: a.profesor, ausencias: 0, dias: 0, diasCompletos: 0, porHoras: 0, clases: 0, guardias: 0 });
    p.ausencias++; p.dias += a.dias; p.clases += a.clases; p.guardias += a.guardias;
    if (a.modo === 'horas') p.porHoras++; else p.diasCompletos += a.dias;
  }
  const porMotivo = {};
  for (const a of grabadas) {
    const art = a.articulo ? articuloDe(a.articulo) : null;
    const k = art ? `Art. ${art.n}. ${art.t}` : a.exenta ? a.exentaMotivo + ' (justificada)' : (((a.motivo || '').trim() || 'Sin indicar') + ' (sin justificar)');
    const m = (porMotivo[k] ||= { motivo: k, ausencias: 0, dias: 0 });
    m.ausencias++; m.dias += a.dias;
  }
  const suma = k => grabadas.reduce((t, a) => t + a[k], 0);
  return {
    mes: r, generado: new Date().toISOString(),
    totales: { ausencias: grabadas.length, profesores: Object.keys(porProf).length, dias: suma('dias'), clases: suma('clases'),
      guardias: suma('guardias'), justificadas: grabadas.filter(a => a.justificacion_id || a.exenta).length, dap: grabadas.filter(a => a.dap).length, actividad: grabadas.filter(a => a.actividad).length, pendientes: detalle.filter(a => a.estado === PENDIENTE).length },
    porProfesor: Object.values(porProf).sort((a, b) => b.dias - a.dias || b.clases - a.clases || a.profesor.localeCompare(b.profesor, 'es')),
    porMotivo: Object.values(porMotivo).sort((a, b) => b.ausencias - a.ausencias || a.motivo.localeCompare(b.motivo, 'es')),
    detalle,
  };
}
