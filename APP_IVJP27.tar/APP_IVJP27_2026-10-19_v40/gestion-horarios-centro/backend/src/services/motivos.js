/** Motivos de ausencia con reglas propias */
/* Asuntos propios (DAP): no necesitan justificante; cuentan siempre como justificadas, con motivo «DAP» */
export const esDAP = m => /\bDAP\b|asuntos?\s+propios?/i.test(String(m || ''));
/* Actividad complementaria o extraescolar: tampoco necesita justificante (cuenta como justificada) */
export const esActividad = m => /actividad(es)?\s+(complementaria|extraescolar)|extraescolar/i.test(String(m || ''));
/** Ausencias que no se justifican: DAP y actividades complementarias o extraescolares */
export const sinJustificante = m => esDAP(m) || esActividad(m);
/** Cómo se nombra el motivo de una ausencia que no necesita justificante ('' si sí lo necesita) */
export const motivoExento = m => esDAP(m) ? 'Asuntos propios (DAP)' : esActividad(m) ? 'Actividad complementaria o extraescolar' : '';
