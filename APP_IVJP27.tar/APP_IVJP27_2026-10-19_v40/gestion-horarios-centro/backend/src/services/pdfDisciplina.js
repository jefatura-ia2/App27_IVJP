/**
 * PDF del parte «Comunicación a Jefatura de Estudios de faltas de disciplina», con la misma estructura que el
 * impreso del centro: cabecera, datos de los hechos, conductas del Decreto 50/2007 (art. 37 y 40) con sus
 * casillas, aclaraciones, lugar y fecha, firma y nota al pie. Lleva además el código de registro interno y
 * qué ejemplar es (profesor/a o Jefatura de Estudios); el de Jefatura muestra el sello de «Recibido».
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import PDFDocument from 'pdfkit';
import { CONTRARIAS, GRAVES, nombreNatural } from './disciplinaService.js';

const LOGO = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..', 'assets', 'logo-ivj.png');
const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
const TINTA = '#111111', RELLENO = '#1e3a8a', GRIS = '#8a8a8a', MORADO = '#7B3F9E', LILA = '#9b7bb0';
const X = 40, ANCHO = 515;

export function generarPdf(p, tipo = 'profesor') {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A4', margin: 0, info: { Title: `Parte de disciplina ${p.codigo || ''}`, Author: 'IES Valle del Jerte · Jefatura de Estudios' } });
    const trozos = [];
    doc.on('data', b => trozos.push(b)); doc.on('end', () => resolve(Buffer.concat(trozos))); doc.on('error', reject);

    /* ---------- cabecera ---------- */
    doc.fillColor(LILA).font('Helvetica-Bold').fontSize(13).text('I.E.S. «VALLE DEL JERTE»', X, 26, { lineBreak: false });
    doc.font('Helvetica').fontSize(6.8).fillColor(GRIS);
    ['C/ Pedro y Francisco González, s/n', '10600 PLASENCIA (Cáceres)', 'Teléfono: 927 01 77 74 / Fax: 927 01 77 75']
      .forEach((l, i) => doc.text(l, X, 44 + i * 8.5, { lineBreak: false }));
    if (fs.existsSync(LOGO)) doc.image(LOGO, 297.5 - 30, 20, { width: 60 });
    doc.fillColor(MORADO).font('Helvetica').fontSize(8.5).text('IES Valle del Jerte', 247.5, 74, { width: 100, align: 'center', characterSpacing: 0.6 });
    doc.moveTo(262, 84).lineTo(333, 84).lineWidth(0.6).strokeColor(MORADO).stroke();
    doc.fillColor('#9c9c9c').font('Helvetica').fontSize(12.5).text('JUNTA DE EXTREMADURA', 355, 24, { width: 200, align: 'right', lineBreak: false });
    doc.fontSize(6.8).fillColor(GRIS).text('Consejería de Educación y Formación Profesional', 330, 40, { width: 180, align: 'right', lineBreak: false });
    doc.rect(522, 37, 15, 9).fill('#7fc47f'); doc.rect(530, 52, 9, 6).fill('#9a9a9a');

    /* registro interno y ejemplar */
    const ejemplar = tipo === 'jefatura' ? 'EJEMPLAR PARA JEFATURA DE ESTUDIOS' : tipo === 'tutor' ? 'EJEMPLAR PARA EL TUTOR/A' : 'EJEMPLAR PARA EL PROFESOR/A';
    doc.roundedRect(X, 94, ANCHO, 17, 4).fill('#f3ecf7');
    doc.fillColor(MORADO).font('Helvetica-Bold').fontSize(8).text(`Registro interno: ${p.codigo || '—'}`, X + 8, 99.5, { lineBreak: false });
    doc.font('Helvetica-Bold').fontSize(8);
    const anchoEj = doc.widthOfString(ejemplar);
    doc.fillColor(MORADO).text(ejemplar, X, 99.5, { width: ANCHO - 8, align: 'right', lineBreak: false });
    const medio = `Registrado el ${fechaHora(p.creado)}${p.tutor ? ' · Tutor/a: ' + nombreNatural(p.tutor) : ''}`;
    const libre = ANCHO - 8 - anchoEj - 14 - 140;
    let fm = 8; doc.font('Helvetica').fontSize(fm);
    while (fm > 5.5 && doc.widthOfString(medio) > libre) doc.fontSize(fm -= 0.25);
    doc.fillColor('#5b4568').text(medio, X + 140, 99.5 + (8 - fm) / 2, { lineBreak: false });
    doc.fontSize(8);

    /* ---------- título ---------- */
    let y = 124;
    doc.fillColor(TINTA).font('Helvetica-Bold').fontSize(11.5)
      .text('COMUNICACIÓN A JEFATURA DE ESTUDIOS DE FALTAS DE DISCIPLINA', X, y, { width: ANCHO, align: 'center', underline: true });

    /* ---------- datos ---------- */
    const [aa, mm, dd] = String(p.fecha).split('-');
    const FS = 10.5;
    const linea = (partes, yy) => {      /* partes: ['texto' | {v, w}] */
      let x = X;
      for (const t of partes) {
        if (typeof t === 'string') { doc.fillColor(TINTA).font('Helvetica').fontSize(FS).text(t, x, yy, { lineBreak: false }); x += doc.widthOfString(t); continue; }
        const w = t.w === '*' ? X + ANCHO - x : t.w;
        doc.moveTo(x + 1, yy + 11).lineTo(x + w - 1, yy + 11).lineWidth(0.6).strokeColor(TINTA).stroke();
        let fs2 = 10; doc.font('Helvetica-Bold').fontSize(fs2);
        while (fs2 > 6.5 && doc.widthOfString(String(t.v || '')) > w - 6) doc.fontSize(fs2 -= 0.5);
        doc.fillColor(RELLENO).text(String(t.v || ''), x + 3, yy + (10 - fs2) * 0.6, { width: w - 6, align: t.c ? 'center' : 'left', lineBreak: false });
        x += w;
      }
    };
    y = 150;
    linea(['D. ', { v: nombreNatural(p.profesor), w: '*' }], y); y += 19;
    linea(['profesor/a de ', { v: p.materia, w: 330 }, ' comunica que el'], y); y += 19;
    linea(['alumno/a ', { v: p.alumno, w: '*' }], y); y += 19;
    linea(['del curso ', { v: p.curso, w: 108, c: 1 }, ' grupo ', { v: p.grupoLetra, w: 112, c: 1 }, '. El día ', { v: Number(dd), w: 26, c: 1 },
      ' de ', { v: MESES[Number(mm) - 1], w: 74, c: 1 }, ' de ', { v: aa, w: '*', c: 1 }], y); y += 19;
    linea(['hora ', { v: p.hora, w: 190 }, ', participó en los siguientes hechos:'], y); y += 27;

    /* ---------- conductas ---------- */
    doc.fillColor(TINTA).font('Helvetica-Bold').fontSize(11).text('Conductas recogidas en el decreto 50/2007', X, y, { width: ANCHO, align: 'center', underline: true });
    y += 24;
    const colI = { x: X, w: 248 }, colD = { x: X + 263, w: 252 };
    const cabecera = (col, antes, clave, despues) => {
      doc.fillColor(TINTA).font('Helvetica').fontSize(8.6).text(antes, col.x, y, { continued: true, width: col.w })
        .font('Helvetica-Bold').text(clave, { continued: true, underline: true }).font('Helvetica').text(despues, { underline: false });
      return doc.y;
    };
    const yI = cabecera(colI, 'Conductas ', 'contrarias', ' recogidas en el artículo 37');
    const yD = cabecera(colD, 'Conductas ', 'gravemente', ' perjudiciales para la convivencia, recogidas en el artículo 40');
    const items = (col, lista, marcadas, y0) => {
      let yy = y0 + 7;
      for (const [k, t] of lista) {
        const on = marcadas.includes(k);
        doc.rect(col.x, yy + 0.5, 7.5, 7.5).lineWidth(0.8).strokeColor(TINTA);
        if (on) { doc.fillAndStroke('#e9ddf2', TINTA); doc.moveTo(col.x + 1.3, yy + 1.8).lineTo(col.x + 6.2, yy + 6.7).moveTo(col.x + 6.2, yy + 1.8).lineTo(col.x + 1.3, yy + 6.7).lineWidth(1.4).strokeColor(RELLENO).stroke(); }
        else doc.stroke();
        doc.fillColor(on ? RELLENO : TINTA).font(on ? 'Helvetica-Bold' : 'Helvetica').fontSize(7.3).text(t, col.x + 13, yy, { width: col.w - 13, lineGap: 0.4 });
        yy = doc.y + 6;
      }
      return yy;
    };
    const finI = items(colI, CONTRARIAS, p.contrarias || [], yI);
    const finD = items(colD, GRAVES, p.graves || [], yD);
    y = Math.max(finI, finD) + 6;

    /* ---------- aclaraciones ---------- */
    const altoCaja = Math.max(120, 690 - y);
    doc.rect(X, y, ANCHO, altoCaja).lineWidth(0.8).strokeColor(TINTA).stroke();
    doc.fillColor(TINTA).font('Helvetica').fontSize(8.8).text('Aclaraciones/ observaciones de los hechos si se estiman necesarias, testigos, lugar,...:', X + 8, y + 7, { width: ANCHO - 16 });
    const obs = String(p.observaciones || '');
    let fo = 9.5; doc.font('Helvetica').fontSize(fo);
    const altoTexto = altoCaja - 30;
    while (fo > 6.5 && doc.heightOfString(obs, { width: ANCHO - 20, lineGap: 1 }) > altoTexto) doc.fontSize(fo -= 0.5);
    doc.fillColor(RELLENO).text(obs, X + 10, y + 22, { width: ANCHO - 20, height: altoTexto, lineGap: 1, ellipsis: true });
    y += altoCaja + 14;

    /* ---------- lugar, fecha y firma ---------- */
    const reg = String(p.creado || '').slice(0, 10) || p.fecha;
    const [ra, rm, rd] = reg.split('-');
    const anchoF = 330, xF = X + (ANCHO - anchoF) / 2;
    let x = xF;
    const trozo = (t) => { doc.fillColor(TINTA).font('Helvetica').fontSize(FS).text(t, x, y, { lineBreak: false }); x += doc.widthOfString(t); };
    const hueco = (v, w) => { doc.moveTo(x + 1, y + 11).lineTo(x + w - 1, y + 11).lineWidth(0.6).strokeColor(TINTA).stroke();
      doc.fillColor(RELLENO).font('Helvetica-Bold').fontSize(10).text(String(v), x, y, { width: w, align: 'center', lineBreak: false }); x += w; };
    trozo('Plasencia, a '); hueco(Number(rd), 40); trozo(' de '); hueco(MESES[Number(rm) - 1], 110); trozo(' de '); hueco(ra, 46);
    y += 34;
    x = X + 150; trozo('Fdo.: '); hueco(nombreNatural(p.profesor), 190);
    y += 26;

    /* ---------- nota al pie ---------- */
    doc.fillColor(TINTA).font('Helvetica').fontSize(6.9).text('Este parte se archivará en Jefatura de Estudios, se entregará copia al Tutor y se podrá poner en conocimiento de los padres/tutores legales a decisión de la Jefatura de Estudios. En caso de suspensión del derecho de asistencia a clase, el tutor informará a los representantes legales del alumno/a (D. 50/2007, art. 38.1.b)', X, Math.max(y, 768), { width: ANCHO, lineGap: 0.3 });

    /* sello de recibido (ejemplar de Jefatura) */
    if (tipo === 'jefatura') {
      const txt = p.recibido ? `RECIBIDO · ${fechaHora(p.recibido)} · ${nombreNatural(p.recibidoPor || p.responsable)}` : `PENDIENTE DE RECIBIR · ${nombreNatural(p.responsable)}`;
      doc.font('Helvetica-Bold').fontSize(7.5);
      const w = doc.widthOfString(txt) + 16;
      doc.roundedRect(X + ANCHO - w, 808, w, 15, 4).fill(p.recibido ? '#dcfce7' : '#fef3c7');
      doc.fillColor(p.recibido ? '#166534' : '#92400e').text(txt, X + ANCHO - w + 8, 812.5, { lineBreak: false });
    }
    doc.fillColor(GRIS).font('Helvetica').fontSize(6.5).text(`${p.codigo || ''} · APP_IVJP27 · Jefatura de Estudios`, X, 813, { lineBreak: false });
    doc.end();
  });
}

function fechaHora(s) {
  if (!s) return '';
  const [f, h] = String(s).split(' ');
  const [a, m, d] = f.split('-');
  return `${d}/${m}/${a}${h ? ' ' + h : ''}`;
}
