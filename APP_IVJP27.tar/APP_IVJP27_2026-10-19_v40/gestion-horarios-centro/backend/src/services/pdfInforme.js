/**
 * PDF del informe mensual de ausencias (A4 vertical), con los colores del centro.
 * Devuelve un Buffer. Usa las fuentes estándar de PDF (Helvetica): acentos y ñ funcionan sin incrustar fuentes.
 */
import PDFDocument from 'pdfkit';

const MORADO = '#6B2D8B', MORADO_OSC = '#522270', MORADO_CL = '#F3E8F8', TINTA = '#1a2332', SUAVE = '#4b5563', LINEA = '#e5e2db', CEBRA = '#FAF7FC';
const LOGO = [['M 55 65 Q 80 110 100 140 Q 120 110 175 30 Q 130 95 100 130 Q 85 105 55 65 Z', '#ffffff'],
  ['M 72 78 Q 90 108 100 122 Q 110 108 140 72 Q 118 100 100 118 Q 92 105 72 78 Z', MORADO],
  ['M 85 92 Q 95 108 100 114 Q 105 108 118 92 Q 108 104 100 112 Q 95 106 85 92 Z', '#ffffff']];
const fmt = s => { if (!s) return ''; const [a, m, d] = s.split('-'); return `${d}/${m}/${a}`; };
const corta = s => { if (!s) return ''; const [, m, d] = s.split('-'); return `${d}/${m}`; };
const horasTxt = a => a.modo === 'horas' ? a.horas.map(h => /^R/.test(h) ? 'recreo ' + h.slice(1) : h + 'ª').join(', ') : 'Todo el día';

/** Banda morada con el logo y el nombre del centro */
function cabecera(doc, generado) {
  const W = doc.page.width, X = doc.page.margins.left, ANCHO = W - X - doc.page.margins.right;
  doc.rect(0, 0, W, 92).fill(MORADO);
  doc.save().translate(X - 4, 18).scale(0.3);
  doc.circle(58, 52, 8).fill('#ffffff');
  LOGO.forEach(([p, c]) => doc.path(p).fill(c));
  doc.restore();
  doc.fillColor('#ffffff').font('Helvetica-Bold').fontSize(9).text('IES', X + 58, 24, { characterSpacing: 2 });
  doc.fontSize(17).text('Valle del Jerte', X + 58, 35);
  doc.font('Helvetica').fontSize(9).fillColor('#EBDDF3').text('Jefatura de Estudios · Plasencia · Curso 2026-27', X + 58, 56);
  const gen = new Date(generado).toLocaleString('es-ES', { timeZone: 'Europe/Madrid', day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  doc.fontSize(8).text('Generado el ' + gen, X, 58, { width: ANCHO, align: 'right' });
  doc.y = 112;
}

/** Tabla con cabecera morada que se repite al cambiar de página */
function hacerTabla(doc) {
  const X = doc.page.margins.left, ANCHO = doc.page.width - X - doc.page.margins.right;
  const ABAJO = () => doc.page.height - doc.page.margins.bottom;
  return (cols, filas, vacio) => {
    const fila = (vals, cab, i) => {
      doc.font(cab ? 'Helvetica-Bold' : 'Helvetica').fontSize(8.5);
      const alto = Math.max(16, ...vals.map((v, j) => doc.heightOfString(String(v), { width: cols[j].w - 8 }) + 7));
      if (doc.y + alto > ABAJO()) { doc.addPage(); if (!cab) fila(cols.map(c => c.t), true, 0); }
      const y = doc.y;
      if (cab) doc.rect(X, y, ANCHO, alto).fill(MORADO);
      else if (i % 2) doc.rect(X, y, ANCHO, alto).fill(CEBRA);
      let x = X;
      vals.forEach((v, j) => {
        doc.fillColor(cab ? '#ffffff' : (cols[j].color ? cols[j].color(v) : TINTA)).font(cab ? 'Helvetica-Bold' : (cols[j].b ? 'Helvetica-Bold' : 'Helvetica'))
          .text(String(v), x + 4, y + 4, { width: cols[j].w - 8, align: cols[j].a || 'left' });
        x += cols[j].w;
      });
      doc.moveTo(X, y + alto).lineTo(X + ANCHO, y + alto).lineWidth(0.5).strokeColor(LINEA).stroke();
      doc.y = y + alto;
    };
    fila(cols.map(c => c.t), true, 0);
    if (!filas.length) { doc.fillColor(SUAVE).font('Helvetica-Oblique').fontSize(9).text(vacio, X + 4, doc.y + 5); doc.moveDown(0.8); }
    filas.forEach((f, i) => fila(f, false, i));
    doc.moveDown(1.1);
  };
}

/** Pie de cada página: texto a la izquierda y «Página x de y» */
function pie(doc, texto, numerar = true) {
  const X = doc.page.margins.left, ANCHO = doc.page.width - X - doc.page.margins.right;
  const r = doc.bufferedPageRange();
  for (let i = 0; i < r.count; i++) {
    doc.switchToPage(r.start + i);
    doc.page.margins.bottom = 0;   /* el pie va por debajo del margen: que no abra páginas nuevas */
    const y = doc.page.height - 34;
    doc.moveTo(X, y - 6).lineTo(X + ANCHO, y - 6).lineWidth(0.5).strokeColor(LINEA).stroke();
    doc.fillColor(SUAVE).font('Helvetica').fontSize(7.5).text(texto, X, y, { width: ANCHO * 0.75, lineBreak: false });
    if (numerar) doc.text(`Página ${i + 1} de ${r.count}`, X, y, { width: ANCHO, align: 'right', lineBreak: false });
  }
}
const nuevoDoc = (titulo, partes) => {
  const doc = new PDFDocument({ size: 'A4', margins: { top: 50, bottom: 50, left: 42, right: 42 }, bufferPages: true,
    info: { Title: titulo, Author: 'Jefatura de Estudios · IES Valle del Jerte' } });
  doc.on('data', c => partes.push(c));
  return doc;
};

export function generarPDF(inf, { conMotivo = true, numerar = true } = {}) {
  return new Promise((resolve, reject) => {
    const trozos = [];
    const doc = nuevoDoc('Informe de ausencias · ' + inf.mes.nombre, trozos);
    doc.on('end', () => resolve(Buffer.concat(trozos))); doc.on('error', reject);
    const W = doc.page.width, X = doc.page.margins.left, ANCHO = W - X - doc.page.margins.right;
    const ABAJO = () => doc.page.height - doc.page.margins.bottom;

    cabecera(doc, inf.generado);
    doc.fillColor(TINTA).font('Helvetica-Bold').fontSize(18).text('Informe mensual de ausencias del profesorado', X);
    doc.font('Helvetica').fontSize(12).fillColor(MORADO_OSC).text(inf.mes.nombre.charAt(0).toUpperCase() + inf.mes.nombre.slice(1) +
      `  ·  del ${fmt(inf.mes.desde)} al ${fmt(inf.mes.hasta)}`, X);
    doc.moveDown(0.9);

    /* ---- cifras ---- */
    const t = inf.totales;
    const cifras = [['Ausencias grabadas', t.ausencias], ['Profesores/as', t.profesores], ['Días lectivos', t.dias], ['Sesiones de clase', t.clases], ['Guardias afectadas', t.guardias]];
    const cw = (ANCHO - 4 * 8) / 5, cy = doc.y;
    cifras.forEach(([l, v], i) => {
      const cx = X + i * (cw + 8);
      doc.roundedRect(cx, cy, cw, 54, 6).fill(MORADO_CL);
      doc.fillColor(MORADO_OSC).font('Helvetica-Bold').fontSize(20).text(String(v), cx, cy + 8, { width: cw, align: 'center' });
      doc.fillColor(SUAVE).font('Helvetica').fontSize(8).text(l, cx, cy + 35, { width: cw, align: 'center' });
    });
    doc.y = cy + 66;
    doc.fillColor(SUAVE).fontSize(8).text(`Justificadas: ${t.justificadas} de ${t.ausencias}` + ((t.dap || t.actividad) ? ` (${[t.dap ? t.dap + ' por asuntos propios, DAP' : '', t.actividad ? t.actividad + ' por actividad complementaria o extraescolar' : ''].filter(Boolean).join(' y ')}, que no necesitan justificante)` : '') + '. ' +
      'Días lectivos: de lunes a viernes dentro del mes (no descuenta festivos). Sesiones: según el horario cargado en la app' +
      (t.pendientes ? `. Hay ${t.pendientes} ausencia(s) pendiente(s) de grabar: aparecen en el detalle pero no cuentan en las cifras.` : '.'), X, doc.y, { width: ANCHO });
    doc.moveDown(1);

    /* ---- tablas ---- */
    const titulo = txt => {
      if (doc.y + 60 > ABAJO()) doc.addPage();
      doc.fillColor(TINTA).font('Helvetica-Bold').fontSize(12).text(txt, X, doc.y); doc.moveDown(0.35);
    };
    const tabla = hacerTabla(doc);
    const pct = ANCHO / 100;

    titulo('Resumen por profesor/a');
    tabla([{ t: 'Profesor/a', w: 34 * pct, b: 1 }, { t: 'Ausencias', w: 11 * pct, a: 'center' }, { t: 'Días lectivos', w: 13 * pct, a: 'center' },
      { t: 'Días completos', w: 13 * pct, a: 'center' }, { t: 'Sesiones de clase', w: 15 * pct, a: 'center' }, { t: 'Guardias', w: 14 * pct, a: 'center' }],
    inf.porProfesor.map(p => [p.profesor, p.ausencias, p.dias, p.diasCompletos, p.clases, p.guardias]), 'No hay ausencias grabadas en este mes.');

    if (conMotivo) {
      titulo('Ausencias por motivo (artículo de la Orden de 29/08/2024 si están justificadas)');
      tabla([{ t: 'Motivo', w: 60 * pct, b: 1 }, { t: 'Ausencias', w: 20 * pct, a: 'center' }, { t: 'Días lectivos', w: 20 * pct, a: 'center' }],
        inf.porMotivo.map(m => [m.motivo, m.ausencias, m.dias]), 'Sin datos.');
    }

    titulo('Detalle de las ausencias del mes');
    const cols = [{ t: 'Fechas', w: 13 * pct }, { t: 'Profesor/a', w: conMotivo ? 24 * pct : 39 * pct, b: 1 }, { t: 'Horas', w: 15 * pct },
      ...(conMotivo ? [{ t: 'Motivo notificado', w: 15 * pct }] : []), { t: 'Días / ses.', w: 10 * pct, a: 'center' },
      { t: 'Justificación', w: 12 * pct, color: v => v === 'Sin justificar' ? '#be123c' : '#15803d' },
      { t: 'Estado', w: 11 * pct, color: v => v === 'Pendiente' ? '#b45309' : '#15803d' }];
    tabla(cols, inf.detalle.map(a => [a.hasta ? `${corta(a.fecha)} – ${corta(a.hasta)}` : fmt(a.fecha), a.profesor + (a.sinHorario ? ' *' : ''),
      horasTxt(a), ...(conMotivo ? [a.motivo || '—'] : []), `${a.dias} / ${a.clases + a.guardias}`, a.articulo ? 'Art. ' + a.articulo : a.dap ? 'Justificada (DAP)' : a.actividad ? 'Justificada (actividad)' : 'Sin justificar', a.estado]), 'No hay ausencias registradas en este mes.');
    if (inf.detalle.some(a => a.sinHorario)) doc.fillColor(SUAVE).font('Helvetica').fontSize(8).text('* Nombre que no coincide con ningún profesor/a del horario: no se pueden contar sus sesiones.', X);

    pie(doc, 'APP_IVJP27 · Informe de ausencias · ' + inf.mes.nombre + (conMotivo ? ' · Documento interno: contiene datos personales' : ''), numerar);
    doc.end();
  });
}

/**
 * Hoja de una justificación (una o varias páginas): docente, ausencias cubiertas, horas de cada día
 * con su cómputo de lectivas y complementarias, artículo de la orden y relación de justificantes.
 */
export function generarHojaJustificacion(j, { ausencias = [], generado = new Date().toISOString(), orden = '' } = {}) {
  return new Promise((resolve, reject) => {
    const trozos = [];
    const doc = nuevoDoc('Justificación de ausencia · ' + j.profesor, trozos);
    doc.on('end', () => resolve(Buffer.concat(trozos))); doc.on('error', reject);
    const X = doc.page.margins.left, ANCHO = doc.page.width - X - doc.page.margins.right, pct = ANCHO / 100;
    cabecera(doc, generado);
    doc.fillColor(TINTA).font('Helvetica-Bold').fontSize(16).text('Justificación de ausencia', X);
    doc.font('Helvetica-Bold').fontSize(12).fillColor(MORADO_OSC).text(j.profesor, X);
    doc.moveDown(0.6);
    const dato = (l, v) => { doc.font('Helvetica-Bold').fontSize(9).fillColor(SUAVE).text(l + ': ', X, doc.y, { continued: true }).font('Helvetica').fillColor(TINTA).text(v, { width: ANCHO }); doc.moveDown(0.15); };
    dato('Motivo', `Art. ${j.articulo}. ${j.articuloTxt}`);
    if (orden) dato('Norma', orden);
    dato('Ausencias justificadas', ausencias.map(a => (a.hasta ? `del ${fmt(a.fecha)} al ${fmt(a.hasta)}` : fmt(a.fecha)) + ` (${horasTxt(a).toLowerCase()})`).join('; ') || '—');
    dato('Registrada', `${j.creado} por ${j.usuario || 'el docente'}`);
    if (j.observaciones) dato('Observaciones', j.observaciones);
    doc.moveDown(0.8);
    const tabla = hacerTabla(doc);
    const tramo = t => /^R/.test(t) ? 'Recreo ' + t.slice(1) : t + 'ª';
    const dias = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
    tabla([{ t: 'Día', w: 26 * pct, b: 1 }, { t: 'Horas de ausencia marcadas', w: 44 * pct }, { t: 'Lectivas', w: 15 * pct, a: 'center' }, { t: 'Complem.', w: 15 * pct, a: 'center' }],
      j.detalle.map(d => [`${dias[new Date(d.fecha + 'T12:00:00Z').getUTCDay()]} ${fmt(d.fecha)}`, d.tramos.map(tramo).join(', '),
        d.lectivas + (d.calculadas && d.calculadas.lectivas !== d.lectivas ? ` (calc. ${d.calculadas.lectivas})` : ''),
        d.complementarias + (d.calculadas && d.calculadas.complementarias !== d.complementarias ? ` (calc. ${d.calculadas.complementarias})` : '')])
        .concat([['Total', '', String(j.lectivas), String(j.complementarias)]]), 'Sin días marcados.');
    doc.fillColor(SUAVE).font('Helvetica').fontSize(8).text('Lectivas: docencia y tutoría con alumnado. Complementarias: guardias, recreos, biblioteca, reuniones, atención a familias, jefaturas y demás horas del horario. «calc.»: valor calculado por la app cuando el docente lo ha corregido.', X, doc.y, { width: ANCHO });
    doc.moveDown(1);
    doc.fillColor(TINTA).font('Helvetica-Bold').fontSize(11).text('Documentación justificativa (PDF)', X); doc.moveDown(0.3);
    j.documentos.forEach((d, i) => { doc.font('Helvetica').fontSize(9).fillColor(TINTA).text(`${i + 1}. ${d.nombre}  ·  subido el ${d.subido}  ·  ${Math.max(1, Math.round(d.bytes / 1024))} KB`, X + 8, doc.y, { width: ANCHO - 8 }); });
    if (!j.documentos.length) doc.font('Helvetica-Oblique').fontSize(9).fillColor('#be123c').text('Sin justificantes.', X + 8);
    pie(doc, 'APP_IVJP27 · Justificación de ausencia · ' + j.profesor, false);
    doc.end();
  });
}
