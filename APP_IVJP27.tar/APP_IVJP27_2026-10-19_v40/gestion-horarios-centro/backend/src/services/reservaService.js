/**
 * Reserva de espacios.
 * Reglas:
 *  · Cualquier docente con sesión puede ver los cuadrantes y reservar periodos libres.
 *  · Una reserva del profesorado va de un día de inicio a uno de fin DENTRO DE LA MISMA SEMANA
 *    (lunes a viernes) y solo en fechas de hoy en adelante. Para más tiempo, se pide a Jefatura.
 *  · Los periodos fijos (bloqueos) no se pueden reservar nunca.
 *  · Cada docente anula sus reservas; administración anula cualquiera.
 *  · Administración puede reservar varias semanas seguidas (se repite el patrón cada semana).
 */
import crypto from 'node:crypto';
import { query, transaccion } from '../db.js';
import { config } from '../config.js';
import { Tramo } from '../models/index.js';

const err = (msg, status = 400) => Object.assign(new Error(msg), { status });
const ISO = /^\d{4}-\d{2}-\d{2}$/;
const TRAMOS = Tramo.TRAMOS_CENTRO.filter(t => t.tipo === 'clase');
const TRAMO_OK = new Set(TRAMOS.map(t => t.codigo));
const txt = (v, n = 80) => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, n);

/* fechas como texto AAAA-MM-DD, sin problemas de zona horaria */
const aDate = s => new Date(s + 'T12:00:00Z');
const aIso = d => d.toISOString().slice(0, 10);
const diaSemana = s => ((aDate(s).getUTCDay() + 6) % 7) + 1;            // 1 lunes … 7 domingo
const lunes = s => { const d = aDate(s); d.setUTCDate(d.getUTCDate() - (diaSemana(s) - 1)); return aIso(d); };
const sumar = (s, n) => { const d = aDate(s); d.setUTCDate(d.getUTCDate() + n); return aIso(d); };
const hoy = () => new Intl.DateTimeFormat('en-CA', { timeZone: config.tz }).format(new Date());

export const tramos = () => TRAMOS.map(t => ({ codigo: t.codigo, inicio: t.inicio, fin: t.fin, turno: t.turno }));

/* ── espacios ── */
export async function espacios(todos = false) {
  const { rows } = await query(`SELECT id, nombre, aula, activo FROM espacio ${todos ? '' : 'WHERE activo'} ORDER BY orden, nombre`);
  return rows;
}
export async function crearEspacio({ nombre, aula }) {
  nombre = txt(nombre, 60); if (!nombre) throw err('Escribe el nombre del espacio');
  let id = nombre.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'espacio';
  const { rows } = await query('SELECT id FROM espacio WHERE id LIKE $1', [id + '%']);
  if (rows.some(r => r.id === id)) id += '-' + (rows.length + 1);
  const { rows: [m] } = await query('SELECT COALESCE(MAX(orden),0)+1 AS o FROM espacio');
  await query('INSERT INTO espacio (id, nombre, aula, orden) VALUES ($1,$2,$3,$4)', [id, nombre, txt(aula, 20), m.o]);
  return { id };
}
export async function cambiarEspacio(id, { nombre, aula, activo }) {
  const { rowCount } = await query(`UPDATE espacio SET nombre = COALESCE($2, nombre), aula = COALESCE($3, aula), activo = COALESCE($4, activo) WHERE id = $1`,
    [id, nombre != null ? (txt(nombre, 60) || null) : null, aula != null ? txt(aula, 20) : null, typeof activo === 'boolean' ? activo : null]);
  if (!rowCount) throw err('No existe ese espacio', 404);
}

/* ── periodos fijos (bloqueos) ── */
export async function bloquear(espacio, { dia, tramo, etiqueta, bloqueado }) {
  dia = Number(dia); tramo = String(tramo);
  if (!(dia >= 1 && dia <= 5) || !TRAMO_OK.has(tramo)) throw err('Periodo no válido');
  if (bloqueado === false) { await query('DELETE FROM bloqueo_espacio WHERE espacio=$1 AND dia=$2 AND tramo=$3', [espacio, dia, tramo]); return; }
  await query(`INSERT INTO bloqueo_espacio (espacio, dia, tramo, etiqueta) VALUES ($1,$2,$3,$4)
    ON CONFLICT (espacio, dia, tramo) DO UPDATE SET etiqueta = EXCLUDED.etiqueta`, [espacio, dia, tramo, txt(etiqueta, 60) || 'Clase fija']);
}
/** Bloquea los periodos en que el horario tiene clase en el aula asociada al espacio */
export async function bloquearDesdeHorario(espacio) {
  const { rows: [e] } = await query('SELECT aula FROM espacio WHERE id = $1', [espacio]);
  if (!e) throw err('No existe ese espacio', 404);
  if (!e.aula) throw err('Este espacio no tiene un aula del horario asociada');
  const { rows } = await query(`SELECT c.dia, c.tramo, string_agg(DISTINCT COALESCE(g.codigo, c.materia), ' · ') AS etiqueta
    FROM clase c JOIN aula a ON a.id = c.aula_id JOIN profesor p ON p.id = c.profesor_id LEFT JOIN grupo g ON g.id = c.grupo_id
    WHERE a.codigo = $1 AND p.activo GROUP BY c.dia, c.tramo`, [e.aula]);
  let n = 0;
  for (const r of rows) if (TRAMO_OK.has(r.tramo)) { await bloquear(espacio, { dia: r.dia, tramo: r.tramo, etiqueta: 'Clase: ' + r.etiqueta }); n++; }
  return { bloqueados: n };
}

/* ── cuadrante de una semana ── */
export async function semana(espacio, desde, usuarioId) {
  if (!ISO.test(String(desde || ''))) desde = hoy();
  const ini = lunes(desde), fin = sumar(ini, 4);
  const { rows: bloqueos } = await query('SELECT dia, tramo, etiqueta FROM bloqueo_espacio WHERE espacio = $1', [espacio]);
  const { rows: reservas } = await query(`SELECT id, to_char(fecha,'YYYY-MM-DD') AS fecha, tramo, docente, materia, lote,
      (usuario_id = $4) AS mia FROM reserva WHERE espacio = $1 AND fecha BETWEEN $2 AND $3 ORDER BY fecha, tramo`,
    [espacio, ini, fin, usuarioId || 0]);
  return { semana: ini, dias: [0, 1, 2, 3, 4].map(i => sumar(ini, i)), hoy: hoy(), bloqueos, reservas };
}

/* ── reservar ── */
export async function reservar(usuario, { espacio, ini, fin, docente, materia, celdas }, esAdmin) {
  if (!ISO.test(String(ini || ''))) throw err('Indica el día de inicio');
  fin = ISO.test(String(fin || '')) ? fin : ini;
  if (fin < ini) throw err('El día de fin no puede ser anterior al de inicio');
  docente = txt(docente); materia = txt(materia);
  if (!docente || !materia) throw err('Escribe el docente y la materia');
  if (!Array.isArray(celdas) || !celdas.length) throw err('Marca en el cuadrante al menos un periodo');
  const { rows: [esp] } = await query('SELECT id FROM espacio WHERE id = $1 AND activo', [espacio]);
  if (!esp) throw err('Ese espacio no se puede reservar', 404);
  if (ini < hoy() && !esAdmin) throw err('No se puede reservar en días pasados');
  const variasSemanas = lunes(fin) !== lunes(ini);
  if (variasSemanas && !esAdmin)
    throw err('La reserva debe estar dentro de una sola semana. Para periodos más largos, contacta con Jefatura de Estudios.');

  /* celdas marcadas → fechas concretas (administración: el patrón se repite cada semana hasta el día de fin) */
  const pedidas = new Map();
  for (const c of celdas) {
    const f = String(c.fecha || ''), t = String(c.tramo || '');
    if (!ISO.test(f) || !TRAMO_OK.has(t) || diaSemana(f) > 5) throw err('Periodo no válido');
    if (!variasSemanas && (f < ini || f > fin)) throw err('Los periodos marcados deben estar entre el día de inicio y el de fin');
    if (variasSemanas) {
      for (let d = sumar(lunes(ini), diaSemana(f) - 1); d <= fin; d = sumar(d, 7)) if (d >= ini) pedidas.set(d + '|' + t, { fecha: d, tramo: t });
    } else pedidas.set(f + '|' + t, { fecha: f, tramo: t });
  }
  const lote = crypto.randomBytes(8).toString('hex');
  return transaccion(async db => {
    const { rows: bl } = await db.query('SELECT dia, tramo FROM bloqueo_espacio WHERE espacio = $1', [espacio]);
    const fijo = new Set(bl.map(b => b.dia + '|' + b.tramo));
    const hechas = [], conflictos = [];
    for (const { fecha, tramo } of pedidas.values()) {
      if (fijo.has(diaSemana(fecha) + '|' + tramo)) { conflictos.push({ fecha, tramo, motivo: 'periodo fijo' }); continue; }
      const r = await db.query(`INSERT INTO reserva (espacio, fecha, tramo, docente, materia, usuario_id, lote)
        VALUES ($1,$2,$3,$4,$5,$6,$7) ON CONFLICT (espacio, fecha, tramo) DO NOTHING RETURNING id`,
        [espacio, fecha, tramo, docente, materia, usuario.id, lote]);
      if (r.rowCount) hechas.push({ fecha, tramo }); else conflictos.push({ fecha, tramo, motivo: 'ya reservado' });
    }
    /* el profesorado reserva todo o nada; administración se queda con lo posible y ve los conflictos */
    if (conflictos.length && !esAdmin) {
      const e = err('Alguno de los periodos ya no está disponible. Actualiza el cuadrante y vuelve a elegir.', 409);
      e.conflictos = conflictos; throw e;
    }
    if (!hechas.length) throw err('Ninguno de los periodos estaba libre', 409);
    return { lote, reservadas: hechas.length, conflictos };
  });
}

/** Anular una celda (o toda la reserva con lote=true): la propia o, si es administración, cualquiera */
export async function anular(usuario, id, todoElLote, esAdmin) {
  const { rows: [r] } = await query('SELECT id, lote, usuario_id FROM reserva WHERE id = $1', [id]);
  if (!r) throw err('Esa reserva ya no existe', 404);
  if (!esAdmin && r.usuario_id !== usuario.id) throw err('Solo puedes anular tus propias reservas', 403);
  const { rowCount } = todoElLote
    ? await query('DELETE FROM reserva WHERE lote = $1 AND fecha >= $2', [r.lote, esAdmin ? '1900-01-01' : hoy()])
    : await query('DELETE FROM reserva WHERE id = $1', [id]);
  return { anuladas: rowCount };
}
