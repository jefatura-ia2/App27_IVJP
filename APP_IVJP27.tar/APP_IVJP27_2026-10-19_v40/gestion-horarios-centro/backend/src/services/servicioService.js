/**
 * Avisos, enlaces de calendarios y ausencias del profesorado, guardados en la base de datos de la app.
 * Sustituye al servicio de Google Apps Script de la hoja «Ausencias 2026-27»: mantiene la misma
 * forma de datos ({avisos, calendarios, ausencias, pendientes}) para que la app no cambie.
 */
import crypto from 'node:crypto';
import { query, transaccion } from '../db.js';
import { Ajuste, Profesor } from '../models/index.js';
import { PENDIENTE, GRABADA } from '../models/Ausencia.js';

const ISO = /^\d{4}-\d{2}-\d{2}$/;
const HORAS = ['1', '2', 'R1', '3', '4', 'R2', '5', '6', '7', '8', '9', '10', '11', '12', '13'];
const CLAVE_CAL = 'calendarios';
export const nuevoId = () => crypto.randomBytes(4).toString('hex');
const err = (msg, status = 400) => Object.assign(new Error(msg), { status });

export function normalizarHoras(v) {
  const l = Array.isArray(v) ? v : String(v || '').split(/[,;\s]+/);
  const set = new Set(l.map(h => String(h).toUpperCase().replace(/[ªº]/g, '').trim()));
  return HORAS.filter(h => set.has(h));
}

/** Deja una ausencia en la forma que se guarda (mismas reglas que tenía la hoja) */
export function limpiarAusencia(a = {}) {
  const horas = normalizarHoras(a.horas);
  const modo = a.modo === 'horas' && horas.length ? 'horas' : 'dia';
  const fecha = String(a.fecha || '').slice(0, 10);
  const hasta = String(a.hasta || '').slice(0, 10);
  return {
    id: String(a.id || '').trim(), prof: String(a.prof || a.profesor || '').trim(),
    fecha: ISO.test(fecha) ? fecha : '', hasta: ISO.test(hasta) && hasta > fecha ? hasta : '',
    modo, horas: modo === 'horas' ? horas : [],
    motivo: String(a.motivo || '').slice(0, 200), obs: String(a.obs || a.tarea || '').slice(0, 1000),
    canal: String(a.canal || '').slice(0, 60),
    detalle: limpiarDetalle(a.detalle, modo === 'horas' ? horas : HORAS),
  };
}
/**
 * Aula y tarea por tramo: {"3":{"aula":"209","obs":"Ficha 4"}} (vale para todos los días de la ausencia)
 * o por día y tramo: {"2026-10-22|3":{"obs":"Ejercicios p. 58"}} (las que deja el profesor/a para cada día).
 * Solo tramos válidos y con algo escrito.
 */
export function limpiarDetalle(d, tramos) {
  const out = {};
  if (!d || typeof d !== 'object') return out;
  for (const [k, x] of Object.entries(d)) {
    const m = String(k).match(/^(?:(\d{4}-\d{2}-\d{2})\|)?([0-9R]{1,2})$/);
    if (!m || !tramos.includes(m[2]) || !x || typeof x !== 'object') continue;
    const aula = String(x.aula || '').trim().slice(0, 30), obs = String(x.obs || '').trim().slice(0, 600);
    if (aula || obs) out[k] = { ...(aula ? { aula } : {}), ...(obs ? { obs } : {}) };
    if (Object.keys(out).length >= 200) break;
  }
  return out;
}

const SELECT = `SELECT id, profesor AS prof, to_char(fecha,'YYYY-MM-DD') AS fecha, COALESCE(to_char(hasta,'YYYY-MM-DD'),'') AS hasta,
  modo, horas, tarea AS obs, detalle, motivo, estado, to_char(creado AT TIME ZONE 'Europe/Madrid','YYYY-MM-DD') AS creado, registrado_por,
  canal, justificacion_id
  FROM ausencia`;

/* ---------------- lectura ---------------- */
export async function leerAvisos() {
  const { rows } = await query(`SELECT id, titulo, texto, nivel, COALESCE(to_char(caduca,'YYYY-MM-DD'),'') AS caduca, enlace,
    to_char(publicado,'YYYY-MM-DD') AS fecha FROM aviso ORDER BY publicado DESC, id`);
  return rows;
}
export async function leerCalendarios() {
  try { return JSON.parse(await Ajuste.leer({ query }, CLAVE_CAL) || '{}'); } catch { return {}; }
}
/** Para Jefatura: todas, con motivo y estado */
export async function ausenciasAdmin() {
  return (await query(`${SELECT} ORDER BY fecha, profesor`)).rows;
}
/** Para todo el claustro: solo grabadas, sin motivo, desde hace una semana en adelante */
async function ausenciasPublicas() {
  const { rows } = await query(`${SELECT} WHERE estado = $1 AND COALESCE(hasta, fecha) >= CURRENT_DATE - 7 ORDER BY fecha, profesor`, [GRABADA]);
  return rows.map(({ motivo, estado, registrado_por, canal, justificacion_id, ...a }) => a);
}
export async function datosPublicos() {
  const [avisos, calendarios, ausencias, p] = await Promise.all([leerAvisos(), leerCalendarios(), ausenciasPublicas(),
    query(`SELECT count(*)::int AS n FROM ausencia WHERE estado = $1`, [PENDIENTE])]);
  return { avisos, calendarios, ausencias, pendientes: p.rows[0].n };
}

/* ---------------- ausencias ---------------- */
async function escribirAusencia(db, a, estado, por) {
  const p = await Profesor.buscarPorNombre(db, a.prof);
  const id = a.id || nuevoId();
  await db.query(
    `INSERT INTO ausencia (id, profesor, profesor_id, fecha, hasta, modo, horas, tarea, motivo, estado, registrado_por, canal, detalle)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
     ON CONFLICT (id) DO UPDATE SET profesor=EXCLUDED.profesor, profesor_id=EXCLUDED.profesor_id, fecha=EXCLUDED.fecha,
       hasta=EXCLUDED.hasta, modo=EXCLUDED.modo, horas=EXCLUDED.horas, tarea=EXCLUDED.tarea, motivo=EXCLUDED.motivo,
       /* las tareas por día que dejó el profesor/a («AAAA-MM-DD|tramo») se conservan al editar desde Jefatura */
       detalle=COALESCE((SELECT jsonb_object_agg(e.key, e.value) FROM jsonb_each(ausencia.detalle) e WHERE e.key LIKE '%|%'), '{}'::jsonb) || EXCLUDED.detalle,
       estado=EXCLUDED.estado, canal=CASE WHEN EXCLUDED.canal <> '' THEN EXCLUDED.canal ELSE ausencia.canal END, sincronizado=now()`,
    [id, p ? p.nombre : a.prof, p ? p.id : null, a.fecha, a.hasta || null, a.modo, a.horas, a.obs, a.motivo, estado, por || '', a.canal || '', JSON.stringify(a.detalle || {})]);
  return id;
}

/** Notificación de un docente: queda pendiente de que Jefatura la grabe */
export async function notificar(a, por) {
  const l = limpiarAusencia(a);
  if (!l.prof || !l.fecha) throw err('Faltan datos de la ausencia');
  if (l.id && (await query('SELECT 1 FROM ausencia WHERE id = $1', [l.id])).rowCount) return l.id;   /* reenvío: no se duplica */
  return transaccion(db => escribirAusencia(db, l, PENDIENTE, por));
}
/** Jefatura añade o corrige una ausencia: queda grabada */
export async function guardarAusencia(a, por) {
  const l = limpiarAusencia(a);
  if (!l.prof || !l.fecha) throw err('Indica profesor/a y fecha');
  return transaccion(db => escribirAusencia(db, l, GRABADA, por));
}
/**
 * Registro semanal de Jefatura (rejilla Lunes–Viernes de un profesor/a): graba de una vez las ausencias de esa
 * semana y quita las que ya no están marcadas. Todo o nada.
 */
export async function guardarSemana({ ausencias = [], borrar = [] } = {}, por) {
  const ls = (Array.isArray(ausencias) ? ausencias : []).slice(0, 40).map(limpiarAusencia);
  if (ls.some(l => !l.prof || !l.fecha)) throw err('Indica profesor/a y fecha');
  const quitar = lista(borrar).filter(id => !ls.some(l => l.id === id));
  return transaccion(async db => {
    const ids = [];
    for (const l of ls) ids.push(await escribirAusencia(db, l, GRABADA, por));
    if (quitar.length) await db.query(`DELETE FROM ausencia WHERE id = ANY($1::text[])`, [quitar]);
    return ids;
  });
}
const lista = ids => (Array.isArray(ids) ? ids : [ids]).map(String).filter(Boolean);
export async function grabarAusencias(ids) {
  await query(`UPDATE ausencia SET estado = $2 WHERE id = ANY($1::text[])`, [lista(ids), GRABADA]);
}
export async function borrarAusencias(ids) {
  await query(`DELETE FROM ausencia WHERE id = ANY($1::text[])`, [lista(ids)]);
}

/** Ausencias del propio profesor/a desde una fecha (para «Mis ausencias» y sus tareas) */
export async function ausenciasDe(prof, desde) {
  const { rows } = await query(`${SELECT} WHERE profesor = $1 AND COALESCE(hasta, fecha) >= $2::date ORDER BY fecha`, [prof, desde]);
  return rows;
}
/** El profesor/a deja (o cambia) las tareas de una ausencia suya: por día y hora, y unas indicaciones generales */
export async function guardarTareas(id, prof, { detalle, obs } = {}) {
  const { rows } = await query(`${SELECT} WHERE id = $1`, [String(id || '')]);
  const a = rows[0];
  if (!a) throw err('Esa ausencia ya no existe', 404);
  if (a.prof !== prof) throw err('Solo puedes dejar tareas en tus propias ausencias');
  const tramos = a.modo === 'horas' ? a.horas : HORAS;
  /* se conserva el aula que hubiera anotado Jefatura */
  const nuevo = limpiarDetalle(detalle, tramos);
  const previo = a.detalle || {};
  for (const [k, v] of Object.entries(previo)) if (v.aula && !nuevo[k]) nuevo[k] = { aula: v.aula };
  for (const [k, v] of Object.entries(nuevo)) if (previo[k] && previo[k].aula && !v.aula) v.aula = previo[k].aula;
  await query(`UPDATE ausencia SET detalle = $2, tarea = $3, sincronizado = now() WHERE id = $1`,
    [a.id, JSON.stringify(nuevo), obs === undefined ? a.obs : String(obs || '').slice(0, 1000)]);
}

/* ---------------- avisos y calendarios ---------------- */
export async function guardarAviso(a = {}) {
  const caduca = ISO.test(String(a.caduca || '')) ? a.caduca : null;
  await query(`INSERT INTO aviso (id, titulo, texto, nivel, caduca, enlace) VALUES ($1,$2,$3,$4,$5,$6)
    ON CONFLICT (id) DO UPDATE SET titulo=EXCLUDED.titulo, texto=EXCLUDED.texto, nivel=EXCLUDED.nivel,
      caduca=EXCLUDED.caduca, enlace=EXCLUDED.enlace`,
    [String(a.id || '') || nuevoId(), String(a.titulo || '').slice(0, 200), String(a.texto || '').slice(0, 4000),
      String(a.nivel || 'info').slice(0, 20), caduca, String(a.enlace || '').slice(0, 500)]);
}
export async function borrarAviso(id) { await query('DELETE FROM aviso WHERE id = $1', [String(id || '')]); }
export async function guardarCalendario(k, c = {}) {
  k = String(k || '').trim();
  if (!/^[a-z0-9_-]{1,30}$/i.test(k)) throw err('Calendario no válido');
  const cal = await leerCalendarios();
  cal[k] = { nombre: String(c.nombre || '').slice(0, 120), url: String(c.url || '').slice(0, 2000) };
  await Ajuste.guardar({ query }, CLAVE_CAL, JSON.stringify(cal));
}

/* ---------------- importación única desde la hoja de Google ---------------- */
/**
 * Copia a la base de datos todo lo que había en la hoja «Ausencias 2026-27» (ausencias con motivo y
 * estado, avisos y enlaces de calendarios) usando su servicio de Apps Script. No borra nada de la base
 * de datos: lo que ya existe con el mismo identificador se actualiza.
 */
export async function importarDeHoja(url, clave, fetchImpl = fetch) {
  if (!url) throw err('No hay dirección del servicio de la hoja (SHEETS_SERVICE_URL)');
  const post = async cuerpo => {
    const r = await fetchImpl(url, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify(cuerpo), redirect: 'follow' });
    return r.json();
  };
  const g = await fetchImpl(url + (url.includes('?') ? '&' : '?') + 'accion=datos&t=' + Date.now(), { redirect: 'follow' });
  const datos = await g.json();
  const adm = await post({ accion: 'ausencias_admin', clave });
  if (!adm || !adm.ok || !Array.isArray(adm.ausencias)) throw err((adm && adm.error) || 'La hoja no entregó las ausencias (¿contraseña de administración?)', 502);
  let ausencias = 0, avisos = 0, calendarios = 0;
  await transaccion(async db => {
    for (const x of adm.ausencias) {
      const l = limpiarAusencia(x);
      if (!l.id || !l.prof || !l.fecha) continue;
      await escribirAusencia(db, l, x.estado === PENDIENTE ? PENDIENTE : GRABADA, 'hoja de Google');
      if (/^\d{4}-\d{2}-\d{2}$/.test(String(x.creado || ''))) await db.query('UPDATE ausencia SET creado = $2::date WHERE id = $1', [l.id, x.creado]);
      ausencias++;
    }
  });
  for (const a of (datos && datos.avisos) || []) { if (a.id || a.titulo) { await guardarAviso(a); avisos++; } }
  const cal = (datos && datos.calendarios) || {};
  for (const k of Object.keys(cal)) { if (cal[k] && (cal[k].url || cal[k].nombre)) { await guardarCalendario(k, cal[k]); calendarios++; } }
  return { ausencias, avisos, calendarios };
}
