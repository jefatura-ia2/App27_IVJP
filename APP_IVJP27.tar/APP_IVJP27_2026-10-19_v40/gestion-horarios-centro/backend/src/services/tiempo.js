/** Fecha y hora "de pared" en la zona horaria del centro */
import { config } from '../config.js';
import { TRAMOS_CENTRO } from '../models/Tramo.js';

export function ahora(fechaBase = new Date(), tz = config.tz) {
  const partes = Object.fromEntries(new Intl.DateTimeFormat('en-CA', {
    timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', hour12: false, weekday: 'short',
  }).formatToParts(fechaBase).map(p => [p.type, p.value]));
  const fecha = `${partes.year}-${partes.month}-${partes.day}`;
  const hhmm = `${partes.hour === '24' ? '00' : partes.hour}:${partes.minute}`;
  return { fecha, hhmm, dia: diaSemana(fecha) };
}

/** 1 = lunes … 5 = viernes; null en fin de semana */
export function diaSemana(fechaISO) {
  const d = new Date(fechaISO + 'T12:00:00Z').getUTCDay();
  return d >= 1 && d <= 5 ? d : null;
}

/** Tramo que contiene la hora indicada (o null fuera de horario) */
export function tramoEn(hhmm, tramos = TRAMOS_CENTRO) {
  return tramos.find(t => hhmm >= t.inicio && hhmm < t.fin) || null;
}

/** Siguiente tramo que empieza después de la hora indicada */
export function siguienteTramo(hhmm, tramos = TRAMOS_CENTRO) {
  return [...tramos].sort((a, b) => a.orden - b.orden).find(t => t.inicio > hhmm) || null;
}

export const esFechaISO = s => /^\d{4}-\d{2}-\d{2}$/.test(String(s || '')) && !isNaN(new Date(s + 'T12:00:00Z'));
