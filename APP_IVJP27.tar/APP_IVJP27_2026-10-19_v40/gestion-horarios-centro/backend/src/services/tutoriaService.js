/**
 * Reunión de tutores con las familias: quién es tutor/a de cada grupo, fecha y hora de la
 * reunión (la fija Jefatura) y los datos del grupo que se insertan en la presentación:
 * horario del grupo, tutor/a y materias con el profesor/a que las imparte.
 */
import { query } from '../db.js';
import * as Ajuste from '../models/Ajuste.js';
import { Tramo } from '../models/index.js';

const db = { query };
const err = (msg, status = 400) => Object.assign(new Error(msg), { status });
const DIAS = ['', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes'];
const hhmm = t => String(t || '').slice(0, 5);
const TRAMO = Object.fromEntries(Tramo.TRAMOS_CENTRO.map(t => [t.codigo, t]));

/* ── fecha y hora de la reunión ── */
export async function reunion() {
  try { return JSON.parse(await Ajuste.leer(db, 'reunion_familias') || '{}'); } catch { return {}; }
}
export async function guardarReunion({ fecha, hora, lugar } = {}) {
  if (fecha && !/^\d{4}-\d{2}-\d{2}$/.test(fecha)) throw err('Fecha no válida');
  if (hora && !/^\d{2}:\d{2}$/.test(hora)) throw err('Hora no válida');
  const r = { fecha: fecha || '', hora: hora || '', lugar: String(lugar || '').trim().slice(0, 120) };
  await Ajuste.guardar(db, 'reunion_familias', JSON.stringify(r));
  return r;
}

/* ── tutorías ── */
export async function gruposDe(profesor) {
  if (!profesor) return [];
  const { rows } = await query('SELECT grupo, nombre_grupo AS "nombreGrupo", delegado, subdelegado FROM tutoria WHERE profesor = $1 ORDER BY grupo', [profesor]);
  return rows;
}
export async function listar() {
  const { rows: tutorias } = await query('SELECT grupo, profesor, nombre_grupo AS "nombreGrupo", delegado, subdelegado FROM tutoria ORDER BY grupo');
  const { rows: grupos } = await query(`SELECT DISTINCT g.codigo FROM clase c JOIN grupo g ON g.id = c.grupo_id
    JOIN profesor p ON p.id = c.profesor_id WHERE p.activo ORDER BY g.codigo`);
  return { tutorias, grupos: grupos.map(r => r.codigo) };
}
export async function asignar(grupo, profesor, nombreGrupo) {
  grupo = String(grupo || '').trim(); profesor = String(profesor || '').trim();
  if (!grupo) throw err('Falta el grupo');
  if (!profesor) { await query('DELETE FROM tutoria WHERE grupo = $1', [grupo]); return; }
  const { rowCount } = await query('SELECT 1 FROM profesor WHERE nombre = $1 AND activo', [profesor]);
  if (!rowCount) throw err('Ese profesor/a no está en el horario');
  await query(`INSERT INTO tutoria (grupo, profesor, nombre_grupo) VALUES ($1,$2,$3)
    ON CONFLICT (grupo) DO UPDATE SET profesor = EXCLUDED.profesor,
      nombre_grupo = CASE WHEN $3 = '' THEN tutoria.nombre_grupo ELSE EXCLUDED.nombre_grupo END`,
    [grupo, profesor, String(nombreGrupo || '').trim()]);
}

/** ¿Puede esta cuenta preparar la presentación de este grupo? (su tutor/a o administración) */
export async function puedeVer(grupo, { esAdmin, profesor }) {
  if (esAdmin) return true;
  const { rowCount } = await query('SELECT 1 FROM tutoria WHERE grupo = $1 AND profesor = $2', [grupo, profesor || '']);
  return rowCount > 0;
}

/* «Apellidos, Nombre» → «Nombre Apellidos» */
export const nombreNatural = n => { const [a, b] = String(n || '').split(', '); return b ? `${b} ${a}` : String(n || ''); };
const franja = (dia, tramo) => { const t = TRAMO[tramo]; return `${DIAS[dia]} de ${t ? t.inicio : ''} a ${t ? t.fin : ''}`; };

/** Datos del grupo para la presentación */
export async function datosGrupo(grupo) {
  const { rows: [tut] } = await query('SELECT grupo, profesor, nombre_grupo AS "nombreGrupo", delegado, subdelegado FROM tutoria WHERE grupo = $1', [grupo]);
  const { rows: ses } = await query(
    `SELECT c.dia, c.tramo, c.materia, c.tipo, c.categoria, COALESCE(a.codigo,'') AS aula, p.nombre AS profesor
     FROM clase c JOIN grupo g ON g.id = c.grupo_id JOIN profesor p ON p.id = c.profesor_id
     LEFT JOIN aula a ON a.id = c.aula_id JOIN tramo t ON t.codigo = c.tramo
     WHERE g.codigo = $1 AND p.activo ORDER BY c.dia, t.orden, c.materia`, [grupo]);
  if (!ses.length && !tut) throw err('Ese grupo no está en el horario', 404);

  /* materias con su profesorado (sin tutoría, guardias, etc.) */
  const mat = new Map();
  for (const s of ses) if (s.categoria === 'docencia') {
    if (!mat.has(s.materia)) mat.set(s.materia, new Set());
    mat.get(s.materia).add(nombreNatural(s.profesor));
  }
  const materias = [...mat].map(([materia, ps]) => ({ materia, profesores: [...ps] }))
    .sort((a, b) => a.materia.localeCompare(b.materia, 'es'));

  /* tramos que tiene el grupo (mañana y/o tarde), con los recreos intermedios */
  const usados = new Set(ses.map(s => s.tramo));
  const ordenes = Tramo.TRAMOS_CENTRO.filter(t => usados.has(t.codigo)).map(t => t.orden);
  const [min, max] = [Math.min(...ordenes), Math.max(...ordenes)];
  const tramos = Tramo.TRAMOS_CENTRO.filter(t => t.orden >= min && t.orden <= max)
    .map(t => ({ codigo: t.codigo, inicio: t.inicio, fin: t.fin, recreo: t.tipo === 'recreo' }));

  const horario = ses.filter(s => s.categoria === 'docencia' || s.categoria === 'tutoria')
    .map(s => ({ dia: s.dia, tramo: s.tramo, materia: s.materia, aula: s.aula, profesor: nombreNatural(s.profesor) }));

  /* del horario del tutor/a: tutoría con el grupo y hora de atención a familias */
  let tutoriaSemanal = '', atencion = '';
  if (tut) {
    const t1 = ses.find(s => s.categoria === 'tutoria' && s.profesor === tut.profesor);
    if (t1) tutoriaSemanal = franja(t1.dia, t1.tramo);
    const { rows: [t2] } = await query(
      `SELECT c.dia, c.tramo FROM clase c JOIN profesor p ON p.id = c.profesor_id
       WHERE p.nombre = $1 AND c.materia ILIKE '%padres%' ORDER BY c.dia LIMIT 1`, [tut.profesor]);
    if (t2) atencion = franja(t2.dia, t2.tramo);
  }
  return {
    grupo, nombreGrupo: (tut && tut.nombreGrupo) || grupo,
    tutor: tut ? nombreNatural(tut.profesor) : '', tutorHorario: tut ? tut.profesor : '',
    delegado: tut ? tut.delegado : '', subdelegado: tut ? tut.subdelegado : '',
    tutoriaSemanal, atencion, materias, tramos, horario, reunion: await reunion(),
  };
}

/** Delegado/a y subdelegado/a del grupo (los escribe su tutor/a) */
export async function guardarDelegados(grupo, { delegado, subdelegado } = {}) {
  const limpio = v => String(v || '').replace(/\s+/g, ' ').trim().slice(0, 80);
  const { rowCount } = await query('UPDATE tutoria SET delegado = $2, subdelegado = $3 WHERE grupo = $1',
    [grupo, limpio(delegado), limpio(subdelegado)]);
  if (!rowCount) throw err('Ese grupo no tiene tutoría asignada', 404);
  return { delegado: limpio(delegado), subdelegado: limpio(subdelegado) };
}
