/* Requiere PostgreSQL (DATABASE_URL). Usa un esquema temporal para no tocar los datos reales. */
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { pool, query } from '../src/db.js';
import { migrar } from '../src/models/index.js';
import { csvHorarios } from '../src/ingestors/index.js';
import * as S from '../src/services/servicioService.js';
import { datosInforme } from '../src/services/informeAusencias.js';
import { generarPDF } from '../src/services/pdfInforme.js';
import * as J from '../src/services/justificacionService.js';
import { generarDossier } from '../src/services/dossier.js';
import { PDFDocument } from 'pdf-lib';
import fs from 'node:fs/promises';
import { estadoDelDia } from '../src/services/guardiasService.js';
import { buscar, sesionesDe, aulasLibres } from '../src/services/horarioService.js';
import * as B from '../src/services/bibliotecaService.js';
import * as Auth from '../src/services/authService.js';

const ESQUEMA = 'prueba_' + process.pid;
const CSV = [
  '"Pérez Gil, Ana",2,3,,,,Guardia de Aula',
  '"López Sanz, Luis",2,3,Matemáticas,E1A,101,Docencia',
  '"López Sanz, Luis",2,4,Matemáticas,E1B,102,Docencia',
  '"Pérez Gil, Ana",2,R1,,,,Guardia de Recreo',
].join('\n');

before(async () => {
  pool.on('connect', c => c.query(`SET search_path TO ${ESQUEMA}`));
  await pool.query(`CREATE SCHEMA ${ESQUEMA}`);
  await migrar(pool);
  await csvHorarios.ingerirTexto(CSV);
});
after(async () => { await pool.query(`DROP SCHEMA ${ESQUEMA} CASCADE`); await pool.end(); });

test('horario cargado y buscador sin tildes', async () => {
  const r = await buscar('lopez');
  assert.equal(r[0].nombre, 'López Sanz, Luis');
  assert.equal((await sesionesDe('profesor', r[0].id)).length, 2);
  const libres = await aulasLibres(2, '3');
  assert.deepEqual(libres.map(a => a.codigo), ['102']);
});

test('ausencia grabada por Jefatura: guardias y grupos sin cubrir', async () => {
  await S.guardarAusencia({ id: 'a1', prof: 'lopez sanz, luis', fecha: '2026-10-06', modo: 'horas', horas: ['3'], obs: 'Ejercicios pág. 20', motivo: 'Cita médica' }, 'jefatura');
  const e = await estadoDelDia('2026-10-06');   // martes
  const t3 = e.tramos.find(t => t.tramo === '3');
  assert.deepEqual(t3.guardias.map(g => g.nombre), ['Pérez Gil, Ana']);
  assert.equal(t3.sinCubrir[0].grupo, 'E1A');   // casa el nombre aunque esté sin tildes
  assert.equal(t3.sinCubrir[0].tarea, 'Ejercicios pág. 20');
  assert.equal(e.tramos.find(t => t.tramo === '4').sinCubrir.length, 0);
});

test('notificada por un docente: pendiente hasta que Jefatura la graba; el público no ve el motivo', async () => {
  const hoy = (await query(`SELECT to_char(CURRENT_DATE,'YYYY-MM-DD') AS d`)).rows[0].d;
  const id = await S.notificar({ prof: 'Pérez Gil, Ana', fecha: hoy, modo: 'dia', motivo: 'Asuntos propios' }, 'aperez');
  let pub = await S.datosPublicos();
  assert.equal(pub.pendientes, 1);
  assert.ok(!pub.ausencias.some(a => a.id === id));
  await S.grabarAusencias([id]);
  pub = await S.datosPublicos();
  const a = pub.ausencias.find(x => x.id === id);
  assert.equal(pub.pendientes, 0);
  assert.equal(a.prof, 'Pérez Gil, Ana');
  assert.equal(a.motivo, undefined);
  assert.equal((await S.ausenciasAdmin()).find(x => x.id === id).motivo, 'Asuntos propios');
  await S.borrarAusencias([id]);
  assert.ok(!(await S.ausenciasAdmin()).some(x => x.id === id));
});

test('avisos y calendarios en la base de datos', async () => {
  await S.guardarAviso({ titulo: 'Claustro', texto: 'El jueves a las 17:00', nivel: 'importante' });
  await S.guardarCalendario('extra', { nombre: 'Actividades extraescolares', url: 'https://calendar.google.com/x' });
  const d = await S.datosPublicos();
  assert.equal(d.avisos[0].titulo, 'Claustro');
  assert.equal(d.calendarios.extra.url, 'https://calendar.google.com/x');
  await S.borrarAviso(d.avisos[0].id);
  assert.equal((await S.datosPublicos()).avisos.length, 0);
});

test('importación única desde la hoja de Google (no borra lo que ya hay)', async () => {
  const falso = async (url, opc) => ({ json: async () => (opc && opc.method === 'POST')
    ? { ok: true, ausencias: [{ id: 'h1', prof: 'López Sanz, Luis', fecha: '2026-09-21', modo: 'dia', motivo: 'Enfermedad', estado: 'Grabada', creado: '2026-09-20' },
                              { id: 'h2', prof: 'Pérez Gil, Ana', fecha: '2026-09-22', modo: 'horas', horas: ['R1'], estado: 'Pendiente' }] }
    : { avisos: [{ id: 'v1', titulo: 'Bienvenida', texto: 'Hola', nivel: 'info' }], calendarios: { dap: { nombre: 'DAP', url: 'https://c/x' } } } });
  const r = await S.importarDeHoja('http://hoja.local/exec', 'rafael2025', falso);
  assert.deepEqual(r, { ausencias: 2, avisos: 1, calendarios: 1 });
  const adm = await S.ausenciasAdmin();
  assert.equal(adm.find(a => a.id === 'h2').estado, 'Pendiente');
  assert.equal(adm.find(a => a.id === 'h1').creado, '2026-09-20');
  assert.ok(adm.some(a => a.id === 'a1'));   // la que ya estaba sigue
});

test('informe mensual: días, sesiones afectadas y PDF', async () => {
  /* Luis: martes 6 (3ª hora, ya grabada) + del 12 al 14 de octubre todo el día (lunes a miércoles) */
  await S.guardarAusencia({ id: 'm1', prof: 'López Sanz, Luis', fecha: '2026-10-12', hasta: '2026-10-14', modo: 'dia', motivo: 'Enfermedad' }, 'jefatura');
  await S.guardarAusencia({ id: 'm2', prof: 'Pérez Gil, Ana', fecha: '2026-09-30', hasta: '2026-10-01', modo: 'dia', motivo: 'Formación' }, 'jefatura');
  const inf = await datosInforme('2026-10');
  const luis = inf.porProfesor.find(p => p.profesor === 'López Sanz, Luis');
  assert.equal(luis.ausencias, 2);
  assert.equal(luis.dias, 4);              // 1 (día 6) + 3 (12-14)
  assert.equal(luis.clases, 1 + 2);        // 3ª del martes 6 + sus 2 clases del martes 13
  const ana = inf.porProfesor.find(p => p.profesor === 'Pérez Gil, Ana');
  assert.equal(ana.dias, 1);               // solo el 1 de octubre cae en el mes
  assert.equal(inf.totales.ausencias, 3);
  const pdf = await generarPDF(inf);
  assert.equal(pdf.subarray(0, 5).toString(), '%PDF-');
  assert.ok(pdf.length > 2000);
});

test('justificación: cuadrante, cómputo de horas, artículo, PDF y dossier', async () => {
  /* Luis: martes 13/10 (dentro de la ausencia m1), marca 3ª y 4ª (dos clases: lectivas) */
  const pdf = await PDFDocument.create(); pdf.addPage([300, 300]);
  const fichero = { originalname: 'parte_de_baja.pdf', buffer: Buffer.from(await pdf.save()) };
  await assert.rejects(J.crear('López Sanz, Luis', { ausencias: ['m1'], articulo: 3, detalle: [{ fecha: '2026-10-13', tramos: ['3'] }] },
    [{ originalname: 'foto.jpg', buffer: Buffer.from('JFIF') }], 'luis'), /PDF/);
  await assert.rejects(J.crear('Pérez Gil, Ana', { ausencias: ['m1'], articulo: 3, detalle: [{ fecha: '2026-10-13', tramos: ['3'] }] }, [fichero], 'ana'), /propias/);
  await assert.rejects(J.crear('López Sanz, Luis', { ausencias: ['m1'], articulo: 19, detalle: [{ fecha: '2026-10-13', tramos: ['3'] }] }, [fichero], 'luis'), /artículo/);
  const jid = await J.crear('López Sanz, Luis', { ausencias: ['m1'], articulo: 3,
    detalle: [{ fecha: '2026-10-13', tramos: ['3', '4'] }, { fecha: '2026-10-12', tramos: ['1', '2'] }] }, [fichero], 'luis');
  const m = await J.mias('López Sanz, Luis', '2026-10-20');
  const j = m.justificaciones.find(x => x.id === jid);
  assert.equal(j.lectivas, 2);              // martes 3ª y 4ª: docencia
  assert.equal(j.complementarias, 0);       // lunes 1ª y 2ª: sin actividad en su horario
  assert.equal(j.documentos.length, 1);
  assert.equal(m.ausencias.find(a => a.id === 'm1').justificacion_id, jid);
  await assert.rejects(J.crear('López Sanz, Luis', { ausencias: ['m1'], articulo: 3, detalle: [{ fecha: '2026-10-13', tramos: ['3'] }] }, [fichero], 'luis'), /ya está justificada/);
  await assert.rejects(J.borrarDoc(jid, j.documentos[0].id, 'López Sanz, Luis', false), /al menos un PDF/);

  const inf = await datosInforme('2026-10');
  assert.equal(inf.detalle.find(a => a.id === 'm1').articulo, 3);
  assert.ok(inf.porMotivo.some(x => x.motivo.startsWith('Art. 3.')));
  const d = await generarDossier('2026-10');
  const leido = await PDFDocument.load(d.pdf);
  assert.equal(d.justificaciones, 1);
  assert.ok(leido.getPageCount() >= 3);     // informe + hoja + justificante
  await J.borrar(jid, 'López Sanz, Luis', false);
  assert.equal((await J.mias('López Sanz, Luis', '2026-10-20')).ausencias.find(a => a.id === 'm1').justificacion_id, null);
});

test('alerta del 1 al 5: ausencias de meses anteriores sin justificar', () => {
  const aus = [{ id: 'x', fecha: '2026-09-28', justificacion_id: null }, { id: 'y', fecha: '2026-10-02', justificacion_id: null }, { id: 'z', fecha: '2026-09-10', justificacion_id: 4 }];
  const a = J.alertaDe(aus, '2026-10-01');
  assert.deepEqual([a.n, a.limite, a.enPlazo], [1, '2026-10-05', true]);
  assert.equal(J.alertaDe(aus, '2026-10-07').enPlazo, false);
  assert.equal(J.alertaDe(aus.slice(1), '2026-10-03'), null);
  assert.equal(J.tipoHora({ categoria: 'tutoria', materia: 'Tutoría con alumnos (ESO)' }), 'lectiva');
  assert.equal(J.tipoHora({ categoria: 'tutoria', materia: 'Tutoría de Atención a Padres y Madres' }), 'complementaria');
  assert.equal(J.tipoHora({ categoria: 'guardia', materia: '' }), 'complementaria');
});

test('biblioteca en el servidor: perfil, clave propia, guardado y paso desde la hoja', async () => {
  const hoja = { records: [{ name: 'Pérez Gil, Ana', dept: 'Lengua', act: 'GB', day: 1, slot: '3ª Diurno' }, { name: 'X', act: 'ZZ', day: 9, slot: 'mal' }] };
  assert.equal(await B.importarDeHoja('http://hoja', async () => ({ json: async () => hoja })), 1);
  assert.deepEqual((await B.listar()).map(r => [r.name, r.act, r.day, r.slot]), [['Pérez Gil, Ana', 'GB', 1, '3ª Diurno']]);

  const prof = await Auth.crear({ nombre: 'Pérez Gil, Ana', rol: 'profesor' });
  const sinPerfil = { id: prof.id, rol: 'profesor', perfiles: [] };
  await assert.rejects(B.comprobar(sinPerfil, 'loquesea'), /perfil de Biblioteca/);
  await Auth.actualizar(prof.id, { perfiles: ['biblioteca', 'inventado'] }, { id: -1 });
  const u = (await Auth.listar()).find(x => x.id === prof.id);
  assert.deepEqual(u.perfiles, ['biblioteca']);
  const conPerfil = { id: prof.id, rol: 'profesor', perfiles: u.perfiles };
  await assert.rejects(B.comprobar(conPerfil, 'Biblio2026'), /aún no ha fijado/);
  await assert.rejects(B.fijarClave('abc'), /al menos 4 caracteres/);
  await B.fijarClave('raton'); await B.comprobar(conPerfil, 'raton');
  await B.fijarClave('Biblio2026');
  assert.equal(await B.claveDefinida(), true);
  await assert.rejects(B.comprobar(conPerfil, 'otra'), /incorrecta/);
  await B.comprobar(conPerfil, 'Biblio2026');
  await B.comprobar({ id: 999, rol: 'admin', perfiles: [] }, 'rafael2025');   /* Jefatura entra también con la de administración */
  assert.deepEqual((await B.gestores()).map(g => g.nombre), ['Pérez Gil, Ana']);

  const recs = await B.guardarTodo([...await B.listar(), { name: 'López Sanz, Luis', dept: 'Matemáticas', act: 'MAY', day: 4, slot: '1º Recreo' }], { deUsuario: true });
  assert.equal(recs.length, 2);
  await B.iniciar();   /* ya hay datos editados: no vuelve a traer nada */
  assert.equal((await B.listar()).length, 2);
});

test('panel de la sala de profesores: enlace secreto, configuración y datos sin motivos', async () => {
  const P = await import('../src/services/panelService.js');
  assert.equal(P.siguienteLectivo('2026-10-16'), '2026-10-19');   /* viernes → lunes */
  assert.equal(P.siguienteLectivo('2026-10-19'), '2026-10-20');
  const t = await P.token();
  assert.equal(await P.tokenValido(t), true);
  assert.equal(await P.tokenValido('otro'), false);
  const r = await P.guardarConfig({ mensaje: 'Hola', enlaces: [{ titulo: 'Planos', url: 'https://x.es/p' }, { titulo: 'Mal', url: 'javascript:alert(1)' }] }, { regenerar: true });
  assert.notEqual(r.token, t);
  assert.equal(await P.tokenValido(t), false);
  assert.deepEqual(r.config.enlaces, [{ titulo: 'Planos', url: 'https://x.es/p' }]);
  const d = await P.datos(new Date('2026-10-16T09:00:00Z'));
  assert.equal(d.ok, true); assert.equal(d.mensaje, 'Hola');
  assert.ok(Array.isArray(d.tramos) && Array.isArray(d.ausentes));
  assert.ok(!JSON.stringify(d).includes('"motivo"'));
});


test('cronología: el cronograma se guarda en el servidor y se limpia lo que no es válido', async () => {
  const C = await import('../src/services/cronologiaService.js');
  assert.equal(await C.leer(), null);
  const v = await C.guardar([
    { id: 1, titulo: 'Evaluación inicial', inicio: '2026-10-14', fin: '2026-10-15', trim: 1, subtipo: 'evaluacion',
      grupos: [{ code: 'E1A', lugar: 'Aula 101', fechaHora: '16:30', fecha: '2026-10-14', alumnos: 29, tutor: 'Antonia' }], enlace: '', extra: 'x' },
    { id: 1, titulo: 'Reunión con familias', inicio: '2026-10-20', subtipo: 'reunion' },
  ], 'jefatura');
  assert.deepEqual(v.eventos.map(e => [e.id, e.titulo, e.fin, e.grupos.length]), [[1, 'Evaluación inicial', '2026-10-15', 1], [2, 'Reunión con familias', '2026-10-20', 0]]);
  assert.equal('extra' in v.eventos[0], false);
  assert.equal((await C.leer()).eventos.length, 2);
  await assert.rejects(C.guardar([{ titulo: 'Sin fecha' }]), /fechas válidas/);
  const P = await import('../src/services/panelService.js');
  assert.equal((await P.datos(new Date('2026-10-16T09:00:00Z'))).cronologia.length, 2);
});

test('calendario de asuntos propios (DAP): crea, actualiza y quita ausencias; títulos no reconocidos', async () => {
  const D = await import('../src/services/dapService.js');
  const X = await import('../src/services/extraescolaresService.js');
  const profs = [{ id: 1, nombre: 'López Sanz, Luis' }, { id: 2, nombre: 'Pérez Gil, Ana' }, { id: 3, nombre: 'Pérez Ruiz, Juan' }];
  assert.equal(D.reconocer('DAP - Luis López', profs).nombre, 'López Sanz, Luis');
  assert.equal(D.reconocer('Asuntos propios: PEREZ GIL', profs).nombre, 'Pérez Gil, Ana');
  assert.equal(D.reconocer('DAP Pérez', profs), null);                       /* dos Pérez: no se adivina */
  assert.equal(D.reconocer('DAP Juan Pérez (2ª-3ª)', profs).nombre, 'Pérez Ruiz, Juan');
  const tramos = [{ codigo: '1', inicio: '08:25', fin: '09:20', tipo: 'lectivo' }, { codigo: '2', inicio: '09:20', fin: '10:15', tipo: 'lectivo' },
    { codigo: 'R1', inicio: '10:15', fin: '10:30', tipo: 'recreo' }, { codigo: '3', inicio: '10:30', fin: '11:25', tipo: 'lectivo' }];
  assert.deepEqual(D.tramosEntre('09:30', '11:00', tramos), ['2', '3']);

  const ics = cuerpo => async () => ({ ok: true, status: 200, text: async () => 'BEGIN:VCALENDAR\n' + cuerpo + 'END:VCALENDAR\n' });
  const ev = (uid, titulo, ini, fin) => `BEGIN:VEVENT\nUID:${uid}\nSUMMARY:${titulo}\nDTSTART${ini.length === 8 ? ';VALUE=DATE' : ''}:${ini}\nDTEND${fin.length === 8 ? ';VALUE=DATE' : ''}:${fin}\nEND:VEVENT\n`;
  await S.guardarCalendario('dap', { nombre: 'Asuntos propios (DAP)', url: 'https://calendar.google.com/calendar/embed?src=dap%40x.es' });
  X._vaciarCache();
  let e = await D.sincronizar({ hoyIso: '2026-10-19', forzar: true, fetchImpl: ics(
    ev('u1', 'DAP - Luis López', '20261021', '20261022') + ev('u2', 'DAP Ana Pérez Gil', '20261022T083000', '20261022T101500') + ev('u3', 'DAP Fulanito', '20261023', '20261024')) });
  assert.equal(e.creadas, 2);
  assert.deepEqual(e.sinReconocer.map(x => x.titulo), ['DAP Fulanito']);
  let dap = (await S.ausenciasAdmin()).filter(a => a.id.startsWith('dap-'));
  assert.deepEqual(dap.map(a => [a.prof, a.fecha, a.modo, a.horas.join(','), a.motivo, a.estado]),
    [['López Sanz, Luis', '2026-10-21', 'dia', '', D.MOTIVO_DAP, 'Grabada'], ['Pérez Gil, Ana', '2026-10-22', 'horas', '1,2', D.MOTIVO_DAP, 'Grabada']]);
  /* Jefatura asigna el título desconocido; se recuerda */
  await S.guardarCalendario('dap', { nombre: 'Asuntos propios (DAP)', url: 'https://calendar.google.com/calendar/embed?src=dap%40x.es' });
  X._vaciarCache();
  const f2 = ics(ev('u1', 'DAP - Luis López', '20261021', '20261022') + ev('u3', 'DAP Fulanito', '20261023', '20261024'));
  await D.sincronizar({ hoyIso: '2026-10-19', forzar: true, fetchImpl: f2 });
  const A = await import('../src/models/index.js');
  await A.Ajuste.guardar({ query }, 'dap_alias', JSON.stringify({ [D.claveTitulo('DAP Fulanito')]: 'Pérez Gil, Ana' }));
  e = await D.sincronizar({ hoyIso: '2026-10-19', forzar: true, fetchImpl: f2 });
  dap = (await S.ausenciasAdmin()).filter(a => a.id.startsWith('dap-'));
  assert.deepEqual(dap.map(a => [a.prof, a.fecha]), [['López Sanz, Luis', '2026-10-21'], ['Pérez Gil, Ana', '2026-10-23']]);   /* la del 22 se borró del calendario */
  assert.equal(e.sinReconocer.length, 0);
  /* si Jefatura ya la había grabado a mano, no se duplica */
  await S.guardarAusencia({ id: 'm1', prof: 'López Sanz, Luis', fecha: '2026-10-21', modo: 'dia', motivo: 'Asuntos propios (DAP)' }, 'jefatura');
  e = await D.sincronizar({ hoyIso: '2026-10-19', forzar: true, fetchImpl: f2 });
  assert.equal(e.duplicadas, 1);
  assert.equal((await S.ausenciasAdmin()).filter(a => a.fecha === '2026-10-21' && a.prof === 'López Sanz, Luis').length, 1);
  /* los asuntos propios no necesitan justificante: en el informe cuentan como justificados, con motivo DAP */
  const inf = await datosInforme('2026-10');
  const dapInf = inf.detalle.filter(a => /DAP/.test(a.motivo));
  assert.ok(dapInf.length >= 2 && dapInf.every(a => a.dap));
  assert.ok(inf.porMotivo.some(m => m.motivo === 'Asuntos propios (DAP) (justificada)'));
  assert.ok(inf.totales.justificadas >= dapInf.length);
  const m = await J.mias('Pérez Gil, Ana', '2026-11-03');
  assert.ok(m.ausencias.filter(a => a.dap).every(a => !a.justificable));
  assert.equal(m.alerta && m.alerta.ids.some(id => id.startsWith('dap-')), false);
  const pdf = await generarPDF(inf, { conMotivo: true });
  assert.ok(pdf.length > 1000);
});

test('datos del docente: correo de Educarex, móvil y años trabajados', async () => {
  assert.throws(() => Auth.limpiarDatos({ email: 'a@gmail.com', movil: '612345678', anios: 3 }), /Educarex/);
  assert.throws(() => Auth.limpiarDatos({ email: 'a@educarex.es', movil: '912345678', anios: 3 }), /móvil/);
  assert.throws(() => Auth.limpiarDatos({ email: 'a@educarex.es', movil: '612345678', anios: '' }), /años/);
  assert.deepEqual(Auth.limpiarDatos({ email: ' Ana@EDUCAREX.es ', movil: '+34 612-34-56-78', anios: '12' }), { email: 'ana@educarex.es', movil: '612 345 678', anios: 12 });
});

test('contador de DAP: días según años trabajados y días usados en el curso', async () => {
  const C = await import('../src/services/contadorDap.js');
  assert.deepEqual([0, 17, 18, 22, 23, 35].map(C.diasDerecho), [4, 4, 5, 5, 6, 6]);
  assert.equal(C.diasDerecho(null), null);
  assert.deepEqual(C.cursoDe('2026-10-18'), { desde: '2026-09-01', hasta: '2027-08-31', nombre: '2026-27' });
  assert.equal(C.aniosActuales(17, '2025-10-01', '2026-10-18'), 18);
  assert.deepEqual(C.diasDe({ fecha: '2026-10-23', hasta: '2026-10-27' }, C.cursoDe('2026-10-18')), ['2026-10-23', '2026-10-26', '2026-10-27']);
  /* solo el propio docente o administración */
  assert.equal(await C.ficha('López Sanz, Luis', { rol: 'profesor', nombre: 'Pérez Gil, Ana' }, '2026-10-30'), null);
  const f = await C.ficha('López Sanz, Luis', { rol: 'admin', nombre: 'Jefatura' }, '2026-10-30');
  assert.ok(f.usados >= 1 && f.dias.includes('2026-10-21'));
});

test('departamento del docente: por materias, jefatura o a mano', async () => {
  const D = await import('../src/services/departamentoProfesor.js');
  assert.equal(D.departamentoDeMateria('Historia de la Filosofía'), 'Filosofía');
  assert.equal(D.departamentoDeMateria('Lengua Extranjera Inglés'), 'Inglés');
  assert.equal(D.departamentoDeMateria('Redes locales'), 'Fam. Prof. Informática y Comunicaciones');
  assert.equal((await D.departamentoDe('López Sanz, Luis')).departamento, 'Matemáticas');
  await D.asignar('López Sanz, Luis', 'Física y Química');
  assert.deepEqual(await D.departamentoDe('lopez sanz, luis'), { departamento: 'Física y Química', origen: 'manual' });
  await D.asignar('López Sanz, Luis', '');
  assert.equal((await D.departamentoDe('López Sanz, Luis')).origen, 'materias');
  await assert.rejects(D.asignar('López Sanz, Luis', 'Astrología'), /no válido/);
});

test('disciplina: etapa del grupo, registro con código, PDF en la carpeta del Jefe/a adjunto y recibido', async () => {
  const { config } = await import('../src/config.js');
  config.disciplinaDir = '/tmp/disciplina_prueba_' + process.pid;
  const D = await import('../src/services/disciplinaService.js');
  assert.equal(D.describirGrupo('E3B').etapa, 'eso');
  assert.equal(D.describirGrupo('2ºPDC').etapa, 'eso');
  assert.deepEqual(D.describirGrupo('B1B_GEN'), { etapa: 'bach', curso: '1º Bachillerato', letra: 'B (General)' });
  assert.equal(D.describirGrupo('1º SMRD', ['mañana']).etapa, 'fpd');
  assert.equal(D.describirGrupo('1º DAM', ['tarde']).etapa, 'fp');
  assert.equal(D.describirGrupo('CETI_ONLIN', ['mañana']).etapa, 'fp');
  const luis = { usuario: 'lsanz', nombre: 'López Sanz, Luis', rol: 'profesor' };
  await assert.rejects(D.crear(luis, { alumno: 'Ana Ruiz', grupo: 'E1A', fecha: '2026-10-01' }), /al menos una conducta/);
  const p = await D.crear(luis, { alumno: 'Ana Ruiz Gil', grupo: 'E1A', fecha: '2026-10-01', hora: '2ª hora', contrarias: ['c1', 'xx'], graves: ['g9'] });
  assert.match(p.codigo, /^DIS-2627-\d{4}$/);
  assert.deepEqual([p.etapa, p.responsable, p.curso, p.grupoLetra, p.contrarias], ['eso', 'Páramo Vicente, Delia Esther', '1º ESO', 'A', ['c1']]);
  const fichero = `${config.disciplinaDir}/Delia Esther Páramo Vicente/${p.archivo}`;
  assert.equal((await fs.readFile(fichero)).subarray(0, 4).toString(), '%PDF');
  /* solo la Jefa adjunta de ESO (o Jefatura) lo recibe */
  await assert.rejects(D.marcarRecibido(p.id, { nombre: 'Calderón de Arriba, Fernando', rol: 'profesor' }), /lo recibe/);
  const delia = { usuario: 'dparamo', nombre: 'Páramo Vicente, Delia Esther', rol: 'profesor' };
  assert.equal((await D.resumen(delia)).pendientes, 1);
  await D.marcarRecibido(p.id, delia);
  assert.deepEqual(await D.resumen(luis), { pendientes: 0, recibidos: 1, tutoria: 0, responsable: false, tutor: false });
  await D.marcarVisto(p.id, luis);
  assert.equal((await D.resumen(luis)).recibidos, 0);
  await assert.rejects(D.pdf(p.id, { usuario: 'otro', nombre: 'Pérez Gil, Ana', rol: 'profesor' }, 'profesor'), /No puedes/);
  /* copia al tutor/a del grupo */
  assert.equal(p.tutor, 'Muriel Criado, M. Antonia');
  const tutora = { usuario: 'mmuriel', nombre: 'Muriel Criado, M. Antonia', rol: 'profesor' };
  assert.equal((await D.resumen(tutora)).tutoria, 1);
  assert.equal((await D.deMiTutoria(tutora)).partes[0].codigo, p.codigo);
  assert.equal((await D.pdf(p.id, tutora, 'tutor')).tipo, 'tutor');
  await assert.rejects(D.marcarLeidoTutor(p.id, delia), /No eres tutor/);
  await D.marcarLeidoTutor(p.id, tutora);
  assert.equal((await D.resumen(tutora)).tutoria, 0);
  const carp = await D.carpeta(delia);
  assert.deepEqual([carp.length, carp[0].nombre, carp[0].archivos.length, carp[0].archivos[0].codigo], [1, 'Delia Esther Páramo Vicente', 1, p.codigo]);
  assert.equal((await D.carpeta({ nombre: 'Jefatura', rol: 'admin' })).length, 4);
  await assert.rejects(D.carpeta(luis), /solo para Jefatura/);
  assert.throws(() => D.archivoCarpeta(delia, 'eso', '../x.pdf'), /no válido/);
  assert.throws(() => D.archivoCarpeta(delia, 'bach', p.archivo), /No tienes acceso/);
  assert.ok(D.archivoCarpeta(delia, 'eso', p.archivo).ruta.endsWith(p.archivo));
  await fs.rm(config.disciplinaDir, { recursive: true, force: true });
});

test('ausencias por actividad complementaria o extraescolar: no necesitan justificación', async () => {
  const M = await import('../src/services/motivos.js');
  assert.ok(M.sinJustificante('Actividad extraescolar') && M.sinJustificante('Actividad complementaria') && M.sinJustificante('Asuntos propios (DAP)'));
  assert.ok(!M.sinJustificante('Cita médica') && !M.sinJustificante('Formación'));
  assert.equal(M.motivoExento('Actividad complementaria'), 'Actividad complementaria o extraescolar');
  await S.guardarAusencia({ id: 'act1', prof: 'Pérez Gil, Ana', fecha: '2026-10-28', modo: 'dia', motivo: 'Actividad extraescolar' }, 'jefatura');
  await S.guardarAusencia({ id: 'act2', prof: 'Pérez Gil, Ana', fecha: '2026-10-29', modo: 'dia', motivo: 'Cita médica' }, 'jefatura');
  const m = await J.mias('Pérez Gil, Ana', '2026-11-03');
  const a1 = m.ausencias.find(a => a.id === 'act1'), a2 = m.ausencias.find(a => a.id === 'act2');
  assert.deepEqual([a1.exenta, a1.justificable, a1.exentaMotivo], [true, false, 'Actividad complementaria o extraescolar']);
  assert.deepEqual([a2.exenta, a2.justificable], [false, true]);
  assert.ok(!m.alerta.ids.includes('act1') && m.alerta.ids.includes('act2'));
  const doc = await PDFDocument.create(); doc.addPage();
  const fichero = { originalname: 'x.pdf', buffer: Buffer.from(await doc.save()) };
  await assert.rejects(J.crear('Pérez Gil, Ana', { ausencias: ['act1'], articulo: 3, detalle: [{ fecha: '2026-10-28', tramos: ['3'] }] }, [fichero], 'apg'), /no necesitan justificación/);
  const inf = await datosInforme('2026-10');
  const d = inf.detalle.find(x => x.id === 'act1');
  assert.deepEqual([d.exenta, d.actividad, d.dap], [true, true, false]);
  assert.ok(inf.porMotivo.some(x => x.motivo === 'Actividad complementaria o extraescolar (justificada)'));
  assert.ok(inf.totales.actividad >= 1);
  await S.borrarAusencias(['act1', 'act2']);
});

test('ausencias: tareas por día que deja el profesor/a y aparecen en las guardias', async () => {
  const { limpiarDetalle } = S;
  assert.deepEqual(limpiarDetalle({ '2026-10-22|3': { obs: ' Ficha 4 ' }, '3': { aula: '209' }, 'x|3': { obs: 'no' }, '2026-10-22|99': { obs: 'no' } }, ['3']),
    { '2026-10-22|3': { obs: 'Ficha 4' }, '3': { aula: '209' } });
  await S.notificar({ id: 'tt1', prof: 'López Sanz, Luis', fecha: '2026-11-03', hasta: '2026-11-04', modo: 'dia', motivo: 'Formación', obs: 'General' }, 'luis');
  await S.guardarTareas('tt1', 'López Sanz, Luis', { detalle: { '2026-11-03|3': { obs: 'E1A: ejercicios 4-7' }, '2026-11-04|3': { obs: 'Otra tarea' } }, obs: 'Libro en la mesa' });
  await assert.rejects(S.guardarTareas('tt1', 'Pérez Gil, Ana', { detalle: {} }), /propias/);
  await S.grabarAusencias(['tt1']);
  /* Jefatura la edita (sin las tareas por día) y se conservan */
  await S.guardarAusencia({ id: 'tt1', prof: 'López Sanz, Luis', fecha: '2026-11-03', hasta: '2026-11-04', modo: 'dia', motivo: 'Formación', obs: 'Libro en la mesa', detalle: { '3': { aula: '105' } } }, 'jefatura');
  const e = await estadoDelDia('2026-11-03');   /* martes: Luis tiene E1A a 3ª */
  const t3 = e.tramos.find(t => t.tramo === '3');
  const sc = t3.sinCubrir.find(x => x.profesor === 'López Sanz, Luis');
  assert.deepEqual([sc.tarea, sc.aula], ['E1A: ejercicios 4-7', '105']);
  await S.borrarAusencias(['tt1']);
});
