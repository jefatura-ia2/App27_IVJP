import { test } from 'node:test';
import assert from 'node:assert/strict';
import { parsearCSV, normalizarFilas } from '../src/ingestors/csvHorarios.js';
import { limpiarAusencia } from '../src/services/servicioService.js';
import { rangoMes, diasLectivos } from '../src/services/informeAusencias.js';
import { calcularEstado, afectaTramo } from '../src/services/guardiasService.js';
import { ahora, tramoEn, diaSemana } from '../src/services/tiempo.js';
import { Clase } from '../src/models/index.js';

test('parsearCSV respeta comillas y comas dentro del nombre', () => {
  const f = parsearCSV('"Amor, María",1,R1,,,,Guardia de Recreo\r\n"Pérez, Ana",2,3,Mates,E1A,101,Docencia\n');
  assert.equal(f.length, 2);
  assert.equal(f[0][0], 'Amor, María');
  assert.equal(f[1][4], 'E1A');
});

test('normalizarFilas descarta días y tramos inválidos y clasifica', () => {
  const { sesiones, descartadas } = normalizarFilas([['A, B', '1', 'r1', '', '', '', 'Guardia de Recreo'], ['A, B', '7', '1'], ['A, B', '2', '99']]);
  assert.equal(sesiones.length, 1);
  assert.equal(sesiones[0].tramo, 'R1');
  assert.equal(sesiones[0].categoria, 'recreo');
  assert.equal(descartadas.length, 2);
});

test('clasificar tipos del horario', () => {
  assert.equal(Clase.clasificar('Guardia de Aula'), 'guardia');
  assert.equal(Clase.clasificar('Tutoría'), 'tutoria');
  assert.equal(Clase.clasificar('Atención a biblioteca'), 'biblioteca');
  assert.equal(Clase.clasificar('Docencia'), 'docencia');
});

test('limpiarAusencia: horas, modo y fechas', () => {
  const a = limpiarAusencia({ id: 'x', prof: 'Pérez, Ana', fecha: '2026-10-06', hasta: '', modo: 'horas', horas: ['3', 'r2', '99'] });
  const b = limpiarAusencia({ id: 'y', prof: 'Luis', fecha: '2026-10-06', hasta: '2026-10-08', modo: 'horas', horas: [] });
  assert.deepEqual(a.horas, ['3', 'R2']);
  assert.equal(a.modo, 'horas');
  assert.equal(b.modo, 'dia');
  assert.equal(b.hasta, '2026-10-08');
});

test('informe: rango del mes y días lectivos', () => {
  const r = rangoMes('2026-02');
  assert.equal(r.desde, '2026-02-01'); assert.equal(r.hasta, '2026-02-28'); assert.equal(r.nombre, 'febrero 2026');
  assert.throws(() => rangoMes('2026-13'));
  const d = diasLectivos('2026-10-09', '2026-10-13');   /* viernes a martes */
  assert.deepEqual(d.map(x => x.dia), [5, 1, 2]);
});

test('tiempo del centro en Europe/Madrid', () => {
  const r = ahora(new Date('2026-10-06T09:00:00Z'), 'Europe/Madrid'); // 11:00 en Madrid (CEST)
  assert.equal(r.fecha, '2026-10-06');
  assert.equal(r.hhmm, '11:00');
  assert.equal(r.dia, 2);
  assert.equal(tramoEn('11:00').codigo, '3');
  assert.equal(tramoEn('11:25').codigo, '4');
  assert.equal(tramoEn('10:20').codigo, 'R1');
  assert.equal(tramoEn('22:00'), null);
  assert.equal(diaSemana('2026-10-10'), null);
});

test('calcularEstado: ausente de guardia y grupos sin cubrir con tarea', () => {
  const tramos = [{ codigo: '3', inicio: '10:30', fin: '11:25', tipo: 'clase' }];
  const s = (profesor_id, profesor, categoria, grupo = null, aula = null) => ({ tramo: '3', profesor_id, profesor, categoria, grupo, aula, materia: 'M' });
  const sesiones = [s(1, 'Ana', 'guardia'), s(2, 'Luis', 'guardia'), s(3, 'Eva', 'docencia', 'E1A', '101'), s(3, 'Eva', 'docencia', 'E1B', '101')];
  const ausencias = [
    { profesor_id: 2, profesor: 'Luis', modo: 'dia', horas: [], tarea: '' },
    { profesor_id: 3, profesor: 'Eva', modo: 'horas', horas: ['3'], tarea: 'Ficha 4' },
  ];
  const [t] = calcularEstado({ tramos, sesiones, ausencias });
  assert.deepEqual(t.guardias.map(g => g.nombre), ['Ana']);
  assert.deepEqual(t.guardiasAusentes.map(g => g.nombre), ['Luis']);
  assert.equal(t.sinCubrir.length, 2);
  assert.equal(t.sinCubrir[0].tarea, 'Ficha 4');
  assert.ok(afectaTramo(ausencias[0], 'R1'));
  assert.ok(!afectaTramo(ausencias[1], '4'));
});

/* ---------- acceso con usuario y contraseña ---------- */
import { hashClave, verificarClave, proponerUsuario, validarClaveNueva, claveAleatoria } from '../src/services/authService.js';

test('contraseñas: se guardan con sal y se verifican', async () => {
  const h1 = await hashClave('Jerte2026x'), h2 = await hashClave('Jerte2026x');
  assert.notEqual(h1, h2);
  assert.ok(await verificarClave('Jerte2026x', h1));
  assert.ok(!(await verificarClave('jerte2026x', h1)));
  assert.ok(!(await verificarClave('x', 'basura')));
});

test('usuarios propuestos y contraseñas válidas', () => {
  assert.equal(proponerUsuario('Amor Rodríguez, María del Carmen'), 'mamor');
  assert.equal(proponerUsuario('Álvarez Sánchez, Sergio'), 'salvarez');
  assert.throws(() => validarClaveNueva('corta1'));
  assert.throws(() => validarClaveNueva('sololetras'));
  validarClaveNueva('Profe2026a');
  assert.equal(claveAleatoria().length, 8);
});

import { interpretarIcs, ocurrencias, urlIcs } from '../src/services/extraescolaresService.js';
test('extraescolares: enlace de Google → .ics público y lectura de iCalendar', () => {
  assert.equal(urlIcs('https://calendar.google.com/calendar/embed?src=abc123%40group.calendar.google.com&ctz=Europe%2FMadrid'),
    'https://calendar.google.com/calendar/ical/abc123%40group.calendar.google.com/public/basic.ics');
  assert.equal(urlIcs('<sin enlace>'), '');
  const ics = ['BEGIN:VCALENDAR', 'BEGIN:VEVENT', 'UID:1', 'SUMMARY:Salida a Cáceres\\, 2º Bach', 'LOCATION:Cáceres',
    'DTSTART;VALUE=DATE:20261020', 'DTEND;VALUE=DATE:20261022', 'END:VEVENT',
    'BEGIN:VEVENT', 'UID:2', 'SUMMARY:Teatro en ing', ' lés', 'DTSTART:20261021T080000Z', 'DTEND:20261021T100000Z', 'END:VEVENT',
    'BEGIN:VEVENT', 'UID:3', 'SUMMARY:Anulada', 'STATUS:CANCELLED', 'DTSTART;VALUE=DATE:20261021', 'END:VEVENT',
    'BEGIN:VEVENT', 'UID:4', 'SUMMARY:Club de lectura', 'DTSTART;TZID=Europe/Madrid:20261019T170000', 'DTEND;TZID=Europe/Madrid:20261019T180000',
    'RRULE:FREQ=WEEKLY;COUNT=3', 'EXDATE;TZID=Europe/Madrid:20261026T170000', 'END:VEVENT', 'END:VCALENDAR'].join('\r\n');
  const ev = ocurrencias(interpretarIcs(ics, 'Europe/Madrid'), '2026-10-19', '2026-11-30');
  assert.deepEqual(ev.map(e => [e.titulo, e.inicio, e.fin, e.hora]), [
    ['Club de lectura', '2026-10-19', '2026-10-19', '17:00'],
    ['Salida a Cáceres, 2º Bach', '2026-10-20', '2026-10-21', ''],   /* DTEND de día completo es exclusivo */
    ['Teatro en inglés', '2026-10-21', '2026-10-21', '10:00'],       /* 08:00 UTC = 10:00 en Madrid */
    ['Club de lectura', '2026-11-02', '2026-11-02', '17:00'],        /* el 26/10 está excluido */
  ]);
});
