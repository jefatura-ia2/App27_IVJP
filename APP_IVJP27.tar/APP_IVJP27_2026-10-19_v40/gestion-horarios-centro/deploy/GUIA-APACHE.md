# Instalación con Apache (sin Docker) en el servidor Linux del centro

La app queda en una **subcarpeta** del Apache del centro, por ejemplo `http://servidor/horarios/`.
Si ese Apache ya sirve otras webs, siguen funcionando igual: la app solo usa su subcarpeta.

## Cómo funciona

```
Navegador ──► Apache (puertos 80/443)
                 ├─ /horarios/        → app compilada  (/opt/gestion-horarios-centro/frontend/dist)
                 ├─ /horarios/api/    → servidor Node de la app (127.0.0.1:3000, solo interno)
                 └─ resto de rutas    → las webs que ya tuviera el servidor
Servidor Node ──► PostgreSQL (base de datos «horarios»)
              └─► Google Apps Script (hoja de ausencias)
```

Apache no ejecuta JavaScript del servidor. Por eso el servidor Node sigue siendo necesario: queda
instalado como servicio del sistema (`horarios-api`), arranca solo y Apache le pasa las peticiones
de `/horarios/api/`. No hace falta Docker.

## Requisitos

- Ubuntu Server 22.04 / 24.04 o Debian 12, con acceso de administrador (`sudo`).
- Conexión a Internet durante la instalación: descarga Node.js 20, PostgreSQL y las librerías de la app.
- Puertos 80 y 443 abiertos hacia el servidor.

## Instalación (una sola vez)

1. Copia el zip al servidor, por ejemplo con WinSCP, y descomprímelo:
   ```
   unzip gestion-horarios-centro.zip && cd gestion-horarios-centro
   ```
2. Lanza el instalador de Apache:
   ```
   sudo bash deploy/instalar-apache.sh
   ```
   Opciones:
   - Otra subcarpeta: `sudo RUTA=/app-horarios bash deploy/instalar-apache.sh`
   - Con nombre de dominio: `sudo DOMINIO=servidor.iesvalledeljerte.es bash deploy/instalar-apache.sh`
3. Al terminar muestra la dirección, por ejemplo `http://192.168.1.50/horarios/`.
   Primera entrada: usuario `jefatura` y la contraseña de administración (por defecto `rafael2025`).
   La app pide cambiarla al entrar.

El instalador hace esto:

- Instala Apache, Node.js 20 y PostgreSQL.
- Crea la base de datos con una contraseña aleatoria y carga el horario.
- Compila la app.
- Activa los módulos de Apache necesarios (`proxy`, `proxy_http`, `headers`, `alias`).
- Añade `/etc/apache2/conf-available/horarios.conf`.
- Deja la app con arranque automático, copias de seguridad diarias a las 2:30 y cortafuegos.

## HTTPS

HTTPS es necesario para instalar la app en el móvil y para que la sesión viaje cifrada.

- **Con dominio público** (Let's Encrypt, gratuito y con renovación automática):
  ```
  sudo DOMINIO=servidor.iesvalledeljerte.es CORREO=jefatura@... bash /opt/gestion-horarios-centro/deploy/https.sh
  ```
- **Solo red interna** (certificado propio):
  ```
  sudo MODO=interno DOMINIO=192.168.1.50 bash /opt/gestion-horarios-centro/deploy/https.sh
  ```

Si el Apache **ya tenía HTTPS** configurado para otras webs, no hagas nada: la app aparece también
en `https://…/horarios/`.

## Actualizar a una versión nueva

Descomprime el zip nuevo en el servidor y, desde esa carpeta, ejecuta:

```
sudo bash deploy/actualizar.sh
```

El actualizador:

- Hace antes una copia de seguridad.
- Conserva datos, PDF, horario editado y configuración.
- Recompila la app y recarga Apache.
- Recuerda que la instalación es con Apache y en qué subcarpeta está.

## App en /var/www/App: actualizar sin contraseña de root

Sirve cuando quien mantiene la app sube los ficheros con WinSCP a `/var/www/App` y no tiene
permisos de administrador.

**Preparación (una sola vez, la hace quien tenga la contraseña de root):**

1. Sube con WinSCP el contenido del zip a `/var/www/App`.
2. Ejecuta:
   ```
   su - -c "bash /var/www/App/deploy/instalar-en-var-www.sh"
   ```

El script hace lo siguiente:

- Traslada la app que funcionaba en `/opt/gestion-horarios-centro` (esa carpeta queda como `.antiguo`).
- Saca los datos (horario, PDF) a `/var/lib/gestion-horarios` y la configuración a
  `/etc/gestion-horarios/horarios.env`. Así, subir ficheros a `/var/www/App` nunca los pisa.
- Permite al usuario dueño de `/var/www/App` (p. ej. `nacho`) hacer copias y reiniciar la app sin
  contraseña. No le da ningún otro permiso de administrador.
- Apache solo sirve la app compilada: el resto de `/var/www/App` (código, scripts) no es accesible por web.

Si algo falla, la app vuelve a quedar funcionando desde `/opt` como estaba.

**Cada actualización (sin root):**

1. Sube con WinSCP el contenido de la versión nueva a `/var/www/App` (sobrescribir).
2. Ejecuta:
   ```
   bash /var/www/App/deploy/actualizar-app.sh
   ```
   Debe terminar con «✔ Actualizado.». Después, Ctrl + F5 en el navegador.

Volver a una copia anterior: `sudo horarios-restaurar <fecha>` (las fechas están en `ls /var/backups/horarios`).

## Comprobaciones y problemas habituales

| Síntoma | Qué mirar |
|---|---|
| `…/horarios/` da 404 | `sudo a2enconf horarios && sudo systemctl reload apache2` |
| La app carga pero no deja entrar (error de servidor) | `systemctl status horarios-api` · `journalctl -u horarios-api -n 50` |
| 503 en `/horarios/api/` | El servidor Node está parado: `sudo systemctl restart horarios-api` |
| No se pueden subir PDF grandes | `LimitRequestBody` en `/etc/apache2/conf-available/horarios.conf` y `MAX_PDF_MB` en `backend/.env` |
| Revisar la configuración de Apache | `sudo apache2ctl configtest` |
| ¿Responde la API? | `curl http://127.0.0.1/horarios/api/salud` → `{"ok":true}` |

## Probado

Probado en Ubuntu 24.04 con Apache 2.4 y Node 20. El arranque de servicios se simuló porque el
entorno de pruebas no tenía systemd. Se comprobó lo siguiente:

- La instalación completa termina bien y la app responde en `http://localhost/horarios/`.
- La web que ya existía en `/` sigue intacta.
- `/horarios` redirige a `/horarios/`.
- Acceso con usuario y contraseña, pantalla principal y Cronología funcionan sin errores.
- El funcionamiento sin conexión queda limitado a `/horarios/`.
- `index.html` y `sw.js` se sirven sin caché; los ficheros de `assets/`, con caché de un año.
- La actualización con `actualizar.sh` funciona.
