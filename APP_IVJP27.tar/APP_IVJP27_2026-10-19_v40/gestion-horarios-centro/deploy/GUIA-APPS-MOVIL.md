# Apps de móvil (Android e iOS)

La app de móvil es la misma app web empaquetada con Capacitor: se ve y funciona igual,
pero se instala como una app más del teléfono. Los datos siguen estando en el servidor del centro.

## Antes de empezar: el servidor tiene que verse desde fuera

Los móviles se conectan desde casa o con datos móviles, así que el servidor del centro tiene que
estar publicado en Internet **con HTTPS**, por ejemplo `https://horarios.iesvalledeljerte.es`
(ver `GUIA-DESPLIEGUE.md`, apartado HTTPS). Para pruebas dentro del centro vale también
`http://IP-del-ordenador:3000`, pero solo en Android.

Al compilar se puede escribir esa dirección. Si se deja vacía, cada profesor/a la escribe la primera
vez que abre la app; se comprueba que responde y queda guardada. Se puede cambiar
desde la pantalla de acceso, con el enlace **Cambiar**.

## Android (APK) — en un PC con Windows

1. Instala **Android Studio** (https://developer.android.com/studio) con las opciones por defecto.
2. Ábrelo una vez y completa el asistente: descarga el SDK de Android. Después puedes cerrarlo.
3. En la carpeta de la app, haz doble clic en **COMPILAR-ANDROID.bat**.
4. Escribe la dirección del servidor, o pulsa Intro para que la pregunte la app.
5. Al terminar aparece **Horarios-IVJ.apk** en la carpeta de la app.
   La primera vez tarda varios minutos porque descarga lo necesario.

**Instalarla en los móviles:** envía el APK por correo, Drive o Classroom. Al abrirlo, Android
pide permitir «instalar apps de origen desconocido».

**Google Play (opcional):** necesitas una cuenta de desarrollador de Google (25 $, pago único)
y un APK/AAB firmado. En Android Studio: *Build → Generate Signed App Bundle*.
Guarda bien el fichero de firma: sin él no se pueden publicar actualizaciones.

## iOS (iPhone / iPad) — necesita un Mac

Apple solo permite compilar apps de iPhone en un **Mac con Xcode**.

1. En el Mac, instala Node.js (https://nodejs.org) y Xcode (App Store); abre Xcode una vez.
2. Copia la carpeta de la app al Mac y haz doble clic en **COMPILAR-IOS.command**.
   Si macOS no te deja abrirlo: botón derecho → Abrir.
3. Se abre Xcode con el proyecto. Para probarla en tu iPhone: conéctalo por cable, elígelo
   arriba y pulsa ▶ (con tu Apple ID; la app caduca a los 7 días).
4. Para repartirla al claustro hace falta la cuenta **Apple Developer** (99 €/año):
   *Product → Archive → Distribute App → TestFlight / App Store*.

**Alternativa sin Mac ni cuenta de Apple:** en el iPhone, abre la app en Safari con la
dirección del servidor → botón Compartir → **Añadir a pantalla de inicio**. Queda un icono
que abre la app a pantalla completa, con los mismos datos.

## Cuando cambie la app

Después de cualquier cambio en la app hay que volver a compilar y repartir la app de móvil.
Los datos (horarios, guardias, ausencias, programaciones) no hace falta: se actualizan solos
desde el servidor.

## Detalles técnicos

- `frontend/capacitor.config.json`: identificador `es.iesvalledeljerte.horarios`.
- Proyectos nativos: `frontend/android` y `frontend/ios`.
- Iconos y pantalla de inicio: generados desde `frontend/assets/` con `npx @capacitor/assets generate`.
- Sesión: en la app nativa la sesión viaja en la cabecera `Authorization: Bearer`, en vez de la
  cookie. El servidor admite siempre los orígenes `capacitor://localhost` y `https://localhost`.
- Los PDF de programaciones se abren con enlaces firmados que caducan a las 12 h (`?f=`), porque
  el navegador del móvil no tiene la sesión de la app.
