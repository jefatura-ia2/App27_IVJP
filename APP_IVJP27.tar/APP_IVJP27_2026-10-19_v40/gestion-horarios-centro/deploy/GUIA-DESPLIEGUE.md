# Guía de despliegue en un servidor del centro

App de horarios del IES Valle del Jerte (`gestion-horarios-centro`). Esta guía lleva la app desde el zip hasta
> **¿El servidor del centro ya usa Apache?** Sigue `GUIA-APACHE.md` (`sudo bash deploy/instalar-apache.sh`): la app queda en `http://servidor/horarios/` y convive con las otras webs, sin Docker.

un servidor del centro funcionando, con copias de seguridad y actualizaciones. Hay dos caminos:

- **A. Servidor Linux (recomendado)**: Ubuntu Server 22.04/24.04 o Debian 12. Un único script lo instala todo.
  Probado de principio a fin en Ubuntu 24.04.
- **B. Docker**: para un servidor Windows o un NAS que ya tenga Docker.

---

## 1. Recursos necesarios

### Equipo
| Recurso | Mínimo | Recomendado |
|---|---|---|
| Procesador | 2 núcleos | 2–4 núcleos |
| Memoria | 2 GB | 4 GB |
| Disco | 20 GB | 40 GB (los PDF de programaciones y las copias crecen cada curso) |
| Sistema | Ubuntu Server 22.04/24.04 LTS o Debian 12 (máquina física o virtual) | Ubuntu Server 24.04 LTS |

Vale una máquina virtual en el servidor que ya tenga el centro (Proxmox, VMware, Hyper-V, VirtualBox).

### Software (lo instala `instalar.sh`)
Node.js 20 LTS · PostgreSQL 16 · nginx · ufw (cortafuegos) · certbot (si hay HTTPS público).

### Red
- **IP fija** para el servidor en la red del centro (p. ej. 192.168.1.50) o, mejor, un **nombre**
  (p. ej. `horarios.iesvalledeljerte.es`).
- **Puertos de entrada**: 80 y 443 (web) y 22 (SSH, solo para administrarlo).
- **Salida a Internet** desde el servidor hacia: `script.google.com` y `script.googleusercontent.com`
  (ausencias de la hoja), `deb.nodesource.com`, `registry.npmjs.org` y los repositorios de Ubuntu (instalación
  y actualizaciones).
- **Salida desde los equipos y móviles** hacia `fonts.googleapis.com`, `unpkg.com`, `cdn.tailwindcss.com`
  (la Cronología los usa) y `script.google.com` (avisos, calendarios y ausencias).
- **Acceso desde fuera del centro** (móviles del profesorado en casa): solo si el router del centro redirige
  80/443 al servidor y hay un nombre público. Si no, la app funciona solo dentro de la red del centro.

### Personas y permisos
- Quien administre el servidor (técnico del centro o CAU) para: crear la máquina, darle IP/nombre, abrir puertos
  y dar acceso SSH con un usuario con `sudo`.
- Jefatura: la contraseña de administración (`rafael2025` o la que se decida).
- Protección de datos: la app guarda nombres del profesorado, horarios y ausencias (sin motivo para el público).
  Conviene comunicarlo al Delegado de Protección de Datos de la Consejería y usar siempre HTTPS (apartado 4).

### Mensaje tipo para pedirlo al técnico
> Necesitamos para Jefatura de Estudios una máquina (virtual vale) con Ubuntu Server 24.04, 2 CPU, 4 GB RAM y
> 40 GB de disco, con IP fija en la red del centro y, si es posible, el nombre `horarios.iesvalledeljerte.es`.
> Puertos 80 y 443 abiertos desde la red del centro (y desde Internet si se permite), SSH para administración,
> y salida a Internet hacia script.google.com, registry.npmjs.org, deb.nodesource.com y los repositorios de Ubuntu.
> Un usuario con permisos sudo para instalar la aplicación.

---

## 2. Camino A — Servidor Linux paso a paso

### 2.1 Subir el proyecto al servidor
Desde tu ordenador (Windows: PowerShell; o con WinSCP arrastrando el fichero):
```
scp gestion-horarios-centro.zip usuario@192.168.1.50:~
```
Conéctate al servidor (`ssh usuario@192.168.1.50`) y descomprime:
```
sudo apt-get install -y unzip
unzip gestion-horarios-centro.zip
cd gestion-horarios-centro
```

### 2.2 Instalar (un solo comando)
```
sudo DOMINIO=192.168.1.50 bash deploy/instalar.sh
```
(cambia `192.168.1.50` por el nombre o la IP del servidor; si la contraseña de administración no es
`rafael2025`, añade `ADMIN_PASSWORD=la-vuestra` delante de `bash`).

Lo que hace, en 9 pasos que verás en pantalla:
1. Instala Node.js 20, PostgreSQL, nginx, cortafuegos y pone la hora de Madrid.
2. Crea el usuario de sistema `horarios` (sin acceso por consola) que ejecuta la app.
3. Copia la app a `/opt/gestion-horarios-centro`.
4. Crea la base de datos y el fichero `backend/.env` con contraseñas aleatorias (solo la primera vez).
5. Instala dependencias, crea las tablas y carga el horario del CSV.
6. Compila la app web.
7. Crea dos servicios que arrancan solos con el servidor: `horarios-api` (la app) y `horarios-cron`
   (trae las ausencias cada 5 min y recarga el horario cada mañana).
8. Configura nginx: sirve la app y reenvía `/api` al servidor Node.
9. Activa el cortafuegos (solo SSH y web) y una copia de seguridad diaria a las 2:30.

Al terminar debe decir **«✔ Instalación terminada. Abre: http://…»**. Ábrelo en el navegador.

### 2.3 Primera entrada y cuentas del profesorado
1. Abre `http://servidor/`: sale la pantalla de acceso.
2. Entra con el usuario **`jefatura`** y la contraseña de administración (`rafael2025` o la que pusieras en
   `ADMIN_PASSWORD`). Te pedirá elegir una contraseña personal.
3. Abre el mosaico **Usuarios** → «Crear cuentas del profesorado». Imprime o descarga las credenciales
   provisionales y repártelas; cada profesor/a elegirá la suya al entrar.

4. **Ausencias solo propias**: no hay que configurar nada. Basta con tener publicado el script de Google **v8**
   (Implementar → Gestionar implementaciones → lápiz → Nueva versión). El servidor registra solo su token en el
   script. Para comprobarlo, abre la dirección del script con `?accion=ping` al final: debe decir `"tokenNotif":true`.

### 2.4 Comprobar
- Tras entrar, la portada muestra los mosaicos (11 para administración, con «Usuarios»).
- Profesores → cualquier profesor/a muestra su horario.
- Cronología → Programaciones muestra los 19 departamentos.
- Estado de los servicios: `systemctl status horarios-api horarios-cron`
- Registros en directo: `journalctl -u horarios-api -f` (salir con Ctrl+C)
- Que llegan las ausencias: `journalctl -u horarios-cron -n 20` debe mostrar `[ausencias] {"ok":true…}`.
  Si pone `ERROR fetch failed`, el servidor no tiene salida a `script.google.com` (apartado 1, Red).

---

## 3. Camino B — Docker (Windows Server, NAS…)

1. Instala Docker Desktop (Windows) o Docker Engine (Linux/NAS).
2. Descomprime el proyecto y, en su carpeta:
   ```
   copy deploy\docker\.env.docker.ejemplo deploy\docker\.env.docker      (Linux: cp …)
   ```
   Edita `deploy/docker/.env.docker` y cambia `PG_PASSWORD`, `ADMIN_TOKEN` y `ORIGEN_WEB`.
3. Arranca:
   ```
   docker compose -f deploy/docker/docker-compose.prod.yml --env-file deploy/docker/.env.docker up -d --build
   ```
4. Abre `http://IP-del-servidor/`. La primera vez carga sola el horario del CSV.
5. Copia de seguridad de la base de datos:
   ```
   docker compose -f deploy/docker/docker-compose.prod.yml exec db pg_dump -U horarios -Fc horarios > copia.dump
   ```
   Los PDF y el horario editado viven en los volúmenes `horarios_pdf` y `horarios_horario`.

---

## 4. HTTPS (imprescindible para contraseñas y para instalar la app en el móvil)

**Con nombre público** (el servidor es accesible desde Internet como `horarios.iesvalledeljerte.es`):
```
sudo DOMINIO=horarios.iesvalledeljerte.es CORREO=jefatura@iesvalledeljerte.es bash /opt/gestion-horarios-centro/deploy/https.sh
```
Pide un certificado gratuito de Let's Encrypt, redirige http→https y lo renueva solo.

**Solo red interna** (sin nombre público):
```
sudo MODO=interno DOMINIO=192.168.1.50 bash /opt/gestion-horarios-centro/deploy/https.sh
```
Crea un certificado propio válido 5 años. Los navegadores avisarán la primera vez; para quitar el aviso,
el técnico puede instalar `/etc/ssl/horarios/cert.pem` como certificado de confianza en los equipos del centro.

Después de activar HTTPS, la app se puede «Añadir a pantalla de inicio» en los móviles.

---

## 5. Copias de seguridad

- Automáticas cada noche a las 2:30 en `/var/backups/horarios` (se guardan 30 días): base de datos, PDF de
  programaciones, horario editado y configuración.
- Hacer una ahora: `sudo /opt/gestion-horarios-centro/deploy/copia-seguridad.sh`
- **Llevarlas fuera del servidor** (NAS, disco externo) al menos una vez por semana; ejemplo al final de
  `copia-seguridad.sh`.
- Restaurar: `ls /var/backups/horarios` para ver las fechas y
  `sudo bash /opt/gestion-horarios-centro/deploy/restaurar.sh 2026-10-05_023000` (pide escribir SI).

---

## 6. Actualizar a una versión nueva

1. Sube y descomprime el zip nuevo en el servidor (como en 2.1, en otra carpeta).
2. Desde esa carpeta: `sudo bash deploy/actualizar.sh`

Hace una copia de seguridad, cambia el código conservando datos, PDF, horario editado y `.env`, recompila y
reinicia. Las tablas nuevas se crean solas. Si algo falla, restaura la copia que indica al final.

---

## 7. Configuración (`/opt/gestion-horarios-centro/backend/.env`)

| Variable | Para qué |
|---|---|
| `ADMIN_PASSWORD` | Contraseña inicial de la cuenta `jefatura` (solo se usa al crearla) y contraseña de administración. Debe coincidir con la del candado (servicio de Google) y con `ADMIN_CRED` de `frontend/public/cronologia.html` |
| `FECHA_LIMITE_PROG` | Fecha límite de entrega de programaciones |
| `CORS_ORIGIN` | Direcciones desde las que se abre la app |
| `SHEETS_SERVICE_URL` | Servicio de Google de la hoja «Ausencias 2026-27» |
| `CRON_AUSENCIAS`, `CRON_HORARIOS` | Cada cuánto se sincroniza |

Tras cambiarlo: `sudo systemctl restart horarios-api horarios-cron`.

---

## 8. Problemas frecuentes

| Síntoma | Causa y solución |
|---|---|
| La web no abre | `systemctl status nginx` · ¿puerto 80 abierto en el cortafuegos del centro? |
| Portada abre pero «No se pudo conectar con el servidor de horarios» | `systemctl status horarios-api` y `journalctl -u horarios-api -n 50` |
| No aparecen las ausencias | Salida a `script.google.com` bloqueada, o el script de Google no está publicado en la última versión |
| «Contraseña de administración no válida» al editar | `ADMIN_PASSWORD` del `.env` distinta a la del candado |
| No se pueden subir PDF grandes | `client_max_body_size` en `/etc/nginx/sites-available/horarios` y `MAX_PDF_MB` en `.env` |
| La Cronología sale en blanco | Los equipos no llegan a `unpkg.com` / `cdn.tailwindcss.com` (filtro de contenidos del centro) |
| «Notificación no autorizada» o `tokenNotif:false` | El script de Google no está en la v8 o `ADMIN_PASSWORD` no coincide con la del script; corrígelo y reinicia `horarios-api` |
| Un profesor/a no puede notificar («cuenta no vinculada») | Usuarios → «Nombre»: ponlo igual que en el horario |
| Un profesor/a no puede entrar | Usuarios → «Restablecer» (le da una contraseña provisional y lo desbloquea) |
| Disco lleno | `du -sh /var/backups/horarios /opt/gestion-horarios-centro/backend/uploads`; baja `DIAS` en la copia |

---

## 9. Ficheros de esta carpeta

| Fichero | Uso |
|---|---|
| `instalar.sh` | Instalación completa en Ubuntu/Debian (se puede repetir sin perder datos) |
| `actualizar.sh` | Instalar una versión nueva conservando datos |
| `copia-seguridad.sh` / `restaurar.sh` | Copias diarias y vuelta atrás |
| `https.sh` | Certificado Let's Encrypt o certificado interno |
| `horarios-api.service`, `horarios-cron.service` | Servicios de systemd (los instala `instalar.sh`) |
| `nginx-horarios.conf` | Sitio web de nginx (lo instala `instalar.sh`) |
| `instalar-apache.sh`, `apache-horarios.conf` | Variante con **Apache** en una subcarpeta (ver `GUIA-APACHE.md`) |
| `env.produccion.ejemplo` | Plantilla del `.env` de producción |
| `docker/` | Camino B: `docker-compose.prod.yml`, Dockerfiles y nginx para Docker |
