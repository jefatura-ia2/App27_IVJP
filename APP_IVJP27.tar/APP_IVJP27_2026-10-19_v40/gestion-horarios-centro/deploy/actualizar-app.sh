#!/usr/bin/env bash
# =====================================================================
#  Actualiza la app instalada en /var/www/App SIN contraseña de root.
#  1) Sube con WinSCP el contenido de la versión nueva a /var/www/App (sobrescribir)
#  2) En el servidor:   bash /var/www/App/deploy/actualizar-app.sh
#  Datos, PDF, horario editado y configuración están fuera de esta carpeta: no se tocan.
#  (Requiere haber hecho antes, una vez y como root, deploy/instalar-en-var-www.sh)
# =====================================================================
set -euo pipefail
DIR="$(cd "$(dirname "$0")/.." && pwd)"
CONF=/etc/gestion-horarios
[ -f "$CONF/instalacion" ] || { echo "Falta la preparación inicial. Pide a quien tenga la contraseña de root que ejecute:"; echo "  su - -c \"bash $DIR/deploy/instalar-en-var-www.sh\""; exit 1; }
. "$CONF/instalacion"
if [ "$(id -u)" = 0 ]; then
  echo "Ejecútalo con tu usuario ($EDITOR_APP), no como root:  bash $DIR/deploy/actualizar-app.sh"; exit 1
fi
[ "$(id -un)" = "$EDITOR_APP" ] || { echo "Esta instalación la actualiza el usuario $EDITOR_APP."; exit 1; }

# ¿Se subió la carpeta entera dentro de la instalación (/var/www/App/gestion-horarios-centro/…) en vez de su contenido?
for sub in "$DIR"/gestion-horarios-centro* "$DIR"/APP_IVJP27*; do
  if [ -d "$sub/frontend" ]; then
    echo "⚠ Hay una versión subida DENTRO de otra carpeta: $sub"
    echo "  Esa no se instala. En WinSCP abre esa carpeta, selecciona TODO lo que tiene dentro (backend, frontend, deploy…),"
    echo "  arrástralo a $DIR (sobrescribir) y borra la carpeta $sub. Después vuelve a ejecutar este comando."
    exit 1
  fi
done

echo "==> 1/4 Copia de seguridad"
sudo -n /usr/local/sbin/horarios-copia || { echo "No tengo permiso para la copia/reinicio. Pide que se repita, como root, deploy/instalar-en-var-www.sh"; exit 1; }

echo "==> 2/4 Limpieza de lo que no debe estar en el servidor"
# un .env subido por error (el del PC de pruebas) no se usa: la configuración está en $CONF
[ -f "$DIR/backend/.env" ] && mv -f "$DIR/backend/.env" "$DIR/backend/.env.no-se-usa" && echo "  apartado backend/.env (no se usa en el servidor)"
chmod -R u+rwX,g+rX,o+rX "$DIR" 2>/dev/null || true
chmod +x "$DIR"/deploy/*.sh 2>/dev/null || true

# páginas antiguas que ya no se usan (la de las familias es ahora reunion-familias.html para todas las reuniones)
rm -f "$DIR"/frontend/public/reunion-familias-20oct*.html "$DIR"/frontend/public/reunion-familias-20oct*.png 2>/dev/null || true

echo "==> 3/4 Dependencias y compilación (tarda un par de minutos)"
(cd "$DIR/backend" && npm ci --omit=dev --no-audit --no-fund)
(cd "$DIR/frontend" && npm ci --no-audit --no-fund && npm run build)
chmod -R o+rX "$DIR/frontend/dist"

if grep -q "reunion-familias.html?ev=" "$DIR/frontend/dist/cronologia.html" 2>/dev/null; then
  echo "  ✔ Cronología: información para las familias e imagen para redes en todas las reuniones"
else
  echo "  ⚠ La Cronología instalada es de una versión antigua: revisa que subiste los ficheros nuevos a $DIR"
fi

echo "==> 4/4 Reinicio (las tablas nuevas se crean solas)"
sudo -n /usr/local/sbin/horarios-reiniciar
sleep 3
if curl -fsS "http://127.0.0.1$RUTA/api/salud" >/dev/null; then
  echo; echo "✔ Actualizado. Abre la app y pulsa Ctrl + F5."
  echo "  Partes de disciplina (PDF de Jefatura): /var/lib/gestion-horarios/uploads/disciplina/<Jefe/a de Estudios adjunto>"
else
  echo; echo "⚠ La app no responde. Mira:  journalctl -u horarios-api -n 50   (o pide a root: sudo journalctl …)"
  echo "  Para volver a los datos de antes:  sudo horarios-restaurar <fecha de la copia del paso 1>"
fi

# ¿La versión nueva trae cambios en la configuración de Apache o de los servicios?
for f in apache-horarios.conf horarios-api.service horarios-cron.service; do
  if ! cmp -s "$DIR/deploy/$f" "$CONF/$f"; then
    echo; echo "ℹ Esta versión cambia la configuración del servidor ($f). Para aplicarla, quien tenga"
    echo "  la contraseña de root debe ejecutar una vez:  su - -c \"bash $DIR/deploy/instalar-en-var-www.sh\""
    break
  fi
done
