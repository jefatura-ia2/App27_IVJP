#!/usr/bin/env bash
# Instala una versión nueva de la app conservando datos, PDF, horario editado y configuración.
# Uso: descomprime el zip nuevo en el servidor y, desde esa carpeta:
#   sudo bash deploy/actualizar.sh
set -euo pipefail
# Instalación trasladada a /var/www/App (instalar-en-var-www.sh): se actualiza con actualizar-app.sh
if [ -f /etc/gestion-horarios/instalacion ]; then
  . /etc/gestion-horarios/instalacion
  echo "Esta instalación funciona desde $DIR. Sube allí los ficheros y ejecuta (sin sudo, como $EDITOR_APP):"
  echo "  bash $DIR/deploy/actualizar-app.sh"; exit 1
fi
[ "$(id -u)" = 0 ] || { echo "Ejecútalo con sudo."; exit 1; }
ORIGEN="$(cd "$(dirname "$0")/.." && pwd)"
DIR="${DIR:-/opt/gestion-horarios-centro}"
[ -f "$DIR/backend/.env" ] || { echo "No hay instalación en $DIR: usa instalar.sh"; exit 1; }
WEB=nginx; RUTA=""; [ -f "$DIR/deploy/.instalacion" ] && . "$DIR/deploy/.instalacion"   # nginx o apache (+ subcarpeta)

echo "==> 1/4 Copia de seguridad previa"
DIR="$DIR" bash "$ORIGEN/deploy/copia-seguridad.sh"

echo "==> 2/4 Código nuevo (se conservan .env, uploads y data)"
rsync -a --exclude node_modules --exclude dist --exclude '.env' --exclude 'backend/uploads' --exclude 'backend/data' --exclude 'deploy/.instalacion' "$ORIGEN"/ "$DIR"/
chown -R horarios:horarios "$DIR"
chmod +x "$DIR"/deploy/*.sh

echo "==> 3/4 Dependencias y compilación"
(cd "$DIR/backend" && runuser -u horarios -- npm ci --omit=dev --no-audit --no-fund)
(cd "$DIR/frontend" && runuser -u horarios -- npm ci --no-audit --no-fund && runuser -u horarios -- npm run build)

echo "==> 4/4 Reinicio (las tablas nuevas se crean solas al arrancar)"
if [ "$WEB" = apache ]; then
  sed -e "s#__DIR__#$DIR#g" -e "s#__RUTA__#$RUTA#g" "$DIR/deploy/apache-horarios.conf" > /etc/apache2/conf-available/horarios.conf
  chmod o+rx "$DIR" "$DIR/frontend"; chmod -R o+rX "$DIR/frontend/dist"
  apache2ctl configtest && systemctl reload apache2
fi
systemctl restart horarios-api horarios-cron
sleep 3
curl -fsS "http://127.0.0.1$RUTA/api/salud" >/dev/null && echo "✔ Actualizado." || echo "⚠ Revisa: journalctl -u horarios-api -n 50"
echo "Si algo va mal, vuelve atrás con: sudo bash $DIR/deploy/restaurar.sh <fecha de la copia de arriba>"
