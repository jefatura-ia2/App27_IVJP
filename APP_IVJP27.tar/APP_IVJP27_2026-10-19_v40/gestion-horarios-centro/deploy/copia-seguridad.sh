#!/usr/bin/env bash
# Copia de seguridad: base de datos + PDF de programaciones + horario (CSV) + configuración (.env).
# Uso: sudo /opt/gestion-horarios-centro/deploy/copia-seguridad.sh   (cada noche lo hace solo a las 2:30)
set -euo pipefail
DIR="${DIR:-/opt/gestion-horarios-centro}"
DEST="${DEST:-/var/backups/horarios}"
DIAS="${DIAS:-30}"
F="$(date +%Y-%m-%d_%H%M%S)"
umask 077
mkdir -p "$DEST"
runuser -u postgres -- pg_dump -Fc horarios > "$DEST/bd_$F.dump"
tar -czf "$DEST/ficheros_$F.tar.gz" -C "$DIR/backend" uploads data .env
find "$DEST" -type f \( -name 'bd_*.dump' -o -name 'ficheros_*.tar.gz' \) -mtime +"$DIAS" -delete
echo "$(date '+%F %T') copia $F en $DEST ($(du -sh "$DEST" | cut -f1) en total)"
# Recomendado: llevar también una copia fuera del servidor (NAS del centro, disco externo…), por ejemplo:
#   rsync -a "$DEST"/ usuario@nas:/copias/horarios/
