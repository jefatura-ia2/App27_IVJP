#!/usr/bin/env bash
# HTTPS para la app. Dos casos:
#  A) El servidor tiene un nombre público (DNS) y los puertos 80/443 abiertos desde Internet:
#       sudo DOMINIO=horarios.iesvalledeljerte.es CORREO=jefatura@... bash deploy/https.sh
#     → certificado gratuito de Let's Encrypt, renovación automática.
#  B) Solo red interna (sin DNS público):
#       sudo MODO=interno DOMINIO=192.168.1.50 bash deploy/https.sh
#     → certificado propio (el navegador avisará la primera vez; se puede instalar en los equipos del centro).
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "Ejecútalo con sudo."; exit 1; }
: "${DOMINIO:?Indica DOMINIO=...}"
MODO="${MODO:-letsencrypt}"
DIR="${DIR:-/opt/gestion-horarios-centro}"
WEB=nginx; RUTA=""; [ -f "$DIR/deploy/.instalacion" ] && . "$DIR/deploy/.instalacion"
if [ "$MODO" = "letsencrypt" ]; then
  : "${CORREO:?Indica CORREO=... para avisos de caducidad}"
  apt-get install -y certbot "python3-certbot-$WEB"
  certbot "--$WEB" -d "$DOMINIO" -m "$CORREO" --agree-tos --redirect --non-interactive
  systemctl list-timers | grep -q certbot && echo "✔ Renovación automática activa."
else
  mkdir -p /etc/ssl/horarios
  if [[ "$DOMINIO" =~ ^[0-9.]+$ ]]; then SAN="IP:$DOMINIO"; else SAN="DNS:$DOMINIO"; fi
  openssl req -x509 -nodes -newkey rsa:2048 -days 1825 \
    -keyout /etc/ssl/horarios/clave.pem -out /etc/ssl/horarios/cert.pem \
    -subj "/CN=$DOMINIO/O=IES Valle del Jerte" -addext "subjectAltName=$SAN"
  chmod 600 /etc/ssl/horarios/clave.pem
  if [ "$WEB" = apache ]; then
    # HTTPS en el sitio por defecto de Apache con el certificado propio (la app está en $RUTA/ de todos los sitios)
    a2enmod -q ssl >/dev/null
    SSLCONF=/etc/apache2/sites-available/default-ssl.conf
    sed -i -e "s#^\(\s*SSLCertificateFile\s\).*#\1/etc/ssl/horarios/cert.pem#" \
           -e "s#^\(\s*SSLCertificateKeyFile\s\).*#\1/etc/ssl/horarios/clave.pem#" "$SSLCONF"
    a2ensite -q default-ssl >/dev/null
    apache2ctl configtest && systemctl reload apache2
    echo "✔ HTTPS interno activo: https://$DOMINIO$RUTA/"
    echo "  Para quitar el aviso, instala /etc/ssl/horarios/cert.pem como certificado de confianza en los equipos."
    exit 0
  fi
  CONF=/etc/nginx/sites-available/horarios
  grep -q "listen 443" "$CONF" || sed -i "0,/listen 80;/s##listen 80;\n    listen 443 ssl;\n    ssl_certificate /etc/ssl/horarios/cert.pem;\n    ssl_certificate_key /etc/ssl/horarios/clave.pem;#" "$CONF"
  nginx -t && systemctl reload nginx
  echo "✔ HTTPS interno activo: https://$DOMINIO"
  echo "  Para quitar el aviso, instala /etc/ssl/horarios/cert.pem como certificado de confianza en los equipos."
fi
