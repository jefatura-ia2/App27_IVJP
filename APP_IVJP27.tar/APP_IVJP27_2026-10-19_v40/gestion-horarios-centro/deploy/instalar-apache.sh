#!/usr/bin/env bash
# =====================================================================
#  Instalación con APACHE (sin Docker) en un servidor Linux del centro
#  Ubuntu Server 22.04 / 24.04 o Debian 12. Si el servidor ya tiene Apache con otras
#  webs, se respetan: la app solo ocupa la subcarpeta indicada.
#
#  Uso (desde la carpeta del proyecto descomprimido):
#    sudo bash deploy/instalar-apache.sh
#    sudo RUTA=/horarios DOMINIO=servidor.iesvalledeljerte.es bash deploy/instalar-apache.sh
#  → la app queda en  http://<DOMINIO o IP>/horarios/
#  Variables: RUTA (por defecto /horarios), DOMINIO, ADMIN_PASSWORD, DIR (ver instalar.sh)
# =====================================================================
export WEB=apache
export RUTA="${RUTA:-/horarios}"
exec bash "$(dirname "$0")/instalar.sh"
