#!/usr/bin/env bash
# =====================================================================
#  Traslada la app instalada (en /opt/gestion-horarios-centro) a /var/www/App, para que
#  se pueda actualizar subiendo los ficheros con WinSCP SIN contraseña de root.
#  Se ejecuta UNA SOLA VEZ, como root, desde la carpeta /var/www/App ya subida:
#     su - -c "bash /var/www/App/deploy/instalar-en-var-www.sh"
#
#  Cómo queda:
#    /var/www/App                       código (del usuario que sube con WinSCP, p. ej. nacho)
#    /var/lib/gestion-horarios          datos: horario CSV, copias del CSV y PDF de programaciones
#    /etc/gestion-horarios/horarios.env configuración (contraseñas): fuera de la carpeta web
#  Así, subir ficheros a /var/www/App nunca pisa datos ni configuración.
#  Después, cada actualización:  bash /var/www/App/deploy/actualizar-app.sh   (sin root)
# =====================================================================
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "Ejecútalo como root:  su - -c \"bash $0\""; exit 1; }

NUEVO="$(cd "$(dirname "$0")/.." && pwd)"
VIEJO="${VIEJO:-/opt/gestion-horarios-centro}"
EDITOR_APP="${EDITOR_APP:-$(stat -c %U "$NUEVO")}"     # quien sube los ficheros (dueño de la carpeta)
DATOS=/var/lib/gestion-horarios
CONF=/etc/gestion-horarios
SERVICIO=horarios
paso() { echo; echo "==> $*"; }

[ "$EDITOR_APP" != root ] || { echo "La carpeta $NUEVO es de root. Indica el usuario que sube con WinSCP:  EDITOR_APP=nacho"; exit 1; }
id -u "$SERVICIO" >/dev/null 2>&1 || { echo "No existe el usuario $SERVICIO: la app no está instalada. Usa antes deploy/instalar-apache.sh"; exit 1; }
[ -f "$NUEVO/backend/package.json" ] && [ -f "$NUEVO/frontend/package.json" ] || { echo "En $NUEVO no está la app completa (falta backend o frontend)."; exit 1; }

# Configuración actual: de la instalación anterior o de una migración ya hecha
if [ -f "$CONF/horarios.env" ]; then ENV_ORIGEN="$CONF/horarios.env"
elif [ -f "$VIEJO/backend/.env" ]; then ENV_ORIGEN="$VIEJO/backend/.env"
else echo "No encuentro la configuración ($VIEJO/backend/.env). ¿Está instalada la app?"; exit 1; fi
WEB=apache; RUTA=/horarios
[ -f "$VIEJO/deploy/.instalacion" ] && . "$VIEJO/deploy/.instalacion"
[ -f "$CONF/instalacion" ] && . "$CONF/instalacion"
[ "$WEB" = apache ] || { echo "Este traslado es para la instalación con Apache."; exit 1; }
echo "Código: $NUEVO (usuario $EDITOR_APP) · datos: $DATOS · configuración: $CONF · web: $RUTA/"

paso "1/7 Copia de seguridad previa"
if [ -x /usr/local/sbin/horarios-copia ]; then /usr/local/sbin/horarios-copia
elif [ -d "$VIEJO/backend" ]; then DIR="$VIEJO" bash "$NUEVO/deploy/copia-seguridad.sh"
fi

paso "2/7 Datos y configuración fuera de la carpeta web"
mkdir -p "$DATOS/data" "$DATOS/uploads/programaciones" "$CONF"
if [ -d "$VIEJO/backend/data" ] && [ ! -f "$DATOS/.trasladado" ]; then
  rsync -a "$VIEJO/backend/data/" "$DATOS/data/"
  [ -d "$VIEJO/backend/uploads/programaciones" ] && rsync -a "$VIEJO/backend/uploads/programaciones/" "$DATOS/uploads/programaciones/"
  date > "$DATOS/.trasladado"
fi
# si aún no hay horario (instalación sin datos), se parte del CSV que trae la app
CSV="$(grep -E '^HORARIOS_CSV=' "$ENV_ORIGEN" | tail -1 | cut -d= -f2- | xargs basename 2>/dev/null || true)"
CSV="${CSV:-datos_horarios_2026-27.csv}"
[ -f "$DATOS/data/$CSV" ] || cp "$NUEVO/backend/data/$CSV" "$DATOS/data/$CSV"
chown -R "$SERVICIO:$SERVICIO" "$DATOS"; chmod 750 "$DATOS"

TMP="$(mktemp)"
grep -vE '^(HORARIOS_CSV|UPLOADS_DIR|FRONTEND_DIST)=' "$ENV_ORIGEN" > "$TMP" || true
{ echo "HORARIOS_CSV=$DATOS/data/$CSV"; echo "UPLOADS_DIR=$DATOS/uploads/programaciones"; echo "FRONTEND_DIST=$NUEVO/frontend/dist"; } >> "$TMP"
install -o root -g "$SERVICIO" -m 640 "$TMP" "$CONF/horarios.env"; rm -f "$TMP"
printf 'WEB=apache\nRUTA=%s\nDIR=%s\nEDITOR_APP=%s\n' "$RUTA" "$NUEVO" "$EDITOR_APP" > "$CONF/instalacion"
# un .env dentro de la carpeta (p. ej. el del PC de pruebas) ya no se usa: se aparta para no confundir
[ -f "$NUEVO/backend/.env" ] && mv -f "$NUEVO/backend/.env" "$NUEVO/backend/.env.no-se-usa"

paso "3/7 Permisos de la carpeta $NUEVO"
usermod -aG "$SERVICIO" "$EDITOR_APP"
chown -R "$EDITOR_APP:$SERVICIO" "$NUEVO"
chmod -R u+rwX,g+rX,o+rX "$NUEVO"
find "$NUEVO" -type d -exec chmod g+s {} +
chmod +x "$NUEVO"/deploy/*.sh

paso "4/7 Dependencias y compilación (como $EDITOR_APP)"
(cd "$NUEVO/backend" && runuser -u "$EDITOR_APP" -- npm ci --omit=dev --no-audit --no-fund)
(cd "$NUEVO/frontend" && runuser -u "$EDITOR_APP" -- npm ci --no-audit --no-fund && runuser -u "$EDITOR_APP" -- npm run build)

paso "5/7 Utilidades para actualizar sin root"
# Plantillas de Apache y de los servicios: copia revisada por root. Las de la carpeta web las puede
# cambiar quien sube ficheros; si cambian en una versión nueva, actualizar-app.sh avisa.
for f in apache-horarios.conf horarios-api.service horarios-cron.service; do
  install -o root -g root -m 644 "$NUEVO/deploy/$f" "$CONF/$f"
done
cat > /usr/local/sbin/horarios-reiniciar <<EOF
#!/usr/bin/env bash
# Reinicia la app de horarios y recarga Apache (lo usa actualizar-app.sh)
set -euo pipefail
sed -e "s#__DIR__#$NUEVO#g" -e "s#__RUTA__#$RUTA#g" "$CONF/apache-horarios.conf" > /etc/apache2/conf-available/horarios.conf
for s in horarios-api horarios-cron; do sed "s#__DIR__#$NUEVO#g" "$CONF/\$s.service" > /etc/systemd/system/\$s.service; done
systemctl daemon-reload
systemctl restart horarios-api horarios-cron
apache2ctl configtest && systemctl reload apache2
EOF
cat > /usr/local/sbin/horarios-copia <<EOF
#!/usr/bin/env bash
# Copia de seguridad: base de datos + datos (horario, PDF) + configuración. Se guardan 30 días.
set -euo pipefail
DEST=/var/backups/horarios; F="\$(date +%Y-%m-%d_%H%M%S)"
umask 077; mkdir -p "\$DEST"
runuser -u postgres -- pg_dump -Fc horarios > "\$DEST/bd_\$F.dump"
tar -czf "\$DEST/ficheros_\$F.tar.gz" -C / "${DATOS#/}" "${CONF#/}"
find "\$DEST" -type f \( -name 'bd_*.dump' -o -name 'ficheros_*.tar.gz' \) -mtime +30 -delete
echo "\$(date '+%F %T') copia \$F en \$DEST"
EOF
cat > /usr/local/sbin/horarios-restaurar <<EOF
#!/usr/bin/env bash
# Restaura una copia de horarios-copia.  Uso: sudo horarios-restaurar 2026-10-15_101500
set -euo pipefail
F="\${1:?Indica la fecha de la copia (mira: ls /var/backups/horarios)}"; DEST=/var/backups/horarios
[ -f "\$DEST/bd_\$F.dump" ] || { echo "No existe \$DEST/bd_\$F.dump"; exit 1; }
read -r -p "Se sustituirán los datos actuales por los del \$F. ¿Continuar? (escribe SI) " r; [ "\$r" = SI ] || exit 1
systemctl stop horarios-cron horarios-api
runuser -u postgres -- pg_restore --clean --if-exists -d horarios < "\$DEST/bd_\$F.dump"
if [ -f "\$DEST/ficheros_\$F.tar.gz" ]; then tar -xzf "\$DEST/ficheros_\$F.tar.gz" -C / "${DATOS#/}" || true; fi
chown -R $SERVICIO:$SERVICIO "$DATOS"
systemctl start horarios-api horarios-cron
echo "✔ Restaurada la copia del \$F."
EOF
chown root:root /usr/local/sbin/horarios-{reiniciar,copia,restaurar}
chmod 755 /usr/local/sbin/horarios-{reiniciar,copia,restaurar}
# El usuario que actualiza puede lanzar SOLO estas tres utilidades (son de root y no las puede modificar)
SUD="$(mktemp)"
echo "$EDITOR_APP ALL=(root) NOPASSWD: /usr/local/sbin/horarios-reiniciar, /usr/local/sbin/horarios-copia, /usr/local/sbin/horarios-restaurar *" > "$SUD"
visudo -cf "$SUD" >/dev/null && install -o root -g root -m 440 "$SUD" /etc/sudoers.d/gestion-horarios; rm -f "$SUD"
cat > /etc/cron.d/horarios-copias <<CRON
# Copia de seguridad diaria de la app de horarios (base de datos, datos y configuración; 30 días)
30 2 * * * root /usr/local/sbin/horarios-copia >> /var/log/horarios-copias.log 2>&1
CRON

paso "6/7 Servicios y Apache apuntando a $NUEVO"
/usr/local/sbin/horarios-reiniciar

paso "7/7 Comprobación"
sleep 3
if curl -fsS "http://127.0.0.1$RUTA/api/salud" >/dev/null; then
  [ -d "$VIEJO" ] && [ "$VIEJO" != "$NUEVO" ] && mv "$VIEJO" "$VIEJO.antiguo" && echo "La instalación anterior queda en $VIEJO.antiguo (bórrala cuando todo vaya bien)."
  echo; echo "✔ Listo. La app funciona desde $NUEVO  →  http://$(hostname -I | awk '{print $1}')$RUTA/"
  echo "  Para actualizar a partir de ahora (como $EDITOR_APP, sin root):"
  echo "    1) Sube con WinSCP el contenido de la versión nueva a $NUEVO"
  echo "    2) bash $NUEVO/deploy/actualizar-app.sh"
  echo "  ($EDITOR_APP debe cerrar la sesión ssh y volver a entrar una vez para que se apliquen los permisos.)"
else
  echo; echo "⚠ La API no responde. Revisa:  journalctl -u horarios-api -n 50"
  if [ -d "$VIEJO/frontend/dist" ] && [ "$VIEJO" != "$NUEVO" ]; then
    echo "  Dejo la app funcionando otra vez desde $VIEJO, como estaba."
    sed -e "s#__DIR__#$VIEJO#g" -e "s#__RUTA__#$RUTA#g" "$VIEJO/deploy/apache-horarios.conf" > /etc/apache2/conf-available/horarios.conf
    for s in horarios-api horarios-cron; do sed "s#__DIR__#$VIEJO#g" "$VIEJO/deploy/$s.service" > "/etc/systemd/system/$s.service"; done
    systemctl daemon-reload; systemctl restart horarios-api horarios-cron; systemctl reload apache2
  fi
  exit 1
fi
