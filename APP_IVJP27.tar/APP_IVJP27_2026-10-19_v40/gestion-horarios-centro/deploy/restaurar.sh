#!/usr/bin/env bash
# Restaura una copia hecha con copia-seguridad.sh.
# Uso: sudo bash deploy/restaurar.sh 2026-10-05_023000      (la fecha que aparece en el nombre de los ficheros)
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "Ejecútalo con sudo."; exit 1; }
F="${1:?Indica la fecha de la copia, p. ej. 2026-10-05_023000 (mira en /var/backups/horarios)}"
DIR="${DIR:-/opt/gestion-horarios-centro}"
DEST="${DEST:-/var/backups/horarios}"
[ -f "$DEST/bd_$F.dump" ] || { echo "No existe $DEST/bd_$F.dump"; exit 1; }
read -r -p "Se sustituirán los datos actuales por los del $F. ¿Continuar? (escribe SI) " r
[ "$r" = "SI" ] || exit 1
systemctl stop horarios-cron horarios-api
runuser -u postgres -- pg_restore --clean --if-exists -d horarios < "$DEST/bd_$F.dump"
tar -xzf "$DEST/ficheros_$F.tar.gz" -C "$DIR/backend"
chown -R horarios:horarios "$DIR/backend"
systemctl start horarios-api horarios-cron
echo "✔ Restaurada la copia del $F."
