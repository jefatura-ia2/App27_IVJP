/* Service worker: la app funciona sin conexión con lo último que se cargó.
   · Ficheros de la app: caché primero.
   · /api: red primero; si no hay conexión, la última respuesta guardada. */
const VERSION = 'horarios-v3';
const APP = ['/', '/index.html', '/cronologia.html', '/manifest.json', '/icons/icon-192.png', '/icons/icon-512.png'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSION).then(c => c.addAll(APP)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VERSION).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.pathname.startsWith('/api/')) {
    e.respondWith(fetch(req).then(r => {
      if (r.ok) { const copia = r.clone(); caches.open(VERSION).then(c => c.put(req, copia)); }
      return r;
    }).catch(() => caches.match(req).then(r => r || new Response(JSON.stringify({ error: 'Sin conexión' }),
      { status: 503, headers: { 'Content-Type': 'application/json' } }))));
    return;
  }
  if (url.origin !== location.origin) return;
  e.respondWith(caches.match(req).then(r => r || fetch(req).then(resp => {
    if (resp.ok && (url.pathname.startsWith('/assets/') || url.pathname === '/')) {
      const copia = resp.clone(); caches.open(VERSION).then(c => c.put(req, copia));
    }
    return resp;
  }).catch(() => caches.match('/index.html'))));
});
