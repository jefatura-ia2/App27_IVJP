package es.iesvalledeljerte.horarios;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
