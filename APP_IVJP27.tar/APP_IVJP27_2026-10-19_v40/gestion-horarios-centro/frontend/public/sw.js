/* Service worker: la app funciona sin conexión con lo último que se cargó.
   · Ficheros de la app: caché primero.
   · /api: red primero; si no hay conexión, la última respuesta guardada. */
const VERSION = 'horarios-v9';
/* carpeta donde está la app («/» o, con Apache, p. ej. «/horarios/») */
const BASE = new URL('./', self.location).pathname;
const APP = ['', 'index.html', 'cronologia.html', 'presentacion.html', 'manifest.json', 'icons/icon-192.png', 'icons/icon-512.png'].map(f => BASE + f);

self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSION).then(c => c.addAll(APP)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VERSION).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.pathname.startsWith(BASE + 'api/')) {
    e.respondWith(fetch(req).then(r => {
      if (r.ok) { const copia = r.clone(); caches.open(VERSION).then(c => c.put(req, copia)); }
      return r;
    }).catch(() => caches.match(req).then(r => r || new Response(JSON.stringify({ error: 'Sin conexión' }),
      { status: 503, headers: { 'Content-Type': 'application/json' } }))));
    return;
  }
  if (url.origin !== location.origin) return;
  if (/\.(mp4|webm)$/i.test(url.pathname)) return;   /* vídeos: directamente del servidor (permite avanzar y retroceder) */
  /* Páginas (index.html, cronologia.html…): red primero, para que al actualizar la app en el servidor
     todos reciban la versión nueva; sin conexión, la última guardada. */
  const esPagina = req.mode === 'navigate' || url.pathname === BASE || url.pathname.endsWith('.html');
  if (esPagina) {
    e.respondWith(fetch(req, { cache: 'no-store' }).then(r => {
      if (r.ok) { const copia = r.clone(); caches.open(VERSION).then(c => c.put(url.pathname === BASE ? BASE : req, copia)); }
      return r;
    }).catch(() => caches.match(req, { ignoreSearch: true }).then(r => r || caches.match(BASE + 'index.html') || caches.match(BASE))));
    return;
  }
  e.respondWith(caches.match(req).then(r => r || fetch(req).then(resp => {
    if (resp.ok && (url.pathname.startsWith(BASE + 'assets/') || url.pathname === BASE)) {
      const copia = resp.clone(); caches.open(VERSION).then(c => c.put(req, copia));
    }
    return resp;
  }).catch(() => caches.match(BASE + 'index.html'))));
});
