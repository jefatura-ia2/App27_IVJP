/**
 * Acceso a la app: inicio de sesión con usuario y contraseña (cuentas creadas por la
 * administración) y cambio obligatorio de la contraseña provisional.
 * Mismo aspecto que el resto de la app (clases de original/original.css).
 */
import React, { useState } from 'react';
import { esNativa, servidorGuardado, guardarServidor, normalizarServidor, tokenApp } from '../servidor.js';

export const API = (window.__API_BASE__ || '/api').replace(/\/$/, '');

export async function pedir(metodo, ruta, cuerpo) {
  let r;
  try {
    r = await fetch(API + ruta, {
      method: metodo, credentials: 'include',
      headers: cuerpo ? { 'Content-Type': 'application/json' } : undefined,
      body: cuerpo ? JSON.stringify(cuerpo) : undefined,
    });
  } catch (e) { const x = new Error('No se pudo conectar con el servidor del centro'); x.red = true; throw x; }
  const esJson = (r.headers.get('content-type') || '').includes('json');
  const d = await r.json().catch(() => ({}));
  /* un 5xx sin JSON no viene de la API: el servidor (backend) está parado o no se puede alcanzar */
  if (r.status >= 500 && !esJson) {
    const x = new Error('El servidor de la app no responde (error ' + r.status + '). Comprueba que el backend está arrancado.');
    x.status = r.status; x.red = true; throw x;
  }
  /* la página es más nueva que el servidor: falta reiniciarlo tras actualizar la app */
  if (r.status === 404 && d.error === 'Ruta no encontrada') {
    const x = new Error('El servidor de la app es de una versión anterior y no tiene esta función. Reinícialo (cierra su ventana y vuelve a arrancarlo) y prueba de nuevo.');
    x.status = 404; throw x;
  }
  if (!r.ok || d.ok === false) { const x = new Error(d.error || 'Error ' + r.status); x.status = r.status; x.datos = d; throw x; }
  return d;
}

/** Cierra la sesión y borra lo que la app guardó en este dispositivo */
export async function cerrarSesion() {
  try { await pedir('POST', '/auth/logout'); } catch (e) { /* sin conexión: se borra igual lo local */ }
  try { ['vj_horario_csv', 'vj_hor_remoto', 'vj_recreo_biblio', 'vj_hor_ausencias', 'vj_usuario'].forEach(k => localStorage.removeItem(k)); } catch (e) { /* nada */ }
  tokenApp.guardar('');
  try { if (window.caches) for (const k of await caches.keys()) await caches.delete(k); } catch (e) { /* nada */ }
  location.hash = '';
  location.reload();
}

function Logo({ size = 70 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 200 200" aria-hidden="true">
      <defs><linearGradient id="lgA" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stopColor="#6B2D8B" /><stop offset="100%" stopColor="#522270" /></linearGradient></defs>
      <circle cx="58" cy="52" r="7" fill="url(#lgA)" />
      <path d="M 55 65 Q 80 110 100 140 Q 120 110 175 30 Q 130 95 100 130 Q 85 105 55 65 Z" fill="url(#lgA)" />
      <path d="M 72 78 Q 90 108 100 122 Q 110 108 140 72 Q 118 100 100 118 Q 92 105 72 78 Z" fill="white" />
      <path d="M 85 92 Q 95 108 100 114 Q 105 108 118 92 Q 108 104 100 112 Q 95 106 85 92 Z" fill="url(#lgA)" />
    </svg>
  );
}

function Marco({ titulo, sub, children }) {
  return (
    <div className="min-h-screen flex flex-col">
      <main className="flex-1 flex items-center justify-center p-4">
        <div className="card w-full max-w-sm p-7 fade-in shadow-sm">
          <div className="flex justify-center mb-3"><span className="bg-paper-warm rounded-2xl p-2"><Logo size={64} /></span></div>
          <div className="text-center mb-5">
            <div className="font-display font-bold text-[11px] tracking-[.2em] text-ink-soft">IES</div>
            <div className="font-display font-bold text-lg text-ink tracking-tight leading-tight">Valle del Jerte</div>
            <div className="text-[11px] text-ink-soft font-medium">Horarios · Curso 2026-27</div>
          </div>
          <h1 className="font-display font-bold text-lg text-ink text-center">{titulo}</h1>
          {sub && <p className="text-xs text-ink-soft text-center mt-1 mb-4 font-medium">{sub}</p>}
          {children}
        </div>
      </main>
      <footer className="text-center py-6 text-xs text-[#522270] font-semibold bg-[#E4CFF0] border-t border-[#CDAEE0]">IES Valle del Jerte · Plasencia · Jefatura de Estudios · Curso 2026-27</footer>
    </div>
  );
}

export function PantallaLogin({ onEntrar }) {
  const [u, setU] = useState(() => { try { return localStorage.getItem('vj_ultimo_login') || ''; } catch (e) { return ''; } });
  const [c, setC] = useState(''); const [ver, setVer] = useState(false);
  const [err, setErr] = useState(''); const [ocupado, setOcupado] = useState(false);
  const entrar = async e => {
    e.preventDefault();
    if (!u.trim() || !c || ocupado) return;
    setOcupado(true); setErr('');
    try {
      const r = await pedir('POST', '/auth/login', { usuario: u.trim(), clave: c });
      try { localStorage.setItem('vj_ultimo_login', u.trim()); } catch (x) { /* nada */ }
      onEntrar(r.usuario);
    } catch (x) { setErr(x.message); setOcupado(false); }
  };
  return (
    <Marco titulo="Acceso del profesorado" sub="Entra con el usuario y la contraseña que te ha dado Jefatura de Estudios">
      <form onSubmit={entrar} className="space-y-3">
        <div><label className="lbl" htmlFor="acc-u">Usuario</label>
          <input id="acc-u" className="field" autoComplete="username" autoCapitalize="none" spellCheck="false" value={u} onChange={e => { setU(e.target.value); setErr(''); }} autoFocus={!u} /></div>
        <div><label className="lbl" htmlFor="acc-c">Contraseña</label>
          <div className="relative">
            <input id="acc-c" className="field !pr-20" type={ver ? 'text' : 'password'} autoComplete="current-password" value={c} onChange={e => { setC(e.target.value); setErr(''); }} autoFocus={!!u} />
            <button type="button" className="absolute right-2 top-1/2 -translate-y-1/2 text-xs font-semibold text-ink-soft px-2 py-1" onClick={() => setVer(!ver)}>{ver ? 'Ocultar' : 'Mostrar'}</button>
          </div></div>
        {err && <p className="text-xs font-semibold text-[#be123c]" role="alert">{err}</p>}
        <button className="btn btn-dark w-full" disabled={ocupado}>{ocupado ? 'Entrando…' : 'Entrar'}</button>
        <p className="text-[11px] text-ink-soft text-center">¿Has olvidado la contraseña? Pide a Jefatura que te la restablezca.</p>
        <p className="text-center"><a href="tutorial/videotutorial.mp4" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#6B2D8B] underline underline-offset-2">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true"><rect x="2.5" y="5" width="19" height="14" rx="3" /><path d="m10 9 5 3-5 3Z" fill="currentColor" /></svg>
          ¿Primera vez? Mira el videotutorial (6 min)</a></p>
        {esNativa && !import.meta.env.VITE_API_URL && (
          <p className="text-[11px] text-ink-soft text-center">Servidor: {servidorGuardado().replace(/^https?:\/\//, '')} ·{' '}
            <button type="button" className="font-semibold text-primary underline" onClick={() => { guardarServidor(''); location.reload(); }}>Cambiar</button></p>
        )}
      </form>
    </Marco>
  );
}

/** App de móvil, primera vez: dirección del servidor del centro */
export function PantallaServidor() {
  const [s, setS] = useState(servidorGuardado());
  const [err, setErr] = useState(''); const [ocupado, setOcupado] = useState(false);
  const guardar = async e => {
    e.preventDefault();
    const dir = normalizarServidor(s);
    if (!dir || ocupado) return;
    setOcupado(true); setErr('');
    try {
      const r = await fetch(dir + '/api/salud', { cache: 'no-store' });
      const d = await r.json().catch(() => ({}));
      if (!r.ok || !d.ok) throw new Error();
      guardarServidor(dir);
      location.reload();
    } catch (x) {
      setErr('No se encuentra la app en esa dirección. Revísala o comprueba la conexión a Internet.');
      setOcupado(false);
    }
  };
  return (
    <Marco titulo="Servidor del centro" sub="Escribe la dirección de la app de horarios que te ha indicado Jefatura de Estudios. Solo se pide la primera vez.">
      <form onSubmit={guardar} className="space-y-3">
        <div><label className="lbl" htmlFor="acc-s">Dirección</label>
          <input id="acc-s" className="field" inputMode="url" autoCapitalize="none" spellCheck="false" placeholder="horarios.iesvalledeljerte.es"
            value={s} onChange={e => { setS(e.target.value); setErr(''); }} autoFocus /></div>
        {err && <p className="text-xs font-semibold text-[#be123c]" role="alert">{err}</p>}
        <button className="btn btn-dark w-full" disabled={ocupado}>{ocupado ? 'Comprobando…' : 'Continuar'}</button>
      </form>
    </Marco>
  );
}

export function FormCambioClave({ provisional, onHecho, onCancelar }) {
  const [a, setA] = useState(''); const [n, setN] = useState(''); const [n2, setN2] = useState('');
  const [err, setErr] = useState(''); const [ocupado, setOcupado] = useState(false);
  const enviar = async e => {
    e.preventDefault();
    if (n !== n2) { setErr('Las dos contraseñas nuevas no coinciden'); return; }
    if (n.length < 8 || !/[A-Za-z]/.test(n) || !/[0-9]/.test(n)) { setErr('Mínimo 8 caracteres, con letras y números'); return; }
    setOcupado(true); setErr('');
    try { await pedir('POST', '/auth/cambiar-clave', { actual: a, nueva: n }); onHecho(); }
    catch (x) { setErr(x.message); setOcupado(false); }
  };
  return (
    <form onSubmit={enviar} className="space-y-3">
      <div><label className="lbl" htmlFor="cc-a">{provisional ? 'Contraseña provisional' : 'Contraseña actual'}</label>
        <input id="cc-a" className="field" type="password" autoComplete="current-password" value={a} onChange={e => { setA(e.target.value); setErr(''); }} autoFocus /></div>
      <div><label className="lbl" htmlFor="cc-n">Nueva contraseña</label>
        <input id="cc-n" className="field" type="password" autoComplete="new-password" value={n} onChange={e => { setN(e.target.value); setErr(''); }} /></div>
      <div><label className="lbl" htmlFor="cc-n2">Repite la nueva contraseña</label>
        <input id="cc-n2" className="field" type="password" autoComplete="new-password" value={n2} onChange={e => { setN2(e.target.value); setErr(''); }} /></div>
      <p className="text-[11px] text-ink-soft">Mínimo 8 caracteres, con letras y números.</p>
      {err && <p className="text-xs font-semibold text-[#be123c]" role="alert">{err}</p>}
      <div className="flex gap-2">
        {onCancelar && <button type="button" className="btn btn-ghost flex-1" onClick={onCancelar}>Cancelar</button>}
        <button className="btn btn-dark flex-1" disabled={ocupado}>{ocupado ? 'Guardando…' : 'Guardar contraseña'}</button>
      </div>
    </form>
  );
}

export function PantallaCambioClave({ usuario, onHecho }) {
  return (
    <Marco titulo={'Hola, ' + ((usuario.nombre || '').split(', ')[1] || usuario.nombre || usuario.usuario)}
      sub="Es tu primera entrada (o Jefatura ha restablecido tu contraseña): elige una contraseña personal">
      <FormCambioClave provisional onHecho={onHecho} />
      <button type="button" className="w-full text-xs font-semibold text-ink-soft mt-4 underline underline-offset-2" onClick={cerrarSesion}>Salir</button>
    </Marco>
  );
}

/** Datos del docente: correo de Educarex, móvil y años trabajados (se piden al entrar si faltan) */
export function FormMisDatos({ usuario, onHecho, onCancelar }) {
  const [email, setEmail] = useState(usuario.email || '');
  const [movil, setMovil] = useState(usuario.movil || '');
  const [anios, setAnios] = useState(usuario.aniosServicio ?? '');
  const [err, setErr] = useState(''); const [ocupado, setOcupado] = useState(false);
  const enviar = async e => {
    e.preventDefault();
    if (!/^[^@\s]+@educarex\.es$/i.test(email.trim())) { setErr('La cuenta de correo tiene que ser de Educarex (…@educarex.es)'); return; }
    setOcupado(true); setErr('');
    try { const r = await pedir('PUT', '/auth/mis-datos', { email: email.trim(), movil, anios }); onHecho(r.usuario); }
    catch (x) { setErr(x.message); setOcupado(false); }
  };
  return (
    <form onSubmit={enviar} className="space-y-3">
      <div><label className="lbl" htmlFor="md-e">Cuenta de correo de Educarex</label>
        <input id="md-e" className="field" type="email" inputMode="email" autoComplete="email" autoCapitalize="none" spellCheck="false" placeholder="nombre@educarex.es"
          value={email} onChange={e => { setEmail(e.target.value); setErr(''); }} autoFocus /></div>
      <div><label className="lbl" htmlFor="md-m">Teléfono móvil de contacto</label>
        <input id="md-m" className="field" type="tel" inputMode="tel" autoComplete="tel" placeholder="600 000 000"
          value={movil} onChange={e => { setMovil(e.target.value); setErr(''); }} /></div>
      <div><label className="lbl" htmlFor="md-a">Años trabajados</label>
        <input id="md-a" className="field" type="number" inputMode="numeric" min="0" max="50" step="1" placeholder="Ej.: 12"
          value={anios} onChange={e => { setAnios(e.target.value); setErr(''); }} /></div>
      <p className="text-[11px] font-semibold rounded-lg px-3 py-2" style={{ background: '#fef3c7', color: '#92400e' }}>
        Nota: el dato de años trabajados es imprescindible para el cálculo de los DAP (días de asuntos propios) de cada profesor/a.</p>
      <p className="text-[11px] text-ink-soft">Solo los ve Jefatura de Estudios. Puedes corregirlos cuando quieras en «Mi cuenta».</p>
      {err && <p className="text-xs font-semibold text-[#be123c]" role="alert">{err}</p>}
      <div className="flex gap-2">
        {onCancelar && <button type="button" className="btn btn-ghost flex-1" onClick={onCancelar}>Cancelar</button>}
        <button className="btn btn-dark flex-1" disabled={ocupado}>{ocupado ? 'Guardando…' : 'Guardar y continuar'}</button>
      </div>
    </form>
  );
}
export function PantallaMisDatos({ usuario, onHecho }) {
  return (
    <Marco titulo={'Hola, ' + ((usuario.nombre || '').split(', ')[1] || usuario.nombre || usuario.usuario)}
      sub="Antes de continuar, completa tus datos de contacto">
      <FormMisDatos usuario={usuario} onHecho={onHecho} />
      <button type="button" className="w-full text-xs font-semibold text-ink-soft mt-4 underline underline-offset-2" onClick={cerrarSesion}>Salir</button>
    </Marco>
  );
}

export function PantallaCargando({ texto = 'Cargando…' }) {
  return <div className="min-h-screen flex items-center justify-center text-sm text-ink-soft font-medium">{texto}</div>;
}
