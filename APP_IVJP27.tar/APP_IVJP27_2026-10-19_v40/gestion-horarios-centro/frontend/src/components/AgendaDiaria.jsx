/**
 * Agenda diaria · vista vertical pensada para el móvil.
 * Un día cada vez (pestañas L-M-X-J-V) y las sesiones en línea de tiempo; resalta el tramo en curso.
 */
import { useState } from 'react';
import { DIAS, DIAS_CORTOS, diaHoy, estilo, textoSesion, etiquetaTramo, horaAhora, tramosUsados } from '../lib/horario.js';
import { useReloj } from '../hooks/useApi.js';

export default function AgendaDiaria({ sesiones, tramos, mostrar = 'profesor', diaInicial }) {
  const [dia, setDia] = useState(diaInicial || diaHoy() || 1);
  useReloj();
  const hoy = diaHoy(), hora = horaAhora();
  const filas = tramosUsados(tramos, sesiones).map(t => ({ t, items: sesiones.filter(s => s.dia === dia && s.tramo === t.codigo) }))
    .filter(f => f.items.length || f.t.tipo === 'clase');
  const ultimaConClase = Math.max(-1, ...filas.map((f, i) => (f.items.length ? i : -1)));
  const visibles = filas.slice(0, ultimaConClase + 1);

  return (
    <div className="fade-in">
      <div className="grid grid-cols-5 gap-1.5 mb-4 sticky top-[60px] z-10 bg-paper py-2 no-print" role="tablist" aria-label="Día de la semana">
        {DIAS.map((d, i) => (
          <button key={d} role="tab" aria-selected={dia === i + 1} onClick={() => setDia(i + 1)}
            className={`chip !px-0 text-center ${dia === i + 1 ? 'chip-on' : ''}`}>
            <span className="block text-[15px] font-bold leading-none">{DIAS_CORTOS[i]}</span>
            {hoy === i + 1 && <span className={`block text-[9px] mt-0.5 font-bold uppercase ${dia === i + 1 ? 'text-white/80' : 'text-primary'}`}>Hoy</span>}
          </button>
        ))}
      </div>
      <h3 className="font-display font-bold text-lg mb-3">{DIAS[dia - 1]}</h3>
      {!visibles.length && <div className="card p-8 text-center text-ink-soft font-medium">Sin actividad este día</div>}
      <ol className="relative border-l-2 border-divider ml-[54px] space-y-2.5">
        {visibles.map(({ t, items }) => {
          const enCurso = hoy === dia && hora >= t.inicio && hora < t.fin;
          return (
            <li key={t.codigo} className="relative pl-4">
              <div className="absolute -left-[64px] top-1 w-[52px] text-right">
                <div className={`font-display font-bold text-[13px] leading-none ${enCurso ? 'text-primary' : 'text-ink'}`}>{etiquetaTramo(t.codigo)}</div>
                <div className="text-[10px] text-ink-soft mt-1">{t.inicio}</div>
              </div>
              <span className={`absolute -left-[7px] top-2 w-3 h-3 rounded-full border-2 border-white ${enCurso ? 'bg-primary ring-4 ring-primary/20' : items.length ? 'bg-ink-blue' : 'bg-divider'}`} />
              {items.length === 0
                ? <div className="text-[12px] text-ink-soft/70 py-1.5">Libre</div>
                : <div className="space-y-1.5">{items.map(s => {
                    const e = estilo(s.categoria);
                    return (
                      <div key={s.id} className={`rounded-xl px-3.5 py-2.5 border-l-4 shadow-sm ${enCurso ? 'ring-2 ring-primary/30' : ''}`} style={{ background: e.bg, borderColor: e.bd, color: e.tx }}>
                        <div className="font-bold text-[13px] leading-snug">{textoSesion(s, mostrar)}</div>
                        {s.materia && <div className="text-[12px] opacity-80 leading-snug mt-0.5">{s.materia}</div>}
                        <div className="text-[10px] opacity-60 mt-1">{t.inicio}–{t.fin}{enCurso && ' · ahora'}</div>
                      </div>
                    );
                  })}</div>}
            </li>
          );
        })}
      </ol>
    </div>
  );
}
