/**
 * Buscador global · filtro rápido por profesor/a, grupo o aula (sin tildes, a partir de 1 carácter).
 * `tipos` limita qué se busca (p. ej. solo 'profesor' en Mi horario). Navegable con teclado.
 */
import { useEffect, useRef, useState } from 'react';
import { api } from '../lib/api.js';
import Icono from './Icono.jsx';

const META = { profesor: { l: 'Profesorado', ico: 'persona', c: '#2d4a6b' }, grupo: { l: 'Grupos', ico: 'grupo', c: '#5c6b4f' }, aula: { l: 'Aulas', ico: 'aula', c: '#a85a3f' } };

export default function BuscadorGlobal({ onElegir, tipos = ['profesor', 'grupo', 'aula'], placeholder = 'Busca profesor/a, grupo o aula…', autoFocus = false }) {
  const [q, setQ] = useState('');
  const [res, setRes] = useState([]);
  const [activo, setActivo] = useState(0);
  const [abierto, setAbierto] = useState(false);
  const [cargando, setCargando] = useState(false);
  const pet = useRef(0);

  useEffect(() => {
    if (!q.trim()) { setRes([]); return undefined; }
    const n = ++pet.current; setCargando(true);
    const t = setTimeout(async () => {
      try { const r = (await api.buscar(q)).filter(x => tipos.includes(x.tipo)); if (n === pet.current) { setRes(r); setActivo(0); } }
      catch { if (n === pet.current) setRes([]); }
      finally { if (n === pet.current) setCargando(false); }
    }, 180);
    return () => clearTimeout(t);
  }, [q, tipos.join()]);

  const elegir = r => { onElegir(r); setQ(''); setRes([]); setAbierto(false); };
  const tecla = e => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setActivo(a => Math.min(a + 1, res.length - 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setActivo(a => Math.max(a - 1, 0)); }
    else if (e.key === 'Enter' && res[activo]) { e.preventDefault(); elegir(res[activo]); }
    else if (e.key === 'Escape') setAbierto(false);
  };
  const grupos = tipos.map(t => ({ t, items: res.filter(r => r.tipo === t) })).filter(g => g.items.length);
  let idx = -1;

  return (
    <div className="relative" onBlur={e => { if (!e.currentTarget.contains(e.relatedTarget)) setAbierto(false); }}>
      <label className="sr-only" htmlFor="buscador">{placeholder}</label>
      <div className="relative">
        <Icono n="buscar" s={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-soft" />
        <input id="buscador" className="field !pl-10 !pr-10 !min-h-[48px] text-[15px]" value={q} placeholder={placeholder} autoComplete="off" autoFocus={autoFocus}
          role="combobox" aria-expanded={abierto && !!res.length} aria-controls="buscador-res"
          onChange={e => { setQ(e.target.value); setAbierto(true); }} onFocus={() => setAbierto(true)} onKeyDown={tecla} />
        {q && <button className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-ink-soft hover:text-ink" aria-label="Borrar búsqueda" onClick={() => setQ('')}><Icono n="cerrar" s={16} /></button>}
      </div>
      {abierto && q.trim() && (
        <div id="buscador-res" role="listbox" className="absolute z-30 left-0 right-0 mt-2 card shadow-xl max-h-[60vh] overflow-y-auto p-1.5 fade-in">
          {!res.length && <div className="p-4 text-sm text-ink-soft">{cargando ? 'Buscando…' : 'Sin resultados'}</div>}
          {grupos.map(g => (
            <div key={g.t} className="mb-1">
              <div className="px-3 pt-2 pb-1 text-[10px] font-bold uppercase tracking-wider text-ink-soft">{META[g.t].l}</div>
              {g.items.map(r => { idx++; const i = idx; return (
                <button key={r.tipo + r.id} role="option" aria-selected={i === activo} tabIndex={-1} onMouseEnter={() => setActivo(i)} onClick={() => elegir(r)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left ${i === activo ? 'bg-paper-warm' : ''}`}>
                  <span className="w-8 h-8 rounded-lg flex items-center justify-center text-white flex-shrink-0" style={{ background: META[r.tipo].c }}><Icono n={META[r.tipo].ico} s={16} /></span>
                  <span className="font-semibold text-[14px] text-ink">{r.tipo === 'aula' ? 'Aula ' + r.nombre : r.nombre}</span>
                </button>
              ); })}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
