/**
 * Estado de guardias en tiempo real.
 *  · modo "ahora": tramo en curso y el siguiente; se refresca cada minuto.
 *  · con `fecha`: todos los tramos de ese día.
 * Muestra profesorado de guardia disponible, de guardia pero ausente (tachado),
 * profesorado ausente y grupos sin profesor con la tarea que haya dejado.
 */
import { api } from '../lib/api.js';
import { useApi } from '../hooks/useApi.js';
import { etiquetaTramo, fmtLarga, corto } from '../lib/horario.js';
import Icono from './Icono.jsx';

function Tramo({ t, destacado, titulo }) {
  const recreo = t.tipo === 'recreo';
  const color = recreo ? ['#0d9488', '#34d3be'] : ['#d97706', '#fbbf24'];
  return (
    <article className={`card p-4 ${destacado ? 'ring-2 ring-primary/40 shadow-lg' : ''}`} aria-label={`${etiquetaTramo(t.tramo)} ${t.inicio}`}>
      <div className="flex gap-4 items-start">
        <div className="w-16 flex-shrink-0 text-center rounded-xl py-2 text-white" style={{ background: `linear-gradient(135deg,${color[0]},${color[1]})` }}>
          <div className="font-display font-bold text-lg leading-none">{recreo ? t.tramo : t.tramo + 'ª'}</div>
          <div className="text-[9px] mt-1 opacity-90 font-medium">{t.inicio}–{t.fin}</div>
        </div>
        <div className="flex-1 min-w-0">
          {titulo && <div className="text-[10px] font-bold uppercase tracking-wider text-primary mb-1">{titulo}</div>}
          <div className="text-[10px] font-bold uppercase tracking-wider text-ink-soft mb-1.5">{recreo ? 'Guardia de recreo' : 'Profesorado de guardia'}</div>
          {!t.guardias.length && !t.guardiasAusentes.length
            ? <p className="text-sm text-ink-soft">Sin profesorado de guardia</p>
            : <div className="flex flex-wrap gap-1.5">
                {t.guardias.map(g => <span key={g.id} className="px-3 py-1.5 rounded-full text-xs font-bold" style={{ background: color[0] + '1c', color: color[0] }}>{g.nombre}</span>)}
                {t.guardiasAusentes.map(g => <span key={g.id} title="De guardia, pero ausente" className="px-3 py-1.5 rounded-full text-xs font-bold bg-gray-100 text-gray-400 line-through">{g.nombre}</span>)}
              </div>}
          {t.guardias.length === 0 && t.guardiasAusentes.length > 0 && <p className="mt-2 text-xs font-bold text-alerta flex items-center gap-1"><Icono n="aviso" s={14} />Toda la guardia está ausente: avisa a Jefatura</p>}
          {t.sinCubrir.length > 0 && (
            <div className="mt-3 pt-3 border-t border-divider">
              <div className="text-[10px] font-bold uppercase tracking-wider text-alerta mb-1.5">Grupos sin profesor ({t.sinCubrir.length})</div>
              <ul className="space-y-1.5">
                {t.sinCubrir.map((c, i) => (
                  <li key={i} className="rounded-lg bg-rose-50 px-3 py-2 text-[12px] text-[#9f1239]">
                    <span className="font-bold">{c.grupo || '—'}</span>{c.aula && <span> · Aula {c.aula}</span>}
                    <span className="opacity-75"> · {c.materia ? c.materia + ' · ' : ''}{corto(c.profesor)}</span>
                    {c.tarea && <div className="mt-1 flex gap-1.5 text-ink-soft"><Icono n="nota" s={14} className="flex-shrink-0 mt-px" /><span><b>Tarea:</b> {c.tarea}</span></div>}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </article>
  );
}

function Ausentes({ lista }) {
  if (!lista.length) return <div className="rounded-xl border-l-4 border-olive bg-olive-light p-3 text-xs font-semibold text-olive">Sin ausencias registradas</div>;
  return (
    <div className="rounded-xl border-l-4 border-alerta bg-rose-50 p-4">
      <div className="font-bold text-sm text-[#9f1239] mb-1">Profesorado ausente ({lista.length})</div>
      <div className="text-xs text-[#9f1239] font-medium leading-relaxed">
        {lista.map((a, i) => <span key={a.id}>{i > 0 && ' · '}{a.profesor} ({a.modo === 'dia' ? 'todo el día' : a.horas.map(etiquetaTramo).join(', ')})</span>)}
      </div>
    </div>
  );
}

export default function EstadoGuardias({ fecha = null }) {
  const { datos, error, cargando } = useApi(() => (fecha ? api.guardiasDia(fecha) : api.guardiasAhora()), [fecha], { cadaMs: 60000 });
  if (cargando && !datos) return <div className="card p-8 text-center text-ink-soft" aria-busy="true">Cargando guardias…</div>;
  if (error && !datos) return <div className="card p-6 text-center text-terracotta font-semibold">No se pudo conectar con el servidor de horarios.</div>;
  if (!datos.lectivo) return <div className="card p-8 text-center text-ink-soft font-medium">{fmtLarga(datos.fecha)} no es día lectivo.</div>;

  if (!fecha) {
    const { actual, siguiente } = datos;
    return (
      <div className="space-y-3 fade-in" aria-live="polite">
        <div className="flex items-center gap-2 text-xs text-ink-soft font-semibold">
          <span className="w-2 h-2 rounded-full bg-olive animate-pulse" />En directo · {datos.hora} · se actualiza cada minuto
        </div>
        <Ausentes lista={datos.ausencias} />
        {actual ? <Tramo t={actual} destacado titulo="Ahora" /> : <div className="card p-6 text-center text-ink-soft font-medium">Fuera del horario lectivo ({datos.hora}).</div>}
        {siguiente && <Tramo t={siguiente} titulo="A continuación" />}
      </div>
    );
  }
  return (
    <div className="space-y-3 fade-in">
      <Ausentes lista={datos.ausencias} />
      {datos.tramos.map(t => <Tramo key={t.tramo} t={t} />)}
    </div>
  );
}
