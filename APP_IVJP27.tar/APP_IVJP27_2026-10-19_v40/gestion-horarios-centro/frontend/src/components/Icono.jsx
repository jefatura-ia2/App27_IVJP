const P = {
  calendario: <><rect x="3.5" y="5" width="17" height="15.5" rx="2.5" /><path d="M3.5 9.5h17M8 3v4M16 3v4" /></>,
  buscar: <><circle cx="10.5" cy="10.5" r="6" /><path d="m15 15 5 5" /></>,
  escudo: <path d="M12 3 4.5 6v5.5c0 4.6 3.2 8.3 7.5 9.5 4.3-1.2 7.5-4.9 7.5-9.5V6Z" />,
  persona: <><circle cx="12" cy="8" r="3.6" /><path d="M4.5 20.5c0-4 3.4-6.3 7.5-6.3s7.5 2.3 7.5 6.3" /></>,
  grupo: <><circle cx="9" cy="8.5" r="3" /><circle cx="17" cy="9.5" r="2.4" /><path d="M3 19.5c0-3.3 2.7-5.3 6-5.3s6 2 6 5.3M15.5 14.4c2.9.2 5 2 5 4.6" /></>,
  aula: <><rect x="6" y="3.5" width="12" height="17.5" rx="1.2" /><path d="M3 21h18" /><circle cx="15" cy="12.6" r=".9" fill="currentColor" /></>,
  reloj: <><circle cx="12" cy="12" r="8.5" /><path d="M12 7.5V12l3 2" /></>,
  aviso: <><path d="M12 4 2.8 19.5h18.4Z" /><path d="M12 10v4.5M12 17.2v.3" /></>,
  cerrar: <path d="m6 6 12 12M18 6 6 18" />,
  imprimir: <><path d="M7 9V3.5h10V9M7 17H4.5v-6.5a1.5 1.5 0 0 1 1.5-1.5h12a1.5 1.5 0 0 1 1.5 1.5V17H17" /><rect x="7" y="14" width="10" height="7" rx="1" /></>,
  nota: <><path d="M6 3.5h8.5L19 8v12.5H6Z" /><path d="M14 3.5V8h5M9 12.5h6M9 16h4" /></>,
  candado: <><rect x="4.5" y="10.5" width="15" height="10" rx="2" /><path d="M7.5 10.5V7a4.5 4.5 0 0 1 9 0v3.5" /></>,
  subir: <><path d="M12 19V6M6 11.5 12 5l6 6.5" /><path d="M5 19.5h14" /></>,
  papelera: <><path d="M5 7h14M9.5 7V4.8c0-.7.5-1.3 1.2-1.3h2.6c.7 0 1.2.6 1.2 1.3V7M7 7l1 13.2c.05.9.8 1.6 1.7 1.6h4.6c.9 0 1.65-.7 1.7-1.6L17 7" /><path d="M10 11v6M14 11v6" /></>,
  mas: <><path d="M12 5v14M5 12h14" /></>,
};
export default function Icono({ n, s = 20, className = '' }) {
  return (
    <svg viewBox="0 0 24 24" width={s} height={s} className={className} fill="none" stroke="currentColor"
      strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">{P[n]}</svg>
  );
}
