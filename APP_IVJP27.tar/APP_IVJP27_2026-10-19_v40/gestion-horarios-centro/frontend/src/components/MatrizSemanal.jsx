/**
 * Matriz semanal · parrilla días × tramos para PC y tablet.
 * Resalta la columna de hoy y la fila del tramo en curso. Imprimible.
 */
import { DIAS, diaHoy, estilo, textoSesion, etiquetaTramo, horaAhora, tramosUsados } from '../lib/horario.js';
import { useReloj } from '../hooks/useApi.js';

export default function MatrizSemanal({ sesiones, tramos, mostrar = 'profesor' }) {
  useReloj();
  const hoy = diaHoy(), hora = horaAhora();
  const filas = tramosUsados(tramos, sesiones);
  const celda = (dia, tramo) => sesiones.filter(s => s.dia === dia && s.tramo === tramo);
  return (
    <div className="card overflow-x-auto fade-in">
      <table className="w-full border-collapse table-fixed min-w-[720px]">
        <thead>
          <tr>
            <th className="w-[78px] p-2" />
            {DIAS.map((d, i) => (
              <th key={d} className={`p-2.5 text-[12px] font-bold uppercase tracking-wider ${hoy === i + 1 ? 'text-primary' : 'text-ink-soft'}`}>
                {d}{hoy === i + 1 && <span className="ml-1.5 text-[9px] bg-primary text-white rounded-full px-1.5 py-0.5 align-middle">HOY</span>}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {filas.map(t => {
            const enCurso = hora >= t.inicio && hora < t.fin;
            const recreo = t.tipo === 'recreo';
            return (
              <tr key={t.codigo} className={`border-t border-divider ${recreo ? 'bg-paper-warm/70' : ''}`}>
                <th className={`p-2 text-left align-top ${enCurso && hoy ? 'text-primary' : 'text-ink'}`}>
                  <div className="font-display font-bold text-[13px]">{etiquetaTramo(t.codigo)}</div>
                  <div className="text-[10px] font-medium text-ink-soft">{t.inicio}–{t.fin}</div>
                </th>
                {DIAS.map((d, i) => {
                  const items = celda(i + 1, t.codigo);
                  const ahora = enCurso && hoy === i + 1;
                  return (
                    <td key={d} className={`p-1 align-top ${hoy === i + 1 ? 'bg-primary/[0.03]' : ''} ${ahora ? 'outline outline-2 outline-primary -outline-offset-2 rounded-lg' : ''}`}>
                      <div className={`space-y-1 ${recreo ? 'min-h-[28px]' : 'min-h-[52px]'}`}>
                        {items.map(s => {
                          const e = estilo(s.categoria);
                          return (
                            <div key={s.id} title={[s.materia, s.profesor, s.grupo, s.aula && 'Aula ' + s.aula].filter(Boolean).join(' · ')}
                              className="rounded-lg px-2 py-1.5 border-l-[3px] text-[11px] leading-tight" style={{ background: e.bg, borderColor: e.bd, color: e.tx }}>
                              <div className="font-bold truncate">{textoSesion(s, mostrar)}</div>
                              {s.materia && !recreo && <div className="truncate opacity-75 mt-0.5">{s.materia}</div>}
                            </div>
                          );
                        })}
                      </div>
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
