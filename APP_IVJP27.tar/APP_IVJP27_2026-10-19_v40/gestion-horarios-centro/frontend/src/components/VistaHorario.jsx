/** Elige la vista según el dispositivo (Agenda en móvil, Matriz en PC/tablet) y permite cambiarla */
import { useState } from 'react';
import { useEsMovil } from '../hooks/useApi.js';
import AgendaDiaria from './AgendaDiaria.jsx';
import MatrizSemanal from './MatrizSemanal.jsx';
import Icono from './Icono.jsx';

export default function VistaHorario({ horario, tramos, mostrar }) {
  const movil = useEsMovil();
  const [forzada, setForzada] = useState(null);
  const vista = forzada || (movil ? 'agenda' : 'matriz');
  const horas = horario.sesiones.filter(s => s.categoria === 'docencia').length;
  return (
    <div className="space-y-4">
      <div className="card p-4 flex items-center justify-between gap-3 flex-wrap">
        <div className="min-w-0">
          <div className="font-display font-bold text-lg text-ink leading-tight">{horario.tipo === 'aula' ? 'Aula ' + horario.nombre : horario.nombre}</div>
          <div className="text-xs text-ink-soft font-medium">{horario.sesiones.length} sesiones semanales{horario.tipo === 'profesor' ? ` · ${horas} de docencia` : ''}</div>
        </div>
        <div className="flex gap-1.5 no-print">
          <div className="flex bg-paper-warm rounded-xl p-1" role="group" aria-label="Vista">
            {[['agenda', 'Día'], ['matriz', 'Semana']].map(([v, l]) => (
              <button key={v} onClick={() => setForzada(v)} aria-pressed={vista === v}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold ${vista === v ? 'bg-white shadow-sm text-ink' : 'text-ink-soft'}`}>{l}</button>
            ))}
          </div>
          {vista === 'matriz' && <button className="chip !py-1.5" onClick={() => window.print()} aria-label="Imprimir"><Icono n="imprimir" s={16} /></button>}
        </div>
      </div>
      <div className="hidden print:block font-display font-bold text-xl">IES Valle del Jerte · {horario.nombre} · Curso 2026-27</div>
      {vista === 'agenda'
        ? <AgendaDiaria sesiones={horario.sesiones} tramos={tramos} mostrar={mostrar} />
        : <MatrizSemanal sesiones={horario.sesiones} tramos={tramos} mostrar={mostrar} />}
    </div>
  );
}
