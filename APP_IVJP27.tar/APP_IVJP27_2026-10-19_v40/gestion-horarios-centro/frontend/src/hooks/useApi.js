import { useCallback, useEffect, useRef, useState } from 'react';

/** Carga datos de la API; `cadaMs` refresca periódicamente (p. ej. guardias en tiempo real) */
export function useApi(fn, deps = [], { cadaMs = 0, activo = true } = {}) {
  const [estado, setEstado] = useState({ datos: null, error: null, cargando: activo });
  const fnRef = useRef(fn); fnRef.current = fn;
  const cargar = useCallback(async (silencioso = false) => {
    if (!silencioso) setEstado(e => ({ ...e, cargando: true }));
    try { const datos = await fnRef.current(); setEstado({ datos, error: null, cargando: false }); }
    catch (error) { setEstado(e => ({ ...e, error, cargando: false })); }
  }, []);
  useEffect(() => {
    if (!activo) return undefined;
    cargar();
    if (!cadaMs) return undefined;
    const t = setInterval(() => { if (!document.hidden) cargar(true); }, cadaMs);
    const vis = () => { if (!document.hidden) cargar(true); };
    document.addEventListener('visibilitychange', vis);
    return () => { clearInterval(t); document.removeEventListener('visibilitychange', vis); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activo, cadaMs, ...deps]);
  return { ...estado, recargar: cargar };
}

/** true en pantallas estrechas (móvil): se usa la Agenda en vez de la Matriz */
export function useEsMovil(px = 768) {
  const q = `(max-width: ${px - 1}px)`;
  const [m, setM] = useState(() => window.matchMedia(q).matches);
  useEffect(() => {
    const mq = window.matchMedia(q); const f = e => setM(e.matches);
    mq.addEventListener('change', f); return () => mq.removeEventListener('change', f);
  }, [q]);
  return m;
}

/** Valor guardado en este dispositivo (p. ej. "mi profesor") */
export function useLocal(clave, inicial) {
  const [v, setV] = useState(() => { try { const x = localStorage.getItem(clave); return x ? JSON.parse(x) : inicial; } catch { return inicial; } });
  const guardar = nv => { setV(nv); try { nv == null ? localStorage.removeItem(clave) : localStorage.setItem(clave, JSON.stringify(nv)); } catch { /* sin almacenamiento */ } };
  return [v, guardar];
}

/** Hora actual que se actualiza cada minuto (para resaltar el tramo en curso) */
export function useReloj() {
  const [ahora, setAhora] = useState(() => new Date());
  useEffect(() => { const t = setInterval(() => setAhora(new Date()), 30000); return () => clearInterval(t); }, []);
  return ahora;
}
