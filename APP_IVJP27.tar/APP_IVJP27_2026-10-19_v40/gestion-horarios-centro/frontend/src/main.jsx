/**
 * Arranque:
 *  1. ¿Hay sesión? (GET /api/auth/yo). Si no → pantalla de acceso con usuario y contraseña.
 *     Con contraseña provisional → pantalla para cambiarla.
 *  2. Con sesión válida se descarga el horario (/api/horario.csv) y se carga la interfaz
 *     original (original/AppOriginal.jsx), que lo lee al iniciarse.
 *  Sin conexión: si este dispositivo ya había entrado, se usa la última copia guardada.
 */
import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import './original/original.css';

import { esNativa, apiBase, tokenApp } from './servidor.js';

const BASE = apiBase();                 // '' = app de móvil sin servidor elegido todavía
window.__API_BASE__ = BASE; // también lo usa la Cronología (public/cronologia.html)
const CACHE = 'vj_horario_csv';

/* Si la sesión caduca o la cierran desde administración mientras se usa la app,
   cualquier respuesta 401/403-provisional de la API devuelve a la pantalla de acceso. */
const fetchOriginal = window.fetch.bind(window);
window.fetch = async (...args) => {
  const url = String(args[0] && args[0].url ? args[0].url : args[0]);
  const esApi = !!BASE && (url.startsWith(BASE) || url.includes('/api/'));
  /* app de móvil: la sesión viaja en la cabecera Authorization (la cookie no sirve entre orígenes) */
  if (esNativa && esApi && typeof args[0] === 'string') {
    const init = { ...(args[1] || {}) };
    const h = new Headers(init.headers || {});
    h.set('X-Cliente', 'app');
    const t = tokenApp.leer(); if (t) h.set('Authorization', 'Bearer ' + t);
    init.headers = h; args = [args[0], init];
  }
  const r = await fetchOriginal(...args);
  if (esNativa && esApi && url.includes('/auth/login') && r.ok) {
    const d = await r.clone().json().catch(() => ({}));
    if (d.token) tokenApp.guardar(d.token);
  }
  if (esApi && !url.includes('/auth/')) {
    if (r.status === 401 || r.status === 403) {
      const d = await r.clone().json().catch(() => ({}));
      if (d.sesion === false) tokenApp.guardar('');
      if (d.sesion === false || d.cambiarClave) { location.reload(); }
    }
  }
  return r;
};

async function cargarHorario() {
  try {
    const r = await fetch(BASE + '/horario.csv', { cache: 'no-store', credentials: 'include' });
    const t = r.ok ? await r.text() : '';
    if (t.trim()) { try { localStorage.setItem(CACHE, t); } catch { /* sin almacenamiento */ } return t; }
  } catch { /* sin conexión */ }
  try { return localStorage.getItem(CACHE) || ''; } catch { return ''; }
}

function Raiz() {
  const [fase, setFase] = useState({ paso: 'comprobando' });
  const [Acc, setAcc] = useState(null);

  const continuar = async usuario => {
    if (usuario.cambiarClave) { setFase({ paso: 'cambio', usuario }); return; }
    /* tras iniciar sesión o cambiar la contraseña, se pide la cuenta completa (incluye el profesor/a vinculado) */
    if (!('profesor' in usuario)) {
      try { const acc = await import('./acceso/Acceso.jsx'); usuario = (await acc.pedir('GET', '/auth/yo')).usuario; } catch { /* sin conexión: se sigue */ }
    }
    /* el profesorado completa su correo de Educarex, móvil y años trabajados (si faltan) */
    if (usuario.datosPendientes) { setFase({ paso: 'datos', usuario }); return; }
    try { localStorage.setItem('vj_usuario', JSON.stringify(usuario)); } catch { /* nada */ }
    setFase({ paso: 'cargando', usuario });
    window.__CSV_HORARIOS__ = await cargarHorario();
    const { default: App } = await import('./original/AppOriginal.jsx');
    setFase({ paso: 'app', usuario, App });
  };

  useEffect(() => {
    (async () => {
      const acc = await import('./acceso/Acceso.jsx');
      setAcc(acc);
      if (!BASE) { setFase({ paso: 'servidor' }); return; }   /* app de móvil: primera vez */
      try {
        const d = await acc.pedir('GET', '/auth/yo');
        continuar(d.usuario);
      } catch (e) {
        if (e.red) {
          /* sin conexión: solo si este dispositivo ya había entrado y tiene copia del horario */
          let u = null; try { u = JSON.parse(localStorage.getItem('vj_usuario') || 'null'); } catch { /* nada */ }
          if (u && localStorage.getItem(CACHE)) { continuar({ ...u, cambiarClave: false, datosPendientes: false }); return; }
          setFase({ paso: 'sinred' });
        } else setFase({ paso: 'login' });
      }
    })();
  }, []);

  if (!Acc || fase.paso === 'comprobando') return null;
  if (fase.paso === 'servidor') return <Acc.PantallaServidor />;
  if (fase.paso === 'login') return <Acc.PantallaLogin onEntrar={continuar} />;
  if (fase.paso === 'cambio') return <Acc.PantallaCambioClave usuario={fase.usuario} onHecho={() => continuar({ ...fase.usuario, cambiarClave: false })} />;
  if (fase.paso === 'datos') return <Acc.PantallaMisDatos usuario={fase.usuario} onHecho={u => continuar({ ...fase.usuario, ...u, datosPendientes: false })} />;
  if (fase.paso === 'sinred') return <Acc.PantallaCargando texto="No hay conexión con el servidor de la app. Si estás probando en tu ordenador, comprueba que la ventana SERVIDOR (backend) está abierta y sin errores; en el centro, inténtalo de nuevo en unos minutos." />;
  if (fase.paso === 'cargando') return <Acc.PantallaCargando texto="Cargando horarios…" />;
  const App = fase.App;
  return <App usuario={fase.usuario} />;
}

/* Panel de la sala de profesores: ?panel=<enlace secreto> abre la pantalla de TV sin iniciar sesión */
const tokenPanel = new URLSearchParams(location.search).get('panel');
function Panel() {
  const [P, setP] = useState(null);
  useEffect(() => { import('./panel/PanelSala.jsx').then(m => setP(() => m.default)); }, []);
  return P ? <P token={tokenPanel} /> : null;
}
createRoot(document.getElementById('root')).render(tokenPanel ? <Panel /> : <Raiz />);

/* PWA: service worker solo en producción y fuera de la app nativa (Capacitor ya empaqueta los ficheros) */
if ('serviceWorker' in navigator && import.meta.env.PROD && !window.Capacitor?.isNativePlatform?.()) {
  window.addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => {}));
}
