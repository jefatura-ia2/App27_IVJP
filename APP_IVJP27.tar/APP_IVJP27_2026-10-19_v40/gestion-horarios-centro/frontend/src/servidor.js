/**
 * Dirección del servidor del centro.
 *  - Navegador (web/PWA): la API está en el mismo sitio → «/api».
 *  - App de móvil (Android/iOS): la app vive dentro del teléfono, así que necesita saber
 *    la dirección del servidor. Se toma de VITE_API_URL (si se compiló con ella) o la
 *    escribe el usuario la primera vez y queda guardada en el teléfono.
 */
export const esNativa = !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
const K = 'vj_servidor';

export function servidorGuardado() { try { return localStorage.getItem(K) || ''; } catch { return ''; } }
export function guardarServidor(s) { try { s ? localStorage.setItem(K, s) : localStorage.removeItem(K); } catch { /* nada */ } }

/** «iesvalle.es» → «https://iesvalle.es» ; quita «/api» y barras finales */
export function normalizarServidor(t) {
  let s = String(t || '').trim();
  if (!s) return '';
  if (!/^https?:\/\//i.test(s)) s = 'https://' + s;
  return s.replace(/\/+$/, '').replace(/\/api$/i, '');
}

export function apiBase() {
  const env = import.meta.env.VITE_API_URL;
  if (env) return env.replace(/\/$/, '');
  if (esNativa) { const s = servidorGuardado(); return s ? s + '/api' : ''; }
  /* web: «api» junto a la página (p. ej. /horarios/api si la app está en /horarios/) */
  return new URL('api', location.href).pathname;
}

/* Sesión en la app de móvil: token enviado en la cabecera Authorization */
const KT = 'vj_token';
export const tokenApp = {
  leer() { try { return localStorage.getItem(KT) || ''; } catch { return ''; } },
  guardar(t) { try { t ? localStorage.setItem(KT, t) : localStorage.removeItem(KT); } catch { /* nada */ } },
};
