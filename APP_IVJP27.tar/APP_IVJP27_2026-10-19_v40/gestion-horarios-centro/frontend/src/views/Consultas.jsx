/** Consultas: horario de cualquier profesor/a, grupo o aula, y aulas libres ahora mismo */
import { useState } from 'react';
import { api } from '../lib/api.js';
import { useApi } from '../hooks/useApi.js';
import { diaHoy, horaAhora, etiquetaTramo } from '../lib/horario.js';
import BuscadorGlobal from '../components/BuscadorGlobal.jsx';
import VistaHorario from '../components/VistaHorario.jsx';

function AulasLibres({ tramos }) {
  const dia = diaHoy(), hora = horaAhora();
  const t = tramos && tramos.find(x => hora >= x.inicio && hora < x.fin && x.tipo === 'clase');
  const { datos } = useApi(() => api.aulasLibres(dia, t.codigo), [dia, t && t.codigo], { activo: !!(dia && t) });
  if (!dia || !t || !datos) return null;
  return (
    <div className="card p-4">
      <div className="lbl">Aulas libres ahora · {etiquetaTramo(t.codigo)} ({t.inicio}–{t.fin})</div>
      <div className="flex flex-wrap gap-1.5">
        {datos.length ? datos.map(a => <span key={a.id} className="px-2.5 py-1 rounded-lg text-[12px] font-semibold bg-olive-light text-olive">{a.codigo}</span>)
          : <span className="text-sm text-ink-soft">Todas las aulas están ocupadas</span>}
      </div>
    </div>
  );
}

export default function Consultas({ tramos }) {
  const [sel, setSel] = useState(null);
  const { datos, error, cargando } = useApi(() => api.horario(sel.tipo, sel.id), [sel && sel.tipo + sel.id], { activo: !!sel });
  return (
    <section className="fade-in space-y-4">
      <div>
        <h1 className="font-display font-bold text-2xl tracking-tight mb-1">Consultas</h1>
        <p className="text-sm text-ink-soft">Horario de cualquier profesor/a, grupo o aula.</p>
      </div>
      <BuscadorGlobal onElegir={r => setSel(r)} />
      {!sel && <AulasLibres tramos={tramos} />}
      {sel && cargando && <div className="card p-8 text-center text-ink-soft">Cargando…</div>}
      {sel && error && <div className="card p-6 text-center text-terracotta font-semibold">{error.message}</div>}
      {sel && datos && tramos && <VistaHorario horario={datos} tramos={tramos} mostrar={sel.tipo} />}
    </section>
  );
}
