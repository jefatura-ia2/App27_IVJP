/** Guardias: estado en tiempo real (ahora) o el día completo de la semana en curso */
import { useState } from 'react';
import { DIAS, MESES, semana, diaHoy } from '../lib/horario.js';
import EstadoGuardias from '../components/EstadoGuardias.jsx';

export default function Guardias() {
  const sem = semana();
  const [fecha, setFecha] = useState(null); // null = ahora
  const hoy = diaHoy();
  return (
    <section className="fade-in">
      <h1 className="font-display font-bold text-2xl tracking-tight mb-1">Guardias</h1>
      <p className="text-sm text-ink-soft mb-4">Semana del {sem[0].num} al {sem[4].num} de {MESES[sem[4].mes]}</p>
      <div className="flex flex-wrap gap-2 mb-5 no-print" role="tablist">
        {hoy && <button role="tab" aria-selected={fecha === null} onClick={() => setFecha(null)} className={`chip ${fecha === null ? 'chip-on' : ''}`}>Ahora</button>}
        {sem.map(d => (
          <button key={d.iso} role="tab" aria-selected={fecha === d.iso} onClick={() => setFecha(d.iso)} className={`chip text-center !px-4 ${fecha === d.iso ? 'chip-on' : ''}`}>
            <span className="block text-[11px] opacity-80">{DIAS[d.dia - 1]}</span><span className="block font-bold leading-none">{d.num}</span>
          </button>
        ))}
      </div>
      <EstadoGuardias key={fecha || 'ahora'} fecha={hoy ? fecha : (fecha || sem[0].iso)} />
    </section>
  );
}
