/** Mi horario: el profesor/a elige su nombre una vez (se recuerda en el dispositivo) */
import { api } from '../lib/api.js';
import { useApi, useLocal } from '../hooks/useApi.js';
import BuscadorGlobal from '../components/BuscadorGlobal.jsx';
import VistaHorario from '../components/VistaHorario.jsx';

export default function MiHorario({ tramos }) {
  const [yo, setYo] = useLocal('ivj_mi_profesor', null);
  const { datos, error, cargando } = useApi(() => api.horario('profesor', yo.id), [yo && yo.id], { activo: !!yo });

  if (!yo) return (
    <section className="max-w-xl mx-auto fade-in">
      <h1 className="font-display font-bold text-2xl tracking-tight mb-1">Mi horario</h1>
      <p className="text-sm text-ink-soft mb-5">Escribe tu nombre o apellido. Lo recordaremos en este dispositivo.</p>
      <BuscadorGlobal tipos={['profesor']} placeholder="Tu nombre o apellido…" onElegir={r => setYo({ id: r.id, nombre: r.nombre })} autoFocus />
    </section>
  );
  return (
    <section className="fade-in">
      <div className="flex items-end justify-between gap-3 mb-4">
        <h1 className="font-display font-bold text-2xl tracking-tight">Mi horario</h1>
        <button className="text-xs font-semibold text-ink-soft underline underline-offset-2 no-print" onClick={() => setYo(null)}>No soy {yo.nombre.split(', ')[1] || yo.nombre}</button>
      </div>
      {cargando && <div className="card p-8 text-center text-ink-soft">Cargando tu horario…</div>}
      {error && <div className="card p-6 text-center text-terracotta font-semibold">{error.message}</div>}
      {datos && tramos && <VistaHorario horario={datos} tramos={tramos} mostrar="profesor" />}
    </section>
  );
}
