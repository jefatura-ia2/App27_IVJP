/** Paleta y tipografía comunes a todas las apps de Jefatura de Estudios */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#1a2332', 'ink-soft': '#3d4a5c', paper: '#FBFBFA', 'paper-warm': '#F5F3EE',
        olive: '#5c6b4f', 'olive-light': '#e8ebe3', terracotta: '#a85a3f', 'terracotta-light': '#f5ebe6',
        'ink-blue': '#2d4a6b', 'ink-blue-light': '#e4ecf4', divider: '#e5e2db',
        primary: '#6366f1', 'primary-dark': '#4f46e5', alerta: '#be123c',
      },
      fontFamily: { display: ['Montserrat', 'system-ui', 'sans-serif'], body: ['Montserrat', 'system-ui', 'sans-serif'] },
    },
  },
  plugins: [],
};
