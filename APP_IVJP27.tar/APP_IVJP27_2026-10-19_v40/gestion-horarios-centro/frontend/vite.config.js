import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

/* En desarrollo, /api se redirige al backend (npm run dev en ../backend) */
export default defineConfig({
  /* rutas relativas: el mismo compilado funciona en la raíz (https://servidor/), en una
     subcarpeta de Apache (https://servidor/horarios/) y dentro de la app de móvil */
  base: './',
  plugins: [react()],
  server: { port: 5173, proxy: { '/api': process.env.API_PROXY || 'http://localhost:3000' } },
  preview: { port: 4173, proxy: { '/api': process.env.API_PROXY || 'http://localhost:3000' } },
  build: { outDir: 'dist', sourcemap: false },
});
