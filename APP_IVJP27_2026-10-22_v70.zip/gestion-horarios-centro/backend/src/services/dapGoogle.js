/**
 * Módulo DAP → calendario de Google «Asuntos propios (DAP)» (el que está enlazado en Calendarios).
 *  · Al conceder un DAP se crea en ese calendario un evento de día completo «DAP · Nombre Apellidos».
 *  · Al revocarlo (o si deja de estar concedido) se borra el evento.
 *  · La escritura la hace el script de Google de la hoja «Ausencias 2026-27» (acción «dap_calendario», v9),
 *    autenticado con la contraseña de administración, porque el enlace .ics del calendario es solo de lectura.
 *  · Lo que no se pudo escribir (sin conexión, script sin actualizar…) se reintenta cada 15 minutos.
 *  · El evento lleva en la descripción la marca [app-dap:<id>]: al leer el calendario (dapService) esos eventos
 *    se reconocen como del módulo y no se duplican como ausencias.
 */
import { query } from '../db.js';
import { config } from '../config.js';
import { leerCalendarios } from './servicioService.js';
import { leerCalendario } from './extraescolaresService.js';

export const MARCA = /\[app-dap:(\d+)\]/;
export const marca = id => `[app-dap:${id}]`;
const natural = n => { const [a, b] = String(n).split(',').map(s => (s || '').trim()); return b ? b + ' ' + a : a; };

/** Identificador del calendario de Google a partir del enlace guardado en Calendarios */
export function calIdDe(url) {
  const u = String(url || '').trim();
  if (!u) return '';
  const m = u.match(/\/calendar\/ical\/([^/]+)\//);
  if (m) return decodeURIComponent(m[1]);
  try {
    const x = new URL(u.replace(/^webcal:/i, 'https:'));
    const id = x.searchParams.get('src') || x.searchParams.get('cid');
    if (id) {
      const d = decodeURIComponent(id);
      if (d.includes('@')) return d;
      try { const b = Buffer.from(d, 'base64').toString('utf8'); if (b.includes('@')) return b; } catch { /* no es base64 */ }
      return d;
    }
  } catch { /* no es una URL */ }
  return /@/.test(u) && !/\s/.test(u) ? u : '';
}

let fetchPorDefecto = (...a) => fetch(...a);
export const _usarFetch = f => { fetchPorDefecto = f || ((...a) => fetch(...a)); };   /* pruebas */

async function llamar(cuerpo, fetchImpl) { return llamarAccion('dap_calendario', cuerpo, fetchImpl); }
async function llamarAccion(accion, cuerpo, fetchImpl) {
  if (!config.sheetsServiceUrl || !config.googleClave) throw new Error('falta el servicio de Google de la hoja (SHEETS_SERVICE_URL)');
  const r = await fetchImpl(config.sheetsServiceUrl, { method: 'POST', redirect: 'follow', signal: AbortSignal.timeout(30000),
    headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify({ accion, clave: config.googleClave, ...cuerpo }) });
  let j; try { j = await r.json(); } catch { throw new Error('el servicio de Google no respondió bien'); }
  if (j && j.error === 'Acción no válida') throw new Error('hay que actualizar el script de Google a la versión 10 (deploy/google/Codigo_horarios_v10.gs)');
  if (!j || !j.ok) throw new Error((j && j.error) || 'error del servicio de Google');
  return j;
}

/** Deja el calendario de Google como corresponde a la solicitud (crear o borrar su evento). Nunca lanza. */
export async function publicar(id, fetchImpl = fetchPorDefecto) {
  const { rows: [s] } = await query(`SELECT id, profesor, to_char(fecha,'YYYY-MM-DD') AS fecha, estado, gcal_id, fuerza_mayor FROM dap_solicitud WHERE id = $1`, [id]);
  if (!s) return { ok: false };
  const quiere = s.estado === 'concedida';
  if (quiere === !!s.gcal_id) { await query(`UPDATE dap_solicitud SET gcal_error = '' WHERE id = $1 AND gcal_error <> ''`, [id]); return { ok: true }; }
  const calId = calIdDe(((await leerCalendarios()).dap || {}).url);
  try {
    if (!calId) throw new Error('falta el enlace del calendario «Asuntos propios (DAP)» en Calendarios');
    const ref = 'DAP-' + String(s.id).padStart(4, '0');
    if (quiere) {
      const j = await llamar({ op: 'crear', calId, fecha: s.fecha, ref, titulo: 'DAP · ' + natural(s.profesor),
        descripcion: `${marca(s.id)} Día de asuntos particulares concedido por la Dirección en la App (registro ${ref}${s.fuerza_mayor ? ', fuerza mayor' : ''}). No lo borres aquí: para revocarlo usa el módulo DAP.` }, fetchImpl);
      await query(`UPDATE dap_solicitud SET gcal_id = $2, gcal_error = '' WHERE id = $1`, [id, j.eventId || ref]);
    } else {
      await llamar({ op: 'borrar', calId, fecha: s.fecha, ref, eventId: s.gcal_id }, fetchImpl);
      await query(`UPDATE dap_solicitud SET gcal_id = '', gcal_error = '' WHERE id = $1`, [id]);
    }
    return { ok: true };
  } catch (e) {
    await query(`UPDATE dap_solicitud SET gcal_error = $2 WHERE id = $1`, [id, String(e.message || e).slice(0, 300)]);
    return { ok: false, error: e.message };
  }
}

/** Reintenta todo lo pendiente (concedidos sin evento y eventos de DAP que ya no están concedidos) */
export async function reintentar(fetchImpl = fetchPorDefecto) {
  const { rows } = await query(`SELECT id FROM dap_solicitud WHERE ((estado = 'concedida' AND gcal_id = '') OR (estado <> 'concedida' AND gcal_id <> ''))
    AND fecha >= CURRENT_DATE - 30 ORDER BY id`);
  let ok = 0, fallos = 0, error = '';
  for (const r of rows) { const x = await publicar(r.id, fetchImpl); if (x.ok) ok++; else { fallos++; error = x.error; } }
  return { pendientes: rows.length, ok, fallos, error };
}

/**
 * Eventos del calendario «Asuntos propios (DAP)» entre dos fechas.
 * Primero por su dirección pública (.ics); si el calendario no es público (en Calendarios se ve igual porque
 * quien lo abre tiene acceso en Google), se leen a través del script de Google (acción «dap_leer», v9).
 */
const cacheScript = new Map();
export async function leerEventos(desde, hasta, { fetchIcs, forzar = false } = {}) {
  const ics = await leerCalendario('dap', desde, hasta, fetchIcs || fetchPorDefecto, { forzar });
  if (!ics.configurado) return { eventos: [], configurado: false, fuente: '', error: ics.error || '' };
  if (!ics.error) return { eventos: ics.eventos, configurado: true, fuente: 'ics', error: '' };
  const calId = calIdDe(((await leerCalendarios()).dap || {}).url);
  const k = calId + '|' + desde + '|' + hasta;
  const c = cacheScript.get(k);
  if (!forzar && c && Date.now() - c.t < 5 * 60 * 1000) return c.r;
  let r;
  try {
    if (!calId) throw new Error('el enlace no identifica el calendario');
    const j = await llamarAccion('dap_leer', { calId, desde, hasta }, fetchPorDefecto);
    r = { eventos: (j.eventos || []).filter(e => e && e.inicio), configurado: true, fuente: 'script', error: '' };
  } catch (e) {
    r = { eventos: ics.eventos || [], configurado: true, fuente: 'ics', error: ics.error + ' · tampoco a través del script de Google (' + e.message + ')' };
  }
  cacheScript.set(k, { t: Date.now(), r });
  return r;
}
export const _vaciarCache = () => cacheScript.clear();


/**
 * Diagnóstico de la escritura en el calendario de Google, paso a paso (para Dirección, Administración y Jefatura):
 * servicio configurado → responde y versión → clave aceptada → calendario identificado → lectura → escritura de prueba.
 */
export async function diagnostico(fetchImpl = fetchPorDefecto) {
  const pasos = [];
  const paso = (titulo, ok, detalle, ayuda = '') => { pasos.push({ titulo, ok, detalle, ayuda }); return ok; };
  const url = config.sheetsServiceUrl;
  if (!paso('Servicio de Google configurado', !!url && !!config.googleClave,
    url ? 'Dirección del script: …' + url.slice(-40) : 'Falta SHEETS_SERVICE_URL',
    'Revisa SHEETS_SERVICE_URL y GOOGLE_CLAVE (o ADMIN_PASSWORD) en el .env del servidor.')) return { pasos };
  /* 1. responde y qué versión tiene */
  let ping = null;
  try {
    const r = await fetchImpl(url + (url.includes('?') ? '&' : '?') + 'accion=ping', { redirect: 'follow', signal: AbortSignal.timeout(30000) });
    const txt = await r.text();
    try { ping = JSON.parse(txt); } catch { ping = { html: /<html/i.test(txt) }; }
  } catch (e) { ping = { red: e.message }; }
  const version = ping && ping.version || '';
  const nv = Number((version.match(/v(\d+)/) || [])[1] || 0);
  if (!paso('El script de Google responde', !!(ping && ping.ok),
    ping && ping.ok ? 'Versión del script: ' + (version || 'desconocida') : ping && ping.html ? 'Google devuelve una página de inicio de sesión, no datos'
      : 'Sin respuesta: ' + (ping && ping.red || 'respuesta no válida'),
    ping && ping.html ? 'En Apps Script: Implementar → Gestionar implementaciones → ✎ → «Ejecutar como: Yo» y «Quién tiene acceso: Cualquier usuario».'
      : 'Comprueba que SHEETS_SERVICE_URL es la URL /exec de la implementación del script.')) return { pasos };
  if (!paso('Versión 10 del script publicada', nv >= 10, 'La URL que usa la app tiene publicada la ' + (version || 'versión antigua'),
    'Pega Codigo_horarios_v10.gs, ejecuta autorizarPermisos() y publica una NUEVA VERSIÓN en la MISMA implementación (Gestionar implementaciones → ✎). ' +
    'Si creaste una implementación nueva, su URL es distinta: o pon esa URL en SHEETS_SERVICE_URL, o publica la versión en la implementación antigua.')) {
    /* se sigue: puede que la v9 funcione igualmente */
  }
  /* 2. clave */
  try {
    const r = await fetchImpl(url, { method: 'POST', redirect: 'follow', signal: AbortSignal.timeout(30000), headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ accion: 'login', clave: config.googleClave }) });
    const j = await r.json();
    if (!paso('La clave de la app es válida en el script', !!(j && j.ok), j && j.ok ? 'Aceptada' : 'El script rechaza la clave',
      'La línea CLAVES_ADMIN del script debe tener la misma clave que GOOGLE_CLAVE (o ADMIN_PASSWORD) del servidor.')) return { pasos };
  } catch (e) { paso('La clave de la app es válida en el script', false, e.message); return { pasos }; }
  /* 3. calendario */
  const enlace = ((await leerCalendarios()).dap || {}).url || '';
  const calId = calIdDe(enlace);
  if (!paso('Calendario «Asuntos propios (DAP)» identificado', !!calId, calId ? 'ID: ' + calId : 'El enlace guardado no identifica el calendario: ' + (enlace || '(vacío)'),
    'En Calendarios, el enlace de «Asuntos propios (DAP)» debe ser la dirección iCal del calendario (…/calendar/ical/<ID>/…/basic.ics).')) return { pasos };
  /* 4. lectura a través del script */
  try {
    const hoy = new Date().toISOString().slice(0, 10);
    const j = await llamarAccion('dap_leer', { calId, desde: hoy, hasta: hoy }, fetchImpl);
    paso('El script puede leer ese calendario', true, 'Eventos de hoy: ' + (j.eventos || []).length);
  } catch (e) {
    paso('El script puede leer ese calendario', false, e.message, 'Comparte el calendario con la cuenta propietaria del script con «Hacer cambios en eventos» y ejecuta autorizarPermisos().');
    return { pasos };
  }
  /* 5. escritura de prueba (2 de enero de 2030, se borra al momento) */
  try {
    const ref = 'PRUEBA-APP-' + Date.now();
    await llamar({ op: 'crear', calId, fecha: '2030-01-02', ref, titulo: 'Prueba de la app (se borra sola)', descripcion: 'Prueba de escritura' }, fetchImpl);
    await llamar({ op: 'borrar', calId, fecha: '2030-01-02', ref }, fetchImpl);
    paso('El script puede escribir en el calendario', true, 'Creado y borrado un evento de prueba');
  } catch (e) {
    paso('El script puede escribir en el calendario', false, e.message,
      'La cuenta del script necesita el permiso «Hacer cambios en eventos» en ese calendario (no basta con «Ver todos los detalles»), y haber aceptado el permiso de Google Calendar (autorizarPermisos).');
  }
  return { pasos };
}
