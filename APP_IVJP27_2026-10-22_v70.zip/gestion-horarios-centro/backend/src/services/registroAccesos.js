/**
 * Registro de accesos a datos personales sensibles (RGPD art. 5.2 y 32 · ENS op.exp.8).
 * Se anota quién, qué y cuándo al abrir o descargar partes de disciplina, justificantes, informes y registros
 * de ausencias, el registro de firmas, al abrir el modo administrador y al borrar datos en el cierre de curso.
 * Lo consultan la cuenta de administración y el perfil «Dirección».
 */
import { query } from '../db.js';

const corta = (v, n) => String(v ?? '').slice(0, n);
/** No interrumpe nunca la petición: si falla, solo se avisa en el registro del servidor */
export function registrar(req, accion, objeto = '') {
  const u = (req && req.usuario) || {};
  const ip = corta(req && (req.ip || ''), 60);
  return query('INSERT INTO registro_acceso (usuario, nombre, accion, objeto, ip) VALUES ($1,$2,$3,$4,$5)',
    [corta(u.usuario, 80), corta(u.nombre, 120), corta(accion, 60), corta(objeto, 300), ip])
    .catch(e => console.log('Registro de accesos:', e.message));
}
export const puedeVer = u => !!u && (u.rol === 'admin' || (u.perfiles || []).includes('direccion'));

export const ACCIONES = {
  modo_admin: 'Abre el modo administrador',
  modo_admin_fallido: 'Intento fallido de modo administrador',
  parte_pdf: 'Abre el PDF de un parte de disciplina',
  parte_carpeta: 'Abre un PDF de la carpeta de disciplina',
  partes_bandeja: 'Consulta la bandeja de partes',
  justificante: 'Abre un justificante',
  justificaciones: 'Consulta las justificaciones',
  ausencias_admin: 'Consulta las ausencias con motivo',
  informe_ausencias: 'Genera el informe de ausencias',
  dossier_ausencias: 'Genera el dossier de ausencias',
  firmas_registro: 'Consulta el registro de firmas',
  datos_usuario: 'Cambia los datos de contacto de otra cuenta',
  cierre_curso: 'Borra datos vencidos (cierre de curso)',
  privacidad: 'Cambia los datos de la información de privacidad',
  dap_impreso: 'Imprime el impreso oficial de un DAP',
};

export async function listar(usuario, { desde, hasta, texto, limite = 300 } = {}) {
  if (!puedeVer(usuario)) throw Object.assign(new Error('El registro de accesos es solo para Dirección y administración'), { status: 404 });
  const p = [], w = [];
  if (desde) { p.push(desde); w.push(`cuando >= $${p.length}::date`); }
  if (hasta) { p.push(hasta); w.push(`cuando < ($${p.length}::date + 1)`); }
  if (texto) { p.push('%' + String(texto).toLowerCase() + '%'); w.push(`(lower(usuario) LIKE $${p.length} OR lower(nombre) LIKE $${p.length} OR lower(objeto) LIKE $${p.length} OR accion LIKE $${p.length})`); }
  p.push(Math.min(Number(limite) || 300, 2000));
  const { rows } = await query(`SELECT id, to_char(cuando AT TIME ZONE 'Europe/Madrid','YYYY-MM-DD HH24:MI:SS') AS cuando, usuario, nombre, accion, objeto, ip
    FROM registro_acceso ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY cuando DESC LIMIT $${p.length}`, p);
  return { registros: rows.map(r => ({ ...r, accionTexto: ACCIONES[r.accion] || r.accion })), acciones: ACCIONES };
}
