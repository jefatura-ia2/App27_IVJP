/**
 * App de horarios del IES Valle del Jerte — interfaz original (APP_IVJP_27.html)
 * portada tal cual: misma portada de mosaicos, cabecera, iconos y secciones.
 * Cambios respecto al HTML:
 *   - El horario (CSV) llega del backend (/api/horario.csv) antes de cargar este módulo.
 *   - La Cronología se sirve desde /cronologia.html y sus programaciones van al backend Node.
 * Avisos, calendarios y ausencias se guardan en la base de datos de la app (API /servicio).
 */
/* eslint-disable */
import React, { useState, useMemo, useEffect, useRef } from 'react';
import ReactDOM from 'react-dom';
import MAPA_ZONAS from '../img/zonas-recreo.jpg';   /* va dentro de la app (assets/): se ve igual en el móvil y sin conexión */
import { pedir, cerrarSesion, FormCambioClave, FormMisDatos, API } from '../acceso/Acceso.jsx';
import { CapaRGPD, VisorPrivacidad, verPrivacidad } from '../privacidad/Privacidad.jsx';

const CSV = window.__CSV_HORARIOS__ || '';
/* ============================================================
   CONFIGURACIÓN
   SERVICIO_URL: servicio del servidor de la app que guarda ausencias,
   avisos y enlaces de calendario en su base de datos y los sirve a todos
   los equipos. La contraseña de administrador se comprueba en el servidor.
   ============================================================ */
/* Avisos, calendarios y ausencias: misma interfaz que el antiguo servicio de la hoja de Google,
   ahora resuelta por el servidor de la app con su base de datos */
const SERVICIO_URL=(window.__API_BASE__||"/api").replace(/\/$/,"")+"/servicio";
/* Biblioteca (G.B. y MAY55): misma hoja de Drive y mismo servicio que biblioteca.html */
/* Cronología: si publicas CCP_IVJP_2027.html por separado (p. ej. en la misma carpeta),
   pon aquí su dirección y la pestaña cargará siempre la versión publicada.
   Vacío = se usa la copia integrada en este mismo fichero. */
const CRONOLOGIA_URL=new URL("cronologia.html",location.href).href;  /* servida desde public/ */
const CORREO_JEFATURA="";               /* opcional: botón "enviar por correo" si falla el envío */
/* (sin claves escritas en el código: el modo administrador se abre con la contraseña personal) */
const REMOTO_VACIO={
  pendientes:0,
  avisos:[],
  calendarios:{extra:{nombre:"Actividades extraescolares",url:""},dap:{nombre:"Asuntos propios (DAP)",url:""}},
  ausencias:[]
};

const DIAS=["Lunes","Martes","Miércoles","Jueves","Viernes"];
const DIAS_C=["L","M","X","J","V"];
const MESES=["enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"];
const cap=t=>t.charAt(0).toUpperCase()+t.slice(1);
const HORAS=[
  {n:"1",l:"08:25–09:20"},{n:"2",l:"09:20–10:15"},{n:"R1",l:"10:15–10:30",r:1},
  {n:"3",l:"10:30–11:25"},{n:"4",l:"11:25–12:20"},{n:"R2",l:"12:20–12:35",r:1},
  {n:"5",l:"12:35–13:30"},{n:"6",l:"13:30–14:25"},
  {n:"7",l:"14:25–15:20",t:1},{n:"8",l:"15:20–16:15",t:1},{n:"9",l:"16:15–17:10",t:1},{n:"10",l:"17:10–18:05",t:1},
  {n:"11",l:"18:25–19:20",t:1},{n:"12",l:"19:20–20:15",t:1},{n:"13",l:"20:15–21:10",t:1}
];
const RECREOS=["R1","R2"];
const horaDe=id=>HORAS.filter(h=>h.n===String(id))[0]||{n:String(id),l:""};

const ETIQUETA={docencia:"Docencia",guardia:"Guardia de aula",recreo:"Guardia de recreo",
  tutoria:"Tutoría",jefatura:"Jefatura",comision:"Comisión / Coordinación",reunion:"Reunión",
  biblioteca:"Atención a biblioteca",otro:"Otras actividades"};

function classify(t){
  const k=(t||"").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"");
  if(k.includes("recreo"))return"recreo";
  if(k.includes("guardia"))return"guardia";
  if(k.includes("biblioteca"))return"biblioteca";
  if(k.includes("jefatura"))return"jefatura";
  if(k.indexOf("tut")===0||k.includes("tutoria"))return"tutoria";
  if(k.includes("reunion"))return"reunion";
  if(k.includes("comision")||k.includes("coordinacion")||k.includes("participacion"))return"comision";
  if(k.indexOf("otras")===0)return"otro";
  return"docencia";
}

function parseCSV(c){
  const filas=[];let campo="",fila=[],q=false;
  for(let i=0;i<c.length;i++){
    const ch=c[i];
    if(ch==='"'){q=!q;}
    else if(ch===","&&!q){fila.push(campo);campo="";}
    else if((ch==="\n"||ch==="\r")&&!q){
      if(campo!==""||fila.length){fila.push(campo);filas.push(fila);fila=[];campo="";}
    }else campo+=ch;
  }
  if(campo!==""||fila.length){fila.push(campo);filas.push(fila);}
  return filas.map(p=>{
    p=p.map(s=>s.trim());
    const slot=(p[2]||"").toUpperCase();
    return{profesor:p[0]||"",dia:+p[1]||0,slot:slot,materia:p[3]||"",grupo:p[4]||"",aula:p[5]||"",tipo:p[6]||"",cat:classify(p[6]||"")};
  }).filter(r=>r.profesor&&r.dia>=1&&r.dia<=5&&HORAS.some(h=>h.n===r.slot));
}
const ENTRADAS=parseCSV(CSV);

/* ---------- Edición del horario desde la app (administración) ----------
   Los cambios se guardan en el servidor (backend Node) y el horario en memoria
   se sustituye al momento, sin recargar la página ni perder la sesión. */
const API_BASE=(window.__API_BASE__||"/api").replace(/\/$/,"");
function aplicarHorario(texto){
  ENTRADAS.splice(0,ENTRADAS.length,...parseCSV(texto));
  Object.keys(PROF_NORM).forEach(k=>{delete PROF_NORM[k];});
  ENTRADAS.forEach(e=>{PROF_NORM[quitarTildes(e.profesor).replace(/\s+/g," ").trim()]=e.profesor;});
  try{localStorage.setItem("vj_horario_csv",texto);}catch(e){}
}
const Horario={
  async enviar(ruta,cuerpo){
    let r;
    try{r=await fetch(API_BASE+ruta,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(cuerpo)});}
    catch(e){throw new Error("No se pudo conectar con el servidor de horarios");}
    const d=await r.json().catch(()=>({}));
    if(!r.ok||!d.ok)throw new Error(d.error||"No se pudo guardar el cambio");
    if(d.csv)aplicarHorario(d.csv);
    return d;
  },
  cambiar:(clave,antes,despues)=>Horario.enviar("/sesiones/cambiar",{clave,antes,despues}),
  importar:(clave,csv)=>Horario.enviar("/horario/importar",{clave,csv})
};
/* Guardia de recreo en biblioteca: se marca en «Guardias de recreo» y se ve en «Biblioteca».
   Asignación semanal fija: [{dia:1-5, tramo:"R1"|"R2", profesor}] guardada en el servidor. */
const RB_KEY="vj_recreo_biblio";
const RecreoBiblio={
  async leer(){
    try{const r=await fetch(API_BASE+"/biblioteca/recreos",{cache:"no-store"});const d=await r.json();
      if(d.ok&&Array.isArray(d.recreos)){LS.set(RB_KEY,d.recreos);return d.recreos;}}catch(e){}
    return LS.get(RB_KEY,[]);
  },
  async marcar(clave,dia,tramo,profesor,marcado){
    let r;
    try{r=await fetch(API_BASE+"/biblioteca/recreos",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({clave,dia,tramo,profesor,marcado})});}
    catch(e){throw new Error("No se pudo conectar con el servidor de horarios");}
    const d=await r.json().catch(()=>({}));
    if(!r.ok||!d.ok)throw new Error(d.error||"No se pudo guardar");
    LS.set(RB_KEY,d.recreos);return d.recreos;
  }
};
/* Zonas de vigilancia del recreo (vista de satélite en src/img/zonas-recreo.jpg) */
const ZONAS_REC=[
  {k:"zona1",l:"Zona 1",c:"#eab308",f:"#fef9c3",t:"#713f12",s:"Puerta de acceso y entrada principal",d:"Supervisar la puerta de acceso a las instalaciones y la zona frontal de la entrada principal."},
  {k:"zona2",l:"Zona 2",c:"#14b8a6",f:"#ccfbf1",t:"#134e4a",s:"Porche interior y aledaños",d:"Supervisar la zona del porche interior y sus aledaños.",aviso:"Está prohibido que los alumnos accedan a la zona de los pinos, detrás de los contenedores."},
  {k:"zona3",l:"Zona 3",c:"#ef4444",f:"#fee2e2",t:"#7f1d1d",s:"Acceso a las pistas y actividades",d:"Supervisar la zona de acceso a las pistas y las actividades que se realicen en ellas."},
  {k:"biblioteca",l:"Biblioteca",c:"#7c4a1d",f:"#f3e8dc",t:"#4a2c0f",s:"Atención a la biblioteca",d:"Atender la biblioteca durante el recreo."}
];
const zonaDe=k=>ZONAS_REC.find(z=>z.k===k);
async function apuntarZona(dia,tramo,profesor,zona){
  const d=await pedir("POST","/recreo/zona",{dia,tramo,profesor,zona:zona||""});
  LS.set(RB_KEY,d.recreos);return d.recreos;
}
function useRecreoBiblio(){
  const[l,setL]=useState(()=>LS.get(RB_KEY,[]));
  useEffect(()=>{let vivo=true;RecreoBiblio.leer().then(x=>{if(vivo)setL(x);});return()=>{vivo=false;};},[]);
  return[l,setL];
}
const TIPOS_BASE=["Docencia","Guardia de Aula","Guardia de Recreo","Atención a Biblioteca","Tutoría","Jefatura de Departamentos","Reuniones de Departamentos","Comisión / Coordinación","Otras actividades"];
const sesionDe=c=>({profesor:c.profesor,dia:c.dia,slot:String(c.slot),materia:c.materia||"",aula:c.aula||"",tipo:c.tipo||"",grupos:(c.grupos||[]).slice()});
const SIN_HORARIO=[]; /* nombres sin horario cargado (ahora ninguno) */

/* ---------- utilidades ---------- */
const LS={
  get(k,d){try{const v=localStorage.getItem(k);return v?JSON.parse(v):d;}catch(e){return d;}},
  set(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}}
};
const pad=n=>String(n).padStart(2,"0");
const isoDe=d=>d.getFullYear()+"-"+pad(d.getMonth()+1)+"-"+pad(d.getDate());
const hoyISO=()=>isoDe(new Date());
const diaHoy=()=>{const d=new Date().getDay();return d>=1&&d<=5?d:1;};
const diaSemanaDe=iso=>new Date(iso+"T12:00:00").getDay();
const fmtCorta=iso=>iso?new Date(iso+"T12:00:00").toLocaleDateString("es-ES",{weekday:"short",day:"numeric",month:"short"}):"";
const fmtLarga=iso=>iso?new Date(iso+"T12:00:00").toLocaleDateString("es-ES",{weekday:"long",day:"numeric",month:"long"}):"";
const quitarTildes=s=>(s||"").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"");
const labelHora=h=>h==="R1"?"Recreo 1":h==="R2"?"Recreo 2":h+"ª";
const corto=n=>{const p=(n||"").split(", ");return p.length>1&&p[1]?p[0]+", "+p[1].charAt(0)+".":n;};
const nuevoId=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,6);
const esSlot=(e,hn)=>String(e.slot)===String(hn);
const unicos=(arr,f)=>[...new Set(arr.map(f).filter(Boolean))];

function semanaActual(){
  const d=new Date();const wd=d.getDay();
  if(wd===6)d.setDate(d.getDate()+2);else if(wd===0)d.setDate(d.getDate()+1);else d.setDate(d.getDate()-(wd-1));
  return[1,2,3,4,5].map(n=>{const x=new Date(d);x.setDate(d.getDate()+n-1);return{dia:n,iso:isoDe(x),num:x.getDate(),mes:x.getMonth()};});
}

/* ---------- servicio de Drive (Google Apps Script) ---------- */
const seguro=u=>/^https?:\/\//i.test(u||"");
/* Acepta un enlace o el código de incrustación completo (<iframe src="…">) y devuelve solo la URL */
const esIframe=t=>/<iframe/i.test(t||"");
const extraerUrl=t=>{
  t=(t||"").trim();
  if(esIframe(t)){const m=t.match(/\ssrc\s*=\s*(?:"([^"]*)"|'([^']*)')/i);t=m?(m[1]||m[2]||""):"";}
  return t.replace(/&amp;/gi,"&").trim();
};
const Servicio={
  async get(){
    const r=await fetch(SERVICIO_URL+"?accion=datos&t="+Date.now(),{credentials:"include",cache:"no-store"});
    if(!r.ok)throw new Error("http "+r.status);return r.json();
  },
  async post(cuerpo){
    const r=await fetch(SERVICIO_URL,{method:"POST",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify(cuerpo)});
    if(!r.ok)throw new Error("http "+r.status);return r.json();
  }
};

/* ============================================================
   ICONOS · duotono, blancos sobre baldosa de color
   ============================================================ */
const ICO={
  prof:<g><circle cx="12" cy="8" r="3.6" fill="currentColor" fillOpacity=".35"/><path d="M4.5 20.5c0-4 3.4-6.3 7.5-6.3s7.5 2.3 7.5 6.3" fill="currentColor" fillOpacity=".2"/></g>,
  grupos:<g><circle cx="12" cy="8" r="3" fill="currentColor" fillOpacity=".35"/><circle cx="5.2" cy="10" r="2.3" fill="currentColor" fillOpacity=".25"/><circle cx="18.8" cy="10" r="2.3" fill="currentColor" fillOpacity=".25"/><path d="M6.4 19.5c0-3.2 2.4-5 5.6-5s5.6 1.8 5.6 5" fill="currentColor" fillOpacity=".2"/><path d="M1.8 18c0-2.2 1.5-3.6 3.6-3.9M22.2 18c0-2.2-1.5-3.6-3.6-3.9"/></g>,
  aula:<g><rect x="6" y="3.5" width="12" height="17.5" rx="1.2" fill="currentColor" fillOpacity=".25"/><path d="M3 21h18"/><circle cx="15" cy="12.6" r=".9" fill="currentColor"/></g>,
  escudo:<g><path d="M12 2.8 19.5 5.6v5.6c0 4.6-3.2 8.2-7.5 9.9-4.3-1.7-7.5-5.3-7.5-9.9V5.6Z" fill="currentColor" fillOpacity=".25"/><path d="m8.6 12 2.4 2.4 4.4-4.6"/></g>,
  campana:<g><path d="M6 16.5v-5a6 6 0 0 1 12 0v5l1.6 2H4.4Z" fill="currentColor" fillOpacity=".25"/><path d="M10 21a2 2 0 0 0 4 0M12 3.2V2"/></g>,
  calendario:<g><rect x="3.5" y="5" width="17" height="15.5" rx="2.2" fill="currentColor" fillOpacity=".22"/><path d="M3.5 10h17M8 3v4M16 3v4"/><circle cx="8.5" cy="14" r=".8" fill="currentColor"/><circle cx="12" cy="14" r=".8" fill="currentColor"/><circle cx="15.5" cy="14" r=".8" fill="currentColor"/><circle cx="8.5" cy="17.2" r=".8" fill="currentColor"/><circle cx="12" cy="17.2" r=".8" fill="currentColor"/></g>,
  crono:<g><path d="M6 3.5v17" /><circle cx="6" cy="6.5" r="2.2" fill="currentColor" fillOpacity=".35"/><circle cx="6" cy="12" r="2.2" fill="currentColor" fillOpacity=".35"/><circle cx="6" cy="17.5" r="2.2" fill="currentColor" fillOpacity=".35"/><rect x="10.5" y="4.6" width="10" height="3.8" rx="1.2" fill="currentColor" fillOpacity=".25"/><rect x="10.5" y="10.1" width="7.5" height="3.8" rx="1.2" fill="currentColor" fillOpacity=".25"/><rect x="10.5" y="15.6" width="9" height="3.8" rx="1.2" fill="currentColor" fillOpacity=".25"/></g>,
  ausencia:<g><circle cx="9.5" cy="8" r="3.4" fill="currentColor" fillOpacity=".35"/><path d="M2.8 20c0-3.7 3-5.8 6.7-5.8 1.4 0 2.7.3 3.8.9" fill="currentColor" fillOpacity=".2"/><path d="M15.5 17.5h6"/></g>,
  presenta:<g><rect x="3" y="4" width="18" height="12" rx="1.6" fill="currentColor" fillOpacity=".25"/><path d="M12 16v3.5M8 20.5h8"/><path d="M7 12.5l3-3 2.5 2 4-4"/></g>,
  libre:<g><circle cx="12" cy="12" r="8.5" fill="currentColor" fillOpacity=".22"/><path d="M8.2 12.3l2.6 2.6 5-5.3"/></g>,
  reservada:<g><rect x="3.5" y="5" width="17" height="15.5" rx="2.2" fill="currentColor" fillOpacity=".22"/><path d="M3.5 10h17M8 3v4M16 3v4"/><circle cx="12" cy="14.2" r="1.6" fill="currentColor"/><path d="M9.3 18.6c.5-1.3 1.5-2 2.7-2s2.2.7 2.7 2"/></g>,
  prohibida:<g><circle cx="12" cy="12" r="8.5" fill="currentColor" fillOpacity=".22"/><path d="M6 6l12 12"/></g>,
  infolab:<g><rect x="3" y="4.5" width="18" height="11.5" rx="1.6" fill="currentColor" fillOpacity=".25"/><path d="M9 20h6M12 16v4"/><path d="M8.5 8.6l-2 1.7 2 1.7M15.5 8.6l2 1.7-2 1.7M12.8 8l-1.6 4.6"/></g>,
  sum:<g><path d="M4 9.5l8-5 8 5" /><rect x="5" y="9.5" width="14" height="5" rx="1" fill="currentColor" fillOpacity=".25"/><circle cx="8" cy="18.2" r="1.5" fill="currentColor" fillOpacity=".5"/><circle cx="12" cy="18.2" r="1.5" fill="currentColor" fillOpacity=".5"/><circle cx="16" cy="18.2" r="1.5" fill="currentColor" fillOpacity=".5"/></g>,
  portatil:<g><rect x="5" y="3.5" width="14" height="9" rx="1.2" fill="currentColor" fillOpacity=".25"/><path d="M3 15h18l-1.3 2.5H4.3z" fill="currentColor" fillOpacity=".2"/><circle cx="7" cy="20.3" r="1.2"/><circle cx="17" cy="20.3" r="1.2"/><path d="M8 18.5v.6M16 18.5v.6"/></g>,
  jjee:<g><rect x="3.5" y="7.5" width="17" height="12.5" rx="1.8" fill="currentColor" fillOpacity=".25"/><path d="M9 7.5V5.6c0-.6.5-1.1 1.1-1.1h3.8c.6 0 1.1.5 1.1 1.1v1.9M3.5 12.5h17M11 12.5v1.8h2v-1.8"/></g>,
  megafono:<g><path d="M3.5 10.5v3a1 1 0 0 0 1 1H7l5.5 4V5.5L7 9.5H4.5a1 1 0 0 0-1 1Z" fill="currentColor" fillOpacity=".3"/><path d="M15.8 9.4a3.8 3.8 0 0 1 0 5.2M18.4 6.8a7.5 7.5 0 0 1 0 10.4"/></g>,
  atras:<path d="M15 5l-7 7 7 7"/>,
  candado:<g><rect x="5" y="10.5" width="14" height="10" rx="2.2"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/></g>,
  ajustes:<g><circle cx="12" cy="12" r="3"/><path d="M12 2.8v2.4M12 18.8v2.4M2.8 12h2.4M18.8 12h2.4M5.5 5.5l1.7 1.7M16.8 16.8l1.7 1.7M5.5 18.5l1.7-1.7M16.8 7.2l1.7-1.7"/></g>,
  buscar:<g><circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/></g>,
  mas:<path d="M12 5v14M5 12h14"/>,
  papelera:<g><path d="M4.5 7h15M9.5 7V4.5h5V7M6.5 7l.8 12.5h9.4L17.5 7"/></g>,
  enlace:<g><path d="M10 6H6.5A2 2 0 0 0 4.5 8v9.5a2 2 0 0 0 2 2H16a2 2 0 0 0 2-2V14M14 4.5h5.5V10M19.5 4.5 10.5 13.5"/></g>,
  imprimir:<g><path d="M7 9V3.5h10V9M7 17H4.5v-7a1 1 0 0 1 1-1h13a1 1 0 0 1 1 1v7H17"/><rect x="7" y="14" width="10" height="6.5" rx="1"/></g>,
  check:<path d="m5 12.5 4.5 4.5L19 7.5"/>,
  cerrar:<path d="M6 6l12 12M18 6 6 18"/>,
  libro:<g><path d="M12 6.6C10.4 5.3 8.1 4.8 4.8 5v12.6c3.3-.2 5.6.3 7.2 1.6 1.6-1.3 3.9-1.8 7.2-1.6V5c-3.3-.2-5.6.3-7.2 1.6Z" fill="currentColor" fillOpacity=".25"/><path d="M12 6.6v12.6"/></g>,
  lapiz:<g><path d="M4 20h4L19 9l-4-4L4 16Z"/><path d="m13.5 6.5 4 4"/></g>,
  reloj:<g><circle cx="12" cy="12" r="8.5"/><path d="M12 7v5.2l3.4 2"/></g>,
  llave:<g><circle cx="8" cy="12" r="4" fill="currentColor" fillOpacity=".3"/><path d="M12 12h8.5M17 12v3M20 12v2"/></g>,
  salir:<g><path d="M14 4.5h4.5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1H14M10 8l-4 4 4 4M6 12h10"/></g>,
  descargar:<g><path d="M12 4v11M7 10.5l5 5 5-5M5 19.5h14"/></g>,
  subir:<g><path d="M12 19V8M7 12.5l5-5 5 5M5 4.5h14"/></g>,
  pantalla:<g><rect x="3" y="4.5" width="18" height="12" rx="1.5" fill="currentColor" fillOpacity=".2"/><path d="M8.5 20.5h7M12 16.5v4"/></g>,
  carpeta:<g><path d="M3 6.5A1.5 1.5 0 0 1 4.5 5h4.2l2 2.2h8.8A1.5 1.5 0 0 1 21 8.7v9.8a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 18.5Z" fill="currentColor" fillOpacity=".25"/><path d="M3 10h18"/></g>,
  dap:<g><rect x="3.5" y="5" width="17" height="15.5" rx="2.5" fill="currentColor" fillOpacity=".22"/><path d="M3.5 9.5h17M8 3v4M16 3v4"/><path d="m9 15 2.2 2.2L15.5 13"/></g>,
  disciplina:<g><rect x="5" y="4" width="14" height="17" rx="2" fill="currentColor" fillOpacity=".22"/><path d="M9 4V3h6v1.5H9Z" fill="currentColor" fillOpacity=".4"/><path d="M12 9v5"/><circle cx="12" cy="17" r=".9" fill="currentColor"/></g>,
  video:<g><rect x="2.5" y="5" width="19" height="14" rx="3" fill="currentColor" fillOpacity=".2"/><path d="m10 9 5 3-5 3Z" fill="currentColor"/></g>,
  informe:<g><path d="M6.5 3.5h8l4 4v13h-12Z" fill="currentColor" fillOpacity=".22"/><path d="M14.5 3.5v4h4M9.5 17v-3M12.5 17v-5M15.5 17v-2"/></g>
};
function Ico({n,s,className}){
  const t=s||22;
  return(
    <svg viewBox="0 0 24 24" width={t} height={t} className={className} fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">
      {ICO[n]}
    </svg>
  );
}

/* Mosaicos de la entrada, por grupos y con una forma para cada grupo:
   · hexágonos (panal): consultar horarios y espacios · cuadrados redondeados: el día a día (guardias, ausencias, calendarios)
   · círculos: la vida del centro (cronología, reunión con familias) · triángulo redondeado: avisos importantes */
const TILES=[
  {id:"profesores",l:"Profesores",ico:"prof",g:["#2d4a6b","#5b8ac0"],forma:"hex"},
  {id:"grupos",l:"Grupos",ico:"grupos",g:["#5c6b4f","#95aa78"],forma:"hex"},
  {id:"aulas",l:"Aulas",ico:"aula",g:["#a85a3f","#e08f6c"],forma:"hex"},
  {id:"biblioteca",l:"Biblioteca",ico:"libro",g:["#7c4a1d","#c98a3d"],forma:"hex"},
  {id:"usuarios",l:"Usuarios",ico:"llave",g:["#334155","#64748b"],soloAdmin:1,forma:"hex"},
  {id:"rgpd",l:"Protección de datos",ico:"candado",g:["#334155","#64748b"],forma:"hex"},   /* registro de accesos, privacidad, plazos y cierre de curso (administración; Dirección ve el registro) */
  {id:"permisos",l:"Perfiles y permisos",ico:"escudo",g:["#6d28d9","#a78bfa"],soloAdmin:1,forma:"hex"},   /* mapa de perfiles: iconos y notificaciones de cada perfil */   /* solo cuenta de administración con el modo administrador (candado) activo */
  {id:"guardias",l:"Guardias",ico:"escudo",g:["#d97706","#fbbf24"],forma:"cuadrado"},   /* guardias de aula y de recreo, en pestañas */
  {id:"ausencia",l:"Ausencias",ico:"ausencia",g:["#be123c","#fb7185"],forma:"cuadrado"},   /* notificar y justificar */
  {id:"calendarios",l:"Calendarios",ico:"calendario",g:["#4f46e5","#8b93fb"],forma:"cuadrado"},
  {id:"dap",l:"DAP",ico:"dap",g:["#0e7490","#22d3ee"],forma:"cuadrado"},   /* días de asuntos particulares: solicitud y concesión */
  {id:"ccp",l:"CCP · Consejo Escolar",ico:"grupos",g:["#7c2d12","#ea580c"],forma:"cuadrado"},   /* convocatorias de la Comisión de Coordinación Pedagógica (solo sus miembros) */
  {id:"disciplina",l:"Disciplina",ico:"disciplina",g:["#1d4ed8","#60a5fa"],forma:"cuadrado"},   /* partes de conductas contrarias (Decreto 50/2007) */
  {id:"cronologia",l:"Cronología",ico:"crono",g:["#4f46e5","#818cf8"],forma:"circulo"},
  {id:"avisos",l:"Avisos importantes",ico:"megafono",g:["#6B2D8B","#b062d6"],forma:"triangulo"},
  {id:"familias",l:"Reunión con familias",ico:"presenta",g:["#c2410c","#fb923c"],soloTutor:1,forma:"circulo"}   /* solo tutores/as (y administración), cerca de las reuniones */
];
/* «Actualizar horario» no es un mosaico: se abre con el icono de la barra superior (solo administración) */
const TILE_CARGA={id:"carga",l:"Actualizar horario",ico:"subir",g:["#15803d","#4ade80"]};
const TILE_RECREO={id:"recreos",l:"Guardias",ico:"campana",g:["#0d9488","#34d3be"]};
const tileDe=id=>TILES.filter(t=>t.id===id)[0];

/* ============================================================
   PANTALLA DE ENTRADA · botones hexagonales (panal) con relleno brillante
   ============================================================ */
/* hexágono (vértice arriba) con las esquinas ligeramente redondeadas */
const HEX_PATH=(r,c)=>{
  const P=[0,1,2,3,4,5].map(k=>{const a=Math.PI/180*(60*k-90);return[100+r*Math.cos(a),115+r*Math.sin(a)];});
  const f=(p,q,t)=>[p[0]+(q[0]-p[0])*t,p[1]+(q[1]-p[1])*t],t=c/r,n=x=>x.map(v=>v.toFixed(2)).join(",");
  let d="";
  P.forEach((v,i)=>{const ant=P[(i+5)%6],sig=P[(i+1)%6],e=f(v,ant,t),s2=f(v,sig,t);d+=(i?"L":"M")+n(e)+"Q"+n(v)+" "+n(s2);});
  return d+"Z";
};
/* polígono con las esquinas redondeadas (para el triángulo de Avisos) */
const POLI_PATH=(P,c)=>{
  const f=(p,q,t)=>[p[0]+(q[0]-p[0])*t,p[1]+(q[1]-p[1])*t],n=x=>x.map(v=>v.toFixed(2)).join(",");
  let d="";const L=P.length;
  P.forEach((v,i)=>{const ant=P[(i+L-1)%L],sig=P[(i+1)%L];
    const da=Math.hypot(ant[0]-v[0],ant[1]-v[1]),ds=Math.hypot(sig[0]-v[0],sig[1]-v[1]);
    const e=f(v,ant,c/da),s2=f(v,sig,c/ds);d+=(i?"L":"M")+n(e)+"Q"+n(v)+" "+n(s2);});
  return d+"Z";
};
const FORMA_PATH={
  cuadrado:"M48 10H152Q190 10 190 48V152Q190 190 152 190H48Q10 190 10 152V48Q10 10 48 10Z",
  circulo:"M100 10A90 90 0 1 1 99.99 10Z",
  triangulo:POLI_PATH([[100,12],[192,180],[8,180]],30)
};
/* mosaico con forma de cuadrado redondeado, círculo o triángulo (mismo relleno brillante que los hexágonos) */
function FormaTile({t,badge,onClick}){
  const id="fm-"+t.id,d=FORMA_PATH[t.forma];
  return(
    <button className={"hex forma forma-"+t.forma} onClick={onClick} aria-label={t.l}>
      <svg viewBox="0 0 200 200" className="hex-svg" aria-hidden="true" focusable="false">
        <defs>
          <linearGradient id={id+"-relleno"} x1="0.2" y1="0" x2="0.8" y2="1"><stop offset="0" stopColor={t.g[1]}/><stop offset="1" stopColor={t.g[0]}/></linearGradient>
          <linearGradient id={id+"-brillo"} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#fff" stopOpacity=".7"/><stop offset="1" stopColor="#fff" stopOpacity=".04"/></linearGradient>
          <radialGradient id={id+"-luz"} cx=".5" cy="1" r=".7"><stop offset="0" stopColor="#fff" stopOpacity=".25"/><stop offset="1" stopColor="#fff" stopOpacity="0"/></radialGradient>
          <clipPath id={id+"-clip"}><path d={d}/></clipPath>
        </defs>
        <path d={d} fill={"url(#"+id+"-relleno)"}/>
        <g clipPath={"url(#"+id+"-clip)"}>
          <rect x="0" y="0" width="200" height="200" fill={"url(#"+id+"-luz)"}/>
          <path d="M0 0 H200 V84 C150 102 50 102 0 84 Z" fill={"url(#"+id+"-brillo)"}/>
        </g>
        <path d={d} fill="none" stroke={t.g[0]} strokeWidth="5" strokeLinejoin="round"/>
      </svg>
      <span className="hex-cont">
        <Ico n={t.ico} s={44} className="hex-ico"/>
        <span className="hex-txt">{t.l}</span>
      </span>
      {badge>0&&<span className="hex-badge">{badge}</span>}
    </button>
  );
}
function HexTile({t,abajo,badge,onClick}){
  const id="hx-"+t.id;
  return(
    <button className="hex" onClick={onClick} aria-label={t.l}>
      <svg viewBox="0 0 200 230" className="hex-svg" aria-hidden="true" focusable="false">
        <defs>
          <linearGradient id={id+"-relleno"} x1="0.2" y1="0" x2="0.8" y2="1"><stop offset="0" stopColor={t.g[1]}/><stop offset="1" stopColor={t.g[0]}/></linearGradient>
          <linearGradient id={id+"-brillo"} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#fff" stopOpacity=".7"/><stop offset="1" stopColor="#fff" stopOpacity=".04"/></linearGradient>
          <radialGradient id={id+"-luz"} cx=".5" cy="1" r=".7"><stop offset="0" stopColor="#fff" stopOpacity=".25"/><stop offset="1" stopColor="#fff" stopOpacity="0"/></radialGradient>
          <clipPath id={id+"-clip"}><path d={HEX_PATH(92,9)}/></clipPath>
        </defs>
        {abajo
          ?<circle cx="100" cy="219" r="6" fill="#fff" stroke={t.g[0]} strokeWidth="3.5"/>
          :<circle cx="100" cy="11" r="6" fill="#fff" stroke={t.g[0]} strokeWidth="3.5"/>}
        <path d={HEX_PATH(92,9)} fill={"url(#"+id+"-relleno)"}/>
        <g clipPath={"url(#"+id+"-clip)"}>
          <rect x="0" y="0" width="200" height="230" fill={"url(#"+id+"-luz)"}/>
          <path d="M0 0 H200 V96 C150 116 50 116 0 96 Z" fill={"url(#"+id+"-brillo)"}/>
        </g>
        <path d={HEX_PATH(92,9)} fill="none" stroke={t.g[0]} strokeWidth="5" strokeLinejoin="round"/>
      </svg>
      <span className="hex-cont">
        <Ico n={t.ico} s={44} className="hex-ico"/>
        <span className="hex-txt">{t.l}</span>
      </span>
      {badge>0&&<span className="hex-badge">{badge}</span>}
    </button>
  );
}
function useAncho(){
  const[w,setW]=useState(()=>window.innerWidth);
  useEffect(()=>{const f=()=>setW(window.innerWidth);window.addEventListener("resize",f);return()=>window.removeEventListener("resize",f);},[]);
  return w;
}
function Panal({tiles,badgeDe,onPick}){
  const w=useAncho();
  const patron=w<640?[2,3]:[3,4];         /* filas alternas: panal */
  const hex=tiles.filter(t=>!t.forma||t.forma==="hex");
  const filas=[];let i=0,k=0;
  /* 4 hexágonos: en rombo (1-2-1); 5: 2-3; si no, filas alternas */
  const reparto=hex.length===4?[1,2,1]:hex.length===5?[2,3]:null;
  if(reparto)reparto.forEach(n=>{filas.push(hex.slice(i,i+n));i+=n;});
  else while(i<hex.length){const n=patron[k%2];filas.push(hex.slice(i,i+n));i+=n;k++;}
  let idx=0;const mitad=Math.ceil(hex.length/2);
  const cuadrados=tiles.filter(t=>t.forma==="cuadrado");
  const centro=tiles.filter(t=>t.forma==="circulo"||t.forma==="triangulo");
  /* el triángulo de Avisos en medio de los círculos */
  const tri=centro.filter(t=>t.forma==="triangulo"),circ=centro.filter(t=>t.forma==="circulo");
  const fila3=circ.length?[circ[0]].concat(tri,circ.slice(1)):tri;
  const Grupo=({titulo,lista})=>lista.length?(
    <div className="mosaico-grupo">
      <div className="mosaico-titulo">{titulo}</div>
      <div className="panal-fila mosaico-fila">{lista.map(t=><FormaTile key={t.id} t={t} badge={badgeDe(t)} onClick={()=>onPick(t.id)}/>)}</div>
    </div>):null;
  return(
    <div className="panal">
      {hex.length>0&&<div className="mosaico-titulo">Horarios y espacios</div>}
      {filas.map((f,r)=>(
        <div key={r} className="panal-fila">
          {f.map(t=>{const j=idx++;return <HexTile key={t.id} t={t} abajo={j<mitad} badge={badgeDe(t)} onClick={()=>onPick(t.id)}/>;})}
        </div>
      ))}
      <Grupo titulo="El día a día" lista={cuadrados}/>
      <Grupo titulo="El centro" lista={fila3}/>
    </div>
  );
}

function TileIcon({t,size}){
  const s=size||72;
  return(
    <span className="inline-flex items-center justify-center text-white flex-shrink-0"
      style={{width:s,height:s,borderRadius:s*0.3,background:"linear-gradient(135deg,"+t.g[0]+","+t.g[1]+")",boxShadow:"0 10px 20px -8px "+t.g[0]+"aa"}}>
      <Ico n={t.ico} s={Math.round(s*0.54)}/>
    </span>
  );
}

function LogoSVG({size}){
  return(
    <svg width={size||64} height={size||64} viewBox="0 0 200 200" className="flex-shrink-0">
      <defs><linearGradient id="logoGrad" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stopColor="#6B2D8B"/><stop offset="100%" stopColor="#522270"/></linearGradient></defs>
            <circle cx="58" cy="52" r="7" fill="url(#logoGrad)"/>
      <path d="M 55 65 Q 80 110 100 140 Q 120 110 175 30 Q 130 95 100 130 Q 85 105 55 65 Z" fill="url(#logoGrad)"/>
      <path d="M 72 78 Q 90 108 100 122 Q 110 108 140 72 Q 118 100 100 118 Q 92 105 72 78 Z" fill="white"/>
      <path d="M 85 92 Q 95 108 100 114 Q 105 108 118 92 Q 108 104 100 112 Q 95 106 85 92 Z" fill="url(#logoGrad)"/>
    </svg>
  );
}

/* ============================================================
   COMPONENTES COMUNES
   ============================================================ */
function Header({admin,onLogin,onLogout,estado,onHome,usuario,onCuenta,onCarga,onTutorial}){
  const E={ok:["Conectado","bg-olive-light text-olive","bg-olive"],busy:["Guardando…","bg-amber-50 text-amber-700","bg-amber-500"],
    error:["Sin conexión","bg-terracotta-light text-terracotta","bg-terracotta"],local:["Modo local","bg-gray-100 text-gray-500","bg-gray-400"],cargando:["Conectando…","bg-gray-100 text-gray-500","bg-gray-400"]};
  const e=E[estado]||E.local;
  return(
    <header className="bg-[#E4CFF0] border-b border-[#CDAEE0] sticky top-0 z-40 no-print">
      <div className="max-w-5xl mx-auto px-3 sm:px-6 py-2 sm:py-3 flex items-center justify-between gap-2 sm:gap-3">
        <button onClick={onHome} className="flex items-center gap-2 sm:gap-3 text-left min-w-0" aria-label="Ir al inicio">
          <div className="bg-white rounded-xl p-1 sm:p-1.5 shrink-0"><LogoSVG size={useAncho()<640?32:42}/></div>
          <div className="leading-tight">
            <div className="font-display font-bold text-[10px] sm:text-sm tracking-[.2em] text-ink-soft">IES</div>
            <div className="font-display font-bold text-base sm:text-[26px] text-ink tracking-tight leading-tight whitespace-nowrap">Valle del Jerte</div>
            <div className="hidden sm:block text-[11px] text-ink-soft font-medium">Horarios · Curso 2026-27</div>
          </div>
        </button>
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {onTutorial&&<button onClick={onTutorial} className="btn btn-ghost !px-2.5 sm:!px-3" title="Videotutorial: aprende a usar la app" aria-label="Ver el videotutorial"><Ico n="video" s={18}/><span className="hidden md:inline text-xs">Tutorial</span></button>}
          {onCarga&&<button onClick={onCarga} className="btn btn-ghost !px-2.5 sm:!px-3" title="Actualizar horario (subir CSV)" aria-label="Actualizar horario"><Ico n="subir" s={18}/></button>}
          {usuario&&<button onClick={onCuenta} className="btn btn-ghost !px-2.5 sm:!px-3" title={"Mi cuenta · "+usuario.usuario} aria-label="Mi cuenta">
            <Ico n="prof" s={18}/><span className="hidden sm:inline text-xs max-w-[11rem] truncate">{(usuario.nombre||"").split(", ")[1]||usuario.nombre||usuario.usuario}</span></button>}
          {admin&&<span className={"hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold "+e[1]}><span className={"w-1.5 h-1.5 rounded-full "+e[2]}></span>{e[0]}</span>}
          {admin
            ?<button onClick={onLogout} className="btn btn-ghost !px-2.5 sm:!px-3 text-xs" title="Salir de administración">Salir<span className="hidden sm:inline">&nbsp;de administración</span></button>
            :<button onClick={onLogin} className="btn btn-ghost !px-2.5 sm:!px-3" title="Acceso administrador" aria-label="Acceso administrador"><Ico n="candado" s={18}/></button>}
        </div>
      </div>
    </header>
  );
}

/* Videotutorial de la app (public/tutorial/videotutorial.mp4) en una ventana */
function ModalTutorial({onClose}){
  useEffect(()=>{const f=e=>{if(e.key==="Escape")onClose();};window.addEventListener("keydown",f);return()=>window.removeEventListener("keydown",f);},[]);
  return(
    <div className="fixed inset-0 z-[60] bg-black/70 flex items-center justify-center p-3 sm:p-6 fade-in" role="dialog" aria-modal="true" aria-label="Videotutorial" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl overflow-hidden" onClick={e=>e.stopPropagation()}>
        <div className="flex items-center gap-3 px-4 py-3 border-b border-divider">
          <span className="w-9 h-9 rounded-lg flex items-center justify-center text-white" style={{background:"#6B2D8B"}}><Ico n="video" s={18}/></span>
          <div className="flex-1 leading-tight"><div className="font-display font-bold text-ink">Videotutorial de la app</div>
            <div className="hidden sm:block text-[11px] text-ink-soft">Mis datos · Profesores y grupos · Aulas · Guardias y recreos · Ausencias · DAP · Disciplina · 7 min</div></div>
          <a className="btn btn-ghost !min-h-[36px] !px-3 text-xs" href="tutorial/videotutorial.mp4" download="Videotutorial_APP_IVJP27.mp4">Descargar</a>
          <button className="btn btn-ghost !min-h-[36px] !px-3" onClick={onClose} aria-label="Cerrar">✕</button>
        </div>
        <video src="tutorial/videotutorial.mp4" poster="tutorial/portada.jpg" controls autoPlay playsInline preload="metadata" className="w-full block bg-black" style={{aspectRatio:"16/9"}}/>
      </div>
    </div>
  );
}

function Seccion({tile,onBack,children}){
  return(
    <div className="fade-in">
      <div className="flex items-center gap-3 mb-6 no-print">
        <button onClick={onBack} aria-label="Volver al inicio" className="w-11 h-11 rounded-xl bg-white border border-divider flex items-center justify-center text-ink-soft hover:text-ink hover:border-ink transition"><Ico n="atras" s={20}/></button>
        <TileIcon t={tile} size={46}/>
        <h2 className="font-display font-bold text-xl sm:text-2xl text-ink tracking-tight">{tile.l}</h2>
      </div>
      {children}
    </div>
  );
}

/* Selector sin precarga: nada se muestra hasta elegir (letra, búsqueda o ficha) */
function Selector({items,tile,onPick,porLetras,pregunta,apagados,marcados,cuenta}){
  const[q,setQ]=useState("");const[l,setL]=useState("");
  const acento=tile.g[0];
  const iniciales=useMemo(()=>porLetras?[...new Set(items.map(i=>quitarTildes(i)[0].toUpperCase()))].sort():[],[items,porLetras]);
  let vis;
  if(q.trim())vis=items.filter(i=>quitarTildes(i).indexOf(quitarTildes(q.trim()))>=0);
  else if(porLetras)vis=l?items.filter(i=>quitarTildes(i)[0].toUpperCase()===l):[];
  else vis=items;
  return(
    <div className="space-y-4 no-print">
      <p className="text-sm text-ink-soft font-medium">{pregunta}</p>
      <div className="relative">
        <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-soft"><Ico n="buscar" s={18}/></span>
        <input className="field !pl-11" value={q} onChange={e=>setQ(e.target.value)} placeholder="Buscar…" aria-label="Buscar"/>
      </div>
      {porLetras&&!q.trim()&&(
        <div className="flex flex-wrap gap-2">
          {iniciales.map(x=>(
            <button key={x} onClick={()=>setL(l===x?"":x)} className={"chip !px-0 w-11 text-center "+(l===x?"on":"")} style={l===x?{background:acento}:{}}>{x}</button>
          ))}
        </div>
      )}
      {vis.length>0&&(
        <div className="flex flex-wrap gap-2 fade-in">
          {vis.map(i=>{const ap=apagados&&apagados.indexOf(i)>=0;const inc=marcados&&marcados[i];return <button key={i} onClick={()=>onPick(i)} className="chip relative" aria-label={inc?i+" · "+inc+" incidencia"+(inc>1?"s":"")+" abierta"+(inc>1?"s":""):undefined} title={inc?inc+" incidencia"+(inc>1?"s":"")+" abierta"+(inc>1?"s":""):ap?"Horario no recibido":""} style={inc?{background:"#dbeafe",borderColor:"#2563eb",color:"#1e3a8a",fontWeight:800}:ap?{borderStyle:"dashed",opacity:.65}:{borderColor:acento+"55"}}>{inc?<span className="absolute -top-1.5 -right-1.5 min-w-[18px] h-[18px] px-1 rounded-full text-[10px] font-bold flex items-center justify-center text-white" style={{background:"#2563eb"}}>{inc}</span>:null}{i}{ap&&" ·"}{cuenta&&cuenta[i]!=null?<span className="ml-1.5 text-[10px] font-bold rounded-full px-1.5 py-0.5 bg-black/5 text-ink-soft" title={cuenta[i]+" alumnos"}>{cuenta[i]} al.</span>:null}</button>;})}
        </div>
      )}
      {q.trim()&&vis.length===0&&<p className="text-sm text-ink-soft py-6 text-center">Sin resultados para «{q}»</p>}
    </div>
  );
}

/* Colores por materia: cada materia de la vista recibe un color distinto
   (mismo criterio en profesores, grupos y aulas; estable según el nombre) */
const HUES=[210,25,130,320,55,265,175,0,95,235,300,195];
function hashStr(t){let h=5381;t=quitarTildes(t);for(let i=0;i<t.length;i++)h=((h<<5)+h+t.charCodeAt(i))>>>0;return h;}
function estiloColor(h,v){
  return v===0
    ?{bg:"hsl("+h+" 78% 92%)",bd:"hsl("+h+" 62% 45%)",tx:"hsl("+h+" 70% 18%)"}
    :{bg:"hsl("+h+" 62% 82%)",bd:"hsl("+h+" 70% 36%)",tx:"hsl("+h+" 75% 14%)"};
}
function coloresMaterias(lista){
  const mats=unicos(lista.filter(e=>e.cat==="docencia"),e=>e.materia).sort((a,b)=>a.localeCompare(b,"es"));
  const usado=[],out={};
  mats.forEach((m,k)=>{
    const nivel=Math.floor(k/HUES.length);
    usado[nivel]=usado[nivel]||new Set();
    let i=hashStr(m)%HUES.length;
    while(usado[nivel].has(i))i=(i+1)%HUES.length;
    usado[nivel].add(i);
    out[m]=estiloColor(HUES[i],nivel%2);
  });
  return out;
}

/* Cuadrícula semanal */
function mergeCells(list){
  const m=new Map();
  list.forEach(e=>{
    const k=[e.dia,e.slot,e.materia,e.aula,e.tipo,e.profesor].join("|");
    if(!m.has(k))m.set(k,{...e,grupos:[],profs:[]});
    const o=m.get(k);
    if(e.grupo&&o.grupos.indexOf(e.grupo)<0)o.grupos.push(e.grupo);
    if(e.profesor&&o.profs.indexOf(e.profesor)<0)o.profs.push(e.profesor);
  });
  return[...m.values()];
}

function Rejilla({lista,mostrar,colores,onEditar}){
  /* en el móvil se ve un día cada vez (con «Semana» para la vista completa desplazable) */
  const movil=useAncho()<640;
  const hoyD=new Date().getDay();
  const[diaM,setDiaM]=useState(hoyD>=1&&hoyD<=5?hoyD:1);
  const unDia=movil&&diaM>0;
  const dias=unDia?[diaM]:[1,2,3,4,5];
  const cols=unDia?"52px minmax(0,1fr)":"52px repeat(5,minmax(0,1fr))";
  const usados=new Set(lista.map(e=>String(e.slot)));
  const col=colores||coloresMaterias(lista);
  const fija={position:"sticky",left:0,zIndex:2,background:"#fff"};
  return(
    <div className="overflow-x-auto">
      {movil&&<div className="flex gap-1 mb-3 no-print" role="tablist" aria-label="Día de la semana">
        {[1,2,3,4,5,0].map(d=><button key={d} role="tab" aria-selected={diaM===d} onClick={()=>setDiaM(d)}
          className={"flex-1 rounded-lg py-1.5 text-xs font-bold border "+(diaM===d?"bg-ink text-white border-ink":"bg-white text-ink-soft border-divider")}>{d?DIAS[d-1].slice(0,3):"Semana"}</button>)}
      </div>}
      <div style={{minWidth:unDia?0:"860px"}}>
        <div className="grid gap-2 mb-2" style={{gridTemplateColumns:cols}}>
          <div style={fija}></div>
          {dias.map(d=><div key={d} className="text-center text-sm font-bold py-1.5 text-ink">{DIAS[d-1]}</div>)}
        </div>
        {HORAS.filter(h=>usados.has(h.n)||(onEditar?!h.t:(!h.r&&!h.t))).map(h=>(
          <div key={h.n} className="grid gap-2 mb-2" style={{gridTemplateColumns:cols}}>
            <div className="text-center pt-2" style={fija}>
              <div className="font-bold text-ink-soft text-sm">{h.r?h.n:h.n+"ª"}</div>
              <div className="text-[9px] leading-tight text-ink-soft/80 font-medium">{h.l}</div>
            </div>
            {dias.map(d=>{
              const celda=mergeCells(lista.filter(e=>e.dia===d&&esSlot(e,h.n)));
              return(
                <div key={d} className="rounded-xl bg-paper-warm/70 border border-divider p-1 flex flex-col gap-1" style={{minHeight:62}}>
                  {celda.length===0&&!onEditar&&<div className="text-[10px] text-ink-soft/30 text-center py-3">—</div>}
                  {celda.map((c,i)=>{
                    const k=c.cat==="docencia"?col[c.materia]:null;
                    return(
                    <div key={i} role={onEditar?"button":undefined} tabIndex={onEditar?0:undefined} title={onEditar?"Cambiar esta sesión":undefined}
                      onClick={onEditar?()=>onEditar(c):undefined} onKeyDown={onEditar?(ev=>{if(ev.key==="Enter")onEditar(c);}):undefined}
                      className={"text-left p-1.5 rounded-lg text-[11px] "+(k?"":"c-"+c.cat)+(onEditar?" relative cursor-pointer hover:ring-2 hover:ring-[#6366f1]":"")} style={k?{background:k.bg,borderLeft:"3px solid "+k.bd,color:k.tx}:undefined}>
                      {onEditar&&<span className="absolute top-1 right-1 opacity-50"><Ico n="lapiz" s={11}/></span>}
                      <div className="font-bold leading-tight">{c.materia||ETIQUETA[c.cat]}</div>
                      {mostrar!=="prof"&&<div className="leading-tight opacity-80 text-[10px] font-medium">{c.profs.map(corto).join(" · ")}</div>}
                      <div className="flex gap-1 flex-wrap mt-0.5">
                        {mostrar!=="grupo"&&c.grupos.map(g=><span key={g} className="px-1 rounded bg-black/5 text-[9px] font-semibold">{g}</span>)}
                        {mostrar!=="aula"&&c.aula&&<span className="px-1 rounded bg-black/5 text-[9px] font-semibold">A{c.aula}</span>}
                      </div>
                    </div>
                    );
                  })}
                  {onEditar&&<button className="bb-add self-center mt-auto" onClick={()=>onEditar(null,d,h.n)} aria-label={"Añadir sesión el "+DIAS[d-1]+" a "+labelHora(h.n)}>+</button>}
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}

/* Formulario para añadir / cambiar / quitar una sesión del horario de un profesor/a */
function FormSesion({inicial,nueva,clave,onClose,onHecho}){
  const[f,setF]=useState(()=>({...inicial,grupos:(inicial.grupos||[]).join(", ")}));
  const[err,setErr]=useState("");const[ocupado,setOcupado]=useState(false);
  const opciones=useMemo(()=>({
    tipos:unicos(TIPOS_BASE.concat(ENTRADAS.map(e=>e.tipo)),t=>t),
    materias:unicos(ENTRADAS,e=>e.materia).sort((a,b)=>a.localeCompare(b,"es")),
    grupos:unicos(ENTRADAS,e=>e.grupo).sort((a,b)=>a.localeCompare(b,"es",{numeric:true})),
    aulas:unicos(ENTRADAS,e=>e.aula).sort((a,b)=>a.localeCompare(b,"es",{numeric:true}))
  }),[]);
  const cambia=(k,v)=>{setF(o=>({...o,[k]:v}));setErr("");};
  const despues=()=>({...f,grupos:String(f.grupos).split(/[,;]/).map(x=>x.trim()).filter(Boolean)});
  const ejecutar=async(antes,desp,msg)=>{
    if(ocupado)return;
    setOcupado(true);setErr("");
    try{await Horario.cambiar(clave,antes,desp);onHecho(msg);}
    catch(e){setErr(e.message);setOcupado(false);}
  };
  const guardar=()=>{
    if(!String(f.tipo).trim()){setErr("Indica el tipo de sesión");return;}
    ejecutar(nueva?null:inicial,despues(),nueva?"Sesión añadida":"Sesión actualizada");
  };
  const quitar=()=>{if(confirm("¿Quitar esta sesión del horario?"))ejecutar(inicial,null,"Sesión eliminada");};
  const cat=classify(f.tipo);
  return(
    <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 no-print" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 fade-in max-h-[92vh] overflow-y-auto" onClick={e=>e.stopPropagation()}>
        <div className="flex items-center gap-3 mb-1">
          <span className="w-10 h-10 rounded-xl bg-paper-warm flex items-center justify-center text-ink-soft"><Ico n="lapiz" s={20}/></span>
          <div>
            <h2 className="font-display font-bold text-lg text-ink leading-tight">{nueva?"Añadir sesión":"Cambiar sesión"}</h2>
            <p className="text-xs text-ink-soft font-medium">{f.profesor}</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3 mt-4">
          <div><label className="lbl">Día</label>
            <select className="field" value={f.dia} onChange={e=>cambia("dia",+e.target.value)}>{DIAS.map((d,i)=><option key={d} value={i+1}>{d}</option>)}</select></div>
          <div><label className="lbl">Hora</label>
            <select className="field" value={f.slot} onChange={e=>cambia("slot",e.target.value)}>{HORAS.map(h=><option key={h.n} value={h.n}>{labelHora(h.n)} · {h.l}</option>)}</select></div>
        </div>
        <label className="lbl mt-3">Tipo</label>
        <input className="field" list="fs-tipos" value={f.tipo} onChange={e=>cambia("tipo",e.target.value)} placeholder="Docencia, Guardia de Aula…"/>
        <div className="flex flex-wrap gap-1.5 mt-2">
          {["Docencia","Guardia de Aula","Guardia de Recreo","Atención a Biblioteca"].map(t=>(
            <button key={t} type="button" className={"chip !min-h-0 !py-1 !px-2.5 text-[11px]"+(f.tipo===t?" on":"")} style={f.tipo===t?{background:"#1a2332"}:undefined} onClick={()=>cambia("tipo",t)}>{t}</button>
          ))}
        </div>
        {(cat==="docencia"||cat==="tutoria"||f.materia)&&<>
          <label className="lbl mt-3">Materia</label>
          <input className="field" list="fs-materias" value={f.materia} onChange={e=>cambia("materia",e.target.value)}/>
        </>}
        <div className="grid grid-cols-2 gap-3 mt-3">
          <div><label className="lbl">Grupo(s)</label>
            <input className="field" list="fs-grupos" value={f.grupos} onChange={e=>cambia("grupos",e.target.value)} placeholder="E1A, E1B"/></div>
          <div><label className="lbl">Aula</label>
            <input className="field" list="fs-aulas" value={f.aula} onChange={e=>cambia("aula",e.target.value)} placeholder="101"/></div>
        </div>
        <p className="text-[11px] text-ink-soft mt-1.5">Varios grupos separados por comas. Deja vacío lo que no proceda (p. ej. en una guardia).</p>
        <datalist id="fs-tipos">{opciones.tipos.map(t=><option key={t} value={t}/>)}</datalist>
        <datalist id="fs-materias">{opciones.materias.map(t=><option key={t} value={t}/>)}</datalist>
        <datalist id="fs-grupos">{opciones.grupos.map(t=><option key={t} value={t}/>)}</datalist>
        <datalist id="fs-aulas">{opciones.aulas.map(t=><option key={t} value={t}/>)}</datalist>
        {err&&<p className="text-xs font-semibold text-[#be123c] mt-3">{err}</p>}
        <div className="flex gap-2 mt-5">
          {!nueva&&<button className="btn btn-ghost !px-3 text-[#be123c]" disabled={ocupado} onClick={quitar} title="Quitar sesión" aria-label="Quitar sesión"><Ico n="papelera" s={18}/></button>}
          <button className="btn btn-ghost flex-1" onClick={onClose}>Cancelar</button>
          <button className="btn btn-dark flex-1" disabled={ocupado} onClick={guardar}>{ocupado?"Guardando…":"Guardar"}</button>
        </div>
      </div>
    </div>
  );
}

/* Horario completo en CSV para Excel: «;» para que Excel en español lo abra en columnas */
function descargarHorarioCSV(){
  const csv="Profesor/a;Día (1-5);Hora (1-13, R1, R2);Materia;Grupo;Aula;Tipo\r\n"+ENTRADAS.map(e=>[e.profesor,e.dia,e.slot,e.materia,e.grupo,e.aula,e.tipo].map(v=>{const t=String(v==null?"":v);return /[";,\n]/.test(t)?'"'+t.replace(/"/g,'""')+'"':t;}).join(";")).join("\r\n");
  const a=document.createElement("a");a.href=URL.createObjectURL(new Blob(["﻿"+csv],{type:"text/csv;charset=utf-8"}));
  a.download="horario_2026-27_"+hoyISO()+".csv";document.body.appendChild(a);a.click();a.remove();
}
/* Barra de administración en Profesores: horario completo en CSV (Excel) y nuevo profesor/a */
function BarraEdicion({clave,onNuevo,onHecho}){
  const ref=React.useRef(null);const[ocupado,setOcupado]=useState(false);
  const descargar=descargarHorarioCSV;
  const subir=async e=>{
    const file=e.target.files&&e.target.files[0];e.target.value="";
    if(!file)return;
    if(!confirm("Se sustituirá el horario COMPLETO del centro por el de «"+file.name+"». ¿Continuar?"))return;
    setOcupado(true);
    try{const r=await Horario.importar(clave,await file.text());onHecho("Horario cargado: "+r.sesiones+" sesiones de "+r.profesores+" profesores"+(r.descartadas?" ("+r.descartadas+" filas descartadas)":""));}
    catch(x){alert(x.message);}
    setOcupado(false);
  };
  return(
    <div className="card p-4 mb-4 no-print fade-in" style={{borderColor:"#c7d2fe",background:"#eef2ff"}}>
      <div className="flex items-center gap-2 mb-1 text-[#3730a3]"><Ico n="lapiz" s={16}/><span className="font-bold text-sm">Modo edición del horario</span></div>
      <p className="text-xs text-ink-soft mb-3">Elige un profesor/a y toca cualquier casilla para cambiarla, o «+» para añadir una sesión. Los cambios se ven al momento en Grupos, Aulas y Guardias.</p>
      <div className="flex flex-wrap gap-2">
        <button className="btn btn-ghost" onClick={onNuevo}><Ico n="mas" s={16}/>Nuevo profesor/a</button>
        <button className="btn btn-ghost" onClick={descargar}><Ico n="descargar" s={16}/>Descargar horario (Excel/CSV)</button>
        <button className="btn btn-ghost" disabled={ocupado} onClick={()=>ref.current&&ref.current.click()}><Ico n="subir" s={16}/>{ocupado?"Cargando…":"Subir horario completo (CSV)"}</button>
        <input ref={ref} type="file" accept=".csv,text/csv" className="hidden" onChange={subir}/>
      </div>
    </div>
  );
}

/* Pantalla de consulta: Profesores / Grupos / Aulas */
/* Cabecera del horario de un docente: correo, móvil, años trabajados y contador de días de asuntos propios (DAP).
   Solo la ve el propio docente y la administración (el servidor no la da a nadie más). */
/* Departamento del docente con su icono (cabecera del horario). Jefatura puede corregirlo. */
const DEP_ICONO={
  "Actividades Complementarias y Extraescolares":["🚌","#0d9488"],"Artes Plásticas":["🎨","#db2777"],"Ciencias Naturales":["🌿","#15803d"],
  "Economía":["📈","#0369a1"],"Educación Física":["⚽","#ea580c"],"Filosofía":["🦉","#7c3aed"],"Física y Química":["⚗️","#0891b2"],
  "Formación y orientación laboral":["💼","#475569"],"Francés":["🥐","#2563eb"],"Geografía e Historia":["🌍","#b45309"],"Griego":["🏛️","#92400e"],
  "Inglés":["🗽","#be123c"],"Latín":["📜","#a16207"],"Lengua Castellana y Literatura":["📖","#9f1239"],"Matemáticas":["📐","#1d4ed8"],
  "Música":["🎵","#c026d3"],"Orientación":["🧭","#0f766e"],"Tecnología":["⚙️","#4d7c0f"],"Fam. Prof. Informática y Comunicaciones":["💻","#4338ca"],
  "Religión":["🕊️","#64748b"]
};
function DepartamentoProfesor({nombre}){
  const[d,setD]=useState(null);const[editar,setEditar]=useState(false);
  useEffect(()=>{let vivo=true;setD(null);setEditar(false);pedir("GET","/departamento-de?profesor="+encodeURIComponent(nombre)).then(r=>{if(vivo)setD(r);}).catch(()=>{});return()=>{vivo=false;};},[nombre]);
  if(!d)return null;
  const[ico,col]=DEP_ICONO[d.departamento]||["🏫","#6b7280"];
  const cambiar=async v=>{try{const r=await pedir("PUT","/departamento-de",{profesor:nombre,departamento:v});setD(r);setEditar(false);}catch(e){alert(e.message);}};
  return(
    <div className="flex items-center gap-2 mt-2 flex-wrap">
      {d.departamento
        ?<span className="inline-flex items-center gap-2 rounded-full pl-1 pr-3 py-1 text-xs font-bold" style={{background:col+"18",color:col}} title={"Departamento de "+d.departamento}>
          <span className="w-7 h-7 rounded-full flex items-center justify-center text-base text-white" style={{background:col}} aria-hidden="true">{ico}</span>
          Departamento de {d.departamento}</span>
        :<span className="text-xs font-semibold text-ink-soft">Departamento sin asignar</span>}
      {d.lista&&!editar&&<button className="text-[11px] font-semibold text-ink-soft underline underline-offset-2 no-print" onClick={()=>setEditar(true)}>{d.departamento?"Cambiar":"Asignar"}{d.origen==="materias"?" (deducido de sus materias)":""}</button>}
      {d.lista&&editar&&<select className="field !w-auto !min-h-[32px] !py-1 text-xs no-print" autoFocus value={d.origen==="manual"?d.departamento:""} onChange={e=>cambiar(e.target.value)} onBlur={()=>setEditar(false)} aria-label="Departamento">
        <option value="">{d.origen==="manual"?"— Automático (según sus materias) —":"— Elige departamento —"}</option>
        {d.lista.map(x=><option key={x} value={x}>{(DEP_ICONO[x]||["🏫"])[0]} {x}</option>)}
      </select>}
    </div>
  );
}

/* Consejo Escolar: profesorado con ese perfil en Usuarios */
let consejoCache=null;
const leerConsejo=()=>consejoCache||(consejoCache=pedir("GET","/consejo-escolar").then(r=>r.miembros||[]).catch(()=>{consejoCache=null;return [];}));
function ConsejoProfesor({nombre}){
  const[es,setEs]=useState(false);
  useEffect(()=>{let vivo=true;leerConsejo().then(l=>{if(vivo)setEs(l.includes(nombre));});return()=>{vivo=false;};},[nombre]);
  if(!es)return null;
  return <span className="inline-flex items-center gap-2 rounded-full pl-1 pr-3 py-1 text-xs font-bold mt-2 mr-2" style={{background:"#fee2e2",color:"#991b1b"}}>
    <span className="w-7 h-7 rounded-full flex items-center justify-center text-base text-white" style={{background:"#991b1b"}} aria-hidden="true">⚖️</span>Miembro del Consejo Escolar</span>;
}
function ConsejoEscolarCard({onPick}){
  const[l,setL]=useState(null);
  useEffect(()=>{leerConsejo().then(setL);},[]);
  if(!l||!l.length)return null;
  return(
    <div className="card p-4 mb-4 border-l-4 no-print" style={{borderLeftColor:"#991b1b"}}>
      <div className="font-display font-bold text-ink flex items-center gap-2 mb-2"><span aria-hidden="true">⚖️</span>Consejo Escolar · representantes del profesorado <span className="pill" style={{background:"#fee2e2",color:"#991b1b"}}>{l.length}</span></div>
      <div className="flex flex-wrap gap-1.5">{l.map(n=><button key={n} className="chip !py-1.5 text-sm" onClick={()=>onPick(n)}>{nomNat(n)}</button>)}</div>
    </div>);
}
/* Cabecera del horario de un grupo: tutor/a, delegado/a y subdelegado/a */
function CabeceraGrupo({grupo}){
  const[g,setG]=useState(null);
  useEffect(()=>{let vivo=true;setG(null);pedir("GET","/grupo-info?grupo="+encodeURIComponent(grupo)).then(r=>{if(vivo)setG(r);}).catch(()=>{});return()=>{vivo=false;};},[grupo]);
  const[ed,setEd]=useState(null);
  const guardarN=async()=>{try{const r=await pedir("PUT","/grupos/alumnos",{valores:{[grupo]:ed}});if(r.ok===false)throw new Error(r.error);setG({...g,alumnos:r.grupos[grupo]??null});setEd(null);}catch(e){alert(e.message);}};
  if(!g)return null;
  const D=({ico,col,l,v})=><div className="flex items-center gap-2 rounded-xl px-3 py-2 min-w-[12rem] flex-1" style={{background:col+"14"}}>
    <span className="w-8 h-8 rounded-full flex items-center justify-center text-base text-white shrink-0" style={{background:col}} aria-hidden="true">{ico}</span>
    <div className="min-w-0"><div className="text-[10px] font-bold uppercase tracking-wide" style={{color:col}}>{l}</div><div className={"text-sm font-bold truncate "+(v?"text-ink":"text-ink-soft font-medium")}>{v||"Sin indicar"}</div></div></div>;
  return(
    <div className="mt-3 flex flex-wrap gap-2">
      <div className="flex items-center gap-2 rounded-xl px-3 py-2 min-w-[10rem]" style={{background:"#b4530914"}}>
        <span className="w-8 h-8 rounded-full flex items-center justify-center text-base text-white shrink-0" style={{background:"#b45309"}} aria-hidden="true">👥</span>
        <div className="min-w-0"><div className="text-[10px] font-bold uppercase tracking-wide" style={{color:"#b45309"}}>Nº de alumnos</div>
          {ed===null?<div className="flex items-center gap-2"><span className={"text-sm font-bold "+(g.alumnos!=null?"text-ink":"text-ink-soft font-medium")}>{g.alumnos!=null?g.alumnos:"Sin indicar"}</span>
            {g.puedeEditarAlumnos&&<button className="text-[11px] font-bold underline underline-offset-2" style={{color:"#b45309"}} onClick={()=>setEd(g.alumnos??"")}>Cambiar</button>}</div>
          :<div className="flex items-center gap-1.5"><input className="field !min-h-[30px] !py-0.5 !px-2 w-16 text-sm" type="number" min="0" max="999" inputMode="numeric" aria-label="Nº de alumnos" value={ed} onChange={e=>setEd(e.target.value)} autoFocus/>
            <button className="text-[11px] font-bold underline" style={{color:"#b45309"}} onClick={guardarN}>Guardar</button><button className="text-[11px] underline text-ink-soft" onClick={()=>setEd(null)}>Cancelar</button></div>}
        </div>
      </div>
      <D ico="🎓" col="#1e40af" l={"Tutor/a"+(g.nombreGrupo?" · "+g.nombreGrupo:"")} v={g.tutor?nomNat(g.tutor):""}/>
      <D ico="⭐" col="#0f766e" l="Delegado/a" v={g.delegado}/>
      <D ico="☆" col="#7c3aed" l="Subdelegado/a" v={g.subdelegado}/>
    </div>);
}

function FichaProfesor({nombre}){
  const[f,setF]=useState(null);
  useEffect(()=>{let vivo=true;setF(null);pedir("GET","/dap/ficha?profesor="+encodeURIComponent(nombre)).then(d=>{if(vivo)setF(d.ficha||null);}).catch(()=>{});return()=>{vivo=false;};},[nombre]);
  if(!f)return null;
  const tramo=f.anios==null?"":f.anios<18?"menos de 18 años":f.anios<23?"de 18 a 22 años":"23 años o más";
  const agotado=f.restantes!=null&&f.restantes<=0;
  return(
    <div className="mt-3 pt-3 border-t border-divider flex flex-wrap items-stretch gap-3 text-xs">
      <div className="flex-1 min-w-[14rem] space-y-1 text-ink-soft font-medium">
        {f.cuenta?<>
          <div className="flex items-center gap-1.5"><span aria-hidden="true">✉</span>{f.email?<a className="font-semibold text-ink hover:underline" href={"mailto:"+f.email}>{f.email}</a>:<span className="text-[#b45309]">correo pendiente</span>}</div>
          <div className="flex items-center gap-1.5"><span aria-hidden="true">📱</span>{f.movil?<a className="font-semibold text-ink hover:underline" href={"tel:"+f.movil.replace(/\s/g,"")}>{f.movil}</a>:<span className="text-ink-soft">sin móvil (voluntario)</span>}</div>
          <div><b className="text-ink">{f.anios??"—"}</b> años trabajados{tramo&&<span className="opacity-80"> · {tramo}</span>}</div>
        </>:<div className="text-[#b45309] font-semibold">Este docente aún no tiene cuenta en la app: sin datos de contacto.</div>}
      </div>
      <div className="rounded-xl px-4 py-2.5 flex items-center gap-3" style={{background:agotado?"#fff1f2":"#ccfbf1",color:agotado?"#9f1239":"#0f766e"}} title={f.dias.length?"Días: "+f.dias.map(fmtCorta).join(" · "):"Sin días de asuntos propios en este curso"}>
        <div className="text-center leading-none">
          <div className="font-display font-bold text-2xl">{f.derecho==null?"?":f.restantes}</div>
          <div className="text-[10px] font-semibold mt-1">{f.derecho==null?"":"disponibles"}</div>
        </div>
        <div className="leading-tight">
          <div className="font-display font-bold text-sm">DAP · curso {f.curso.nombre}</div>
          <div className="font-semibold">{f.derecho==null?"Faltan los años trabajados para calcularlos":f.usados+" usados de "+f.derecho+" retribuidos"}</div>
          {f.futuros>0&&<div className="opacity-80">{f.futuros} ya solicitado{f.futuros===1?"":"s"} para próximas fechas</div>}
          {f.dias.length>0&&<div className="opacity-80">{f.dias.map(d=>fmtCorta(d)).join(" · ")}</div>}
        </div>
      </div>
    </div>
  );
}

/* ── Incidencias en las aulas: cualquiera las marca; Jefatura de Estudios y Conserjería las reciben y resuelven ── */
const AZUL="#2563eb";
function IncidenciasAula({aula,onCambio}){
  const[d,setD]=useState(null);const[nueva,setNueva]=useState(null);const[ocupado,setOcupado]=useState(false);
  const cargar=()=>pedir("GET","/incidencias?aula="+encodeURIComponent(aula)).then(setD).catch(()=>setD({incidencias:[]}));
  useEffect(()=>{setD(null);setNueva(null);cargar();},[aula]);
  const enviar=async()=>{setOcupado(true);try{setD(await pedir("POST","/incidencias",{aula,descripcion:nueva}));setNueva(null);onCambio&&onCambio();}catch(e){alert(e.message);}setOcupado(false);};
  const resolver=async i=>{const nota=prompt("¿Dar por resuelta la incidencia? Nota (opcional):","");if(nota===null)return;try{setD(await pedir("POST","/incidencias/"+i.id+"/resolver",{nota}));onCambio&&onCambio();}catch(e){alert(e.message);}};
  if(!d)return null;
  const ab=d.incidencias;
  return(
    <div className="mt-3 no-print">
      {ab.length>0&&<div className="rounded-xl p-3 space-y-2 mb-2" style={{background:"#eff6ff",border:"2px solid "+AZUL}}>
        <div className="text-xs font-bold uppercase tracking-wide" style={{color:"#1e3a8a"}}>⚠ Incidencia{ab.length>1?"s":""} abierta{ab.length>1?"s":""} en esta aula</div>
        {ab.map(i=><div key={i.id} className="flex flex-wrap items-start gap-2 text-sm">
          <span className="flex-1 min-w-[12rem]"><b style={{color:"#1e3a8a"}}>{i.descripcion}</b><span className="block text-[11px] text-ink-soft">Marcada por {nomNat(i.nombre)||i.usuario} · {i.creado.slice(8,10)}/{i.creado.slice(5,7)} {i.creado.slice(11)}</span></span>
          {(d.gestiona)&&<button className="btn !min-h-[32px] text-xs text-white" style={{background:AZUL}} onClick={()=>resolver(i)}>✓ Resuelta</button>}
        </div>)}
      </div>}
      {nueva===null?<button className="btn btn-ghost !min-h-[34px] text-xs" style={{borderColor:AZUL,color:AZUL}} onClick={()=>setNueva("")}><Ico n="mas" s={15}/>Marcar incidencia en el aula</button>
        :<div className="rounded-xl p-3 space-y-2" style={{background:"#eff6ff"}}>
          <label className="lbl" htmlFor="inc-d">¿Qué ocurre en el aula?</label>
          <textarea id="inc-d" className="field" rows={2} maxLength={500} value={nueva} onChange={e=>setNueva(e.target.value)} placeholder="Ej.: el proyector no enciende, persiana rota, falta una silla…" autoFocus/>
          <p className="text-[11px] text-ink-soft">Lo reciben como aviso Jefatura de Estudios y Conserjería. El aula aparecerá en azul hasta que se resuelva.</p>
          <div className="flex gap-2"><button className="btn !min-h-[36px] text-xs text-white" style={{background:AZUL}} disabled={ocupado||nueva.trim().length<4} onClick={enviar}>Enviar incidencia</button><button className="btn btn-ghost !min-h-[36px] text-xs" onClick={()=>setNueva(null)}>Cancelar</button></div>
        </div>}
    </div>);
}
function IncidenciasAbiertas({onPick,recarga}){
  const[d,setD]=useState(null);
  useEffect(()=>{pedir("GET","/incidencias").then(setD).catch(()=>{});},[recarga]);
  if(!d||!d.incidencias.length)return null;
  return(
    <div className="card p-4 mb-4 no-print" style={{borderColor:AZUL,background:"#eff6ff"}}>
      <div className="font-display font-bold mb-2" style={{color:"#1e3a8a"}}>⚠ Incidencias abiertas en las aulas ({d.incidencias.length})</div>
      <div className="space-y-1.5">{d.incidencias.slice(0,8).map(i=><button key={i.id} onClick={()=>onPick(i.aula)} className="w-full text-left flex flex-wrap items-center gap-2 text-sm rounded-lg px-2 py-1 hover:bg-white">
        <span className="pill text-white" style={{background:AZUL}}>Aula {i.aula}</span><span className="flex-1 text-ink">{i.descripcion}</span><span className="text-[11px] text-ink-soft">{i.creado.slice(8,10)}/{i.creado.slice(5,7)}</span></button>)}</div>
    </div>);
}

const CajaRgpd=({t,sub,children})=><div className="card p-4 sm:p-5 mb-4"><div className="font-display font-bold text-ink">{t}</div>{sub&&<p className="text-xs text-ink-soft mb-3">{sub}</p>}{children}</div>;
/* ── Protección de datos: registro de accesos, información de privacidad, plazos y cierre de curso ── */
function PantallaRgpd({tile,onBack,onToast,esAdminCuenta}){
  const[priv,setPriv]=useState(null);const[edP,setEdP]=useState(null);
  const[plz,setPlz]=useState(null);const[prev,setPrev]=useState(null);const[conf,setConf]=useState("");const[ocupado,setOcupado]=useState(false);
  const[reg,setReg]=useState(null);const[f,setF]=useState({desde:"",hasta:"",texto:""});
  const cargarPriv=()=>pedir("GET","/privacidad").then(d=>{setPriv(d);setPlz(d.plazos);}).catch(()=>{});
  const cargarReg=()=>pedir("GET","/registro-accesos?"+new URLSearchParams(Object.entries(f).filter(([,v])=>v))).then(setReg).catch(e=>setReg({error:e.message,registros:[]}));
  useEffect(()=>{cargarPriv();cargarReg();},[]);
  const guardarPriv=async()=>{try{const d=await pedir("PUT","/privacidad",edP);setPriv(d);setEdP(null);onToast("Información de privacidad guardada");}catch(e){alert(e.message);}};
  const guardarPlz=async()=>{try{await pedir("PUT","/privacidad/plazos",{plazos:plz});onToast("Plazos guardados");setPrev(null);cargarPriv();}catch(e){alert(e.message);}};
  const verPrev=async()=>{try{setPrev(await pedir("GET","/privacidad/cierre"));}catch(e){alert(e.message);}};
  const cierre=async()=>{setOcupado(true);try{const r=await pedir("POST","/privacidad/cierre",{confirmar:conf});onToast("Cierre de curso hecho: "+Object.values(r.borrado).reduce((a,b)=>a+b,0)+" registros borrados");setConf("");setPrev(null);cargarReg();}catch(e){alert(e.message);}setOcupado(false);};
  const csv=()=>{const l=[["Fecha y hora","Usuario","Nombre","Acción","Detalle","IP"]].concat((reg.registros||[]).map(r=>[r.cuando,r.usuario,r.nombre,r.accionTexto,r.objeto,r.ip]));
    const b=new Blob(["\ufeff"+l.map(x=>x.map(v=>'"'+String(v??"").replace(/"/g,'""')+'"').join(";")).join("\n")],{type:"text/csv"});const a=document.createElement("a");a.href=URL.createObjectURL(b);a.download="registro_accesos.csv";a.click();};
  const plazoTxt=n=>n===0?"solo el curso actual":"curso actual + "+n;
  return(
    <Seccion tile={tile} onBack={onBack}>
      <p className="text-sm text-ink-soft mb-4">Herramientas para cumplir el RGPD, la LOPDGDD y el Esquema Nacional de Seguridad. {esAdminCuenta?"La cuenta de administración gestiona la información de privacidad, los plazos y el cierre de curso; ":""}Dirección y administración consultan el registro de accesos.</p>
      {esAdminCuenta&&<CajaRgpd t="Información de protección de datos" sub="La ve todo el mundo en la pantalla de entrada y al pie de la app («Protección de datos»). El texto lo debe validar el Delegado/a de Protección de Datos de la Consejería.">
        {priv&&!edP&&<div className="text-sm space-y-1.5">
          <p><b>Responsable:</b> {priv.responsable}</p><p><b>DPD:</b> {priv.dpd}</p><p><b>Contacto:</b> {priv.contacto}</p>
          <p>{priv.validado?<span className="pill" style={{background:"#dcfce7",color:"#166534"}}>Validado por el DPD · {priv.validadoFecha}</span>:null}</p>
          <div className="flex flex-wrap gap-2 pt-1"><button className="btn btn-ghost !min-h-[36px] text-xs" onClick={()=>verPrivacidad("datos")}>Ver como la ve el profesorado</button>
            <button className="btn btn-dark !min-h-[36px] text-xs" onClick={()=>setEdP({responsable:priv.responsable,dpd:priv.dpd,contacto:priv.contacto,validado:priv.validado})}><Ico n="lapiz" s={15}/>Editar</button></div></div>}
        {edP&&<div className="space-y-2.5">
          {[["responsable","Responsable del tratamiento"],["dpd","Delegado/a de Protección de Datos (contacto)"],["contacto","Contacto en el centro para ejercer los derechos"]].map(([k,l])=>
            <div key={k}><label className="lbl" htmlFor={"pv-"+k}>{l}</label><textarea id={"pv-"+k} className="field" rows={2} value={edP[k]} onChange={e=>setEdP({...edP,[k]:e.target.value})}/></div>)}
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={!!edP.validado} onChange={e=>setEdP({...edP,validado:e.target.checked})}/>El Delegado/a de Protección de Datos ha validado este texto</label>
          <div className="flex gap-2"><button className="btn btn-dark !min-h-[38px] text-xs" onClick={guardarPriv}>Guardar</button><button className="btn btn-ghost !min-h-[38px] text-xs" onClick={()=>setEdP(null)}>Cancelar</button></div></div>}
      </CajaRgpd>}
      {esAdminCuenta&&plz&&priv&&<CajaRgpd t="Plazos de conservación y cierre de curso" sub="Cursos completos que se conservan además del actual (RGPD art. 5.1.e). Fijadlos con el DPD. El cierre de curso borra definitivamente lo que haya vencido; haced antes una copia de seguridad.">
        <div className="grid sm:grid-cols-2 gap-2">{priv.categorias.map(c=><label key={c.k} className="flex items-center gap-2 rounded-lg border border-divider px-3 py-2 text-sm">
          <span className="flex-1">{c.l}</span><span className="text-[11px] text-ink-soft whitespace-nowrap">{plazoTxt(plz[c.k])}</span>
          <input type="number" min="0" max="10" className="w-16 shrink-0 rounded-lg border border-divider bg-white px-2 py-1 text-sm text-right" aria-label={"Cursos que se conservan: "+c.l} value={plz[c.k]} onChange={e=>setPlz({...plz,[c.k]:Number(e.target.value)})}/></label>)}</div>
        <div className="flex flex-wrap gap-2 mt-3"><button className="btn btn-ghost !min-h-[36px] text-xs" onClick={guardarPlz}>Guardar plazos</button><button className="btn btn-dark !min-h-[36px] text-xs" onClick={verPrev}>Cierre de curso: ver qué se borraría</button></div>
        {prev&&<div className="mt-3 rounded-xl p-3" style={{background:"#fff1f2"}}>
          <div className="text-sm font-bold mb-1.5" style={{color:"#9f1239"}}>Se borrarían {prev.total} registros</div>
          <ul className="text-xs space-y-0.5 mb-3">{prev.categorias.map(c=><li key={c.k}><b>{c.l}</b>: {c.n} (anteriores al {fmtFH(c.antesDe)})</li>)}</ul>
          {prev.total>0&&<div className="flex flex-wrap items-center gap-2"><input className="field !min-h-[36px] w-40 text-sm" placeholder="Escribe BORRAR" aria-label="Escribe BORRAR para confirmar" value={conf} onChange={e=>setConf(e.target.value)}/>
            <button className="btn !min-h-[36px] text-xs text-white" style={{background:"#be123c"}} disabled={conf!=="BORRAR"||ocupado} onClick={cierre}>Borrar definitivamente</button></div>}
        </div>}
      </CajaRgpd>}
      <CajaRgpd t="Registro de accesos a datos sensibles" sub="Quién abre partes de disciplina, justificantes, ausencias con motivo, informes y el registro de firmas, y quién usa el modo administrador (RGPD art. 5.2 · ENS op.exp.8).">
        <div className="flex flex-wrap gap-2 items-end mb-3">
          <div><label className="lbl" htmlFor="ra-d">Desde</label><input id="ra-d" type="date" className="field !min-h-[36px]" value={f.desde} onChange={e=>setF({...f,desde:e.target.value})}/></div>
          <div><label className="lbl" htmlFor="ra-h">Hasta</label><input id="ra-h" type="date" className="field !min-h-[36px]" value={f.hasta} onChange={e=>setF({...f,hasta:e.target.value})}/></div>
          <div className="flex-1 min-w-[10rem]"><label className="lbl" htmlFor="ra-t">Persona o detalle</label><input id="ra-t" className="field !min-h-[36px]" value={f.texto} onChange={e=>setF({...f,texto:e.target.value})}/></div>
          <button className="btn btn-dark !min-h-[36px] text-xs" onClick={cargarReg}>Buscar</button>{reg&&reg.registros.length>0&&<button className="btn btn-ghost !min-h-[36px] text-xs" onClick={csv}>CSV</button>}</div>
        {!reg?<p className="text-sm text-ink-soft">Cargando…</p>:reg.error?<p className="text-sm text-[#be123c]">{reg.error}</p>:!reg.registros.length?<p className="text-sm text-ink-soft">Sin registros.</p>
          :<div className="overflow-x-auto"><table className="w-full text-xs min-w-[640px]"><thead><tr className="text-left text-ink-soft"><th className="py-1.5 pr-2">Fecha y hora</th><th className="pr-2">Persona</th><th className="pr-2">Acción</th><th className="pr-2">Detalle</th><th>IP</th></tr></thead>
            <tbody>{reg.registros.map(r=><tr key={r.id} className="border-t border-divider align-top"><td className="py-1.5 pr-2 whitespace-nowrap">{fmtFH(r.cuando)}</td><td className="pr-2"><b>{r.nombre||r.usuario}</b><div className="text-ink-soft">{r.usuario}</div></td>
              <td className="pr-2" style={r.accion==="modo_admin_fallido"?{color:"#be123c",fontWeight:700}:undefined}>{r.accionTexto}</td><td className="pr-2">{r.objeto}</td><td className="text-ink-soft">{r.ip}</td></tr>)}</tbody></table></div>}
      </CajaRgpd>
    </Seccion>);
}

/* ── Nº de alumnos por grupo: lo escribe Jefatura de Estudios ── */
function AlumnosGrupos({items,datos,onGuardado}){
  const[abierto,setAbierto]=useState(false);const[v,setV]=useState({});const[ocupado,setOcupado]=useState(false);
  if(!datos)return null;
  const abrir=()=>{setV(Object.fromEntries(items.map(g=>[g,datos.grupos[g]??""])));setAbierto(true);};
  const guardar=async()=>{setOcupado(true);try{const cambios=Object.fromEntries(Object.entries(v).filter(([g,x])=>String(datos.grupos[g]??"")!==String(x)));const r=await pedir("PUT","/grupos/alumnos",{valores:cambios});if(r.ok===false)throw new Error(r.error);onGuardado(r);setAbierto(false);}catch(e){alert(e.message);}setOcupado(false);};
  const total=Object.values(v).reduce((s,x)=>s+(Number(x)||0),0);
  return(
    <div className="card p-4 mb-4 no-print">
      <div className="flex flex-wrap items-center gap-3">
        <span className="w-9 h-9 rounded-xl flex items-center justify-center text-white" style={{background:"#b45309"}} aria-hidden="true">👥</span>
        <div className="flex-1 min-w-[12rem]"><div className="font-display font-bold text-ink">Nº de alumnos por grupo</div>
          <div className="text-xs text-ink-soft">{datos.total?datos.total+" alumnos en "+Object.keys(datos.grupos).length+" grupos":"Aún sin indicar"}{datos.puedeEditar?" · lo escribe Jefatura de Estudios":""}</div></div>
        {datos.puedeEditar&&!abierto&&<button className="btn btn-ghost !min-h-[36px] text-xs" onClick={abrir}><Ico n="lapiz" s={15}/>Editar</button>}
      </div>
      {abierto&&<div className="mt-3">
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-2">
          {items.map(g=><label key={g} className="flex items-center gap-2 rounded-lg border border-divider px-2 py-1.5 bg-white">
            <span className="text-xs font-bold text-ink flex-1 truncate">{g}</span>
            <input className="w-14 text-right text-sm font-semibold outline-none bg-paper-warm/60 rounded px-1 py-0.5" type="number" min="0" max="999" inputMode="numeric" aria-label={"Alumnos de "+g} value={v[g]} onChange={e=>setV({...v,[g]:e.target.value})}/></label>)}
        </div>
        <div className="flex flex-wrap items-center gap-2 mt-3"><span className="text-sm font-semibold text-ink flex-1">Total: {total} alumnos</span>
          <button className="btn btn-dark !min-h-[38px] text-xs" disabled={ocupado} onClick={guardar}>Guardar</button><button className="btn btn-ghost !min-h-[38px] text-xs" onClick={()=>setAbierto(false)}>Cancelar</button></div>
      </div>}
    </div>);
}

function PantallaConsulta({tile,onBack,items,campo,mostrar,porLetras,pregunta,prefijo,sinHorario,ver,editable,clave,onCambio,arriba}){
  const[sel,setSel]=useState("");
  const[form,setForm]=useState(null);   /* {inicial, nueva} */
  const[incVer,setIncVer]=useState(0);const[incAulas,setIncAulas]=useState(null);   /* aulas con incidencias abiertas (en azul) */
  const[nAlum,setNAlum]=useState(null);   /* nº de alumnos por grupo */
  useEffect(()=>{if(campo==="grupo")pedir("GET","/grupos/alumnos").then(d=>{if(d&&d.ok!==false)setNAlum(d);}).catch(()=>{});},[campo,sel]);
  useEffect(()=>{if(campo==="aula")pedir("GET","/incidencias/resumen").then(d=>setIncAulas(Object.fromEntries((d.aulas||[]).map(a=>[a.aula,a.n])))).catch(()=>{});},[campo,incVer,sel]);
  const lista=useMemo(()=>sel?ENTRADAS.filter(e=>e[campo]===sel):[],[sel,campo,ver]);
  const editar=(c,dia,slot)=>setForm(c?{inicial:sesionDe(c),nueva:false}:{inicial:{profesor:sel,dia,slot:String(slot),materia:"",aula:"",tipo:"Docencia",grupos:[]},nueva:true});
  const nuevoProf=()=>{const n=prompt("Nombre del nuevo profesor/a, como «Apellidos, Nombre»:");if(n&&n.trim())setSel(n.trim());};
  const colores=useMemo(()=>coloresMaterias(lista),[lista]);
  const resumen=useMemo(()=>{
    if(!sel)return"";
    const franjas=f=>new Set(lista.filter(f).map(e=>e.dia+"-"+e.slot)).size;
    if(campo==="profesor")return franjas(e=>e.cat==="docencia")+" horas lectivas · "+franjas(e=>e.cat==="guardia"||e.cat==="recreo")+" guardias";
    return franjas(()=>true)+" franjas semanales ocupadas";
  },[sel,lista,campo]);
  const titulo=(prefijo||"")+sel;
  return(
    <Seccion tile={tile} onBack={onBack}>
      {!sel&&arriba}
      {editable&&!sel&&<BarraEdicion clave={clave} onNuevo={nuevoProf} onHecho={m=>onCambio(m)}/>}
      {!sel&&campo==="profesor"&&<ConsejoEscolarCard onPick={setSel}/>}
      {!sel&&campo==="aula"&&<IncidenciasAbiertas onPick={setSel} recarga={incVer}/>}
      {!sel&&campo==="grupo"&&<AlumnosGrupos items={items} datos={nAlum} onGuardado={setNAlum}/>}
      {!sel&&<Selector items={items} tile={tile} porLetras={porLetras} pregunta={pregunta} onPick={setSel} apagados={sinHorario} marcados={campo==="aula"?incAulas:null} cuenta={campo==="grupo"&&nAlum?nAlum.grupos:null}/>}
      {!sel&&sinHorario&&sinHorario.length>0&&<p className="text-[11px] text-ink-soft mt-3 no-print">Los nombres con trazo discontinuo y «·» aún no tienen horario cargado.</p>}
      {sel&&sinHorario&&sinHorario.indexOf(sel)>=0&&(
        <div className="card p-6 fade-in">
          <div className="font-display font-bold text-lg text-ink mb-1">{sel}</div>
          <p className="text-sm text-ink-soft">El horario de este profesor/a no figura en los datos cargados. Jefatura de Estudios lo añadirá en cuanto se reciba.</p>
          <button className="btn btn-dark mt-4" onClick={()=>setSel("")}>Volver</button>
        </div>
      )}
      {sel&&!(sinHorario&&sinHorario.indexOf(sel)>=0)&&(
        <div className="space-y-4">
          <div className="card p-4 flex items-start justify-between gap-3 flex-wrap no-print">
            <div className="flex-1 min-w-[16rem]">
              <div className="font-display font-bold text-lg text-ink">{titulo}</div>
              <div className="text-xs text-ink-soft font-medium">{resumen}</div>
              {campo==="profesor"&&<DepartamentoProfesor nombre={sel}/>}
              {campo==="profesor"&&<ConsejoProfesor nombre={sel}/>}
              {campo==="grupo"&&<CabeceraGrupo grupo={sel}/>}
              {campo==="aula"&&<IncidenciasAula aula={sel} onCambio={()=>setIncVer(v=>v+1)}/>}
              {campo==="profesor"&&<FichaProfesor nombre={sel}/>}
              {campo==="profesor"&&<AvisoDisciplina nombre={sel}/>}
            </div>
            <div className="flex gap-2">
              <button className="btn btn-ghost" onClick={()=>window.print()}><Ico n="imprimir" s={16}/>Imprimir</button>
              <button className="btn btn-dark" onClick={()=>setSel("")}>Cambiar</button>
            </div>
          </div>
          <div className="print-only"><div className="font-display font-bold text-xl">IES Valle del Jerte · {titulo}</div><div className="text-xs">Horario curso 2026-27</div></div>
          {editable&&<div className="text-xs font-semibold text-[#3730a3] flex items-center gap-1.5 no-print"><Ico n="lapiz" s={14}/>Modo edición: toca una sesión para cambiarla o «+» para añadir otra.</div>}
          <div className="card p-3"><Rejilla lista={lista} mostrar={mostrar} colores={colores} onEditar={editable?editar:undefined}/></div>
          {Object.keys(colores).length>0&&(
            <div className="card p-4">
              <div className="lbl">Materias</div>
              <div className="flex flex-wrap gap-2">
                {Object.keys(colores).map(m=>{const k=colores[m];return <span key={m} className="inline-flex items-center px-2.5 py-1 rounded-lg text-[11px] font-semibold" style={{background:k.bg,borderLeft:"3px solid "+k.bd,color:k.tx}}>{m}</span>;})}
              </div>
            </div>
          )}
        </div>
      )}
      {form&&<FormSesion inicial={form.inicial} nueva={form.nueva} clave={clave} onClose={()=>setForm(null)} onHecho={m=>{setForm(null);onCambio(m);}}/>}
    </Seccion>
  );
}

/* Guardias de aula y de recreo
   Los profesores ausentes salen de la base de datos de la app (ausencias
   grabadas por Jefatura). El administrador puede añadir,
   editar o quitar ausencias desde aquí; también se pueden escribir a mano
   en la hoja y aparecen en la siguiente actualización. */
const PROF_NORM={};
ENTRADAS.forEach(e=>{PROF_NORM[quitarTildes(e.profesor).replace(/\s+/g," ").trim()]=e.profesor;});
/* Admite el nombre tal como esté escrito en la hoja (tildes, mayúsculas o espacios distintos) */
const nombreHorario=n=>PROF_NORM[quitarTildes(n).replace(/\s+/g," ").trim()]||n;
const esDAP=m=>/\bDAP\b|asuntos?\s+propios?/i.test(String(m||""));   /* asuntos propios: no necesitan justificante */
const esActividad=m=>/actividad(es)?\s+(complementaria|extraescolar)|extraescolar/i.test(String(m||""));   /* actividades complementarias o extraescolares: tampoco */
const MOTIVOS=["Cita médica","Asuntos propios (DAP)","Formación","Deber inexcusable","Actividad complementaria","Actividad extraescolar","Otro"];
const enRango=(a,iso)=>a.fecha<=iso&&iso<=(a.hasta||a.fecha);
const textoHoras=a=>a.modo==="dia"?"todo el día":(a.horas||[]).map(labelHora).join(", ");

const CANALES=["Teléfono","Correo electrónico","En persona","Otro medio"];
function FormAusenciaAdmin({inicial,profs,acento,onCancel,onSave,conCanal}){
  const[f,setF]=useState(inicial);
  const[ocupado,setOcupado]=useState(false);
  const wd=f.fecha?diaSemanaDe(f.fecha):0;
  const finde=f.fecha&&(wd===0||wd===6);
  const valido=f.prof&&f.fecha&&!finde&&(f.modo==="dia"||f.horas.length>0)&&(!f.hasta||f.hasta>=f.fecha);
  const alternar=h=>setF({...f,horas:f.horas.indexOf(h)>=0?f.horas.filter(x=>x!==h):f.horas.concat(h)});
  const guardar=async()=>{
    setOcupado(true);
    const ord=h=>HORAS.findIndex(x=>x.n===h);
    const ok=await onSave({...f,hasta:f.hasta&&f.hasta!==f.fecha?f.hasta:"",horas:f.modo==="horas"?f.horas.slice().sort((a,b)=>ord(a)-ord(b)):[],obs:(f.obs||"").trim()});
    setOcupado(false);
  };
  return(
    <div className="rounded-xl border border-divider bg-paper-warm p-4 space-y-3 fade-in">
      <div className="lbl">{f.id?"Editar ausencia":"Nueva ausencia"}</div>
      <select className="field" value={f.prof} onChange={e=>setF({...f,prof:e.target.value})}>
        <option value="">— Profesor/a —</option>
        {profs.map(p=><option key={p} value={p}>{p}</option>)}
      </select>
      <div className="grid sm:grid-cols-2 gap-3">
        <div><label className="lbl">Fecha</label><input type="date" className="field" value={f.fecha} onChange={e=>setF({...f,fecha:e.target.value})}/></div>
        <div><label className="lbl">Hasta (opcional)</label><input type="date" className="field" min={f.fecha} value={f.hasta} onChange={e=>setF({...f,hasta:e.target.value})}/></div>
      </div>
      {finde&&<p className="text-xs font-semibold text-[#be123c]">La fecha elegida es fin de semana.</p>}
      <div className="flex gap-2">
        {[["dia","Todo el día"],["horas","Horas concretas"]].map(m=>(
          <button key={m[0]} onClick={()=>setF({...f,modo:m[0]})} className={"chip flex-1 "+(f.modo===m[0]?"on":"")} style={f.modo===m[0]?{background:acento}:{}}>{m[1]}</button>
        ))}
      </div>
      {f.modo==="horas"&&(
        <div className="flex flex-wrap gap-2">
          {HORAS.map(x=>x.n).map(h=>{const on=f.horas.indexOf(h)>=0;return(
            <button key={h} onClick={()=>alternar(h)} className={"chip !px-3 "+(on?"on":"")} style={on?{background:acento}:{}}>{labelHora(h)}</button>);})}
        </div>
      )}
      <div className="grid sm:grid-cols-2 gap-3">
        <div><label className="lbl">Motivo (solo Jefatura)</label>
          <select className="field" value={f.motivo} onChange={e=>setF({...f,motivo:e.target.value})}>{MOTIVOS.concat(MOTIVOS.indexOf(f.motivo)<0&&f.motivo?[f.motivo]:[]).map(m=><option key={m}>{m}</option>)}</select></div>
        <div><label className="lbl">Tarea / indicaciones para la guardia</label><textarea className="field" rows={2} value={f.obs} onChange={e=>setF({...f,obs:e.target.value})}/></div>
      </div>
      {conCanal&&<div><label className="lbl">¿Cómo la comunicó el profesor/a?</label>
        <div className="flex flex-wrap gap-2">{CANALES.map(c=><button key={c} onClick={()=>setF({...f,canal:f.canal===c?"":c})} className={"chip "+(f.canal===c?"on":"")} style={f.canal===c?{background:acento}:{}}>{c}</button>)}</div></div>}
      <div className="flex gap-2"><button className="btn btn-ghost" onClick={onCancel}>Cancelar</button><button className="btn btn-dark" disabled={!valido||ocupado} onClick={guardar}>{ocupado?"Guardando…":f.id?"Guardar y confirmar":"Registrar y confirmar"}</button></div>
    </div>
  );
}

/* ============================================================
   REGISTRO SEMANAL DE AUSENCIAS (Jefatura · Guardias de aula)
   Rejilla Lunes–Viernes con el horario del profesor/a: en cada hora se marca
   la ausencia y se anota el aula donde queda el grupo, la tarea (observaciones)
   y el tipo. «Día completo» y «Tipo» de cada día se aplican a toda la columna.
   ============================================================ */
const SIN_DET="Sin determinar";
const TIPOS_REG=[SIN_DET].concat(MOTIVOS);
const lunesReg=iso=>{const wd=diaSemanaDe(iso);return sumarDias(iso,wd===0?1:wd===6?2:1-wd);};
const mismoProf=(a,p)=>nombreHorario(a.prof)===p;

function RegistroSemanalAusencias({inicial,lista,profs,acento,onGuardar,onCancel,onVariosDias}){
  const[prof,setProf]=useState(inicial.prof||"");
  const[fecha,setFecha]=useState(inicial.fecha||hoyISO());
  const lunes=lunesReg(fecha);
  const fechas=[0,1,2,3,4].map(i=>sumarDias(lunes,i));
  const[cel,setCel]=useState({});      /* "fecha|tramo" → {on,aula,obs,tipo} */
  const[dias,setDias]=useState({});    /* fecha → {completo,tipo} */
  const[ocupado,setOcupado]=useState(false);
  const[err,setErr]=useState("");

  /* horario del profesor/a: sesiones por día y tramo */
  const ses=useMemo(()=>{const m={};ENTRADAS.filter(e=>e.profesor===prof).forEach(e=>{((m[e.dia]=m[e.dia]||{})[e.slot]=m[e.dia][e.slot]||[]).push(e);});return m;},[prof]);
  const sesDe=(f,s)=>((ses[diaSemanaDe(f)]||{})[s])||[];
  const filas=HORAS.filter(h=>(!h.r&&!h.t)||[1,2,3,4,5].some(d=>((ses[d]||{})[h.n]||[]).length));
  const aulaHorario=(f,s)=>{const l=sesDe(f,s);return(l.find(e=>e.aula)||{}).aula||"";};

  /* ausencias ya grabadas de esa semana */
  const delProf=useMemo(()=>(lista||[]).filter(a=>a.estado!=="Pendiente"&&prof&&mismoProf(a,prof)),[lista,prof]);
  const deSemana=delProf.filter(a=>!a.hasta&&a.fecha>=fechas[0]&&a.fecha<=fechas[4]);
  const largas=delProf.filter(a=>a.hasta&&a.fecha<=fechas[4]&&a.hasta>=fechas[0]);
  const bloqueado=f=>largas.find(a=>enRango(a,f));

  /* al cambiar de profesor/a o de semana se cargan sus ausencias */
  const clave=prof+"|"+lunes+"|"+deSemana.map(a=>a.id).join(",");
  useEffect(()=>{
    const c={},d={};
    deSemana.forEach(a=>{
      const tipo=a.motivo||SIN_DET;
      const tramos=a.modo==="dia"?filas.map(h=>h.n).filter(s=>sesDe(a.fecha,s).length):(a.horas||[]).map(String);
      if(a.modo==="dia")d[a.fecha]={completo:true,tipo};
      tramos.forEach(s=>{const x=(a.detalle||{})[s]||{};c[a.fecha+"|"+s]={on:true,aula:x.aula||aulaHorario(a.fecha,s),obs:x.obs||(a.obs&&!Object.keys(a.detalle||{}).length?a.obs:""),tipo};});
    });
    setCel(c);setDias(d);setErr("");
  },[clave]);

  const celda=(f,s)=>cel[f+"|"+s]||{on:false,aula:aulaHorario(f,s),obs:"",tipo:(dias[f]||{}).tipo||SIN_DET};
  const ponCelda=(f,s,cambio)=>setCel(c=>({...c,[f+"|"+s]:{...celda(f,s),...cambio}}));
  const tramosConClase=f=>filas.map(h=>h.n).filter(s=>sesDe(f,s).length);
  const ponCompleto=(f,v)=>{
    const tipo=(dias[f]||{}).tipo||SIN_DET;
    setDias(d=>({...d,[f]:{...(d[f]||{tipo}),completo:v}}));
    setCel(c=>{const n={...c};tramosConClase(f).forEach(s=>{n[f+"|"+s]={...celda(f,s),on:v,...(v?{tipo}:{})};});return n;});
  };
  const ponTipoDia=(f,tipo)=>{
    setDias(d=>({...d,[f]:{...(d[f]||{}),tipo}}));
    setCel(c=>{const n={...c};tramosConClase(f).forEach(s=>{n[f+"|"+s]={...celda(f,s),tipo};});return n;});
  };

  const marcadas=fechas.reduce((n,f)=>n+tramosConClase(f).filter(s=>celda(f,s).on).length,0);

  const guardar=async()=>{
    setErr("");
    const ausencias=[];const libres=deSemana.map(a=>a.id);
    const tomarId=(f,tipo)=>{
      let i=libres.findIndex(id=>{const a=deSemana.find(x=>x.id===id);return a.fecha===f&&(a.motivo||SIN_DET)===tipo;});
      if(i<0)i=libres.findIndex(id=>deSemana.find(x=>x.id===id).fecha===f);
      return i>=0?libres.splice(i,1)[0]:"";
    };
    fechas.forEach(f=>{
      if(bloqueado(f))return;
      const on=tramosConClase(f).filter(s=>celda(f,s).on);
      const completo=!!(dias[f]||{}).completo;
      if(!on.length&&!completo)return;
      const grupos={};
      if(completo)grupos[(dias[f]||{}).tipo||SIN_DET]=on;
      else on.forEach(s=>{const t=celda(f,s).tipo||SIN_DET;(grupos[t]=grupos[t]||[]).push(s);});
      Object.keys(grupos).forEach(tipo=>{
        const tr=grupos[tipo];const detalle={};
        tr.forEach(s=>{const x=celda(f,s);detalle[s]={aula:(x.aula||"").trim(),obs:(x.obs||"").trim()};});
        const obs=unicos(tr.map(s=>(celda(f,s).obs||"").trim()),x=>x).join(" · ");
        ausencias.push({id:tomarId(f,tipo),prof,fecha:f,hasta:"",modo:completo?"dia":"horas",horas:completo?[]:tr,motivo:tipo,obs,detalle});
      });
    });
    if(!ausencias.length&&!deSemana.length){setErr("Marca al menos una hora o un día completo.");return;}
    setOcupado(true);
    const ok=await onGuardar({ausencias,borrar:libres});
    setOcupado(false);
    if(ok===false)setErr("No se pudo guardar. Inténtalo de nuevo.");
  };

  const ctrl="w-full rounded-lg border border-divider bg-white px-2 py-1 text-xs text-ink focus:outline-none focus:ring-2";
  return(
    <div className="rounded-xl border border-divider bg-paper-warm p-4 space-y-4 fade-in">
      <div className="flex flex-wrap items-end gap-3">
        <div className="flex-1 min-w-[14rem]"><label className="lbl">Profesor/a</label>
          <select className="field" value={prof} onChange={e=>setProf(e.target.value)}>
            <option value="">— Elige profesor/a —</option>
            {profs.map(p=><option key={p} value={p}>{p}</option>)}
          </select></div>
        <div><label className="lbl">Fecha cualquiera de la semana</label>
          <input type="date" className="field" value={fecha} onChange={e=>e.target.value&&setFecha(e.target.value)}/></div>
        <div className="flex gap-1 pb-0.5">
          <button className="btn btn-ghost !px-3" aria-label="Semana anterior" onClick={()=>setFecha(sumarDias(lunes,-7))}>‹</button>
          <button className="btn btn-ghost !px-3" onClick={()=>setFecha(hoyISO())}>Esta semana</button>
          <button className="btn btn-ghost !px-3" aria-label="Semana siguiente" onClick={()=>setFecha(sumarDias(lunes,7))}>›</button>
        </div>
      </div>

      {!prof&&<p className="text-sm text-ink-soft">Elige un profesor o profesora para ver su horario de la semana y marcar las horas de ausencia.</p>}

      {prof&&<>
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="font-display font-bold text-ink">Horario completo · semana del {fmtCorta(fechas[0])} al {fmtCorta(fechas[4])}</div>
          <div className="flex items-center gap-3 text-[11px] font-semibold text-ink-soft">
            <span className="flex items-center gap-1"><i className="w-3 h-3 rounded" style={{background:"#15803d"}}/>Lectiva</span>
            <span className="flex items-center gap-1"><i className="w-3 h-3 rounded" style={{background:"#d97706"}}/>Guardia / complementaria</span>
          </div>
        </div>
        <div className="overflow-x-auto -mx-1 px-1">
          <table className="w-full border-separate" style={{borderSpacing:4,minWidth:820,tableLayout:"fixed"}}>
            <thead><tr>
              <th className="text-left align-bottom text-[11px] font-bold uppercase tracking-wide text-white rounded-lg px-2 py-2" style={{background:acento,width:84}}>Hora / Tramo</th>
              {fechas.map(f=>{const b=bloqueado(f);const d=dias[f]||{};return(
                <th key={f} className="rounded-lg px-2 py-2 text-white align-top" style={{background:acento}}>
                  <div className="font-display font-bold text-sm">{cap(fmtCorta(f))}</div>
                  {b?<div className="text-[11px] font-semibold mt-1 opacity-95">Ausencia del {fmtCorta(b.fecha)} al {fmtCorta(b.hasta)}</div>:<>
                  <label className="flex items-center justify-center gap-1.5 text-[11px] font-semibold mt-1 cursor-pointer"><input type="checkbox" checked={!!d.completo} onChange={e=>ponCompleto(f,e.target.checked)}/>Día completo</label>
                  <div className="text-[10px] font-semibold opacity-90 mt-1">Tipo</div>
                  <select className={ctrl+" !text-ink mt-0.5"} value={d.tipo||SIN_DET} onChange={e=>ponTipoDia(f,e.target.value)}>{TIPOS_REG.map(t=><option key={t}>{t}</option>)}</select></>}
                </th>);})}
            </tr></thead>
            <tbody>{filas.map(h=><tr key={h.n}>
              <td className="align-top rounded-lg bg-white border border-divider px-2 py-2 text-[11px] font-semibold text-ink-soft leading-snug">
                <div className="font-display font-bold text-ink text-sm">{labelHora(h.n)}</div>{h.l.split("–").map((t,i)=><div key={i}>{t}</div>)}</td>
              {fechas.map(f=>{
                const l=sesDe(f,h.n);
                if(!l.length)return <td key={f} className="rounded-lg bg-white/50 border border-dashed border-divider"/>;
                const x=celda(f,h.n);const b=bloqueado(f);
                const lect=l.some(e=>tipoHora(e)==="lectiva");const col=lect?"#15803d":"#d97706";
                const e0=l[0];const grupos=unicos(l,e=>e.grupo).join(", ");
                const titulo=e0.cat==="docencia"?e0.materia:ETIQUETA[e0.cat]||e0.materia;
                const id="c-"+f+"-"+h.n;
                return(
                <td key={f} className="align-top rounded-lg bg-white border p-1.5" style={{borderColor:x.on?"#be123c":"var(--divider,#e5e2db)",boxShadow:x.on?"0 0 0 1px #be123c inset":"none",opacity:b?.5:1}}>
                  <label htmlFor={id} className="flex items-start gap-1.5 rounded-md px-2 py-1 text-white text-[11px] font-semibold leading-tight cursor-pointer" style={{background:col}}>
                    <input id={id} type="checkbox" className="mt-0.5" disabled={!!b} checked={!!x.on} onChange={e=>ponCelda(f,h.n,{on:e.target.checked})}/>
                    <span className="flex-1 min-w-0"><span className="block truncate" title={titulo}>{titulo}</span><span className="opacity-90">{[grupos,aulaHorario(f,h.n)].filter(Boolean).join(" · ")}</span></span>
                  </label>
                  <div className={"space-y-1 mt-1.5 "+(x.on?"":"opacity-60")}>
                    <input className={ctrl} placeholder="Aula" aria-label={"Aula, "+labelHora(h.n)+" "+fmtCorta(f)} disabled={!!b} value={x.aula} onChange={e=>ponCelda(f,h.n,{aula:e.target.value,on:true})}/>
                    <textarea className={ctrl+" resize-y"} rows={2} placeholder="Observaciones / tarea" aria-label={"Observaciones, "+labelHora(h.n)+" "+fmtCorta(f)} disabled={!!b} value={x.obs} onChange={e=>ponCelda(f,h.n,{obs:e.target.value,on:e.target.value?true:x.on})}/>
                    <select className={ctrl} aria-label={"Tipo, "+labelHora(h.n)+" "+fmtCorta(f)} disabled={!!b} value={x.tipo} onChange={e=>ponCelda(f,h.n,{tipo:e.target.value,on:true})}>{TIPOS_REG.concat(TIPOS_REG.indexOf(x.tipo)<0?[x.tipo]:[]).map(t=><option key={t}>{t}</option>)}</select>
                  </div>
                </td>);
              })}
            </tr>)}</tbody>
          </table>
        </div>
        {largas.length>0&&<p className="text-xs text-ink-soft">Los días con una ausencia de varios días se editan desde la lista de ausencias (lápiz).</p>}
      </>}

      {err&&<p className="text-xs font-semibold text-[#be123c]">{err}</p>}
      <div className="flex flex-wrap items-center gap-2">
        <button className="btn btn-ghost" onClick={onCancel}>Cancelar</button>
        {onVariosDias&&<button className="btn btn-ghost" onClick={()=>onVariosDias(prof,fecha)}>Ausencia de varios días…</button>}
        <span className="flex-1"/>
        {prof&&<span className="text-xs font-semibold text-ink-soft">{marcadas} hora{marcadas===1?"":"s"} marcada{marcadas===1?"":"s"}</span>}
        <button className="btn btn-dark" disabled={!prof||ocupado} onClick={guardar}>{ocupado?"Guardando…":"Guardar semana"}</button>
      </div>
    </div>
  );
}

/* Cuadrante de guardias del día, igual que la pantalla de la sala de profesores (Guardias y Biblioteca) */
function CuadranteHoy({biblioteca,recreo}){
  const k=biblioteca?"vj_cuadrante_bib":recreo?"vj_cuadrante_rec2":"vj_cuadrante_hoy2";
  const[ver,setVer]=useState(()=>LS.get(k,!!biblioteca));   /* guardias: plegado por defecto */
  const alternar=()=>{LS.set(k,!ver);setVer(!ver);};
  const url=location.origin+location.pathname+(biblioteca?"?panel=biblioteca":recreo?"?panel=recreo":"?panel=sesion");
  const caja=useRef(null);
  useEffect(()=>{
    if(!ver||!caja.current)return;
    const ajustar=()=>{if(caja.current)caja.current.style.setProperty("--esc",String(caja.current.clientWidth/1920));};
    ajustar();const ro=new ResizeObserver(ajustar);ro.observe(caja.current);return()=>ro.disconnect();
  },[ver]);
  return(
    <div className="card p-3 mb-5 no-print">
      <div className="flex items-center justify-between gap-2 px-1 pb-2 flex-wrap">
        <div className="flex items-center gap-2"><span className="w-8 h-8 rounded-lg flex items-center justify-center text-white" style={{background:"#6B2D8B"}}><Ico n="pantalla" s={17}/></span>
          <div className="leading-tight"><div className="font-display font-bold text-ink text-sm">{biblioteca?"Cuadrante de la biblioteca de hoy":recreo?"Cuadrante de guardias de recreo de hoy":"Cuadrante de guardias de hoy"}</div>
          <div className="text-[11px] text-ink-soft font-medium">{biblioteca?"Atención a biblioteca (G.B.), MAY55 y guardias de recreo en biblioteca · se actualiza solo cada minuto":recreo?"Quién está de guardia en cada recreo, en el patio y en la biblioteca · se actualiza solo cada minuto":"El mismo que se proyecta en la sala de profesores · se actualiza solo cada minuto"}</div></div></div>
        <div className="flex gap-2">
          {ver&&<button className="btn btn-ghost !min-h-[36px] !px-3 text-xs" onClick={()=>window.open(url,biblioteca?"cuadrante_bib":recreo?"cuadrante_rec":"cuadrante_hoy")}><Ico n="enlace" s={14}/>Pantalla completa</button>}
          <button className="btn btn-ghost !min-h-[36px] !px-3 text-xs" aria-expanded={ver} onClick={alternar}>{ver?"Ocultar":"Ver cuadrante"}</button>
        </div>
      </div>
      {ver&&<div ref={caja} className="relative w-full overflow-hidden rounded-xl border border-divider" style={{aspectRatio:"16/9"}}>
        <iframe title={biblioteca?"Cuadrante de la biblioteca de hoy":recreo?"Cuadrante de guardias de recreo de hoy":"Cuadrante de guardias de hoy"} src={url} className="absolute top-0 left-0 border-0 origin-top-left" style={{width:"1920px",height:"1080px",transform:"scale(var(--esc,0.4))"}}/>
      </div>}
    </div>
  );
}

/* ── Firma de las guardias: cada profesor/a marca su guardia de hoy; queda la fecha y la hora para Jefatura ── */
function FirmaGuardias({tipo}){
  const[d,setD]=useState(null);const[ocupado,setOcupado]=useState("");const[err,setErr]=useState("");
  const cargar=()=>pedir("GET","/guardias/firmas/mias").then(setD).catch(()=>{});
  useEffect(()=>{cargar();const t=setInterval(cargar,60000);return()=>clearInterval(t);},[]);
  if(!d||!d.profesor)return null;
  const l=d.guardias.filter(g=>tipo==="recreo"?g.tipo==="recreo":g.tipo==="aula");
  if(!l.length)return null;
  const firmar=async g=>{setOcupado(g.tramo);setErr("");try{setD(await pedir("POST","/guardias/firmas",{tramo:g.tramo}));}catch(e){setErr(e.message);}setOcupado("");};
  const zona=z=>({zona1:"Zona 1",zona2:"Zona 2",zona3:"Zona 3",biblioteca:"Biblioteca"}[z]||"");
  return(
    <div className="card p-4 mb-5 border-l-4 no-print" style={{borderLeftColor:tipo==="recreo"?"#0d9488":"#d97706"}}>
      <div className="font-display font-bold text-ink flex items-center gap-2"><Ico n="check" s={18}/>Firma de mis guardias de {tipo==="recreo"?"recreo":"aula"} · hoy</div>
      <p className="text-xs text-ink-soft mb-3">Marca la casilla al hacer cada guardia (desde 10 minutos antes). Jefatura de Estudios recibe el registro con la fecha y la hora de tu firma.</p>
      <div className="flex flex-wrap gap-2">{l.map(g=>{const f=!!g.firmado;return(
        <label key={g.tramo} className={"flex items-center gap-3 rounded-xl border-2 px-4 py-2.5 min-w-[14rem] flex-1 "+(f?"":g.puede?"cursor-pointer hover:shadow-md":"opacity-60")} style={f?{borderColor:"#16a34a",background:"#f0fdf4"}:{borderColor:"#e7e1ec"}}>
          <input type="checkbox" className="w-6 h-6" style={{accentColor:"#16a34a"}} checked={f} disabled={f||!g.puede||!!ocupado} onChange={()=>firmar(g)} aria-label={"Firmar guardia "+labelHora(g.tramo)}/>
          <span className="flex-1 leading-tight"><b className="text-ink text-sm">{labelHora(g.tramo)} · {g.inicio}–{g.fin}</b>{g.zona&&<span className="text-xs text-ink-soft"> · {zona(g.zona)}</span>}
            <span className={"block text-xs font-semibold "+(f?"text-[#166534]":"text-ink-soft")}>{f?"Firmada a las "+g.firmado.slice(11,16):g.puede?"Pendiente de firmar":"Podrás firmarla 10 min antes"}</span></span>
        </label>);})}</div>
      {err&&<p className="text-xs font-semibold text-[#be123c] mt-2" role="alert">{err}</p>}
    </div>);
}
/* Registro de firmas de guardia (Jefatura de Estudios) */
function PantallaFirmas({tile,onBack,arriba}){
  const[desde,setDesde]=useState(hoyISO());const[hasta,setHasta]=useState(hoyISO());const[r,setR]=useState(null);const[err,setErr]=useState("");
  const[solo,setSolo]=useState("todas");
  const cargar=()=>pedir("GET","/guardias/firmas?desde="+desde+"&hasta="+hasta).then(x=>{setR(x);setErr("");}).catch(e=>setErr(e.message));
  useEffect(()=>{cargar();},[desde,hasta]);
  return(
    <Seccion tile={tile} onBack={onBack}>
      {arriba}
      <div className="card p-4 mb-4 flex flex-wrap items-end gap-3 no-print">
        <div><label className="lbl">Desde</label><input type="date" className="field !w-auto" value={desde} onChange={e=>setDesde(e.target.value)}/></div>
        <div><label className="lbl">Hasta</label><input type="date" className="field !w-auto" value={hasta} onChange={e=>setHasta(e.target.value)}/></div>
        <div className="flex gap-1.5">{[["todas","Todas"],["sin","Sin firmar"],["con","Firmadas"]].map(([k,l])=><button key={k} className={"chip"+(solo===k?" on":"")} style={solo===k?{background:"#334155"}:{}} onClick={()=>setSolo(k)}>{l}</button>)}</div>
        <div className="flex-1"/>
        <button className="btn btn-ghost" onClick={cargar}><Ico n="reloj" s={16}/>Actualizar</button>
        <a className="btn btn-dark" href={API+"/guardias/firmas?formato=csv&desde="+desde+"&hasta="+hasta}><Ico n="informe" s={16}/>Descargar CSV</a>
      </div>
      {err&&<div className="card p-4 text-sm font-semibold text-[#9f1239]">{err}</div>}
      {r&&!r.dias.length&&<div className="card p-6 text-sm text-ink-soft text-center">No hay guardias en esas fechas.</div>}
      {r&&r.dias.map(d=>(
        <div key={d.fecha} className="card p-4 mb-4">
          <div className="flex items-center gap-2 mb-2 flex-wrap"><b className="font-display text-ink">{cap(fmtLarga(d.fecha))}</b>
            <span className="pill" style={d.firmadas===d.total?{background:"#dcfce7",color:"#166534"}:{background:"#fef3c7",color:"#92400e"}}>{d.firmadas} de {d.total} firmadas</span>
            {d.filas.some(f=>!f.firmado&&!f.ausente&&!f.futura)&&<span className="pill" style={{background:"#ffe4e6",color:"#9f1239"}}>{d.filas.filter(f=>!f.firmado&&!f.ausente&&!f.futura).length} sin firmar</span>}</div>
          <table className="w-full text-sm"><thead><tr className="text-left text-[11px] uppercase tracking-wide text-ink-soft"><th className="py-1">Tramo</th><th>Tipo</th><th>Profesor/a</th><th>Firma</th></tr></thead>
            <tbody>{d.filas.filter(f=>solo==="todas"||(solo==="con"?f.firmado:!f.firmado)).map((f,i)=><tr key={i} className="border-t border-divider">
              <td className="py-1.5 font-semibold whitespace-nowrap">{labelHora(f.tramo)} <span className="text-[11px] text-ink-soft font-medium">{f.inicio}</span></td>
              <td className="text-xs">{f.tipo==="recreo"?"Recreo"+(f.zona?" · "+({zona1:"Zona 1",zona2:"Zona 2",zona3:"Zona 3",biblioteca:"Biblioteca"}[f.zona]||""):""):"Aula"}</td>
              <td className="font-semibold text-ink">{f.profesor}</td>
              <td>{f.firmado?<span className="pill" style={{background:"#dcfce7",color:"#166534"}}>✓ {f.firmado.slice(8,10)}/{f.firmado.slice(5,7)} · {f.firmado.slice(11,16)}</span>
                :f.ausente?<span className="pill" style={{background:"#f1f5f9",color:"#475569"}}>Ausente</span>:f.futura?<span className="pill" style={{background:"#f1f5f9",color:"#475569"}}>Aún no ha empezado</span>:<span className="pill" style={{background:"#ffe4e6",color:"#9f1239"}}>Sin firmar</span>}</td></tr>)}</tbody></table>
        </div>))}
    </Seccion>);
}

/* ── CCP · Comisión de Coordinación Pedagógica: convocatorias, «Enterado/a» y miembros ── */
function PantallaCcp({tile,onBack,onToast,onAvisos}){
  const[d,setD]=useState(null);const[err,setErr]=useState("");const[form,setForm]=useState(null);const[ocupado,setOcupado]=useState(false);
  const[organo,setOrgano]=useState("ccp");
  const cargar=(o=organo)=>pedir("GET","/ccp?organo="+o).then(x=>{setD(x);setErr("");}).catch(async e=>{
    if(o==="ccp"){try{const x=await pedir("GET","/ccp?organo=consejo");setOrgano("consejo");setD(x);return;}catch(e2){}}setErr(e.message);});
  useEffect(()=>{setForm(null);cargar(organo);},[organo]);
  const hacer=async(fn,msg)=>{setOcupado(true);try{setD(await fn());if(msg)onToast(msg);onAvisos&&onAvisos();}catch(e){onToast(e.message);}setOcupado(false);};
  if(err)return <Seccion tile={tile} onBack={onBack}><div className="card p-5 text-sm font-semibold text-[#9f1239]">{err}</div></Seccion>;
  if(!d)return <Seccion tile={tile} onBack={onBack}><div className="card p-5 text-sm text-ink-soft">Cargando…</div></Seccion>;
  const C=organo==="consejo"?"#991b1b":"#c2410c";const NOM=organo==="consejo"?"el Consejo Escolar":"la CCP";
  return(
    <Seccion tile={tile} onBack={onBack}>
      <div className="flex flex-wrap gap-2 mb-4 no-print" role="tablist">
        {[["ccp","CCP"],["consejo","Consejo Escolar"]].filter(([k])=>!d.accesos||d.accesos[k]).map(([k,l])=><button key={k} role="tab" aria-selected={organo===k} className={"chip"+(organo===k?" on":"")} style={organo===k?{background:k==="consejo"?"#991b1b":"#c2410c"}:{}} onClick={()=>setOrgano(k)}>{l}</button>)}
      </div>
      <div className="flex flex-wrap items-center gap-3 mb-4">
        <p className="text-sm text-ink-soft flex-1 min-w-[16rem]">{organo==="consejo"?"Consejo Escolar: representantes del profesorado (perfil «Consejo Escolar»), la Directora y los Jefes/as de Estudios.":"Comisión de Coordinación Pedagógica: jefes/as de departamento, la Directora, el Jefe/a de Estudios y Rosa Sánchez."} Solo convocan la Directora y los Jefes/as de Estudios. Cada miembro recibe el aviso en la portada y confirma con «Enterado/a». Las reuniones de los próximos 14 días se proyectan en rojo en «Avisos» de la sala de profesores.</p>
        {d.convoca&&<button className="btn btn-dark" style={{background:C}} onClick={()=>setForm({organo,fecha:"",hora:organo==="consejo"?"17:00":"16:30",lugar:organo==="consejo"?"Biblioteca":"Sala de reuniones",orden:"1. Lectura y aprobación, si procede, del acta de la sesión anterior.\n2. \n3. Ruegos y preguntas."})}><Ico n="mas" s={16}/>Convocar reunión</button>}
      </div>
      {form&&<div className="card p-5 mb-4 border-l-4 space-y-3 fade-in" style={{borderLeftColor:C}}>
        <div className="font-display font-bold text-ink">{form.id?"Modificar la convocatoria":"Nueva convocatoria de "+NOM}</div>
        <div className="grid sm:grid-cols-3 gap-3">
          <div><label className="lbl">Fecha</label><input type="date" className="field" min={d.hoy} value={form.fecha} onChange={e=>setForm({...form,fecha:e.target.value})}/></div>
          <div><label className="lbl">Hora</label><input type="time" className="field" value={form.hora} onChange={e=>setForm({...form,hora:e.target.value})}/></div>
          <div><label className="lbl">Lugar</label><input className="field" value={form.lugar} onChange={e=>setForm({...form,lugar:e.target.value})}/></div>
        </div>
        <div><label className="lbl">Orden del día</label><textarea className="field" rows={5} value={form.orden} onChange={e=>setForm({...form,orden:e.target.value})}/></div>
        {form.id&&<p className="text-[11px] text-[#b45309] font-semibold">Al modificarla, los miembros tendrán que volver a confirmar.</p>}
        <div className="flex gap-2"><button className="btn btn-dark" style={{background:C}} disabled={ocupado||!form.fecha} onClick={()=>hacer(()=>pedir("POST","/ccp",{...form,organo}),"Convocatoria enviada a los miembros de "+NOM).then(()=>setForm(null))}>{form.id?"Guardar cambios":"Enviar convocatoria"}</button>
          <button className="btn btn-ghost" onClick={()=>setForm(null)}>Cancelar</button></div>
      </div>}
      {!d.reuniones.length&&<div className="card p-6 text-sm text-ink-soft text-center mb-4">No hay reuniones convocadas.</div>}
      <div className="space-y-3 mb-5">{d.reuniones.map(r=>{
        const faltan=d.miembros.filter(m=>!r.enterados.some(e=>e.usuario===m.usuario));
        return(
        <div key={r.id} className={"card p-4 border-l-4"+(r.proxima?"":" opacity-70")} style={{borderLeftColor:r.anulada?"#94a3b8":r.proxima?C:"#cbd5e1"}}>
          <div className="flex flex-wrap items-start gap-3">
            <div className="flex-1 min-w-[16rem]">
              <div className="flex items-center gap-2 flex-wrap"><b className="font-display text-ink text-lg">{cap(fmtLarga(r.fecha))} · {r.hora}</b>
                {r.anulada?<span className="pill" style={{background:"#f1f5f9",color:"#475569"}}>Anulada</span>:r.proxima?<span className="pill" style={{background:"#ffedd5",color:"#9a3412"}}>Próxima</span>:<span className="pill" style={{background:"#f1f5f9",color:"#475569"}}>Celebrada</span>}</div>
              <div className="text-xs text-ink-soft">{r.lugar}{r.convoca?" · convoca "+nomNat(r.convoca):""}</div>
              {r.orden&&<pre className="mt-2 text-sm text-ink whitespace-pre-wrap font-body bg-paper-warm rounded-xl p-3">{r.orden}</pre>}
            </div>
            <div className="flex flex-col gap-2 items-end">
              {d.miembro&&r.proxima&&!r.anulada&&(r.yoEnterado?<span className="pill" style={{background:"#dcfce7",color:"#166534"}}>✓ Enterado/a</span>
                :<button className="btn btn-dark !min-h-[38px]" style={{background:"#16a34a"}} disabled={ocupado} onClick={()=>hacer(()=>pedir("POST","/ccp/"+r.id+"/enterado",{}),"Confirmado")}>✓ Enterado/a</button>)}
              {d.convoca&&r.proxima&&<div className="flex gap-1.5">
                <button className="btn btn-ghost !min-h-[34px] text-xs" onClick={()=>setForm({id:r.id,fecha:r.fecha,hora:r.hora,lugar:r.lugar,orden:r.orden})}>Modificar</button>
                <button className="btn btn-ghost !min-h-[34px] text-xs" disabled={ocupado} onClick={()=>{if(confirm(r.anulada?"¿Volver a convocar esta reunión?":"¿Anular esta reunión? Se avisará a los miembros."))hacer(()=>pedir("POST","/ccp/"+r.id+"/anular",{}),r.anulada?"Reunión convocada de nuevo":"Reunión anulada");}}>{r.anulada?"Reactivar":"Anular"}</button></div>}
            </div>
          </div>
          {d.convoca&&r.proxima&&!r.anulada&&<div className="mt-3 pt-3 border-t border-divider text-xs">
            <b className="text-ink">Confirmada por {r.enterados.length} de {d.miembros.length}</b>
            {faltan.length>0&&<span className="text-ink-soft"> · faltan: {faltan.map(m=>nomNat(m.nombre)).join(", ")}</span>}</div>}
        </div>);})}</div>
      <div className="card p-4">
        <div className="font-display font-bold text-ink mb-2">Miembros de {NOM} ({d.miembros.length})</div>
        {!d.miembros.length?<p className="text-sm text-ink-soft">Aún no hay miembros: asigna los perfiles «Jefe/a de departamento», «Dirección», «Jefe/a de Estudios» (todas las etapas) o «Miembro de la CCP» en Usuarios.</p>
          :<div className="grid sm:grid-cols-2 gap-x-6 gap-y-1">{d.miembros.map(m=><div key={m.usuario} className="text-sm py-1 border-b border-divider"><b className="text-ink">{nomNat(m.nombre)}</b> <span className="text-xs text-ink-soft">· {m.cargo}</span></div>)}</div>}
      </div>
    </Seccion>);
}

function PantallaGuardias({tile,onBack,tipo,remotas,conectado,admin,ops,profs,clave,arriba,yo,esAdminCuenta}){
  const[biblio,setBiblio]=useRecreoBiblio();
  const[marcando,setMarcando]=useState("");
  const[menuZona,setMenuZona]=useState("");   /* «tramo|profesor» con el selector de zona abierto */
  const[verMapa,setVerMapa]=useState(()=>LS.get("vj_mapa_zonas",true));
  const enBib=(s,p)=>biblio.some(x=>x.dia===dia&&x.tramo===s&&x.profesor===p&&(x.zona||"biblioteca")==="biblioteca");
  const zonaDeProf=(s,p)=>{const x=biblio.find(r=>r.dia===dia&&r.tramo===s&&r.profesor===p);return x?(x.zona||"biblioteca"):"";};
  const puedeZona=p=>esAdminCuenta||admin||(yo&&quitarTildes(yo)===quitarTildes(p));
  const elegirZona=async(s,p,z)=>{
    setMarcando(s+"|"+p);setMenuZona("");
    try{setBiblio(await apuntarZona(dia,s,p,z));}catch(e){alert(e.message);}
    setMarcando("");
  };
  const marcarBib=async(s,p)=>{
    if(!admin||marcando)return;
    setMarcando(s+"|"+p);
    try{setBiblio(await RecreoBiblio.marcar(clave,dia,s,p,!enBib(s,p)));}catch(e){alert(e.message);}
    setMarcando("");
  };
  const semana=useMemo(semanaActual,[]);
  const hoyG=new Date();const mesHoy=hoyG.getMonth(),anioHoy=hoyG.getFullYear();
  const[dia,setDia]=useState(tipo==="guardia"&&new Date().getDay()>=1&&new Date().getDay()<=5?new Date().getDay():0);
  const[lista,setLista]=useState(null);   /* ausencias con motivo (solo administrador) */
  const[form,setForm]=useState(null);
  const[rejilla,setRejilla]=useState(null);   /* registro semanal {prof,fecha} */
  const iso=dia?semana[dia-1].iso:"";
  const gestion=admin&&tipo==="guardia";
  const cargarLista=async()=>{if(gestion)setLista(await ops.ausenciasAdmin());};
  useEffect(()=>{if(gestion)cargarLista();else setLista(null);},[gestion,remotas]);

  /* Conectado: la hoja manda (lo borrado allí desaparece aquí).
     Sin conexión: se añaden las notificadas desde este equipo que no llegaron a enviarse. */
  const fuente=useMemo(()=>{
    const base=((gestion&&lista)?lista:remotas).filter(a=>a.estado!=="Pendiente");  /* solo las grabadas por Jefatura */
    if(conectado)return base;
    const locales=LS.get("vj_hor_ausencias",[]).filter(l=>!base.some(r=>r.id===l.id));
    return base.concat(locales);
  },[remotas,lista,gestion,conectado]);
  const ausentes=useMemo(()=>{
    if(!iso||tipo!=="guardia")return[];
    return fuente.filter(a=>enRango(a,iso)).map(a=>({...a,prof:nombreHorario(a.prof)}))
      .sort((a,b)=>a.prof.localeCompare(b.prof,"es"));
  },[iso,fuente,tipo]);
  const ausentesHora=s=>ausentes.filter(a=>a.modo==="dia"||(a.horas||[]).map(String).indexOf(s)>=0).map(a=>a.prof);

  const usadosG=new Set(ENTRADAS.filter(e=>e.cat===tipo).map(e=>e.slot));
  const slots=HORAS.filter(h=>tipo==="recreo"?h.r:(!h.r&&(!h.t||usadosG.has(h.n)))).map(h=>h.n);
  const filas=slots.map(s=>{
    const fuera=tipo==="guardia"?ausentesHora(s):[];
    const todos=unicos(ENTRADAS.filter(e=>e.cat===tipo&&e.dia===dia&&String(e.slot)===s),e=>e.profesor).sort((a,b)=>a.localeCompare(b,"es"));
    const profsG=todos.filter(p=>fuera.indexOf(p)<0);       /* profesorado de guardia disponible */
    const guardiaAusente=todos.filter(p=>fuera.indexOf(p)>=0); /* de guardia pero ausente */
    const sinCubrir=[];
    ausentes.forEach(a=>{
      if(a.modo!=="dia"&&(a.horas||[]).map(String).indexOf(s)<0)return;
      ENTRADAS.filter(e=>e.profesor===a.prof&&e.dia===dia&&String(e.slot)===s&&(e.cat==="docencia"||(e.cat==="tutoria"&&e.grupo)))
        .forEach(e=>{const d=(a.detalle||{})[s]||{};if(!sinCubrir.some(c=>c.prof===a.prof&&c.grupo===e.grupo))sinCubrir.push({prof:a.prof,grupo:e.grupo,aula:d.aula||e.aula,materia:e.materia,obs:d.obs||(Object.keys(a.detalle||{}).length?"":a.obs)});});
    });
    return{s,profs:profsG,guardiaAusente,sinCubrir,hora:horaDe(s).l};
  });

  const guardar=async a=>{const ok=await ops.ausenciaGuardar(a);if(ok){setForm(null);}return ok;};
  const borrar=async a=>{if(confirm("¿Eliminar la ausencia de "+nombreHorario(a.prof)+" ("+fmtCorta(a.fecha)+")? Se borrará definitivamente."))await ops.ausenciaBorrar([a.id]);};
  const grabar=async ids=>{await ops.ausenciaGrabar(ids);};
  const pendientes=gestion?(lista||[]).filter(a=>a.estado==="Pendiente")
    .sort((a,b)=>a.fecha.localeCompare(b.fecha)||a.prof.localeCompare(b.prof,"es")):[];
  const vacio=()=>({id:"",prof:"",fecha:iso||hoyISO(),hasta:"",modo:"dia",horas:[],motivo:"Cita médica",obs:""});
  const listaAdmin=gestion?(lista||[]).filter(a=>a.estado!=="Pendiente").filter(a=>iso?enRango(a,iso):(a.hasta||a.fecha)>=hoyISO())
    .sort((a,b)=>a.fecha.localeCompare(b.fecha)||a.prof.localeCompare(b.prof,"es")):[];

  return(
    <Seccion tile={tile} onBack={onBack}>
      {arriba}
      <CuadranteHoy recreo={tipo==="recreo"}/>
      {tipo==="recreo"&&<div className="card p-3 mb-5 no-print">
        <div className="flex items-center justify-between gap-2 px-1 pb-2 flex-wrap">
          <div className="flex items-center gap-2"><span className="w-8 h-8 rounded-lg flex items-center justify-center text-white" style={{background:"#0d9488"}}><Ico n="aula" s={17}/></span>
            <div className="leading-tight"><div className="font-display font-bold text-ink text-sm">Zonas de vigilancia del recreo</div>
            <div className="flex flex-wrap gap-x-3 gap-y-1 mt-0.5">{ZONAS_REC.map(z=><span key={z.k} className="inline-flex items-center gap-1 text-[11px] font-semibold text-ink-soft"><i className="w-2.5 h-2.5 rounded-full" style={{background:z.c}}/>{z.l}</span>)}</div></div></div>
          <button className="btn btn-ghost !min-h-[36px] !px-3 text-xs" aria-expanded={verMapa} onClick={()=>{LS.set("vj_mapa_zonas",!verMapa);setVerMapa(!verMapa);}}>{verMapa?"Ocultar mapa":"Ver mapa"}</button>
        </div>
        <ul className="grid sm:grid-cols-2 gap-2 mb-3">{ZONAS_REC.map(z=><li key={z.k} className="rounded-xl px-3 py-2 border-l-4 text-xs leading-snug" style={{background:z.f,borderColor:z.c,color:z.t}}>
          <div className="font-bold text-sm mb-0.5">{z.l} · {z.s}</div>{z.d}
          {z.aviso&&<div className="mt-1.5 font-bold flex gap-1.5 items-start" style={{color:"#b91c1c"}}><span aria-hidden="true">⚠</span><span>{z.aviso}</span></div>}</li>)}</ul>
        {verMapa&&<a href={MAPA_ZONAS} target="_blank" rel="noopener noreferrer" title="Abrir el mapa en grande" className="block"><img src={MAPA_ZONAS} alt="Mapa de las zonas de vigilancia" width="1206" height="820" className="block w-full h-auto rounded-xl border border-divider"/></a>}
      </div>}
      <div className="flex items-center gap-3 mb-5">
        <span className="inline-flex items-center justify-center w-12 h-12 rounded-xl text-white flex-shrink-0" style={{background:"linear-gradient(135deg,"+tile.g[0]+","+tile.g[1]+")"}}><Ico n="calendario" s={24}/></span>
        <div className="leading-tight">
          <div className="font-display font-bold text-xl text-ink tracking-tight">{cap(MESES[mesHoy])} {anioHoy}</div>
          <div className="text-xs text-ink-soft font-medium mt-0.5">Semana del {semana[0].num}{semana[0].mes!==semana[4].mes?" de "+MESES[semana[0].mes]:""} al {semana[4].num} de {MESES[semana[4].mes]}</div>
        </div>
      </div>
      <p className="text-sm text-ink-soft font-medium mb-4 no-print">¿Qué día quieres consultar?</p>
      <div className="flex flex-wrap gap-2 mb-6 no-print">
        {semana.map(d=>{
          const n=tipo==="guardia"?fuente.filter(a=>enRango(a,d.iso)).length:0;
          return(
          <button key={d.dia} onClick={()=>setDia(dia===d.dia?0:d.dia)} className={"chip relative !px-4 text-center "+(dia===d.dia?"on":"")} style={dia===d.dia?{background:tile.g[0]}:{}}>
            <div className="text-[11px] opacity-80">{DIAS[d.dia-1]}</div>
            <div className="text-base font-bold leading-none">{d.num}</div>
            {d.mes!==mesHoy&&<div className="text-[10px] font-semibold uppercase tracking-wide opacity-80 mt-0.5">{MESES[d.mes].slice(0,3)}</div>}
            {n>0&&<span className="absolute -top-2 -right-2 min-w-[20px] h-5 px-1 rounded-full bg-[#be123c] text-white text-[10px] font-bold flex items-center justify-center border-2 border-white" title={n+" ausencia(s)"}>{n}</span>}
          </button>);
        })}
      </div>

      {gestion&&pendientes.length>0&&(
        <div className="card p-4 mb-4 space-y-3 no-print border-l-4" style={{borderLeftColor:"#be123c"}}>
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div>
              <div className="font-display font-bold text-ink">Notificadas por el profesorado · pendientes de grabar ({pendientes.length})</div>
              <div className="text-xs text-ink-soft font-medium">No aparecen en Guardias de aula hasta que las grabes. Puedes corregirlas antes con el lápiz.</div>
            </div>
            {pendientes.length>1&&<button className="btn btn-dark" onClick={()=>{if(confirm("¿Grabar las "+pendientes.length+" ausencias pendientes?"))grabar(pendientes.map(a=>a.id));}}>Grabar todas</button>}
          </div>
          <div className="divide-y divide-divider">
            {pendientes.map(a=>(
              <div key={a.id} className="py-2.5 flex items-start gap-2 flex-wrap sm:flex-nowrap">
                <div className="flex-1 min-w-[12rem]">
                  <div className="text-sm font-bold text-ink">{nombreHorario(a.prof)}</div>
                  <div className="text-xs text-ink-soft font-medium">{fmtCorta(a.fecha)}{a.hasta?" → "+fmtCorta(a.hasta):""} · {textoHoras(a)}{a.motivo?" · "+a.motivo:""}{a.creado?" · notificada el "+fmtCorta(a.creado):""}</div>
                  {a.obs&&<div className="text-xs text-ink-soft mt-0.5 italic">{a.obs}</div>}
                  {!PROF_NORM[quitarTildes(a.prof).replace(/\s+/g," ").trim()]&&<div className="text-[11px] font-semibold text-[#be123c] mt-0.5">El nombre no coincide con ningún horario: edítalo antes de grabar.</div>}
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  <button className="btn btn-dark !px-3 !py-1.5 text-xs" onClick={()=>grabar([a.id])}><Ico n="check" s={14}/>Grabar</button>
                  <button className="p-2 rounded-lg hover:bg-black/5 text-ink-soft" aria-label="Editar y grabar" onClick={()=>setForm({id:a.id,prof:nombreHorario(a.prof),fecha:a.fecha,hasta:a.hasta||"",modo:a.modo,horas:(a.horas||[]).map(String),motivo:a.motivo||"Otro",obs:a.obs||""})}><Ico n="lapiz" s={18}/></button>
                  <button className="p-2 rounded-lg hover:bg-rose-50 text-[#be123c]" aria-label="Eliminar notificación" onClick={()=>borrar(a)}><Ico n="papelera" s={18}/></button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      {gestion&&(
        <div className="card p-4 mb-6 space-y-3 no-print">
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div>
              <div className="font-display font-bold text-ink">Administrador · Ausencias grabadas {iso?"del "+fmtLarga(iso):"próximas"}</div>
              <div className="text-xs text-ink-soft font-medium">Se guardan en la base de datos de la app y cuentan en los informes mensuales.</div>
            </div>
            {!form&&!rejilla&&<button className="btn btn-dark" onClick={()=>setRejilla({prof:"",fecha:iso||hoyISO()})}><Ico n="mas" s={16}/>Registrar ausencia</button>}
          </div>
          {rejilla&&<RegistroSemanalAusencias key={rejilla.prof+"|"+rejilla.fecha} inicial={rejilla} lista={lista} profs={profs} acento={tile.g[0]} onCancel={()=>setRejilla(null)}
            onVariosDias={(p,f)=>{setRejilla(null);setForm({...vacio(),prof:p,fecha:f});}}
            onGuardar={async d=>{const ok=await ops.ausenciasSemana(d);if(ok){setRejilla(null);cargarLista();}return ok;}}/>}
          {form&&<FormAusenciaAdmin key={form.id||"nueva"} inicial={form} profs={profs} acento={tile.g[0]} onCancel={()=>setForm(null)} onSave={guardar}/>}
          {lista===null&&<p className="text-xs text-ink-soft">Cargando ausencias…</p>}
          {lista!==null&&listaAdmin.length===0&&<p className="text-sm text-ink-soft">No hay ausencias grabadas {iso?"para este día":"a partir de hoy"}.</p>}
          {listaAdmin.length>0&&(
            <div className="divide-y divide-divider">
              {listaAdmin.map(a=>{
                const reconocido=!!PROF_NORM[quitarTildes(a.prof).replace(/\s+/g," ").trim()];
                return(
                <div key={a.id} className="py-2.5 flex items-start gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-bold text-ink">{nombreHorario(a.prof)}</div>
                    <div className="text-xs text-ink-soft font-medium">{fmtCorta(a.fecha)}{a.hasta?" → "+fmtCorta(a.hasta):""} · {textoHoras(a)}{a.motivo?" · "+a.motivo:""}</div>
                    {a.obs&&<div className="text-xs text-ink-soft mt-0.5 italic">{a.obs}</div>}
                    {!reconocido&&<div className="text-[11px] font-semibold text-[#be123c] mt-0.5">El nombre no coincide con ningún horario: edítalo con el lápiz.</div>}
                  </div>
                  <button className="p-2 rounded-lg hover:bg-black/5 text-ink-soft" aria-label="Editar ausencia" onClick={()=>a.hasta?setForm({id:a.id,prof:nombreHorario(a.prof),fecha:a.fecha,hasta:a.hasta||"",modo:a.modo,horas:(a.horas||[]).map(String),motivo:a.motivo||"Otro",obs:a.obs||""}):(setForm(null),setRejilla({prof:nombreHorario(a.prof),fecha:a.fecha}))}><Ico n="lapiz" s={18}/></button>
                  <button className="p-2 rounded-lg hover:bg-rose-50 text-[#be123c]" aria-label="Quitar ausencia" onClick={()=>borrar(a)}><Ico n="papelera" s={18}/></button>
                </div>);
              })}
            </div>
          )}
        </div>
      )}

      {dia>0&&(
        <div className="space-y-3 fade-in">
          {tipo==="guardia"&&(ausentes.length>0?(
            <div className="rounded-xl border-l-4 border-[#be123c] bg-rose-50 p-4">
              <div className="font-bold text-sm text-[#9f1239] mb-1">Profesorado ausente ({ausentes.length})</div>
              <div className="text-xs text-[#9f1239] font-medium leading-relaxed">
                {ausentes.map((a,i)=><span key={a.id||i}>{i>0&&" · "}{a.prof} ({textoHoras(a)})</span>)}
              </div>
            </div>
          ):(
            <div className="rounded-xl border-l-4 border-olive bg-olive-light p-3 text-xs font-semibold text-olive">Sin ausencias registradas para este día.</div>
          ))}
          {tipo==="recreo"&&(
            <div className="rounded-xl border-l-4 p-3 text-xs font-semibold no-print flex items-start gap-2" style={{borderColor:"#0d9488",background:"#0d948814",color:"#0f766e"}}>
              <Ico n="campana" s={16}/><span>{esAdminCuenta||admin?"Toca el nombre de cualquier profesor/a de guardia para asignarle una zona.":"Toca tu nombre en tu guardia de recreo para apuntarte a una zona."} Cada recreo debe tener cubiertas las cuatro: Zona 1, Zona 2, Zona 3 y Biblioteca. Se repite cada {DIAS[dia-1].toLowerCase()}.</span>
            </div>
          )}
          {filas.map(f=>(
            <div key={f.s} className="card p-4 flex gap-4 items-start">
              <div className="w-16 flex-shrink-0 text-center rounded-xl py-2 text-white" style={{background:"linear-gradient(135deg,"+tile.g[0]+","+tile.g[1]+")"}}>
                <div className="font-display font-bold text-lg leading-none">{tipo==="guardia"?f.s+"ª":f.s}</div>
                {f.hora&&<div className="text-[9px] mt-1 opacity-90 font-medium">{f.hora}</div>}
              </div>
              <div className="flex-1 min-w-0">
                {f.profs.length===0&&f.guardiaAusente.length===0
                  ?<p className="text-sm text-ink-soft py-1.5">Sin profesorado de guardia</p>
                  :<div className="flex flex-wrap gap-1.5">
                    {tipo==="recreo"&&f.profs.map(p=>{
                      const z=zonaDe(zonaDeProf(f.s,p));const k=f.s+"|"+p;const puede=puedeZona(p);
                      const estilo=z?{background:z.c,color:z.k==="zona1"?z.t:"#fff"}:{background:tile.g[0]+"18",color:tile.g[0]};
                      const cont=<>{p}<span className="font-semibold opacity-90 whitespace-nowrap">· {z?z.l:"sin zona"}</span></>;
                      return(
                        <span key={p} className="relative inline-block">
                          {puede
                            ?<button type="button" aria-expanded={menuZona===k} disabled={!!marcando} onClick={()=>setMenuZona(menuZona===k?"":k)}
                                title="Elegir zona de vigilancia" className={"inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition hover:ring-2 hover:ring-black/20"+(marcando===k?" opacity-50":"")+(yo&&quitarTildes(yo)===quitarTildes(p)?" ring-2 ring-offset-1 ring-[#0d9488]":"")} style={estilo}>{cont}</button>
                            :<span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold" style={estilo}>{cont}</span>}
                          {menuZona===k&&<span className="absolute z-30 left-0 top-full mt-1 bg-white rounded-xl shadow-xl border border-divider p-1.5 flex flex-col gap-1 min-w-[15rem]">
                            {ZONAS_REC.map(o=><button key={o.k} type="button" onClick={()=>elegirZona(f.s,p,o.k)} className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs font-bold text-left hover:bg-black/5" style={{color:o.t}}>
                              <i className="w-3.5 h-3.5 rounded-full flex-shrink-0" style={{background:o.c}}/><span className="leading-tight">{o.l}{z&&z.k===o.k&&" ✓"}<span className="block text-[10px] font-medium opacity-80">{o.s}</span></span></button>)}
                            {z&&<button type="button" onClick={()=>elegirZona(f.s,p,"")} className="px-2.5 py-1.5 rounded-lg text-xs font-semibold text-left text-ink-soft hover:bg-black/5">Quitar zona</button>}
                          </span>}
                        </span>);
                    })}
                    {tipo!=="recreo"&&f.profs.map(p=>{
                      if(tipo!=="recreo")return <span key={p} className="px-3 py-1.5 rounded-full text-xs font-bold" style={{background:tile.g[0]+"18",color:tile.g[0]}}>{p}</span>;
                      const b=enBib(f.s,p);
                      const estilo=b?{background:"#7c4a1d",color:"#fff"}:{background:tile.g[0]+"18",color:tile.g[0]};
                      const cont=<>{b&&<Ico n="libro" s={14}/>}{p}{b&&<span className="font-semibold opacity-90 whitespace-nowrap">· Biblioteca</span>}</>;
                      return admin
                        ?<button key={p} type="button" aria-pressed={b} disabled={!!marcando} onClick={()=>marcarBib(f.s,p)}
                            title={b?"Quitar: ya no hace la guardia en la biblioteca":"Marcar: hace esta guardia de recreo en la biblioteca"}
                            className={"inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition hover:ring-2 hover:ring-[#7c4a1d]/40"+(marcando===f.s+"|"+p?" opacity-50":"")} style={estilo}>{cont}</button>
                        :<span key={p} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold" style={estilo}>{cont}</span>;
                    })}
                    {f.guardiaAusente.map(p=><span key={p} className="px-3 py-1.5 rounded-full text-xs font-bold bg-gray-100 text-gray-400 line-through" title="De guardia, pero ausente">{p}</span>)}
                  </div>}
                {tipo==="recreo"&&(f.profs.length>0||f.guardiaAusente.length>0)&&(
                  <div className="mt-2.5 flex flex-wrap gap-1.5">
                    {ZONAS_REC.map(z=>{const n=f.profs.filter(p=>zonaDeProf(f.s,p)===z.k).length;return(
                      <span key={z.k} className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-bold" style={n?{background:z.f,color:z.t}:{background:"#fff1f2",color:"#be123c"}}>
                        <i className="w-2.5 h-2.5 rounded-full" style={{background:z.c}}/>{z.l}: {n?n:"sin cubrir"}</span>);})}
                  </div>
                )}
                {f.sinCubrir.length>0&&(
                  <div className="mt-3 pt-3 border-t border-divider">
                    <div className="text-[10px] font-bold uppercase tracking-wider text-[#be123c] mb-1.5">Grupos sin profesor ({f.sinCubrir.length})</div>
                    <div className="flex flex-wrap gap-1.5">
                      {f.sinCubrir.map((c,i)=><span key={i} className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-rose-50 text-[#9f1239]" title={c.obs?"Tarea: "+c.obs:""}>{c.grupo||"—"}{c.aula&&" · A"+c.aula} <span className="opacity-70">({c.prof})</span>{c.obs&&" 📝"}</span>)}
                    </div>
                    {f.sinCubrir.some(c=>c.obs)&&<div className="mt-2 space-y-0.5">{unicos(f.sinCubrir.filter(c=>c.obs),c=>c.prof+"|"+c.obs).map(k=>{const p=k.split("|");return <div key={k} className="text-[11px] text-ink-soft"><b>Tarea ({corto(p[0])}):</b> {p.slice(1).join("|")}</div>;})}</div>}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
      <div className="mt-5"><FirmaGuardias tipo={tipo}/></div>
    </Seccion>
  );
}


/* Biblioteca · Atención a biblioteca (G.B.) */
const SLOT_API={"1ª Diurno":"1","2ª Diurno":"2","1º Recreo":"R1","3ª Diurno":"3","4ª Diurno":"4","2º Recreo":"R2","5ª Diurno":"5","6ª Diurno":"6","7ª Diurno":"7"};
const minDe=hm=>{const p=hm.split(":");return(+p[0])*60+(+p[1]);};
function slotAhora(){
  const n=new Date();const wd=n.getDay();if(wd<1||wd>5)return null;
  const m=n.getHours()*60+n.getMinutes();
  for(let i=0;i<HORAS.length;i++){
    const h=HORAS[i];const p=h.l.split("–");
    if(p.length===2&&m>=minDe(p[0])&&m<minDe(p[1]))return{dia:wd,h:h};
  }
  return null;
}
/* ============================================================
   BIBLIOTECA · G.B. (Atención a Biblioteca) y MAY55 (Mayores de 55 años)
   Misma funcionalidad que biblioteca.html: pestañas por día, filtros,
   búsqueda, listado por profesor, modo administrador (alta, edición,
   baja, exportar/importar JSON) y hojas de firmas imprimibles en PDF.
   Lee y guarda en la MISMA hoja de Drive que biblioteca.html (mismo formato).
   ============================================================ */
const BB_SLOTS=[
  {k:"1ª Diurno",l:"1ª hora"},{k:"2ª Diurno",l:"2ª hora"},{k:"1º Recreo",l:"1º recreo",r:1},
  {k:"3ª Diurno",l:"3ª hora"},{k:"4ª Diurno",l:"4ª hora"},{k:"2º Recreo",l:"2º recreo",r:1},
  {k:"5ª Diurno",l:"5ª hora"},{k:"6ª Diurno",l:"6ª hora"},{k:"7ª Diurno",l:"7ª hora"}
];
const BB_SI=Object.fromEntries(BB_SLOTS.map((s,i)=>[s.k,i]));
const BB_LBL={GB:"G.B.",MAY:"MAY55",REC:"Recreo"};
const BB_LONG={GB:"Atención a Biblioteca",MAY:"Mayores de 55 años",REC:"Guardia de recreo en biblioteca"};
const BB_KEY="gbmay-records-v1";
const bbMorning=r=>BB_SI[r.slot]!==undefined;
const bbShort=n=>{const p=String(n).split(",");return(p[1]?p[1].trim()+" ":"")+p[0].trim();};
const bbSort=(a,b)=>a.act.localeCompare(b.act)||a.name.localeCompare(b.name,"es");
const bbHora=k=>{const id=SLOT_API[k];const h=id?HORAS.filter(x=>x.n===id)[0]:null;return h?h.l:"";};
const leerTexto=f=>f.text?f.text():new Promise((ok,ko)=>{const r=new FileReader();r.onload=()=>ok(r.result);r.onerror=ko;r.readAsText(f);});

/* ---------- diálogos ---------- */
function BBModal({titulo,children,onClose,ancho}){
  return(
    <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 no-print" role="dialog" aria-modal="true" aria-label={titulo} onMouseDown={e=>{if(e.target===e.currentTarget)onClose();}}>
      <div className="bg-white rounded-2xl shadow-2xl w-full p-6 fade-in max-h-[92vh] overflow-y-auto" style={{maxWidth:ancho||440}}>
        <h2 className="font-display font-bold text-lg text-ink mb-4">{titulo}</h2>
        {children}
      </div>
    </div>
  );
}

function BBLogin({onSubmit,onClose}){
  const[p,setP]=useState("");const[err,setErr]=useState("");const[ocupado,setOcupado]=useState(false);
  const entrar=async()=>{
    if(!p||ocupado)return;setOcupado(true);setErr("");
    const ok=await onSubmit(p);setOcupado(false);
    if(ok!==true)setErr(typeof ok==="string"?ok:"Clave incorrecta.");
  };
  return(
    <BBModal titulo="Gestión de la Biblioteca" onClose={onClose} ancho={380}>
      <p className="text-xs text-ink-soft font-medium mb-3">Escribe la clave de la biblioteca que te ha dado Jefatura de Estudios.</p>
      <label className="lbl" htmlFor="bb-pw">Clave de la biblioteca</label>
      <input id="bb-pw" type="password" className="field mb-2" value={p} autoFocus autoComplete="current-password" onChange={e=>{setP(e.target.value);setErr("");}} onKeyDown={e=>{if(e.key==="Enter")entrar();}}/>
      <p className="text-xs font-semibold text-[#be123c] min-h-[1em] mb-2">{err}</p>
      <div className="flex gap-2 justify-end"><button className="btn btn-ghost" onClick={onClose}>Cancelar</button><button className="btn btn-dark" disabled={ocupado} onClick={entrar}>{ocupado?"Comprobando…":"Entrar"}</button></div>
    </BBModal>
  );
}

function BBEdit({rec,preset,dia,data,onSave,onClose}){
  const[name,setName]=useState(rec?rec.name:"");
  const[dept,setDept]=useState(rec?rec.dept:"");
  const[act,setAct]=useState(rec?rec.act:"GB");
  const[d,setD]=useState(rec?rec.day:dia);
  const[slot,setSlot]=useState(rec?rec.slot:(preset||"1ª Diurno"));
  const[err,setErr]=useState("");const[ocupado,setOcupado]=useState(false);
  const nombres=useMemo(()=>[...new Set(data.map(r=>r.name))].sort((a,b)=>a.localeCompare(b,"es")),[data]);
  const deptos=useMemo(()=>[...new Set(data.map(r=>r.dept).filter(Boolean))].sort((a,b)=>a.localeCompare(b,"es")),[data]);
  const alCambiarNombre=v=>{setName(v);const r=data.find(x=>x.name===v.trim());if(r&&!dept)setDept(r.dept);};
  const guardar=async()=>{
    const nombre=name.trim().replace(/\s+/g," ");
    if(!nombre){setErr("Escribe el nombre del profesor o profesora.");return;}
    setOcupado(true);setErr("");
    const e=await onSave({name:nombre,dept:dept.trim(),act:act,day:+d,slot:slot},rec?rec.id:null);
    setOcupado(false);if(e)setErr(e);
  };
  return(
    <BBModal titulo={rec?"Editar registro":"Nuevo registro"} onClose={onClose}>
      <div className="space-y-3">
        <div><label className="lbl" htmlFor="bb-name">Profesor/a (Apellidos, Nombre)</label><input id="bb-name" className="field" list="bb-dl-names" maxLength={120} placeholder="Apellidos, Nombre" value={name} autoFocus onChange={e=>alCambiarNombre(e.target.value)}/><datalist id="bb-dl-names">{nombres.map(n=><option key={n} value={n}/>)}</datalist></div>
        <div><label className="lbl" htmlFor="bb-dept">Departamento</label><input id="bb-dept" className="field" list="bb-dl-depts" maxLength={120} value={dept} onChange={e=>setDept(e.target.value)}/><datalist id="bb-dl-depts">{deptos.map(n=><option key={n} value={n}/>)}</datalist></div>
        <div>
          <div className="lbl">Actividad</div>
          <div className="flex gap-2">
            {["GB","MAY"].map(k=>(
              <label key={k} className={"bb-seg "+k+(act===k?" on":"")}><input type="radio" name="bb-act" value={k} checked={act===k} onChange={()=>setAct(k)}/> {BB_LBL[k]}</label>
            ))}
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div><label className="lbl" htmlFor="bb-day">Día</label><select id="bb-day" className="field" value={d} onChange={e=>setD(+e.target.value)}>{DIAS.map((x,i)=><option key={i} value={i}>{x}</option>)}</select></div>
          <div><label className="lbl" htmlFor="bb-slot">Tramo</label><select id="bb-slot" className="field" value={slot} onChange={e=>setSlot(e.target.value)}>{BB_SLOTS.map(s=><option key={s.k} value={s.k}>{s.l}</option>)}</select></div>
        </div>
        <p className="text-xs font-semibold text-[#be123c] min-h-[1em]">{err}</p>
        <div className="flex gap-2 justify-end"><button className="btn btn-ghost" onClick={onClose}>Cancelar</button><button className="btn btn-dark" disabled={ocupado} onClick={guardar}>{ocupado?"Guardando…":"Guardar"}</button></div>
      </div>
    </BBModal>
  );
}

function BBDel({rec,onOk,onClose}){
  const[ocupado,setOcupado]=useState(false);
  return(
    <BBModal titulo="Eliminar registro" onClose={onClose} ancho={400}>
      <p className="text-sm text-ink-soft mb-4">Se eliminará {BB_LBL[rec.act]} de {rec.name} el {DIAS[rec.day].toLowerCase()} en la {BB_SLOTS[BB_SI[rec.slot]].l}.</p>
      <div className="flex gap-2 justify-end"><button className="btn btn-ghost" onClick={onClose}>Cancelar</button><button className="btn" style={{background:"#fee2e2",color:"#dc2626"}} disabled={ocupado} onClick={async()=>{setOcupado(true);await onOk();}}>{ocupado?"Eliminando…":"Eliminar"}</button></div>
    </BBModal>
  );
}

function BBPrint({dia,onOk,onClose}){
  const[d,setD]=useState(String(dia));const[fecha,setFecha]=useState("");
  const[gb,setGb]=useState(true);const[may,setMay]=useState(true);
  return(
    <BBModal titulo="Imprimir hoja de firmas" onClose={onClose}>
      <div className="space-y-3">
        <div><label className="lbl" htmlFor="bb-pday">Día</label>
          <select id="bb-pday" className="field" value={d} onChange={e=>setD(e.target.value)}>
            {DIAS.map((x,i)=><option key={i} value={i}>{x}</option>)}
            <option value="all">Toda la semana (una hoja por día)</option>
          </select></div>
        <div><label className="lbl" htmlFor="bb-pdate">Fecha (opcional)</label><input id="bb-pdate" type="date" className="field" value={fecha} onChange={e=>setFecha(e.target.value)}/>
          {d==="all"&&<p className="text-[11px] text-ink-soft mt-1">Si indicas una fecha, se toma como parte de esa semana y cada hoja lleva su día.</p>}</div>
        <div className="space-y-1.5">
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={gb} onChange={e=>setGb(e.target.checked)}/> Incluir G.B.</label>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={may} onChange={e=>setMay(e.target.checked)}/> Incluir MAY55</label>
        </div>
        <p className="text-xs text-ink-soft leading-relaxed">En el cuadro de impresión elige «Guardar como PDF» para obtener el archivo. Si eliges «Toda la semana», cada día sale en una hoja.</p>
        <div className="flex gap-2 justify-end"><button className="btn btn-ghost" onClick={onClose}>Cancelar</button><button className="btn btn-dark" onClick={()=>onOk({dia:d==="all"?"all":+d,fecha:fecha,acts:(!gb&&!may)?{GB:true,MAY:true}:{GB:gb,MAY:may}})}>Imprimir / PDF</button></div>
      </div>
    </BBModal>
  );
}

/* ---------- hojas de firmas (solo se ven al imprimir) ---------- */
function BBHoja({d,fecha,acts,data}){
  const filas=[];
  BB_SLOTS.forEach(s=>{
    const lista=data.filter(o=>o.day===d&&o.slot===s.k&&acts[o.act]).sort(bbSort);
    lista.forEach((o,i)=>filas.push(
      <tr key={s.k+"-"+i+"-"+o.id} className={s.r?"rec":""}>
        {i===0&&<td className="tr" rowSpan={lista.length}>{s.l}</td>}
        <td className={"act "+o.act}>{BB_LBL[o.act]}</td><td>{o.name}</td><td className="dp">{o.dept}</td><td></td><td></td>
      </tr>
    ));
  });
  return(
    <section className="sheet">
      <div className="sh-head">
        <div style={{display:"flex",alignItems:"center",gap:10}}><LogoSVG size={60}/><div className="c">I.E.S. Valle del Jerte · Plasencia (Cáceres)<br/>Curso 2026/2027 · Jefatura de Estudios</div></div>
        <div style={{textAlign:"right"}}><div className="c">Control de presencia</div><h2>G.B. y MAY55</h2></div>
      </div>
      <div className="sh-meta"><span>Día: <b>{DIAS[d]}</b></span><span>Fecha: {fecha||"____ / ____ / ________"}</span></div>
      <div className="sh-legend"><span><i style={{background:"#dce8f7"}}></i>G.B. = {BB_LONG.GB}</span><span><i style={{background:"#fbe8cf"}}></i>MAY55 = {BB_LONG.MAY}</span><span><i style={{background:"#d5efe9"}}></i>Recreo = {BB_LONG.REC}</span></div>
      <table className="sign">
        <colgroup><col style={{width:"15mm"}}/><col style={{width:"17mm"}}/><col/><col style={{width:"38mm"}}/><col style={{width:"17mm"}}/><col style={{width:"40mm"}}/></colgroup>
        <thead><tr><th>Tramo</th><th>Activ.</th><th>Profesor/a</th><th>Departamento</th><th>Hora</th><th>Firma</th></tr></thead>
        <tbody>{filas.length?filas:<tr><td colSpan={6} style={{textAlign:"center",height:"14mm"}}>No hay profesorado asignado este día.</td></tr>}</tbody>
      </table>
      <div className="sh-obs">Observaciones / incidencias:</div>
      <div className="sh-foot"><div>Vº Bº Jefatura de Estudios</div><div>Sello del centro</div></div>
    </section>
  );
}
function BBHojas({hojas,data}){
  const destino=document.getElementById("print-area");
  if(!hojas||!destino)return null;
  const todos=hojas.dia==="all";
  let base=null;
  if(todos&&hojas.fecha){const d0=new Date(hojas.fecha+"T12:00:00");const wd=(d0.getDay()+6)%7;base=new Date(d0);base.setDate(d0.getDate()-Math.min(wd,4));}
  const fechaDe=i=>{
    if(todos){if(!base)return"";const x=new Date(base);x.setDate(base.getDate()+i);return x.toLocaleDateString("es-ES");}
    return hojas.fecha?new Date(hojas.fecha+"T12:00:00").toLocaleDateString("es-ES"):"";
  };
  const dias=todos?[0,1,2,3,4]:[hojas.dia];
  return ReactDOM.createPortal(<div className="hoja-firmas">{dias.map(d=><BBHoja key={d} d={d} fecha={fechaDe(d)} acts={hojas.acts} data={data}/>)}</div>,destino);
}

/* ---------- pantalla ---------- */
function PantallaBiblioteca({tile,onBack}){
  const[data,setData]=useState([]);
  const[recBib]=useRecreoBiblio();
  /* guardias de recreo marcadas en «Guardias de recreo» como registros de la biblioteca */
  const SLOT_REC={R1:"1º Recreo",R2:"2º Recreo"};
  const todo=useMemo(()=>data.concat(recBib.filter(x=>(x.zona||"biblioteca")==="biblioteca").map((x,i)=>({id:"rec-"+i,name:x.profesor,dept:BB_LONG.REC,act:"REC",day:x.dia-1,slot:SLOT_REC[x.tramo]}))),[data,recBib]);
  const[cargado,setCargado]=useState(false);
  const[mode,setMode]=useState("local");   /* «server»: datos del servidor del centro · «local»: sin conexión, copia de este navegador (solo lectura) */
  const[puede,setPuede]=useState(false);   /* cuenta con perfil Biblioteca o de administración */
  const[isAdmin,setIsAdmin]=useState(false);
  const[pass,setPass]=useState("");
  const[on,setOn]=useState({GB:true,MAY:true});
  const[q,setQ]=useState("");
  const[day,setDay]=useState(()=>{const w=new Date().getDay();if(w>=1&&w<=5)return w-1;const s=+LS.get("gbmay-day",0);return s>=0&&s<5?s:0;});
  const[st,setSt]=useState({msg:"",cls:""});
  const[dlg,setDlg]=useState(null);
  const[hojas,setHojas]=useState(null);

  useEffect(()=>{
    let vivo=true;
    (async()=>{
      let datos,modo="local",gest=false;
      try{
        const j=await pedir("GET","/biblioteca/registros");
        modo="server";datos=j.records;gest=!!j.puedeGestionar;LS.set(BB_KEY,datos);
      }catch(e){
        const p=LS.get(BB_KEY,null);
        datos=Array.isArray(p)?p:[];
      }
      if(!vivo)return;
      setMode(modo);setPuede(gest);setData(datos.filter(bbMorning));setCargado(true);
      let pw="";try{pw=sessionStorage.getItem("gbmay-pw")||"";}catch(e){}
      if(pw&&modo==="server"&&gest){
        let ok=false;
        try{await pedir("POST","/biblioteca/acceso",{clave:pw});ok=true;}catch(e){}
        if(vivo&&ok){setIsAdmin(true);setPass(pw);setSt({msg:"Los cambios se guardan en el servidor del centro.",cls:""});}
      }
    })();
    return()=>{vivo=false;};
  },[]);

  /* impresión de hojas de firmas: se oculta el resto de la app solo mientras se imprime */
  useEffect(()=>{
    if(!hojas)return;
    document.body.classList.add("modo-firmas");
    const fin=()=>{document.body.classList.remove("modo-firmas");setHojas(null);};
    window.addEventListener("afterprint",fin);
    const t=setTimeout(()=>window.print(),120);
    return()=>{clearTimeout(t);window.removeEventListener("afterprint",fin);document.body.classList.remove("modo-firmas");};
  },[hojas]);

  const entrar=async pw=>{
    if(mode!=="server")return "Sin conexión con el servidor del centro.";
    try{await pedir("POST","/biblioteca/acceso",{clave:pw});}catch(e){return e.message||"Clave incorrecta.";}
    setIsAdmin(true);setPass(pw);try{sessionStorage.setItem("gbmay-pw",pw);}catch(e){}
    setSt({msg:"Los cambios se guardan en el servidor del centro.",cls:""});
    setDlg(null);return true;
  };
  const salir=()=>{setIsAdmin(false);setPass("");try{sessionStorage.removeItem("gbmay-pw");}catch(e){}};

  /* guarda la lista completa en el servidor del centro: devuelve null si se guardó, o el texto del error */
  const persistir=async nuevo=>{
    if(mode!=="server"){const m="Sin conexión con el servidor del centro: no se puede guardar.";setSt({msg:m,cls:"err"});return m;}
    setSt({msg:"Guardando…",cls:""});
    try{
      const j=await pedir("PUT","/biblioteca/registros",{clave:pass,records:nuevo});
      const recs=j.records.filter(bbMorning);setData(recs);LS.set(BB_KEY,recs);
      setSt({msg:"Guardado en el servidor del centro · "+new Date().toLocaleTimeString("es-ES",{hour:"2-digit",minute:"2-digit"}),cls:"ok"});
      return null;
    }catch(e){const m="No se pudo guardar: "+e.message;setSt({msg:m,cls:"err"});return m;}
  };
  const guardarReg=async(rec,id)=>{
    const dup=data.find(r=>r.id!==id&&r.name===rec.name&&r.act===rec.act&&r.day===rec.day&&r.slot===rec.slot);
    if(dup)return"Ese registro ya existe en ese día y tramo.";
    const nuevo=id!=null?data.map(r=>r.id===id?{...r,...rec}:r):data.concat({...rec});
    const e=await persistir(nuevo);if(e)return e;
    setDay(rec.day);LS.set("gbmay-day",rec.day);setDlg(null);return null;
  };
  const borrarReg=async rec=>{
    await persistir(data.filter(r=>r.id!==rec.id));
    setDlg(null);
  };
  const traerHoja=async()=>{
    if(!confirm("¿Sustituir los registros de la biblioteca por los que había en la hoja de Google anterior? Se perderán los cambios hechos aquí desde entonces."))return;
    setSt({msg:"Trayendo la hoja de Google…",cls:""});
    try{const j=await pedir("POST","/biblioteca/importar-hoja",{clave:pass});const recs=j.records.filter(bbMorning);setData(recs);LS.set(BB_KEY,recs);setSt({msg:j.importados+" registros traídos de la hoja anterior",cls:"ok"});}
    catch(e){setSt({msg:"No se pudo traer: "+e.message,cls:"err"});}
  };
  const exportar=()=>{
    const blob=new Blob([JSON.stringify({version:1,updated:new Date().toISOString(),records:data},null,1)],{type:"application/json"});
    const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="datos.json";document.body.appendChild(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(a.href),2000);
  };
  const importar=async e=>{
    const f=e.target.files[0];e.target.value="";if(!f)return;
    try{
      const j=JSON.parse(await leerTexto(f));const recs=Array.isArray(j)?j:j.records;
      if(!Array.isArray(recs))throw 0;
      const limpio=recs.filter(r=>r&&r.name&&(r.act==="GB"||r.act==="MAY")&&r.day>=0&&r.day<5&&BB_SI[r.slot]!==undefined)
        .map((r,i)=>({id:i+1,name:String(r.name),dept:String(r.dept||""),act:r.act,day:+r.day,slot:r.slot}));
      await persistir(limpio);
    }catch(err){setSt({msg:"El archivo no tiene el formato esperado.",cls:"err"});}
  };

  const qn=quitarTildes(q.trim());
  const acierto=o=>qn&&(quitarTildes(o.name).indexOf(qn)>=0||quitarTildes(o.dept).indexOf(qn)>=0);
  const en=(d,s)=>todo.filter(o=>o.day===d&&o.slot===s&&(o.act==="REC"||on[o.act])).sort(bbSort);
  const nGB=data.filter(o=>o.act==="GB").length,nMAY=data.filter(o=>o.act==="MAY").length;
  const por=useMemo(()=>{
    const by={};
    data.filter(o=>on[o.act]&&(!qn||acierto(o))).forEach(o=>{(by[o.name]=by[o.name]||{dept:o.dept,items:[]}).items.push(o);});
    return by;
  },[data,on,qn]);
  const ahora=slotAhora();
  const enBiblio=(cargado&&ahora)?todo.filter(r=>(r.act==="GB"||r.act==="REC")&&r.day===ahora.dia-1&&SLOT_API[r.slot]===ahora.h.n).sort(bbSort):[];
  const verde=tile.g[0];
  const pie=mode==="server"
    ?"Datos guardados en el servidor del centro. Solo horario de mañana. Los editan las cuentas con perfil Biblioteca, que asigna Jefatura de Estudios."
    :"Sin conexión con el servidor del centro: se muestra la última copia guardada en este navegador (solo lectura).";

  return(
    <Seccion tile={tile} onBack={onBack}>
      <CuadranteHoy biblioteca/>
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 no-print">
          <div className="card px-4 py-3 flex-1 min-w-[260px]">
            <div className="font-display font-bold text-ink text-sm leading-snug">Profesorado en <span className="bb-t-GB">G.B. · Atención a Biblioteca</span> y <span className="bb-t-MAY">MAY55 · Mayores de 55 años</span></div>
            <p className="text-xs text-ink-soft font-medium mt-1">Horario de mañana organizado por días. Elige un día en las pestañas para ver, tramo a tramo, quién tiene cotejada cada actividad en su horario.</p>
          </div>
          <div className="flex gap-2">
            <button className="btn btn-ghost" onClick={()=>setDlg({t:"print"})}><Ico n="imprimir" s={16}/>Imprimir hoja de firmas</button>
            {(puede||isAdmin)&&<button className={"btn "+(isAdmin?"btn-dark":"btn-ghost")} onClick={()=>isAdmin?salir():setDlg({t:"login"})}><Ico n="candado" s={16}/>{isAdmin?"Salir de gestión":"Gestionar"}</button>}
          </div>
        </div>

        {isAdmin&&(
          <div className="flex flex-wrap items-center gap-3 rounded-2xl p-3 no-print" style={{background:"#e4ecf4",border:"1px solid #c5d5e6"}}>
            <span className="font-display font-bold text-sm text-ink-blue mr-auto">Gestión de la biblioteca activa</span>
            <span className={"text-xs font-semibold "+(st.cls==="ok"?"text-olive":st.cls==="err"?"text-[#be123c]":"text-ink-soft")}>{st.msg}</span>
            <button className="btn btn-ghost !min-h-[38px]" onClick={()=>setDlg({t:"edit",rec:null})}>+ Nuevo registro</button>
            <button className="btn btn-ghost !min-h-[38px]" onClick={exportar}>Exportar copia (JSON)</button>
            <label className="btn btn-ghost !min-h-[38px] cursor-pointer">Importar JSON<input type="file" accept=".json,application/json" hidden onChange={importar}/></label>
            <button className="btn btn-ghost !min-h-[38px]" onClick={traerHoja} title="Solo para el cambio desde Google Drive">Traer de la hoja anterior</button>
          </div>
        )}

        {ahora&&cargado&&(
          <div className="rounded-xl border-l-4 p-4 fade-in no-print" style={{borderColor:verde,background:verde+"14"}}>
            <div className="text-[11px] font-bold uppercase tracking-wider" style={{color:verde}}>Ahora en la biblioteca (G.B.) · {ahora.h.r?ahora.h.n:ahora.h.n+"ª hora"} ({ahora.h.l})</div>
            {enBiblio.length>0
              ?<div className="flex flex-wrap gap-1.5 mt-2">{enBiblio.map(r=><span key={r.id} className="px-3 py-1.5 rounded-full text-xs font-bold bg-white" style={{color:verde,border:"1px solid "+verde+"55"}}>{bbShort(r.name)}</span>)}</div>
              :<p className="text-sm text-ink-soft mt-1">Ahora mismo no hay nadie asignado a la biblioteca.</p>}
          </div>
        )}

        <div className="flex flex-wrap items-center gap-2.5 no-print">
          {["GB","MAY"].map(k=>(
            <button key={k} className={"bb-toggle "+k} aria-pressed={on[k]} onClick={()=>setOn({...on,[k]:!on[k]})}><span className="dot"></span>{BB_LBL[k]} · {BB_LONG[k]} <span className="n">{k==="GB"?nGB:nMAY}</span></button>
          ))}
          <div className="relative flex-1 min-w-[220px] max-w-sm">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-soft"><Ico n="buscar" s={18}/></span>
            <input type="search" className="field !pl-11" value={q} onChange={e=>setQ(e.target.value)} placeholder="Buscar profesor o departamento…" aria-label="Buscar profesor o departamento"/>
          </div>
        </div>

        {!cargado&&<div className="card p-8 text-center text-ink-soft text-sm font-semibold">Cargando datos de la biblioteca…</div>}
        {cargado&&(
          <React.Fragment>
            <div className="bb-days no-print" role="tablist">
              {DIAS.map((d,i)=>(
                <button key={i} role="tab" aria-selected={i===day} onClick={()=>{setDay(i);LS.set("gbmay-day",i);}}><span>{d}</span><span className="dc">{todo.filter(o=>o.day===i&&(o.act==="REC"||on[o.act])).length}</span></button>
              ))}
            </div>
            <div className="space-y-2.5" role="tabpanel">
              {BB_SLOTS.map(s=>{
                const lista=en(day,s.k);
                return(
                  <section key={s.k} className={"bb-slot"+(s.r?" rec":"")+(qn?" bb-dim":"")}>
                    <h3>{s.l}<span className="hr">{bbHora(s.k)}</span>{isAdmin&&<button type="button" className="bb-add" onClick={()=>setDlg({t:"edit",rec:null,preset:s.k})}>+ Añadir</button>}</h3>
                    <div className="bb-cell">
                      {lista.length===0&&<span className="text-ink-soft/60 text-sm pt-1">—</span>}
                      {lista.map(o=>(
                        <div key={o.id} className={"bb-chip "+o.act+(acierto(o)?" hit":"")+(isAdmin&&o.act!=="REC"?" adm":"")} title={o.act==="REC"?o.name+" — guardia de recreo en biblioteca (se cambia en Guardias de recreo)":o.name+" — "+o.dept}>
                          <span className="tag">{BB_LBL[o.act]}</span><span className="nm">{bbShort(o.name)}</span><span className="dp">{o.dept}</span>
                          {isAdmin&&o.act!=="REC"&&(
                            <span className="ops">
                              <button type="button" aria-label={"Editar "+o.name} onClick={()=>setDlg({t:"edit",rec:o})}><Ico n="lapiz" s={14}/></button>
                              <button type="button" className="del" aria-label={"Eliminar "+o.name} onClick={()=>setDlg({t:"del",rec:o})}><Ico n="papelera" s={14}/></button>
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  </section>
                );
              })}
            </div>
            <details className="card p-4 no-print">
              <summary className="cursor-pointer font-display font-bold text-sm text-ink">Listado por profesor</summary>
              <ul className="bb-plist mt-3">
                {Object.keys(por).sort((a,b)=>a.localeCompare(b,"es")).map(n=>(
                  <li key={n}><span className="who">{n}</span><span className="text-xs text-ink-soft">{por[n].dept}</span>
                    <span className="when">{por[n].items.slice().sort((a,b)=>a.day-b.day||BB_SI[a.slot]-BB_SI[b.slot]).map(o=><span key={o.id} className={"pill "+o.act}>{BB_LBL[o.act]} · {DIAS[o.day].slice(0,3)} {BB_SLOTS[BB_SI[o.slot]].l}</span>)}</span></li>
                ))}
                {Object.keys(por).length===0&&<li className="text-xs text-ink-soft">Sin resultados.</li>}
              </ul>
            </details>
          </React.Fragment>
        )}
        <p className="text-xs text-ink-soft font-medium no-print">{pie}</p>
      </div>

      {dlg&&dlg.t==="login"&&<BBLogin onSubmit={entrar} onClose={()=>setDlg(null)}/>}
      {dlg&&dlg.t==="edit"&&<BBEdit rec={dlg.rec} preset={dlg.preset} dia={day} data={data} onSave={guardarReg} onClose={()=>setDlg(null)}/>}
      {dlg&&dlg.t==="del"&&<BBDel rec={dlg.rec} onOk={()=>borrarReg(dlg.rec)} onClose={()=>setDlg(null)}/>}
      {dlg&&dlg.t==="print"&&<BBPrint dia={day} onClose={()=>setDlg(null)} onOk={o=>{setDlg(null);setHojas({...o,acts:{...o.acts,REC:true}});}}/>}
      <BBHojas hojas={hojas} data={todo}/>
    </Seccion>
  );
}

/* Calendarios */
function PantallaCalendarios({tile,onBack,remoto,admin,ops}){
  const[cual,setCual]=useState("");
  const[edit,setEdit]=useState(null);
  const[ocupado,setOcupado]=useState(false);
  const[detectado,setDetectado]=useState(false);
  const[recarga,setRecarga]=useState(0);   /* para volver a pedir el calendario a Google sin caché */
  const defs=[
    {k:"extra",ico:"calendario",g:["#4f46e5","#8b93fb"]},
    {k:"dap",ico:"ausencia",g:["#0d9488","#34d3be"]}
  ];
  const cal=cual?remoto.calendarios[cual]:null;
  const ok=cal&&seguro(cal.url);
  const embebible=ok&&/calendar\.google\.com|\/embed/i.test(cal.url);
  const guardar=async()=>{
    setOcupado(true);
    const r=await ops.calGuardar(cual,{nombre:(edit.nombre||"").trim()||cal.nombre,url:extraerUrl(edit.url)});
    setOcupado(false);if(r){setEdit(null);setDetectado(false);}
  };
  return(
    <Seccion tile={tile} onBack={onBack}>
      <div className="grid sm:grid-cols-2 gap-3 mb-6 no-print">
        {defs.map(d=>{
          const c=remoto.calendarios[d.k];const on=cual===d.k;
          return(
            <button key={d.k} onClick={()=>{setCual(on?"":d.k);setEdit(null);setDetectado(false);}} className="card p-4 flex items-center gap-4 text-left transition hover:shadow-md" style={on?{borderColor:d.g[0],boxShadow:"0 0 0 2px "+d.g[0]+"33"}:{}}>
              <TileIcon t={{ico:d.ico,g:d.g}} size={52}/>
              <div className="flex-1"><div className="font-display font-bold text-ink">{c.nombre}</div><div className="text-xs text-ink-soft font-medium">{seguro(c.url)?"Toca para ver":"Aún sin enlace"}</div></div>
            </button>
          );
        })}
      </div>
      {cal&&(
        <div className="space-y-4 fade-in">
          {ok?(
            <React.Fragment>
              <div className="flex flex-wrap gap-2 no-print">
                <a href={cal.url} target="_blank" rel="noopener noreferrer" className="btn btn-dark"><Ico n="enlace" s={16}/>Abrir {cal.nombre} en una pestaña nueva</a>
                {embebible&&<button className="btn btn-ghost" onClick={()=>setRecarga(Date.now())} title="Vuelve a pedir el calendario a Google"><Ico n="reloj" s={16}/>Recargar calendario</button>}
              </div>
              {embebible&&<div className="card overflow-hidden"><iframe key={recarga} src={recarga?cal.url+(cal.url.indexOf("?")>=0?"&":"?")+"_r="+recarga:cal.url} title={cal.nombre} style={{width:"100%",height:"70vh",border:0}} loading="lazy"></iframe></div>}
              {admin&&embebible&&/calendar\.google\.com/i.test(cal.url)&&<div className="card p-4 text-xs text-ink-soft leading-relaxed no-print">
                <b className="text-ink">¿No aparecen los cambios?</b> El calendario se muestra tal como lo publica Google, en directo. Comprueba:
                <b> 1)</b> que las actividades se añaden en este mismo calendario ({(cal.url.match(/[?&]src=([^&]+)/)||[,"—"])[1].split("%40")[0].replace(/%2E/gi,".").slice(0,40)}…), no en «Mi calendario»;
                <b> 2)</b> en Google Calendar → Configuración de este calendario → <b>Permisos de acceso</b>: «Hacer disponible públicamente» marcado y «Ver todos los detalles de los eventos»;
                <b> 3)</b> si el calendario es de una cuenta @educarex.es, quien no haya iniciado sesión con esa cuenta puede verlo vacío: créalo en una cuenta que permita compartir públicamente.
              </div>}
            </React.Fragment>
          ):(
            <div className="card p-8 text-center text-ink-soft"><p className="font-semibold">El administrador aún no ha publicado este calendario.</p></div>
          )}
          {admin&&(
            <div className="card p-4 space-y-3 no-print">
              <div className="lbl">Administrador · enlace del calendario</div>
              <input className="field" placeholder="Nombre" value={edit?edit.nombre:cal.nombre} onChange={e=>setEdit({nombre:e.target.value,url:edit?edit.url:cal.url})}/>
              <input className="field" placeholder="Pega el enlace o el código <iframe …> de Google Calendar" value={edit?edit.url:cal.url} onChange={e=>{const v=e.target.value;const d=esIframe(v);setDetectado(d);setEdit({nombre:edit?edit.nombre:cal.nombre,url:d?extraerUrl(v):v});}}/>
              {detectado&&<p className="text-xs font-semibold text-olive">Código de incrustación detectado: se ha extraído el enlace automáticamente.</p>}
              {edit&&edit.url&&!seguro(edit.url)&&<p className="text-xs font-semibold text-[#be123c]">El enlace debe empezar por https://</p>}
              <p className="text-xs text-ink-soft leading-relaxed">En Google Calendar: Configuración del calendario → <b>Integrar el calendario</b> → copia el <b>código de inserción</b> (el que empieza por {"<iframe"}) o la URL pública, y pégalo tal cual. Para que el resto lo vea, el calendario debe estar compartido con quien lo consulte; si no es público, solo lo verán quienes tengan acceso. Cualquier otro enlace se abrirá en una pestaña nueva.</p>
              <button className="btn btn-dark" disabled={!edit||ocupado} onClick={guardar}>{ocupado?"Guardando…":"Guardar enlace"}</button>
            </div>
          )}
        </div>
      )}
    </Seccion>
  );
}

/* Avisos importantes */
const NIVELES={
  urgente:{l:"Urgente",bg:"#fff1f2",bd:"#be123c",tx:"#9f1239"},
  importante:{l:"Importante",bg:"#fffbeb",bd:"#d97706",tx:"#92400e"},
  info:{l:"Informativo",bg:"#e4ecf4",bd:"#2d4a6b",tx:"#1f3a56"}
};
const avisoVigente=a=>!a.caduca||a.caduca>=hoyISO();

function PantallaAvisos({tile,onBack,remoto,admin,ops}){
  const vacio={id:"",titulo:"",texto:"",nivel:"importante",caduca:"",enlace:""};
  const[f,setF]=useState(null);
  const[ocupado,setOcupado]=useState(false);
  const orden={urgente:0,importante:1,info:2};
  const lista=remoto.avisos.filter(a=>admin||avisoVigente(a)).sort((a,b)=>(orden[a.nivel]!=null?orden[a.nivel]:2)-(orden[b.nivel]!=null?orden[b.nivel]:2)||(b.fecha||"").localeCompare(a.fecha||""));
  const publicar=async()=>{
    if(!f.titulo.trim())return;
    setOcupado(true);
    const r=await ops.avisoGuardar({id:f.id,titulo:f.titulo.trim(),texto:f.texto.trim(),nivel:f.nivel,caduca:f.caduca,enlace:f.enlace.trim()});
    setOcupado(false);if(r)setF(null);
  };
  return(
    <Seccion tile={tile} onBack={onBack}>
      {admin&&!f&&<button className="btn btn-dark mb-5 no-print" onClick={()=>setF(vacio)}><Ico n="mas" s={16}/>Nuevo aviso</button>}
      {admin&&f&&(
        <div className="card p-4 space-y-3 mb-5 fade-in no-print">
          <div className="lbl">{f.id?"Editar aviso":"Nuevo aviso"}</div>
          <div><label className="lbl">Título</label><input className="field" value={f.titulo} onChange={e=>setF({...f,titulo:e.target.value})}/></div>
          <div><label className="lbl">Texto</label><textarea className="field" rows={3} value={f.texto} onChange={e=>setF({...f,texto:e.target.value})}/></div>
          <div className="grid sm:grid-cols-3 gap-3">
            <div><label className="lbl">Nivel</label><select className="field" value={f.nivel} onChange={e=>setF({...f,nivel:e.target.value})}>{Object.keys(NIVELES).map(k=><option key={k} value={k}>{NIVELES[k].l}</option>)}</select></div>
            <div><label className="lbl">Se oculta el (opcional)</label><input type="date" className="field" value={f.caduca} onChange={e=>setF({...f,caduca:e.target.value})}/></div>
            <div><label className="lbl">Enlace (opcional)</label><input className="field" placeholder="https://…" value={f.enlace} onChange={e=>setF({...f,enlace:e.target.value})}/></div>
          </div>
          <div className="flex gap-2"><button className="btn btn-ghost" onClick={()=>setF(null)}>Cancelar</button><button className="btn btn-dark" disabled={!f.titulo.trim()||ocupado} onClick={publicar}>{ocupado?"Publicando…":(f.id?"Guardar cambios":"Publicar")}</button></div>
        </div>
      )}
      {lista.length===0&&<div className="card p-10 text-center text-ink-soft"><p className="font-semibold">No hay avisos vigentes</p></div>}
      <div className="space-y-3">
        {lista.map(a=>{
          const n=NIVELES[a.nivel]||NIVELES.info;
          return(
            <div key={a.id} className="rounded-xl p-4 border-l-4 fade-in" style={{background:n.bg,borderColor:n.bd}}>
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full text-white" style={{background:n.bd}}>{n.l}</span>
                    <span className="text-[11px] font-medium" style={{color:n.tx,opacity:.7}}>{fmtCorta(a.fecha)}</span>
                    {!avisoVigente(a)&&<span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-gray-200 text-gray-600">Caducado</span>}
                  </div>
                  <h3 className="font-display font-bold text-base leading-tight" style={{color:n.tx}}>{a.titulo}</h3>
                  {a.texto&&<p className="text-sm mt-1.5 leading-relaxed whitespace-pre-line" style={{color:n.tx}}>{a.texto}</p>}
                  {seguro(a.enlace)&&<a href={a.enlace} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 text-xs font-bold mt-2 underline" style={{color:n.tx}}><Ico n="enlace" s={14}/>Más información</a>}
                </div>
                {admin&&(
                  <div className="flex flex-shrink-0 no-print">
                    <button className="p-2 rounded-lg hover:bg-black/5" style={{color:n.tx}} aria-label="Editar aviso" onClick={()=>setF({id:a.id,titulo:a.titulo,texto:a.texto||"",nivel:a.nivel,caduca:a.caduca||"",enlace:a.enlace||""})}><Ico n="lapiz" s={18}/></button>
                    <button className="p-2 rounded-lg hover:bg-black/5" style={{color:n.tx}} aria-label="Eliminar aviso" onClick={()=>{if(confirm("¿Eliminar este aviso?"))ops.avisoBorrar(a.id);}}><Ico n="papelera" s={18}/></button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </Seccion>
  );
}

/* Cronología: cronograma de evaluaciones, reuniones y entrega de notas + programaciones
   didácticas (app CCP_IVJP_2027 integrada). Conserva su propio acceso de administrador,
   el de jefes de departamento y la publicación de nuevas versiones. */
let CCP_HTML=null;
function htmlCronologia(){
  if(CCP_HTML===null){
    const el=document.getElementById("ccp-src");
    CCP_HTML=el?el.textContent.replace(/<\\\/script/g,"<"+"/script").replace(/<\\!--/g,"<"+"!--"):"";
  }
  return CCP_HTML;
}
function PantallaCronologia({tile,onBack}){
  const externo=seguro(CRONOLOGIA_URL);
  const html=externo?"":htmlCronologia();
  const[cargada,setCargada]=useState(false);
  return(
    <Seccion tile={tile} onBack={onBack}>
      {!externo&&!html
        ?<div className="card p-10 text-center text-ink-soft"><p className="font-semibold">La cronología no está disponible en esta versión de la app.</p></div>
        :<div className="card overflow-hidden relative">
          {!cargada&&<div className="absolute inset-0 flex items-center justify-center text-sm text-ink-soft font-medium bg-white">Cargando cronología…</div>}
          <iframe title="Cronología · Coordinación Pedagógica" onLoad={()=>setCargada(true)}
            {...(externo?{src:CRONOLOGIA_URL}:{srcDoc:html})}
            style={{width:"100%",height:"calc(100dvh - 190px)",minHeight:560,border:0,display:"block"}}></iframe>
        </div>}
      {false&&<a href={CRONOLOGIA_URL} target="_blank" rel="noopener noreferrer" className="btn btn-ghost mt-3 no-print"><Ico n="enlace" s={16}/>Abrir la cronología en una pestaña nueva</a>}
    </Seccion>
  );
}

/* Notificación de ausencia */
/* ── Tareas para la guardia ──
   Clases que pierde el profesor/a en cada día de la ausencia (de hoy en adelante) y la tarea que deja para cada una.
   Se guardan por día y hora («AAAA-MM-DD|tramo») y salen en Guardias de aula y en el panel de la sala de profesores. */
function clasesAusencia(prof,fecha,hasta,modo,horas){
  if(!prof||!fecha)return[];
  const hoy=hoyISO(),fin=hasta&&hasta>fecha?hasta:fecha,out=[];
  let d=fecha,n=0;
  while(d<=fin&&n<40){
    const wd=diaSemanaDe(d);
    if(wd>=1&&wd<=5&&d>=hoy){
      const ses=ENTRADAS.filter(e=>e.profesor===prof&&e.dia===wd&&(e.cat==="docencia"||(e.cat==="tutoria"&&e.grupo))&&(modo!=="horas"||horas.indexOf(String(e.slot))>=0));
      const porHora={};
      ses.forEach(e=>{const k=d+"|"+e.slot;(porHora[k]||(porHora[k]={k,fecha:d,slot:String(e.slot),grupos:[],aula:e.aula,materia:e.materia})).grupos.push(e.grupo);});
      Object.values(porHora).sort((a,b)=>HORAS.findIndex(h=>h.n===a.slot)-HORAS.findIndex(h=>h.n===b.slot)).forEach(x=>out.push(x));
    }
    const t=new Date(d+"T12:00:00");t.setDate(t.getDate()+1);d=isoDe(t);n++;
  }
  return out;
}
function EditorTareas({clases,valor,onCambio,acento}){
  if(!clases.length)return <p className="text-xs text-ink-soft">No tienes clases en los días de hoy en adelante de esta ausencia.</p>;
  const dias=[...new Set(clases.map(c=>c.fecha))];
  return(
    <div className="space-y-3">
      {dias.map(d=>(
        <div key={d} className="rounded-xl border border-divider overflow-hidden">
          <div className="px-3 py-2 text-xs font-bold text-white" style={{background:acento}}>{cap(fmtLarga(d))}</div>
          <div className="divide-y divide-divider">
            {clases.filter(c=>c.fecha===d).map(c=>(
              <div key={c.k} className="p-3 grid sm:grid-cols-[11rem_1fr] gap-2 items-start">
                <div className="leading-tight">
                  <div className="font-bold text-sm text-ink">{labelHora(c.slot)} · {c.grupos.filter(Boolean).join(", ")||"—"}</div>
                  <div className="text-[11px] text-ink-soft">{c.materia}{c.aula?" · Aula "+c.aula:""}</div>
                </div>
                <textarea className="field !min-h-[44px] text-sm resize-y" rows={2} placeholder="Tarea para el grupo (qué deben hacer, dónde está el material…)"
                  aria-label={"Tarea "+labelHora(c.slot)+" "+fmtCorta(d)} value={valor[c.k]||""} onChange={e=>onCambio({...valor,[c.k]:e.target.value})}/>
              </div>))}
          </div>
        </div>))}
    </div>
  );
}
const tareasADetalle=v=>Object.fromEntries(Object.entries(v).filter(([,t])=>String(t||"").trim()).map(([k,t])=>[k,{obs:String(t).trim()}]));
const detalleATareas=d=>Object.fromEntries(Object.entries(d||{}).filter(([k,x])=>k.includes("|")&&x&&x.obs).map(([k,x])=>[k,x.obs]));

/* «Mis próximas ausencias»: el profesor/a ve las suyas y puede dejar o cambiar las tareas */
function MisAusencias({prof,acento,onToast,recarga}){
  const[lista,setLista]=useState(null);
  const[abierta,setAbierta]=useState("");
  const[tareas,setTareas]=useState({});const[general,setGeneral]=useState("");
  const[guardando,setGuardando]=useState(false);
  const cargar=()=>pedir("GET","/ausencias/mias").then(d=>setLista(d.ausencias||[])).catch(()=>setLista([]));
  useEffect(()=>{cargar();},[recarga]);
  if(!lista||!lista.length)return null;
  const abrir=a=>{if(abierta===a.id){setAbierta("");return;}setAbierta(a.id);setTareas(detalleATareas(a.detalle));setGeneral(a.obs||"");};
  const guardar=async a=>{
    setGuardando(true);
    try{const d=await pedir("PUT","/ausencias/"+a.id+"/tareas",{detalle:{...Object.fromEntries(Object.entries(a.detalle||{}).filter(([k])=>!k.includes("|"))),...tareasADetalle(tareas)},obs:general.trim()});
      setLista(d.ausencias||[]);setAbierta("");onToast&&onToast("Tareas guardadas: las verá el profesorado de guardia");}
    catch(e){onToast&&onToast(e.message);}
    setGuardando(false);
  };
  return(
    <div className="card p-5 mt-5">
      <div className="font-display font-bold text-ink mb-1">Mis próximas ausencias</div>
      <p className="text-xs text-ink-soft mb-3">Deja o cambia las tareas de cada clase: se verán en Guardias de aula y en el panel de la sala de profesores.</p>
      <div className="space-y-2">
        {lista.map(a=>{
          const n=Object.keys(detalleATareas(a.detalle)).length;
          const clases=clasesAusencia(prof,a.fecha,a.hasta,a.modo,(a.horas||[]).map(String));
          return(
          <div key={a.id} className="rounded-xl border border-divider">
            <div className="p-3 flex flex-wrap items-center gap-2">
              <div className="flex-1 min-w-[12rem] leading-tight">
                <div className="font-bold text-sm text-ink">{a.hasta?"Del "+fmtCorta(a.fecha)+" al "+fmtCorta(a.hasta):cap(fmtLarga(a.fecha))}</div>
                <div className="text-[11px] text-ink-soft">{a.modo==="horas"?"Horas: "+a.horas.map(labelHora).join(", "):"Todo el día"} · {a.estado==="Grabada"?"registrada por Jefatura":"pendiente de que Jefatura la registre"}</div>
              </div>
              <span className="pill" style={n?{background:"#dcfce7",color:"#166534"}:{background:"#fef3c7",color:"#92400e"}}>{n?n+" tarea"+(n===1?"":"s"):"Sin tareas"}</span>
              <button className="btn btn-ghost !min-h-[36px] !px-3 text-xs" onClick={()=>abrir(a)} aria-expanded={abierta===a.id}>{abierta===a.id?"Cerrar":n?"Ver / cambiar tareas":"Dejar tareas"}</button>
            </div>
            {abierta===a.id&&<div className="p-3 pt-0 space-y-3 fade-in">
              <EditorTareas clases={clases} valor={tareas} onCambio={setTareas} acento={acento}/>
              <div><label className="lbl">Indicaciones generales para la guardia</label><textarea className="field" rows={2} value={general} onChange={e=>setGeneral(e.target.value)} placeholder="Opcional"/></div>
              <button className="btn btn-dark" disabled={guardando} onClick={()=>guardar(a)}>{guardando?"Guardando…":"Guardar tareas"}</button>
            </div>}
          </div>);})}
      </div>
    </div>
  );
}

function PantallaAusencia({tile,onBack,ops,profs,usuario,esAdmin,arriba}){
  /* Cada profesor/a solo notifica sus propias ausencias; administración, las de cualquiera */
  const propio=(usuario&&usuario.profesor)||"";
  const[prof,setProf]=useState(esAdmin?"":propio);
  const[error,setError]=useState("");
  const[fecha,setFecha]=useState("");
  const[hasta,setHasta]=useState("");
  const[modo,setModo]=useState("dia");
  const[horas,setHoras]=useState([]);
  const[motivo,setMotivo]=useState("Cita médica");
  const[obs,setObs]=useState("");
  const[pasada,setPasada]=useState(false);      /* excepcional: ausencia de días anteriores */
  const[tareas,setTareas]=useState({});
  const[recarga,setRecarga]=useState(0);
  const[hecho,setHecho]=useState(null);
  const[enviando,setEnviando]=useState(false);
  const wd=fecha?diaSemanaDe(fecha):0;
  const finde=fecha&&(wd===0||wd===6);
  const sesiones=useMemo(()=>(prof&&wd>=1&&wd<=5)?ENTRADAS.filter(e=>e.profesor===prof&&e.dia===wd&&(e.cat==="docencia"||e.cat==="guardia"||e.cat==="recreo"||e.cat==="biblioteca"||(e.cat==="tutoria"&&e.grupo))):[],[prof,wd]);
  const horasConClase=useMemo(()=>new Set(sesiones.map(e=>String(e.slot))),[sesiones]);
  const idxH=id=>HORAS.findIndex(h=>h.n===String(id));
  const afectadas=sesiones.filter(e=>modo==="dia"||horas.indexOf(String(e.slot))>=0)
    .sort((a,b)=>idxH(a.slot)-idxH(b.slot));
  const ayer=(()=>{const d=new Date();d.setDate(d.getDate()-1);return isoDe(d);})();
  const hace30=(()=>{const d=new Date();d.setDate(d.getDate()-30);return isoDe(d);})();
  const fueraRango=fecha&&(pasada?(!esAdmin&&fecha<hace30):fecha<hoyISO());
  const clases=useMemo(()=>clasesAusencia(prof,fecha,hasta,modo,horas),[prof,fecha,hasta,modo,horas]);
  const valido=prof&&fecha&&!finde&&!fueraRango&&(modo==="dia"||horas.length>0)&&(!hasta||hasta>=fecha);
  const alternar=h=>setHoras(horas.indexOf(h)>=0?horas.filter(x=>x!==h):horas.concat(h));

  const texto=a=>"AUSENCIA · "+a.prof+"\nFecha: "+fmtLarga(a.fecha)+(a.hasta&&a.hasta!==a.fecha?" al "+fmtLarga(a.hasta):"")+
    "\n"+(a.modo==="dia"?"Todo el día":"Horas: "+a.horas.map(labelHora).join(", "))+"\nMotivo: "+a.motivo+(a.fecha<hoyISO()?"\nNotificada fuera de plazo (días anteriores)":"")+(a.obs?"\nObservaciones: "+a.obs:"")+
    (a.detalle&&Object.keys(a.detalle).length?"\nTareas para la guardia:\n"+Object.entries(a.detalle).map(([k,x])=>"  · "+fmtCorta(k.split("|")[0])+", "+labelHora(k.split("|")[1])+": "+x.obs).join("\n"):"");

  const enviar=async()=>{
    setEnviando(true);
    const detalle=tareasADetalle(Object.fromEntries(Object.entries(tareas).filter(([k])=>clases.some(c=>c.k===k))));
    const a={id:nuevoId(),prof,fecha,hasta:hasta&&hasta!==fecha?hasta:"",modo,horas:modo==="horas"?horas.slice().sort():[],motivo,obs:obs.trim(),detalle,creado:new Date().toISOString(),estado:"local"};
    setError("");
    const r=await ops.ausencia(a);
    if(r.error){setError(r.error);setEnviando(false);return;}
    if(r.ok)a.estado="enviada";
    /* copia local (solo para ver las guardias sin conexión): sin el motivo ni las observaciones (datos de salud) */
    {const{motivo:_m,obs:_o,...sinMotivo}=a;LS.set("vj_hor_ausencias",[sinMotivo].concat(LS.get("vj_hor_ausencias",[])).slice(0,30));}
    setHecho(a);setEnviando(false);setRecarga(x=>x+1);
  };
  const reiniciar=()=>{setHecho(null);setProf(esAdmin?"":propio);setFecha("");setHasta("");setModo("dia");setHoras([]);setObs("");setTareas({});setPasada(false);};

  if(hecho){
    const mail=CORREO_JEFATURA?"mailto:"+CORREO_JEFATURA+"?subject="+encodeURIComponent("Ausencia · "+hecho.prof+" · "+hecho.fecha)+"&body="+encodeURIComponent(texto(hecho)):"";
    return(
      <Seccion tile={tile} onBack={onBack}>
        {arriba}
        <div className="card p-6 fade-in">
          <div className="flex items-center gap-3 mb-4">
            <span className="w-11 h-11 rounded-full bg-olive-light text-olive flex items-center justify-center"><Ico n="check" s={22}/></span>
            <div><div className="font-display font-bold text-lg text-ink">{hecho.estado==="enviada"?"Ausencia notificada":"Ausencia registrada en este equipo"}</div>
            <div className="text-xs text-ink-soft font-medium">{hecho.estado==="enviada"?"Jefatura de Estudios la revisará y, al grabarla, aparecerá en Guardias de aula.":"No se ha podido enviar a Jefatura desde este equipo: avísales con alguno de estos botones."}</div></div>
          </div>
          <pre className="bg-paper-warm rounded-xl p-4 text-sm whitespace-pre-wrap font-body text-ink-soft mb-4">{texto(hecho)}</pre>
          <div className="flex gap-2 flex-wrap">
            <button className="btn btn-ghost" onClick={()=>{navigator.clipboard&&navigator.clipboard.writeText(texto(hecho));}}>Copiar texto</button>
            {mail&&<a className="btn btn-dark" href={mail}>Enviar por correo</a>}
            <button className="btn btn-ghost" onClick={reiniciar}>Notificar otra</button>
          </div>
        </div>
        {!esAdmin&&propio&&<MisAusencias prof={propio} acento={tile.g[0]} recarga={recarga}/>}
      </Seccion>
    );
  }
  const acento=tile.g[0];
  if(!esAdmin&&!propio)return(
    <Seccion tile={tile} onBack={onBack}>
      {arriba}
      <div className="card p-6 fade-in">
        <div className="font-display font-bold text-lg text-ink mb-1">No puedes notificar ausencias con esta cuenta</div>
        <p className="text-sm text-ink-soft">Tu cuenta ({usuario&&usuario.nombre||"sin nombre"}) no está vinculada a ningún profesor/a del horario. Pide a Jefatura de Estudios que revise el nombre de tu cuenta en «Usuarios».</p>
      </div>
    </Seccion>
  );
  return(
    <Seccion tile={tile} onBack={onBack}>
      {arriba}
      <div className="card p-5 space-y-5">
        <div>
          <label className="lbl">1 · ¿Quién se ausenta?</label>
          {esAdmin
            ?<><select className="field" value={prof} onChange={e=>setProf(e.target.value)}>
                <option value="">— Elige profesor/a —</option>
                {profs.map(p=><option key={p} value={p}>{p}</option>)}
              </select>
              <p className="text-[11px] text-ink-soft mt-1.5">Como administración puedes notificar la ausencia de cualquier profesor/a.</p></>
            :<><div className="field flex items-center gap-2 bg-paper-warm" aria-readonly="true"><Ico n="prof" s={16}/><b className="text-ink">{propio}</b></div>
              <p className="text-[11px] text-ink-soft mt-1.5">Solo puedes notificar tus propias ausencias. Si necesitas avisar de la de otra persona, díselo a Jefatura de Estudios.</p></>}
        </div>
        <div className="grid sm:grid-cols-2 gap-3">
          <div><label className="lbl">2 · Fecha</label><input type="date" className="field" min={pasada?(esAdmin?undefined:hace30):hoyISO()} max={pasada?ayer:undefined} value={fecha} onChange={e=>setFecha(e.target.value)}/></div>
          <div><label className="lbl">Hasta (opcional, varios días)</label><input type="date" className="field" min={fecha||hoyISO()} value={hasta} onChange={e=>setHasta(e.target.value)}/></div>
        </div>
        <label className="flex items-start gap-2.5 rounded-xl px-3 py-2.5 cursor-pointer text-sm border" style={pasada?{background:"#fff7ed",borderColor:"#fdba74"}:{borderColor:"transparent"}}>
          <input type="checkbox" className="mt-0.5 w-4 h-4" style={{accentColor:"#c2410c"}} checked={pasada} onChange={e=>{setPasada(e.target.checked);setFecha("");setHasta("");}}/>
          <span><b className="text-ink">Ausencia de días anteriores</b> <span className="text-ink-soft">(excepcional)</span>
            {pasada&&<span className="block text-[11px] text-[#9a3412] mt-0.5">Solo para ausencias que no pudiste avisar a tiempo, de los últimos 30 días. Jefatura la recibirá marcada como «notificada fuera de plazo».</span>}</span>
        </label>
        {finde&&<p className="text-xs font-semibold text-[#be123c]">La fecha elegida es fin de semana.</p>}
        {fueraRango&&<p className="text-xs font-semibold text-[#be123c]">{pasada?"Solo se pueden notificar ausencias de los últimos 30 días.":"Para un día anterior a hoy, marca «Ausencia de días anteriores»."}</p>}
        <div>
          <label className="lbl">3 · ¿Todo el día o solo algunas horas?</label>
          <div className="flex gap-2">
            {[["dia","Todo el día"],["horas","Horas concretas"]].map(m=>(
              <button key={m[0]} onClick={()=>setModo(m[0])} className={"chip flex-1 "+(modo===m[0]?"on":"")} style={modo===m[0]?{background:acento}:{}}>{m[1]}</button>
            ))}
          </div>
          {modo==="horas"&&(
            <div className="flex flex-wrap gap-2 mt-3 fade-in">
              {HORAS.filter(x=>!x.t||horasConClase.has(x.n)).map(x=>x.n).map(h=>{
                const on=horas.indexOf(h)>=0;const tiene=horasConClase.has(h);
                return(
                  <button key={h} onClick={()=>alternar(h)} className={"chip relative !px-4 "+(on?"on":"")} style={on?{background:acento}:{}} title={tiene?"Tienes actividad en esta hora":""}>
                    {h==="R1"||h==="R2"?"Recreo "+h.charAt(1):h+"ª"}
                    {tiene&&<span className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full" style={{background:on?"#fff":acento}}></span>}
                  </button>
                );
              })}
            </div>
          )}
          {modo==="horas"&&prof&&fecha&&<p className="text-[11px] text-ink-soft mt-2">El punto marca las horas en las que ese día tiene clase o guardia.</p>}
        </div>
        {afectadas.length>0&&(
          <div className="rounded-xl bg-paper-warm border border-divider p-4 fade-in">
            <div className="lbl">Se verá afectado</div>
            <div className="flex flex-wrap gap-1.5">
              {afectadas.map((e,i)=><span key={i} className={"px-2.5 py-1 rounded-lg text-[11px] font-semibold c-"+e.cat}>{labelHora(e.slot)} · {e.cat==="docencia"?(e.grupo||"")+(e.aula?" A"+e.aula:""):ETIQUETA[e.cat]}</span>)}
            </div>
          </div>
        )}
        <div className="grid sm:grid-cols-2 gap-3">
          <div><label className="lbl">4 · Motivo</label>
            <select className="field" value={motivo} onChange={e=>setMotivo(e.target.value)}>
              {["Cita médica","Asuntos propios (DAP)","Formación","Deber inexcusable","Actividad complementaria","Actividad extraescolar","Otro"].map(m=><option key={m}>{m}</option>)}
            </select>
            <p className="text-[11px] text-ink-soft mt-1.5">El motivo solo lo recibe Jefatura; no se muestra al resto del claustro.</p>
            <CapaRGPD className="mt-2">Jefatura de Estudios usa estos datos para organizar las guardias y tramitar la ausencia (misión de interés público y, si el motivo es de salud, RGPD art. 9.2.b). Indica solo el motivo, sin diagnósticos ni detalles médicos.</CapaRGPD>
          </div>
          <div><label className="lbl">Indicaciones generales para la guardia</label><textarea className="field" rows={3} value={obs} onChange={e=>setObs(e.target.value)} placeholder="Opcional (vale para todas las clases)"/></div>
        </div>
        {clases.length>0&&(
          <div className="fade-in">
            <label className="lbl">5 · Tareas para cada clase</label>
            <p className="text-[11px] text-ink-soft -mt-1 mb-2">Se verán en Guardias de aula y en el panel de la sala de profesores, en la hora de cada grupo. También podrás dejarlas o cambiarlas después, en «Mis próximas ausencias».</p>
            <EditorTareas clases={clases} valor={tareas} onCambio={setTareas} acento={acento}/>
          </div>)}
        {error&&<p className="text-xs font-semibold text-[#be123c]" role="alert">{error}</p>}
        <button className="btn btn-dark w-full !py-3" disabled={!valido||enviando} onClick={enviar}>{enviando?"Enviando…":"Notificar ausencia"}</button>
      </div>
      {!esAdmin&&propio&&<MisAusencias prof={propio} acento={acento} recarga={recarga}/>}
    </Seccion>
  );
}

/* ---------- Acceso de administración ---------- */
function ModalLogin({verificar,onOk,onClose}){
  const[p,setP]=useState("");const[err,setErr]=useState("");const[ocupado,setOcupado]=useState(false);
  const entrar=async()=>{
    if(!p||ocupado)return;
    setOcupado(true);setErr("");
    const r=await verificar(p);
    setOcupado(false);
    if(r==="ok")onOk(p);
    else setErr(r==="red"?"No se pudo conectar con el servidor":r==="mal"?"Contraseña incorrecta":r);
  };
  return(
    <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 no-print">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6 fade-in">
        <div className="flex justify-center mb-3"><LogoSVG size={70}/></div>
        <h2 className="font-display font-bold text-lg text-ink text-center">Acceso restringido</h2>
        <p className="text-xs text-ink-soft text-center mb-4 font-medium">Solo cuentas de administración. Escribe <b>la contraseña de tu propia cuenta</b>: cada acción queda registrada a tu nombre.</p>
        <input type="password" className="field mb-2" placeholder="Tu contraseña" autoComplete="current-password" aria-label="Tu contraseña" value={p} onChange={e=>{setP(e.target.value);setErr("");}} onKeyDown={e=>{if(e.key==="Enter")entrar();}} autoFocus/>
        {err&&<p className="text-xs font-semibold text-[#be123c] mb-2">{err}</p>}
        <div className="flex gap-2 mt-2"><button className="btn btn-ghost flex-1" onClick={onClose}>Cancelar</button><button className="btn btn-dark flex-1" disabled={ocupado} onClick={entrar}>{ocupado?"Comprobando…":"Entrar"}</button></div>
      </div>
    </div>
  );
}

/* ---------- Mi cuenta: cambiar contraseña y cerrar sesión ---------- */
function ModalCuenta({usuario,onClose,onToast,abrirDatos,onDatos}){
  const[cambiar,setCambiar]=useState(false);
  const[datos,setDatos]=useState(!!abrirDatos);
  const[yo,setYo]=useState(usuario);
  return(
    <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 no-print" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6 fade-in" onClick={e=>e.stopPropagation()}>
        <div className="flex items-center gap-3 mb-4">
          <span className="w-11 h-11 rounded-xl bg-paper-warm flex items-center justify-center text-ink-soft"><Ico n="prof" s={22}/></span>
          <div className="min-w-0">
            <div className="font-display font-bold text-ink leading-tight truncate">{usuario.nombre||usuario.usuario}</div>
            <div className="text-xs text-ink-soft font-medium">Usuario «{usuario.usuario}» · {etiquetaCuenta(usuario)}</div>
          </div>
        </div>
        {datos
          ?<FormMisDatos usuario={yo} onCancelar={()=>setDatos(false)} onHecho={u=>{setYo({...yo,...u});setDatos(false);try{localStorage.setItem("vj_usuario",JSON.stringify({...yo,...u}));}catch(e){}onDatos&&onDatos(u);onToast((u.datosFaltan||[]).length?"Datos guardados · aún falta: "+u.datosFaltan.join(", "):"Datos guardados");}}/>
          :cambiar
          ?<FormCambioClave onCancelar={()=>setCambiar(false)} onHecho={()=>{setCambiar(false);onClose();onToast("Contraseña cambiada");}}/>
          :<div className="space-y-2">
            {!sinDatosDocente(yo)&&<div className="rounded-xl bg-paper-warm p-3 text-xs text-ink-soft space-y-0.5">
              <div><b className="text-ink">Correo:</b> {yo.email||<span className="text-[#b45309] font-semibold">pendiente</span>}</div><div><b className="text-ink">Móvil:</b> {yo.movil||<span className="text-ink-soft">no indicado (voluntario)</span>}</div>
              <div><b className="text-ink">Años trabajados:</b> {yo.aniosServicio??<span className="text-[#b45309] font-semibold">pendiente</span>}</div></div>}
            {!sinDatosDocente(yo)&&(()=>{const f=!yo.email||!yo.movil||yo.aniosServicio==null;return <button className={"btn w-full "+(f?"btn-dark":"btn-ghost")} style={f?{background:"#b45309"}:{}} onClick={()=>setDatos(true)}><Ico n="lapiz" s={16}/>{f?"Completar mis datos (correo, móvil, años)":"Modificar mis datos (correo, móvil, años)"}</button>;})()}
            <DapEnCuenta/>
            <button className="btn btn-ghost w-full" onClick={()=>setCambiar(true)}><Ico n="llave" s={16}/>Cambiar mi contraseña</button>
            <button className="btn btn-dark w-full" onClick={cerrarSesion}><Ico n="salir" s={16}/>Cerrar sesión</button>
            <button className="btn btn-ghost w-full" onClick={onClose}>Volver</button>
          </div>}
      </div>
    </div>
  );
}

/* ---------- Usuarios: cuentas de acceso del profesorado (solo administración) ---------- */
function abrirCredenciales(lista){
  const filas=lista.map(c=>"<tr><td>"+esc(c.nombre)+"</td><td><b>"+esc(c.usuario)+"</b></td><td><b>"+esc(c.clave)+"</b></td></tr>").join("");
  const w=window.open("","_blank");
  if(!w){alert("El navegador ha bloqueado la ventana: permite ventanas emergentes para imprimir.");return;}
  w.document.write("<!doctype html><meta charset='utf-8'><title>Credenciales · Horarios IES Valle del Jerte</title>"+
    "<style>body{font-family:Montserrat,system-ui,sans-serif;margin:24px;color:#1a2332}h1{font-size:18px}p{font-size:12px;color:#3d4a5c}"+
    "table{border-collapse:collapse;width:100%;font-size:13px}td,th{border:1px dashed #9a968a;padding:10px 8px;text-align:left}th{background:#F5F3EE}</style>"+
    "<h1>IES Valle del Jerte · Acceso a la app de horarios</h1><p>Entra en la app con tu usuario y esta contraseña provisional; al entrar te pedirá elegir una contraseña personal. Recorta tu fila.</p>"+
    "<table><tr><th>Profesor/a</th><th>Usuario</th><th>Contraseña provisional</th></tr>"+filas+"</table>");
  w.document.close();w.focus();setTimeout(()=>w.print(),300);
}
const esc=t=>String(t==null?"":t).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
function descargarCredenciales(lista){
  const csv="Profesor/a;Usuario;Contraseña provisional\n"+lista.map(c=>[c.nombre,c.usuario,c.clave].map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(";")).join("\n");
  const a=document.createElement("a");a.href=URL.createObjectURL(new Blob(["﻿"+csv],{type:"text/csv;charset=utf-8"}));
  a.download="credenciales_"+hoyISO()+".csv";document.body.appendChild(a);a.click();a.remove();
}

/* ── Aulas: pestañas «Horario de las aulas» / «Reserva de espacios» ── */
/* ── Ausencias: pestañas «Notificar» y «Justificar» ── */
/* ── Disciplina ──
   El profesor/a comunica a Jefatura de Estudios una falta de disciplina con el impreso del centro (Decreto 50/2007).
   Se le asigna un código de registro y se generan dos PDF: el suyo (lo descarga) y el de Jefatura, que queda en la
   carpeta «disciplina» del servidor, en la subcarpeta del Jefe/a de Estudios adjunto de la etapa. Ese Jefe/a lo
   marca como recibido (OK) en su bandeja y el profesor/a ve el «Recibido» en la cabecera de su horario. */
const DISC_COLOR="#1d4ed8";
let abrirBandejaDisc=false;   /* el aviso de la entrada abre directamente la bandeja */
const ETAPA_COLOR={eso:"#7c3aed",bach:"#0369a1",fpd:"#0f766e",fp:"#b45309"};
const nombreNat=n=>{const[a,b]=String(n||"").split(",").map(s=>(s||"").trim());return b?b+" "+a:a;};
const fmtFH=s=>{if(!s)return"";const[f,h]=String(s).split(" ");const[a,m,d]=f.split("-");return d+"/"+m+"/"+a+(h?" · "+h:"");};
const pdfParte=(id,copia,descargar)=>API+"/disciplina/"+id+"/pdf?copia="+copia+(descargar?"&descargar=1":"");
function PestanasDisciplina({modo,onModo,bandeja,pendientes,tutor,nuevosTutoria}){
  const P=[["nuevo","Nuevo parte","lapiz"],["mios","Mis partes","informe"]].concat(tutor?[["tutoria","Partes de mi tutoría","grupos"]]:[]).concat(bandeja?[["bandeja","Partes recibidos (Jefatura)","escudo"],["carpeta","Carpeta de partes","carpeta"]]:[]);
  return(
    <div className="flex flex-wrap gap-2 mb-5 no-print" role="tablist">
      {P.map(([k,l,ico])=><button key={k} role="tab" aria-selected={modo===k} onClick={()=>onModo(k)} className={"chip flex items-center gap-2"+(modo===k?" on":"")} style={modo===k?{background:DISC_COLOR}:{}}>
        <Ico n={ico} s={16}/>{l}{k==="tutoria"&&nuevosTutoria>0&&<span className="min-w-[20px] h-5 px-1.5 rounded-full text-[11px] font-bold flex items-center justify-center" style={{background:modo===k?"#fff":DISC_COLOR,color:modo===k?DISC_COLOR:"#fff"}}>{nuevosTutoria}</span>}{k==="bandeja"&&pendientes>0&&<span className="min-w-[20px] h-5 px-1.5 rounded-full text-[11px] font-bold flex items-center justify-center" style={{background:modo===k?"#fff":DISC_COLOR,color:modo===k?DISC_COLOR:"#fff"}}>{pendientes}</span>}
      </button>)}
    </div>
  );
}
function EstadoParte({p}){
  return p.recibido
    ?<span className="pill" style={{background:"#dcfce7",color:"#166534"}} title={"Recibido por "+nombreNat(p.recibidoPor)+" el "+fmtFH(p.recibido)}>✓ Recibido · {fmtFH(p.recibido).split(" · ")[0]}</span>
    :<span className="pill" style={{background:"#fef3c7",color:"#92400e"}}>Pendiente de recibir</span>;
}
function PantallaDisciplina({tile,onBack,onToast,onResumen}){
  const[cfg,setCfg]=useState(null);
  const[error,setError]=useState("");
  const[modo,setModo]=useState(()=>{const b=abrirBandejaDisc;abrirBandejaDisc=false;return b||"nuevo";});
  const[mios,setMios]=useState(null);
  const[bandeja,setBandeja]=useState(null);
  const[hecho,setHecho]=useState(null);       /* parte recién registrado */
  const vacio=()=>({alumno:"",grupo:"",curso:"",grupoLetra:"",materia:"",fecha:hoyISO(),hora:"",contrarias:[],graves:[],observaciones:""});
  const[f,setF]=useState(vacio);
  const[enviando,setEnviando]=useState(false);
  const[soloPend,setSoloPend]=useState(true);
  const[ocupado,setOcupado]=useState(0);
  const[carpetas,setCarpetas]=useState(null);
  const[tutoria,setTutoria]=useState(null);
  const[buscaC,setBuscaC]=useState("");
  useEffect(()=>{pedir("GET","/disciplina/config").then(d=>{if(d.ok===false)setError(d.error);else setCfg(d);}).catch(e=>setError(e.message||"No se pudo cargar"));},[]);
  const cargarMios=()=>pedir("GET","/disciplina/mios").then(d=>setMios(d.partes||[])).catch(()=>setMios([]));
  const cargarBandeja=()=>pedir("GET","/disciplina/bandeja").then(d=>setBandeja(d.partes||[])).catch(()=>setBandeja([]));
  const cargarTutoria=()=>pedir("GET","/disciplina/tutoria").then(d=>setTutoria(d.partes||[])).catch(()=>setTutoria([]));
  const esTutorG=cfg&&cfg.soyTutorDe&&cfg.soyTutorDe.length>0;
  useEffect(()=>{if(esTutorG&&tutoria===null)cargarTutoria();},[esTutorG]);
  const leido=async p=>{setOcupado(p.id);try{const d=await pedir("POST","/disciplina/"+p.id+"/leido-tutor",{});if(d.ok===false)throw new Error(d.error);setTutoria(d.partes||[]);onResumen&&onResumen();}catch(err){onToast(err.message||"No se pudo guardar");}setOcupado(0);};
  const esJefe=cfg&&(cfg.esAdmin||cfg.soyResponsable.length>0);
  useEffect(()=>{if(modo==="mios")cargarMios();if(modo==="bandeja")cargarBandeja();if(modo==="tutoria")cargarTutoria();if(modo==="carpeta")pedir("GET","/disciplina/carpeta").then(d=>setCarpetas(d.ok===false?[]:d.carpetas||[])).catch(()=>setCarpetas([]));},[modo]);
  useEffect(()=>{if(esJefe&&bandeja===null)cargarBandeja();},[esJefe]);
  const grupoSel=cfg&&cfg.grupos.find(g=>g.codigo===f.grupo);
  const elegirGrupo=c=>{const g=cfg.grupos.find(x=>x.codigo===c);setF({...f,grupo:c,curso:g?g.curso:"",grupoLetra:g?g.letra:""});};
  const marca=(campo,k)=>setF({...f,[campo]:f[campo].includes(k)?f[campo].filter(x=>x!==k):f[campo].concat(k)});
  const enviar=async e=>{
    e.preventDefault();
    if(f.alumno.trim().length<3)return onToast("Escribe el nombre y apellidos del alumno/a");
    if(!f.grupo)return onToast("Elige el grupo");
    if(!f.contrarias.length&&!f.graves.length)return onToast("Marca al menos una conducta");
    setEnviando(true);
    try{
      const d=await pedir("POST","/disciplina",f);
      if(d.ok===false)throw new Error(d.error);
      setHecho(d.parte);setMios(d.mios);setF(vacio());window.scrollTo(0,0);onResumen&&onResumen();
    }catch(err){onToast(err.message||"No se pudo registrar el parte");}
    setEnviando(false);
  };
  const recibir=async(p,ok)=>{
    setOcupado(p.id);
    try{const d=await pedir("POST","/disciplina/"+p.id+"/recibido",{ok});if(d.ok===false)throw new Error(d.error);
      setBandeja(b=>b.map(x=>x.id===p.id?d.parte:x));onToast(ok?"Parte "+p.codigo+" marcado como recibido":"Recibido deshecho");onResumen&&onResumen();}
    catch(err){onToast(err.message||"No se pudo guardar");}
    setOcupado(0);
  };
  const arriba=<PestanasDisciplina modo={modo} onModo={m=>{setModo(m);setHecho(null);}} bandeja={esJefe} pendientes={(bandeja||[]).filter(p=>!p.recibido).length} tutor={esTutorG} nuevosTutoria={(tutoria||[]).filter(p=>!p.tutorVisto).length}/>;
  if(error)return <Seccion tile={tile} onBack={onBack}><div className="card p-5 text-sm font-semibold text-[#9f1239]">{error}</div></Seccion>;
  if(!cfg)return <Seccion tile={tile} onBack={onBack}><div className="card p-5 text-sm text-ink-soft">Cargando…</div></Seccion>;
  const lblConducta=(k)=>{const c=cfg.contrarias.concat(cfg.graves).find(x=>x[0]===k);return c?c[1]:k;};
  const misG=cfg.grupos.filter(g=>cfg.misGrupos.includes(g.codigo));
  const porEtapa=Object.keys(cfg.etapas).map(e=>[e,cfg.grupos.filter(g=>g.etapa===e)]);
  const Casillas=({titulo,campo,lista,color})=>(
    <fieldset className="flex-1 min-w-[16rem]">
      <legend className="text-xs font-semibold text-ink-soft mb-2">{titulo}</legend>
      <div className="space-y-1.5">{lista.map(([k,t])=>{const on=f[campo].includes(k);return(
        <label key={k} className="flex items-start gap-2.5 rounded-lg px-2.5 py-2 cursor-pointer text-[13px] leading-snug border transition" style={on?{background:color+"14",borderColor:color,color:"#111827",fontWeight:600}:{borderColor:"transparent"}}>
          <input type="checkbox" className="mt-0.5 w-4 h-4 flex-shrink-0" style={{accentColor:color}} checked={on} onChange={()=>marca(campo,k)}/><span>{t}</span></label>);})}</div>
    </fieldset>);
  return(
    <Seccion tile={tile} onBack={onBack}>
      {arriba}
      {modo==="nuevo"&&hecho&&(
        <div className="card p-5 mb-5 fade-in border-l-4" style={{borderColor:"#16a34a"}}>
          <div className="font-display font-bold text-lg text-ink">Parte registrado · {hecho.codigo}</div>
          <p className="text-sm text-ink-soft mt-1">Lo recibe <b className="text-ink">{nombreNat(hecho.responsable)}</b> ({cfg.etapas[hecho.etapa].nombre}){hecho.tutor&&hecho.tutor!==cfg.profesor?<> y se ha notificado al tutor/a, <b className="text-ink">{nombreNat(hecho.tutor)}</b></>:""}. Cuando lo marque como recibido, lo verás en la cabecera de tu horario y en «Mis partes».</p>
          <div className="flex flex-wrap gap-2 mt-4">
            <a className="btn btn-dark" href={pdfParte(hecho.id,"profesor",1)}><Ico n="imprimir" s={16}/>Descargar mi ejemplar (PDF)</a>
            <a className="btn btn-ghost" href={pdfParte(hecho.id,"profesor")} target="_blank" rel="noopener noreferrer">Ver el PDF</a>
            <button className="btn btn-ghost" onClick={()=>setHecho(null)}>Registrar otro parte</button>
          </div>
        </div>)}
      {modo==="nuevo"&&!hecho&&(
        <form className="card p-5 space-y-5" onSubmit={enviar}>
          <div className="text-center"><div className="font-display font-bold text-base sm:text-lg text-ink">Comunicación a Jefatura de Estudios de faltas de disciplina</div>
            <div className="text-xs text-ink-soft">Conductas recogidas en el Decreto 50/2007</div></div>
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2"><label className="lbl">Profesor/a</label><div className="field !bg-[#f8fafc] font-semibold">{nombreNat(cfg.profesor)}</div></div>
            <div className="sm:col-span-2"><label className="lbl" htmlFor="dis-al">Alumno/a (nombre y apellidos)</label><input id="dis-al" className="field" value={f.alumno} onChange={e=>setF({...f,alumno:e.target.value})} placeholder="Nombre y apellidos" autoComplete="off" required/></div>
            <div><label className="lbl" htmlFor="dis-gr">Grupo</label>
              <select id="dis-gr" className="field" value={f.grupo} onChange={e=>elegirGrupo(e.target.value)} required>
                <option value="">— Elige el grupo —</option>
                {misG.length>0&&<optgroup label="Mis grupos">{misG.map(g=><option key={"m"+g.codigo} value={g.codigo}>{g.codigo} · {g.curso} {g.letra}</option>)}</optgroup>}
                {porEtapa.map(([e,l])=>l.length>0&&<optgroup key={e} label={cfg.etapas[e].nombre}>{l.map(g=><option key={g.codigo} value={g.codigo}>{g.codigo} · {g.curso} {g.letra}</option>)}</optgroup>)}
              </select></div>
            <div className="grid grid-cols-2 gap-2">
              <div><label className="lbl" htmlFor="dis-cu">Curso</label><input id="dis-cu" className="field" value={f.curso} onChange={e=>setF({...f,curso:e.target.value})}/></div>
              <div><label className="lbl" htmlFor="dis-gl">Grupo (en el parte)</label><input id="dis-gl" className="field" value={f.grupoLetra} onChange={e=>setF({...f,grupoLetra:e.target.value})}/></div>
            </div>
            <div className="sm:col-span-2"><label className="lbl" htmlFor="dis-ma">Profesor/a de (materia)</label>
              <input id="dis-ma" className="field" list="dis-materias" value={f.materia} onChange={e=>setF({...f,materia:e.target.value})} placeholder="Materia o módulo"/>
              <datalist id="dis-materias">{cfg.misMaterias.map(m=><option key={m} value={m}/>)}</datalist></div>
            <div><label className="lbl" htmlFor="dis-fe">Día de los hechos</label><input id="dis-fe" type="date" className="field" max={hoyISO()} value={f.fecha} onChange={e=>setF({...f,fecha:e.target.value})} required/></div>
            <div><label className="lbl" htmlFor="dis-ho">Hora</label>
              <input id="dis-ho" className="field" list="dis-horas" value={f.hora} onChange={e=>setF({...f,hora:e.target.value})} placeholder="Elige o escribe la hora"/>
              <datalist id="dis-horas">{cfg.horas.map(h=><option key={h} value={h}/>)}</datalist></div>
          </div>
          {grupoSel&&<div className="rounded-xl px-4 py-3 text-sm flex items-center gap-2" style={{background:ETAPA_COLOR[grupoSel.etapa]+"14",color:ETAPA_COLOR[grupoSel.etapa]}}>
            <Ico n="escudo" s={18}/><span>Este parte lo recibirá <b>{nombreNat(grupoSel.responsable)}</b>, Jefe/a de Estudios adjunto de {cfg.etapas[grupoSel.etapa].nombre}{grupoSel.tutor?<>, y se notificará al tutor/a del grupo, <b>{nombreNat(grupoSel.tutor)}</b></>:" (este grupo no tiene tutor/a asignado en la app)"}.</span></div>}
          <div className="border-t border-divider pt-4">
            <div className="font-display font-bold text-ink text-center mb-3 underline underline-offset-4">Conductas recogidas en el decreto 50/2007</div>
            <div className="flex flex-wrap gap-5">
              <Casillas titulo="Conductas contrarias recogidas en el artículo 37" campo="contrarias" lista={cfg.contrarias} color="#b45309"/>
              <Casillas titulo="Conductas gravemente perjudiciales para la convivencia, recogidas en el artículo 40" campo="graves" lista={cfg.graves} color="#be123c"/>
            </div>
          </div>
          <div><label className="lbl" htmlFor="dis-ob">Aclaraciones / observaciones de los hechos si se estiman necesarias, testigos, lugar…</label>
            <textarea id="dis-ob" className="field resize-y" rows={5} maxLength={2500} value={f.observaciones} onChange={e=>setF({...f,observaciones:e.target.value})}/></div>
          <CapaRGPD>Los datos del alumno/a solo los ven tú y el Jefe/a de Estudios de la etapa; el tutor/a recibe un aviso sin datos personales. Base: función educativa (LOE, disp. adic. 23.ª) y Decreto 50/2007. Todo el personal tiene deber de sigilo: no compartas el parte por otros medios.</CapaRGPD>
          <p className="text-[11px] text-ink-soft">Este parte se archivará en Jefatura de Estudios, se informará al Tutor y se podrá poner en conocimiento de los padres/tutores legales a decisión de la Jefatura de Estudios. En caso de suspensión del derecho de asistencia a clase, el tutor informará a los representantes legales del alumno/a (D. 50/2007, art. 38.1.b).</p>
          <div className="flex justify-end"><button className="btn btn-dark" disabled={enviando} style={{background:DISC_COLOR}}>{enviando?"Registrando…":"Registrar y generar los PDF"}</button></div>
        </form>)}
      {modo==="mios"&&(
        mios===null?<div className="card p-5 text-sm text-ink-soft">Cargando…</div>
        :!mios.length?<div className="card p-6 text-sm text-ink-soft text-center">Aún no has registrado ningún parte.</div>
        :<div className="space-y-3">{mios.map(p=>(
          <div key={p.id} className="card p-4 flex flex-wrap items-center gap-3">
            <div className="flex-1 min-w-[14rem]">
              <div className="flex items-center gap-2 flex-wrap"><b className="font-display text-ink">{p.codigo}</b><EstadoParte p={p}/></div>
              <div className="text-sm text-ink font-semibold mt-1">{p.alumno} · {p.grupo}</div>
              <div className="text-xs text-ink-soft">Hechos del {fmtCorta(p.fecha)}{p.hora?" · "+p.hora:""} · lo recibe {nombreNat(p.responsable)}{p.tutor?" · tutor/a: "+nombreNat(p.tutor):""}{p.recibido?" · recibido por "+nombreNat(p.recibidoPor)+" el "+fmtFH(p.recibido):""}</div>
            </div>
            <a className="btn btn-ghost !min-h-[38px] text-xs" href={pdfParte(p.id,"profesor",1)}><Ico n="imprimir" s={15}/>Mi PDF</a>
          </div>))}</div>)}
      {modo==="tutoria"&&esTutorG&&(
        tutoria===null?<div className="card p-5 text-sm text-ink-soft">Cargando…</div>
        :<div className="space-y-3">
          <p className="text-xs text-ink-soft font-medium">Avisos de conductas contrarias registradas en tu tutoría ({cfg.soyTutorDe.join(", ")}). Por protección de datos solo se indica el grupo y la fecha: para conocer el alumno/a y los hechos, consulta con Jefatura de Estudios.</p>
          {!tutoria.length?<div className="card p-6 text-sm text-ink-soft text-center">No hay avisos de tu grupo.</div>
          :tutoria.map(p=>(
            <div key={p.id} className="card p-4 border-l-4" style={{borderColor:p.tutorVisto?"#cbd5e1":DISC_COLOR}}>
              <div className="flex flex-wrap items-center gap-3">
                <div className="flex-1 min-w-[14rem]">
                  <div className="flex items-center gap-2 flex-wrap"><b className="font-display text-ink">{p.codigo}</b>
                    {!p.tutorVisto&&<span className="pill" style={{background:"#dbeafe",color:DISC_COLOR}}>Nuevo</span>}</div>
                  <div className="text-sm text-ink mt-1">Se ha registrado una <b>conducta contraria</b> de un alumno/a del grupo <b>{p.grupo}</b> · hechos del {fmtCorta(p.fecha)}.</div>
                  {p.tutorVisto&&<div className="text-[11px] text-ink-soft mt-0.5">Leído el {fmtFH(p.tutorVisto)}</div>}
                </div>
                {!p.tutorVisto&&<button className="btn btn-dark !min-h-[40px]" style={{background:DISC_COLOR}} disabled={ocupado===p.id} onClick={()=>leido(p)}>✓ Leído</button>}
              </div>
            </div>))}
        </div>)}
      {modo==="carpeta"&&esJefe&&(
        carpetas===null?<div className="card p-5 text-sm text-ink-soft">Cargando…</div>
        :<div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="text-xs text-ink-soft font-medium">Carpeta «disciplina» del servidor · ejemplares de Jefatura de Estudios{cfg.esAdmin?" de las cuatro etapas":""}. Solo están los partes <b>pendientes de recibir</b>: al pulsar «Recibido (OK)» el PDF se borra de la carpeta (protección de datos) y puede volver a generarse desde «Partes recibidos».</p>
            <input className="field !w-auto !min-h-[38px] text-sm" placeholder="Buscar alumno/a, grupo o código…" value={buscaC} onChange={e=>setBuscaC(e.target.value)} aria-label="Buscar en la carpeta"/>
          </div>
          {carpetas.map(c=>{
            const q=normProfe(buscaC);
            const l=c.archivos.filter(a=>!q||normProfe(a.nombre+" "+a.alumno+" "+a.grupo).includes(q));
            return(
            <div key={c.etapa} className="card p-4">
              <div className="flex items-center gap-3 mb-3">
                <span className="w-10 h-10 rounded-xl flex items-center justify-center text-white" style={{background:ETAPA_COLOR[c.etapa]}}><Ico n="carpeta" s={20}/></span>
                <div className="leading-tight flex-1"><div className="font-display font-bold text-ink">disciplina / {c.nombre}</div>
                  <div className="text-xs text-ink-soft">{c.etapaNombre} · {c.archivos.length} parte{c.archivos.length===1?"":"s"}</div></div>
              </div>
              {!l.length?<p className="text-sm text-ink-soft px-1">{c.archivos.length?"Ningún parte coincide con la búsqueda.":"Carpeta vacía: no hay partes pendientes de recibir."}</p>
              :<ul className="divide-y divide-divider">{l.map(a=>{const url=API+"/disciplina/carpeta/archivo?etapa="+c.etapa+"&nombre="+encodeURIComponent(a.nombre);return(
                <li key={a.nombre} className="py-2.5 flex flex-wrap items-center gap-3">
                  <span className="text-[#b91c1c] text-[10px] font-extrabold border border-[#fca5a5] rounded px-1 py-0.5">PDF</span>
                  <div className="flex-1 min-w-[12rem] leading-tight">
                    <div className="text-sm font-semibold text-ink break-all">{a.nombre}</div>
                    <div className="text-[11px] text-ink-soft">{new Date(a.fecha).toLocaleString("es-ES",{day:"numeric",month:"short",year:"numeric",hour:"2-digit",minute:"2-digit"})} · {Math.max(1,Math.round(a.bytes/1024))} KB{a.codigo?(a.recibido?" · ✓ recibido":" · pendiente de recibir"):""}</div>
                  </div>
                  <a className="btn btn-ghost !min-h-[34px] !px-3 text-xs" href={url} target="_blank" rel="noopener noreferrer">Ver</a>
                  <a className="btn btn-ghost !min-h-[34px] !px-3 text-xs" href={url+"&descargar=1"}><Ico n="descargar" s={14}/>Descargar</a>
                </li>);})}</ul>}
            </div>);})}
        </div>)}
      {modo==="bandeja"&&esJefe&&(()=>{
        const lista=(bandeja||[]).filter(p=>!soloPend||!p.recibido);
        return <>
          <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
            <p className="text-xs text-ink-soft font-medium">{cfg.esAdmin?"Jefatura ve los partes de todas las etapas.":"Partes de "+cfg.soyResponsable.map(e=>cfg.etapas[e].nombre).join(" y ")+"."} Los PDF se guardan en la carpeta «disciplina» del servidor.</p>
            <div className="flex gap-1.5">{[[true,"Pendientes"],[false,"Todos"]].map(([v,l])=><button key={l} className={"chip"+(soloPend===v?" on":"")} style={soloPend===v?{background:DISC_COLOR}:{}} onClick={()=>setSoloPend(v)}>{l}</button>)}</div>
          </div>
          {bandeja===null?<div className="card p-5 text-sm text-ink-soft">Cargando…</div>
          :!lista.length?<div className="card p-6 text-sm text-ink-soft text-center">{soloPend?"No hay partes pendientes de recibir.":"Todavía no hay partes."}</div>
          :<div className="space-y-3">{lista.map(p=>(
            <div key={p.id} className="card p-4 border-l-4" style={{borderColor:p.recibido?"#16a34a":ETAPA_COLOR[p.etapa]}}>
              <div className="flex flex-wrap items-start gap-3">
                <div className="flex-1 min-w-[15rem]">
                  <div className="flex items-center gap-2 flex-wrap"><b className="font-display text-ink">{p.codigo}</b><EstadoParte p={p}/>{cfg.esAdmin&&<span className="pill" style={{background:ETAPA_COLOR[p.etapa]+"18",color:ETAPA_COLOR[p.etapa]}}>{nombreNat(p.responsable)}</span>}</div>
                  <div className="text-sm text-ink font-semibold mt-1">{p.alumno} · {p.curso} {p.grupoLetra} <span className="text-ink-soft font-medium">({p.grupo})</span></div>
                  <div className="text-xs text-ink-soft">Comunica {nombreNat(p.profesor)}{p.materia?" ("+p.materia+")":""} · hechos del {fmtCorta(p.fecha)}{p.hora?" · "+p.hora:""} · registrado {fmtFH(p.creado)}</div>
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {p.contrarias.map(k=><span key={k} className="text-[11px] font-semibold rounded-md px-2 py-0.5" style={{background:"#fef3c7",color:"#92400e"}} title="Conducta contraria (art. 37)">{lblConducta(k)}</span>)}
                    {p.graves.map(k=><span key={k} className="text-[11px] font-semibold rounded-md px-2 py-0.5" style={{background:"#ffe4e6",color:"#9f1239"}} title="Conducta gravemente perjudicial (art. 40)">{lblConducta(k)}</span>)}
                  </div>
                  {p.observaciones&&<p className="text-xs text-ink mt-2 whitespace-pre-line">{p.observaciones}</p>}
                </div>
                <div className="flex flex-col gap-2 items-stretch">
                  {!p.recibido
                    ?<button className="btn btn-dark !min-h-[40px]" style={{background:"#16a34a"}} disabled={ocupado===p.id} onClick={()=>recibir(p,true)} title="Al recibirlo, el PDF se borra de la carpeta del servidor">✓ Recibido (OK)</button>
                    :<button className="btn btn-ghost !min-h-[36px] text-xs" disabled={ocupado===p.id} onClick={()=>recibir(p,false)}>Deshacer recibido</button>}
                  <a className="btn btn-ghost !min-h-[36px] text-xs" href={pdfParte(p.id,"jefatura")} target="_blank" rel="noopener noreferrer"><Ico n="imprimir" s={15}/>Ver PDF</a>
                </div>
              </div>
            </div>))}</div>}
        </>;
      })()}
    </Seccion>
  );
}
/* En la cabecera del horario del profesor/a: recibidos de sus partes que aún no ha visto */
function AvisoDisciplina({nombre}){
  const[d,setD]=useState(null);
  const[tut,setTut]=useState([]);
  useEffect(()=>{let vivo=true;setD(null);setTut([]);
    pedir("GET","/disciplina/mios").then(r=>{if(!vivo)return;setD(r);
      if(r&&r.profesor&&normProfe(r.profesor)===normProfe(nombre))pedir("GET","/disciplina/tutoria").then(t=>{if(vivo)setTut((t.partes||[]).filter(p=>!p.tutorVisto));}).catch(()=>{});
    }).catch(()=>{});return()=>{vivo=false;};},[nombre]);
  if(!d||!d.profesor||normProfe(d.profesor)!==normProfe(nombre))return null;
  /* protección de datos: las notificaciones de conductas contrarias solo las reciben Jefatura de Estudios y el tutor/a;
     quien pone el parte ve su estado en «Disciplina → Mis partes», sin avisos */
  const nuevos=[];const pend=0;
  const leidoT=async p=>{try{await pedir("POST","/disciplina/"+p.id+"/leido-tutor",{});setTut(t=>t.filter(x=>x.id!==p.id));}catch{}};
  if(!nuevos.length&&!pend&&!tut.length)return null;
  const visto=async p=>{try{await pedir("POST","/disciplina/"+p.id+"/visto",{});setD({...d,partes:d.partes.map(x=>x.id===p.id?{...x,visto:true}:x)});}catch{}};
  return(
    <div className="mt-3 pt-3 border-t border-divider space-y-2 text-xs">
      {nuevos.map(p=>(
        <div key={p.id} className="rounded-xl px-3.5 py-2.5 flex items-center gap-3 flex-wrap" style={{background:"#dcfce7",color:"#166534"}}>
          <span className="w-7 h-7 rounded-full bg-white flex items-center justify-center font-bold" aria-hidden="true">✓</span>
          <span className="flex-1 min-w-[12rem]"><b>Recibido</b> · parte de disciplina {p.codigo} ({p.alumno}, {p.grupo}) recibido por {nombreNat(p.recibidoPor)} el {fmtFH(p.recibido)}.</span>
          <button className="font-bold underline underline-offset-2" onClick={()=>visto(p)}>Entendido</button>
        </div>))}
      {tut.map(p=>(
        <div key={"t"+p.id} className="rounded-xl px-3.5 py-2.5 flex items-center gap-3 flex-wrap" style={{background:"#dbeafe",color:"#1e3a8a"}}>
          <span className="w-7 h-7 rounded-full bg-white flex items-center justify-center flex-shrink-0" style={{color:DISC_COLOR}} aria-hidden="true"><Ico n="disciplina" s={16}/></span>
          <span className="flex-1 min-w-[12rem]"><b>Tu tutoría</b> · se ha registrado una conducta contraria de un alumno/a del grupo {p.grupo} (hechos del {fmtCorta(p.fecha)}). Para más información, consulta con Jefatura de Estudios.</span>
          <button className="font-bold underline underline-offset-2" onClick={()=>leidoT(p)}>Leído</button>
        </div>))}
      {pend>0&&<div className="font-semibold" style={{color:"#92400e"}}>{pend} parte{pend===1?"":"s"} de disciplina pendiente{pend===1?"":"s"} de recibir por Jefatura.</div>}
    </div>
  );
}
const normProfe=s=>String(s||"").normalize("NFD").replace(/[̀-ͯ]/g,"").toLowerCase().replace(/\s+/g," ").trim();

/* ── DAP · Días de Asuntos Particulares ──
   Profesorado: pide días en un calendario (hasta 3 meses vista) dentro de los que le corresponden.
   Directora (perfil «direccion»): concede, deniega o revoca; bloquea días. Administración 1 y 2 y Jefatura: lo ven todo.
   Al concederse, el día se graba como ausencia DAP (Ausencias, Guardias y panel). Resolución en PDF firmada. */
const DAP_COLOR="#0e7490";
const DAP_EST={solicitada:["Pendiente","#fef3c7","#92400e"],concedida:["Concedido","#dcfce7","#166534"],denegada:["Denegado","#ffe4e6","#9f1239"],revocada:["Revocado","#ffe4e6","#9f1239"],anulada:["Retirada","#f1f5f9","#475569"]};
/* Diagnóstico paso a paso de la escritura en el calendario de Google «Asuntos propios (DAP)» */
function DiagnosticoCalendarioDap({estado,onCambio,onHecho}){
  useEffect(()=>{if(estado.cargando)pedir("GET","/dap/diagnostico-calendario").then(d=>{onCambio(d);onHecho&&onHecho();}).catch(e=>onCambio({error:e.message,pasos:[]}));},[estado.cargando]);
  return(
    <div className="card p-4 mb-3 text-sm">
      <div className="flex items-center gap-2 mb-2"><b className="font-display text-ink flex-1">Diagnóstico del calendario de Google</b>
        <button className="btn btn-ghost !min-h-[30px] text-xs" disabled={estado.cargando} onClick={()=>onCambio({cargando:true})}>Repetir</button>
        <button className="btn btn-ghost !min-h-[30px] text-xs" onClick={()=>onCambio(null)}>Cerrar</button></div>
      {estado.cargando?<p className="text-ink-soft text-xs">Comprobando paso a paso (puede tardar unos segundos)…</p>
      :estado.error?<p className="text-[#be123c] text-xs font-semibold">{estado.error}</p>
      :<><ol className="space-y-1.5">{estado.pasos.map((p,i)=><li key={i} className="rounded-lg px-3 py-2" style={{background:p.ok?"#f0fdf4":"#fff1f2"}}>
          <div className="font-semibold" style={{color:p.ok?"#166534":"#9f1239"}}>{p.ok?"✔":"✖"} {p.titulo}</div>
          <div className="text-xs text-ink-soft break-all">{p.detalle}</div>
          {!p.ok&&p.ayuda&&<div className="text-xs mt-1 text-ink"><b>Qué hacer:</b> {p.ayuda}</div>}</li>)}</ol>
        {estado.reintento&&<p className="text-xs mt-2 font-semibold" style={{color:"#166534"}}>Todo correcto. Reintentados {estado.reintento.pendientes} DAP pendientes: {estado.reintento.ok} apuntados en Google{estado.reintento.fallos?", "+estado.reintento.fallos+" con error ("+estado.reintento.error+")":""}.</p>}
        {(estado.pendientes||[]).length>0&&!estado.reintento&&<p className="text-xs mt-2 text-ink-soft">{estado.pendientes.length} DAP concedidos esperan a apuntarse en Google. Se apuntarán solos cuando todos los pasos estén en verde.</p>}</>}
    </div>);
}
const dapPdf=(id,descargar)=>API+"/dap/solicitudes/"+id+"/pdf"+(descargar?"?descargar=1":"");
/* impreso oficial «Permiso por asuntos particulares (Art. 12)»: lo imprimen Administración 1 y 2 (y Dirección/Jefatura) */
const dapImpreso=id=>API+"/dap/solicitudes/"+id+"/impreso";
const BotonImpreso=({s})=>["concedida","denegada","revocada"].includes(s.estado)?<a className="btn !min-h-[36px] text-xs text-white" style={{background:"#1f2d4d"}} href={dapImpreso(s.id)} target="_blank" rel="noopener noreferrer" title="Impreso del centro: ejemplar para registro y para el interesado"><Ico n="imprimir" s={15}/>Impreso oficial</a>:null;
const nomNat=n=>{const[a,b]=String(n||"").split(",").map(s=>(s||"").trim());return b?b+" "+a:a;};
const nomCorto=n=>{const[a,b]=String(n||"").split(",").map(s=>(s||"").trim());return b?b.split(" ")[0]+" "+a.split(" ")[0]:a;};
let abrirDapEn="";
/* DAP que no vienen de una solicitud: apuntados en el calendario de Google «Asuntos propios (DAP)» o grabados en Ausencias */
const nomDap=s=>s.sinReconocer?"«"+s.profesor+"»":nomNat(s.profesor);
const origenDap=s=>s.origen==="calendario"?"Apuntado en el calendario «Asuntos propios (DAP)»":s.origen==="ausencias"?"Grabado por Jefatura en Ausencias":"";
function ChipDap({e}){const x=DAP_EST[e]||DAP_EST.anulada;return <span className="pill" style={{background:x[1],color:x[2]}}>{x[0]}</span>;}
function addMes(iso,n){const d=new Date(iso+"T12:00:00");d.setDate(1);d.setMonth(d.getMonth()+n);return isoDe(d).slice(0,8)+"01";}
function finMes(iso){const d=new Date(iso+"T12:00:00");d.setMonth(d.getMonth()+1);d.setDate(0);return isoDe(d);}

function CalendarioDap({cal,mes,setMes,gestiona,misFechas,onDia,sel,yo}){
  const ini=mes,fin=finMes(mes);
  const primero=(new Date(ini+"T12:00:00").getDay()+6)%7;
  const dias=[];for(let i=0;i<primero;i++)dias.push(null);
  for(let d=ini;d<=fin;d=sumarDias(d,1))dias.push(d);
  const bl=Object.fromEntries((cal.bloqueos||[]).map(b=>[b.fecha,b]));
  const minMes=cal.hoy.slice(0,8)+"01",maxMes=cal.limite.slice(0,8)+"01";
  return(
    <div className="card p-4">
      <div className="flex items-center justify-between mb-3">
        <button className="btn btn-ghost !min-h-[36px] !px-3" disabled={mes<=minMes&&!gestiona} onClick={()=>setMes(addMes(mes,-1))} aria-label="Mes anterior">‹</button>
        <div className="font-display font-bold text-lg text-ink">{cap(MESES[+mes.slice(5,7)-1])} {mes.slice(0,4)}</div>
        <button className="btn btn-ghost !min-h-[36px] !px-3" disabled={mes>=maxMes&&!gestiona} onClick={()=>setMes(addMes(mes,1))} aria-label="Mes siguiente">›</button>
      </div>
      <div className="grid grid-cols-7 gap-1.5 text-center text-[11px] font-bold text-ink-soft mb-1">{["L","M","X","J","V","S","D"].map(d=><div key={d}>{d}</div>)}</div>
      <div className="grid grid-cols-7 gap-1.5">
        {dias.map((d,i)=>{
          if(!d)return <div key={"v"+i}/>;
          const wd=new Date(d+"T12:00:00").getDay(),finde=wd===0||wd===6;
          const info=cal.dias[d]||{concedidas:{diurno:0,vespertino:0},pendientes:0,solicitudes:[]};
          const b=bl[d],mia=misFechas[d];
          const fuera=d<=cal.hoy||d>cal.limite;
          const lleno=info.concedidas.diurno>=cal.cupo&&info.concedidas.vespertino>=cal.cupo;
          const clic=!finde&&(gestiona||(!fuera&&!b));
          let estilo={background:"#fff",borderColor:"#e7e1ec"};
          if(finde||(fuera&&!gestiona))estilo={background:"#f5f4f0",borderColor:"#f0ede6",opacity:.55};
          if(!finde&&!(fuera&&!gestiona)&&(info.concedidas.diurno+info.concedidas.vespertino)>0)estilo={background:"#f0fdf4",borderColor:"#bbf7d0"};
          if(!finde&&!(fuera&&!gestiona)&&info.pendientes>0&&!(info.concedidas.diurno+info.concedidas.vespertino))estilo={background:"#fffbeb",borderColor:"#fde68a"};
          if(b)estilo={background:"repeating-linear-gradient(135deg,#fde8ee 0 6px,#fff 6px 12px)",borderColor:"#fda4af"};
          if(mia)estilo={...estilo,background:DAP_EST[mia.estado][1],borderColor:DAP_EST[mia.estado][2]};
          if(sel===d)estilo={...estilo,boxShadow:"0 0 0 3px "+DAP_COLOR};
          return(
            <button key={d} type="button" disabled={!clic} onClick={()=>onDia(d)} title={b?b.motivo:""}
              className="rounded-lg border min-h-[64px] sm:min-h-[76px] p-1.5 text-left flex flex-col gap-0.5 transition hover:shadow-md disabled:hover:shadow-none disabled:cursor-default" style={estilo}>
              <span className="text-xs font-bold text-ink">{+d.slice(8)}</span>
              {b&&<span className="text-[9px] leading-tight font-bold text-[#9f1239] line-clamp-2">{b.motivo}</span>}
              {mia&&<span className="text-[9px] font-bold" style={{color:DAP_EST[mia.estado][2]}}>Mi DAP · {DAP_EST[mia.estado][0]}</span>}
              {!finde&&!b&&(info.concedidas.diurno+info.concedidas.vespertino+info.pendientes)>0&&<span className="text-[9px] leading-tight text-ink-soft">
                {lleno?<b className="text-[#be123c]">Completo</b>:<>D {info.concedidas.diurno}/{cal.cupo} · V {info.concedidas.vespertino}/{cal.cupo}</>}
                {info.pendientes>0&&<span className="block text-[#b45309] font-semibold">{info.pendientes} pendiente{info.pendientes>1?"s":""}</span>}</span>}
              {!finde&&info.solicitudes.filter(s=>!yo||s.profesor!==yo).slice(0,3).map(s=><span key={s.id} className="text-[9px] leading-tight truncate font-semibold" style={{color:DAP_EST[s.estado][2]}} title={nomDap(s)}>{s.sinReconocer?s.profesor:nomCorto(s.profesor)}</span>)}
              {!finde&&info.solicitudes.filter(s=>!yo||s.profesor!==yo).length>3&&<span className="text-[9px] font-semibold text-ink-soft">+{info.solicitudes.filter(s=>!yo||s.profesor!==yo).length-3} más</span>}
            </button>);
        })}
      </div>
      <div className="flex flex-wrap gap-3 mt-3 text-[11px] text-ink-soft">
        <span className="flex items-center gap-1"><i className="w-3 h-3 rounded border" style={{background:"repeating-linear-gradient(135deg,#fde8ee 0 3px,#fff 3px 6px)",borderColor:"#fda4af"}}/>Bloqueado (evaluaciones, claustros…)</span>
        <span className="flex items-center gap-1"><i className="w-3 h-3 rounded" style={{background:"#fef3c7"}}/>Pendiente</span>
        <span className="flex items-center gap-1"><i className="w-3 h-3 rounded" style={{background:"#dcfce7"}}/>Concedido (también los del calendario de Google)</span>
        <span>D / V: concedidos en turno diurno / vespertino (máx. {cal.cupo} por turno)</span>
      </div>
    </div>
  );
}

function PantallaDap({tile,onBack,onToast,onAvisos}){
  const[mio,setMio]=useState(null);const[cal,setCal]=useState(null);const[err,setErr]=useState("");
  const[diag,setDiag]=useState(null);   /* diagnóstico de la escritura en el calendario de Google */
  const[mes,setMes]=useState(()=>hoyISO().slice(0,8)+"01");
  const[modo,setModo]=useState(()=>{const m=abrirDapEn;abrirDapEn="";return m;});
  const[sel,setSel]=useState("");const[obs,setObs]=useState("");const[ocupado,setOcupado]=useState(false);
  const[lista,setLista]=useState(null);const[registro,setRegistro]=useState(null);const[filtro,setFiltro]=useState("solicitada");
  const[nota,setNota]=useState({});const[fm,setFm]=useState({});const[motivoBl,setMotivoBl]=useState("");
  const cargarCal=(m=mes)=>pedir("GET","/dap/calendario?desde="+addMes(m,-1)+"&hasta="+finMes(addMes(m,1))).then(setCal).catch(e=>setErr(e.message));
  const cargarMio=()=>pedir("GET","/dap/mio").then(d=>{setMio(d);setModo(x=>x||(d.rol!=="profesor"?"calendario":d.profesor?"solicitar":"calendario"));}).catch(e=>setErr(e.message));
  const cargarLista=(f=filtro)=>pedir("GET","/dap/solicitudes"+(f?"?estado="+f:"")).then(d=>setLista(d.solicitudes)).catch(e=>onToast(e.message));
  useEffect(()=>{cargarMio();},[]);
  useEffect(()=>{cargarCal(mes);},[mes]);
  useEffect(()=>{if(modo==="pendientes")cargarLista("solicitada");if(modo==="historial")cargarLista(filtro);if(modo==="registro")pedir("GET","/dap/registro").then(d=>{setRegistro(d.eventos);onAvisos&&onAvisos();}).catch(()=>setRegistro([]));},[modo,filtro]);
  useEffect(()=>{if(mio&&mio.solicitudes)mio.solicitudes.filter(s=>!s.visto&&!s.origen).forEach(s=>pedir("POST","/dap/solicitudes/"+s.id+"/visto",{}).then(()=>onAvisos&&onAvisos()).catch(()=>{}));},[mio]);
  if(err)return <Seccion tile={tile} onBack={onBack}><div className="card p-5 text-sm font-semibold text-[#9f1239]">{err}</div></Seccion>;
  if(!mio||!cal)return <Seccion tile={tile} onBack={onBack}><div className="card p-5 text-sm text-ink-soft">Cargando…</div></Seccion>;
  const rol=mio.rol,dir=rol==="direccion",gestiona=rol!=="profesor";
  const misFechas=Object.fromEntries((mio.solicitudes||[]).filter(s=>s.estado==="solicitada"||s.estado==="concedida").map(s=>[s.fecha,s]));
  const sal=mio.saldo;
  const refrescar=()=>{cargarMio();cargarCal();if(modo==="pendientes")cargarLista("solicitada");if(modo==="historial")cargarLista(filtro);onAvisos&&onAvisos();};
  const solicitar=async()=>{setOcupado(true);try{await pedir("POST","/dap/solicitudes",{fecha:sel,observaciones:obs});onToast("Solicitud enviada a la Dirección");setSel("");setObs("");refrescar();}catch(e){onToast(e.message);}setOcupado(false);};
  const anular=async s=>{if(!confirm("¿Retirar la solicitud del "+fmtLarga(s.fecha)+"?"))return;try{await pedir("POST","/dap/solicitudes/"+s.id+"/anular",{});onToast("Solicitud retirada");refrescar();}catch(e){onToast(e.message);}};
  const resolver=async(s,accion)=>{
    const n=(nota[s.id]||"").trim();
    if(accion==="revocar"&&!n)return onToast("Escribe el motivo de la revocación");
    if(accion==="denegar"&&!confirm("¿Denegar el DAP de "+nomNat(s.profesor)+" del "+fmtLarga(s.fecha)+"?"))return;
    setOcupado(true);
    try{await pedir("POST","/dap/solicitudes/"+s.id+"/resolver",{accion,nota:n,fuerzaMayor:!!fm[s.id]});
      onToast(accion==="conceder"?"DAP concedido: se ha avisado al profesor/a":accion==="revocar"?"DAP revocado":"Solicitud denegada");setNota({...nota,[s.id]:""});refrescar();}
    catch(e){onToast(e.message);}
    setOcupado(false);
  };
  const sincronizar=async()=>{setOcupado(true);try{const r=await pedir("POST","/dap/sincronizar",{});const l=r.lectura||{},e=r.escritura||{};
    onToast(l.configurado===false?"Falta el enlace del calendario «Asuntos propios (DAP)» en Calendarios":l.error?l.error:e.fallos?"Calendario leído; no se pudo escribir: "+e.error
      :"Sincronizado: "+(l.eventos||0)+" días en el calendario"+(e.ok?" · "+e.ok+" cambios enviados":"")+(l.sinReconocer?" · "+l.sinReconocer+" sin reconocer (ver Ausencias)":""));refrescar();}
    catch(x){onToast(x.message);}setOcupado(false);};
  const bloquear=async quitar=>{try{await pedir("POST","/dap/bloqueos",{fecha:sel,motivo:motivoBl,quitar});onToast(quitar?"Día desbloqueado":"Día bloqueado para DAP");setMotivoBl("");cargarCal();}catch(e){onToast(e.message);}};
  const P=[...(mio.profesor?[["solicitar","Solicitar DAP","calendario"],["mias","Mis solicitudes","informe"]]:[]),
    ...(dir?[["pendientes","Pendientes de resolver","escudo"]]:[]),
    ...(gestiona?[["calendario","Calendario del centro","calendario"],["historial","Solicitudes","informe"],["registro","Registro de avisos","megafono"]]:[])];
  const Tarjeta=({s,acciones})=>{
    const d=s.concedidasDia||{diurno:0,vespertino:0};
    return(
    <div className="card p-4 border-l-4" style={{borderColor:DAP_EST[s.estado][2]}}>
      <div className="flex flex-wrap items-start gap-3">
        <div className="flex-1 min-w-[15rem]">
          <div className="flex items-center gap-2 flex-wrap"><b className="font-display text-ink">{nomDap(s)}</b><ChipDap e={s.estado}/>{s.sinReconocer&&<span className="pill" style={{background:"#fef3c7",color:"#92400e"}}>Sin reconocer el nombre</span>}{s.fuerzaMayor&&<span className="pill" style={{background:"#ede9fe",color:"#5b21b6"}}>Fuerza mayor</span>}</div>
          <div className="text-sm text-ink font-semibold mt-0.5">{cap(fmtLarga(s.fecha))} · turno {s.turnos.join(" y ")}</div>
          {s.origen?<div className="text-xs font-semibold flex flex-wrap items-center gap-1" style={{color:DAP_COLOR}}><Ico n="calendario" s={13}/>{origenDap(s)}{s.creado?" · "+s.creado.slice(8,10)+"/"+s.creado.slice(5,7):""} · concedidos ese día: diurno {d.diurno}/2, vespertino {d.vespertino}/2</div>
          :<div className="text-xs text-ink-soft">Solicitado el {s.creado.slice(8,10)}/{s.creado.slice(5,7)} a las {s.creado.slice(11,16)}{s.posicion?" · "+s.posicion+"º en la cola de ese día":""} · concedidos ese día: diurno {d.diurno}/2, vespertino {d.vespertino}/2</div>}
          {!s.origen&&s.estado==="concedida"&&(s.enCalendario?<p className="text-[11px] font-semibold mt-1" style={{color:DAP_COLOR}}>✓ Apuntado en el calendario «Asuntos propios (DAP)»</p>
            :s.errorCalendario?<p className="text-[11px] font-semibold text-[#b45309] mt-1">⚠ Aún no está en el calendario de Google: {s.errorCalendario} (se reintenta cada 15 min)</p>:null)}
          {s.observaciones&&<p className="text-xs text-ink mt-1">«{s.observaciones}»</p>}
          {s.bloqueo&&<p className="text-xs font-bold text-[#be123c] mt-1">⚠ Día bloqueado: {s.bloqueo.motivo}</p>}
          {s.cupoLleno&&s.estado==="solicitada"&&<p className="text-xs font-bold text-[#be123c] mt-1">⚠ Cupo completo en su turno: solo por fuerza mayor</p>}
          {s.resuelto&&<p className="text-xs text-ink-soft mt-1">Resuelto el {s.resuelto.slice(8,10)}/{s.resuelto.slice(5,7)} por {nomNat(s.resueltoPor)}{s.nota?" · «"+s.nota+"»":""}</p>}
        </div>
        {acciones}
      </div>
    </div>);
  };
  const AccionesDir=({s})=>s.origen?null:!dir?(["concedida","denegada","revocada"].includes(s.estado)&&<div className="flex flex-wrap gap-2"><BotonImpreso s={s}/><a className="btn btn-ghost !min-h-[36px] text-xs" href={dapPdf(s.id)} target="_blank" rel="noopener noreferrer"><Ico n="imprimir" s={15}/>Resolución</a></div>):(
    <div className="flex flex-col gap-2 w-full sm:w-64">
      {(s.estado==="solicitada"||s.estado==="concedida")&&<input className="field !min-h-[36px] text-xs" placeholder={s.estado==="concedida"?"Motivo de la revocación (obligatorio)":"Nota (si es fuerza mayor, obligatoria)"} value={nota[s.id]||""} onChange={e=>setNota({...nota,[s.id]:e.target.value})}/>}
      {s.estado==="solicitada"&&(s.cupoLleno||s.bloqueo)&&<label className="flex items-center gap-2 text-xs font-semibold text-[#5b21b6]"><input type="checkbox" checked={!!fm[s.id]} onChange={e=>setFm({...fm,[s.id]:e.target.checked})}/>Conceder por fuerza mayor</label>}
      {s.estado==="solicitada"&&<div className="flex gap-2"><button className="btn btn-dark flex-1 !min-h-[38px]" style={{background:"#16a34a"}} disabled={ocupado} onClick={()=>resolver(s,"conceder")}>✓ Conceder</button>
        <button className="btn btn-ghost flex-1 !min-h-[38px]" disabled={ocupado} onClick={()=>resolver(s,"denegar")}>Denegar</button></div>}
      {s.estado==="concedida"&&s.fecha>=cal.hoy&&<button className="btn btn-ghost !min-h-[38px] text-[#be123c]" disabled={ocupado} onClick={()=>resolver(s,"revocar")}>Revocar</button>}
      {["concedida","denegada","revocada"].includes(s.estado)&&<a className="btn btn-ghost !min-h-[36px] text-xs" href={dapPdf(s.id)} target="_blank" rel="noopener noreferrer"><Ico n="imprimir" s={15}/>Resolución PDF</a>}
      <BotonImpreso s={s}/>
    </div>);
  const delDia=sel&&cal.dias[sel]?cal.dias[sel].solicitudes:[];
  const blSel=(cal.bloqueos||[]).find(b=>b.fecha===sel);
  return(
    <Seccion tile={tile} onBack={onBack}>
      <div className="flex flex-wrap gap-2 mb-5 no-print" role="tablist">
        {P.map(([k,l,ico])=><button key={k} role="tab" aria-selected={modo===k} onClick={()=>{setModo(k);setSel("");}} className={"chip flex items-center gap-2"+(modo===k?" on":"")} style={modo===k?{background:DAP_COLOR}:{}}><Ico n={ico} s={16}/>{l}</button>)}
      </div>
      {sal&&(modo==="solicitar"||modo==="mias")&&(
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4">
          {[["Te corresponden",sal.derecho??"?","#0e7490"],["Disfrutados / concedidos",sal.usados,"#166534"],["Pendientes",sal.pendientes,"#b45309"],["Disponibles",sal.disponibles??"?",sal.disponibles>0?"#0e7490":"#be123c"]].map(([l,v,c])=>
            <div key={l} className="card p-3 text-center"><div className="font-display font-bold text-2xl" style={{color:c}}>{v}</div><div className="text-[11px] font-semibold text-ink-soft">{l}</div></div>)}
        </div>)}
      {modo==="solicitar"&&<>
        <p className="text-xs text-ink-soft mb-3">Toca un día libre para solicitarlo (hasta el {fmtLarga(cal.limite)}). En cada día ves qué compañeros/as lo tienen pedido (naranja) o concedido (verde). No se conceden DAP en días de evaluación, claustro u otros que fije la Dirección. Como norma general, se conceden dos por día en cada turno, por orden de llegada; si un día está completo puedes pedirlo igualmente y quedarás en la cola.</p>
        <CalendarioDap cal={cal} mes={mes} setMes={setMes} gestiona={false} misFechas={misFechas} yo={mio.profesor} sel={sel} onDia={d=>{setSel(misFechas[d]?"":d);if(misFechas[d])setModo("mias");}}/>
        {sel&&<div className="card p-5 mt-4 fade-in border-l-4" style={{borderColor:DAP_COLOR}}>
          <div className="font-display font-bold text-ink">Solicitar DAP para el {fmtLarga(sel)}</div>
          {cal.dias[sel]&&(cal.dias[sel].concedidas.diurno>=cal.cupo||cal.dias[sel].concedidas.vespertino>=cal.cupo)&&<p className="text-xs font-semibold text-[#b45309] mt-1">Ese día ya hay {cal.cupo} DAP concedidos en algún turno: tu solicitud quedará en la cola y la Dirección decidirá.</p>}
          {cal.dias[sel]&&cal.dias[sel].solicitudes.length>0&&<div className="mt-3 rounded-xl bg-paper-warm p-3">
            <div className="text-xs font-bold text-ink mb-1.5">Compañeros/as con DAP ese día</div>
            <div className="flex flex-wrap gap-1.5">{cal.dias[sel].solicitudes.map(s=><span key={s.id} className="pill flex items-center gap-1" style={{background:DAP_EST[s.estado][1],color:DAP_EST[s.estado][2]}}>{nomDap(s)} · {DAP_EST[s.estado][0].toLowerCase()} · {s.turnos.join(" y ")}</span>)}</div>
            <p className="text-[11px] text-ink-soft mt-1.5">Las solicitudes se atienden por orden de llegada (máx. {cal.cupo} por turno).</p>
          </div>}
          <label className="lbl mt-3">Observaciones para la Dirección (opcional)</label>
          <textarea className="field" rows={2} maxLength={500} value={obs} onChange={e=>setObs(e.target.value)} placeholder="No es obligatorio indicar el motivo"/>
          <div className="flex gap-2 mt-3"><button className="btn btn-dark" style={{background:DAP_COLOR}} disabled={ocupado||(sal&&sal.disponibles<=0)} onClick={solicitar}>{ocupado?"Enviando…":"Enviar solicitud"}</button>
            <button className="btn btn-ghost" onClick={()=>setSel("")}>Cancelar</button></div>
          {sal&&sal.disponibles<=0&&<p className="text-xs font-semibold text-[#be123c] mt-2">Ya has usado o solicitado todos tus DAP de este curso.</p>}
        </div>}
      </>}
      {modo==="mias"&&(!mio.solicitudes.length?<div className="card p-6 text-sm text-ink-soft text-center">Aún no has solicitado ningún DAP.</div>
        :<div className="space-y-3">{mio.solicitudes.map(s=>(
          <div key={s.id} className="card p-4 flex flex-wrap items-center gap-3 border-l-4" style={{borderColor:DAP_EST[s.estado][2]}}>
            <div className="flex-1 min-w-[14rem]">
              <div className="flex items-center gap-2 flex-wrap"><b className="font-display text-ink">{cap(fmtLarga(s.fecha))}</b><ChipDap e={s.estado}/></div>
              {s.origen?<div className="text-xs font-semibold" style={{color:DAP_COLOR}}>{origenDap(s)}</div>:
              <div className="text-xs text-ink-soft">Solicitado el {s.creado.slice(8,10)}/{s.creado.slice(5,7)}{s.resuelto?" · resuelto el "+s.resuelto.slice(8,10)+"/"+s.resuelto.slice(5,7)+" por "+nomNat(s.resueltoPor):""}</div>}
              {s.nota&&s.estado!=="concedida"&&<div className="text-xs text-[#9f1239] mt-0.5">Motivo: {s.nota}</div>}
            </div>
            {s.estado==="solicitada"&&<button className="btn btn-ghost !min-h-[36px] text-xs" onClick={()=>anular(s)}>Retirar solicitud</button>}
            {!s.origen&&["concedida","denegada","revocada"].includes(s.estado)&&<a className="btn btn-ghost !min-h-[36px] text-xs" href={dapPdf(s.id)} target="_blank" rel="noopener noreferrer"><Ico n="imprimir" s={15}/>Resolución PDF</a>}
          </div>))}</div>)}
      {modo==="pendientes"&&(lista===null?<div className="card p-5 text-sm text-ink-soft">Cargando…</div>
        :!lista.length?<div className="card p-6 text-sm text-ink-soft text-center">No hay solicitudes pendientes.</div>
        :<div className="space-y-3"><p className="text-xs text-ink-soft">Ordenadas por fecha y, dentro de cada día, por orden de llegada (prioridad).</p>{lista.map(s=><Tarjeta key={s.id} s={s} acciones={<AccionesDir s={s}/>}/>)}</div>)}
      {modo==="calendario"&&<>
        <div className="flex flex-wrap items-center gap-2 mb-3 text-xs text-ink-soft">
          <span className="flex-1 min-w-[14rem]">Sincronizado con el calendario de Google «Asuntos propios (DAP)» de Calendarios: lo que se concede aquí se apunta allí y lo que Jefatura apunta allí cuenta aquí como concedido (se revisa cada 15 minutos).</span>
          <button className="btn btn-ghost !min-h-[34px] text-xs" disabled={ocupado} onClick={sincronizar}>{ocupado?"Sincronizando…":"Sincronizar ahora"}</button>
          {gestiona&&<button className="btn btn-ghost !min-h-[34px] text-xs" onClick={()=>setDiag({cargando:true})}>Diagnóstico del calendario</button>}
        </div>
        {diag&&<DiagnosticoCalendarioDap estado={diag} onCambio={setDiag} onHecho={refrescar}/>}
        {cal.calendarioGoogle&&!cal.calendarioGoogle.configurado&&<p className="card p-3 mb-3 text-xs font-semibold text-[#b45309]">Falta el enlace del calendario «Asuntos propios (DAP)» en Calendarios: hasta que se ponga, aquí solo salen las solicitudes hechas en este módulo.</p>}
        {cal.calendarioGoogle&&cal.calendarioGoogle.error&&<p className="card p-3 mb-3 text-xs font-semibold text-[#be123c]">No se pueden leer los días del calendario «Asuntos propios (DAP)»: {cal.calendarioGoogle.error}. Si el calendario no es público, actualiza el script de Google a la versión 10, ejecuta autorizarPermisos() y compártelo con la cuenta del script.</p>}
        <CalendarioDap cal={cal} mes={mes} setMes={setMes} gestiona={true} misFechas={{}} sel={sel} onDia={setSel}/>
        {sel&&<div className="card p-4 mt-4 fade-in">
          <div className="font-display font-bold text-ink mb-2">{cap(fmtLarga(sel))}</div>
          {blSel&&<p className="text-sm font-semibold text-[#be123c] mb-2">Bloqueado para DAP: {blSel.motivo}{blSel.origen==="cronologia"?" (de la Cronología)":""}</p>}
          {!delDia.length?<p className="text-sm text-ink-soft">No hay solicitudes para este día.</p>
            :<ul className="divide-y divide-divider">{delDia.map(s=><li key={s.id} className="py-2 flex items-center gap-2 text-sm"><b className="flex-1 text-ink">{nomDap(s)}{s.sinReconocer&&<span className="ml-2 text-[11px] font-semibold text-[#92400e]">sin reconocer: asígnalo en Ausencias → Calendario DAP</span>}</b><span className="text-xs text-ink-soft">{s.turnos.join(" y ")} · {s.origen?(s.origen==="calendario"?"calendario DAP":"Ausencias"):s.creado.slice(8,10)+"/"+s.creado.slice(5,7)+" "+s.creado.slice(11,16)}</span><ChipDap e={s.estado}/></li>)}</ul>}
          {dir&&<div className="flex flex-wrap gap-2 mt-3 pt-3 border-t border-divider">
            {blSel&&blSel.origen==="direccion"?<button className="btn btn-ghost !min-h-[36px] text-xs" onClick={()=>bloquear(true)}>Desbloquear este día</button>
              :!blSel&&<><input className="field !min-h-[36px] !w-auto flex-1 text-xs" placeholder="Motivo (claustro, visita, actividad…)" value={motivoBl} onChange={e=>setMotivoBl(e.target.value)}/><button className="btn btn-ghost !min-h-[36px] text-xs" onClick={()=>bloquear(false)}>Bloquear para DAP</button></>}
            {delDia.some(s=>s.estado==="solicitada")&&<button className="btn btn-dark !min-h-[36px] text-xs" style={{background:DAP_COLOR}} onClick={()=>setModo("pendientes")}>Resolver pendientes</button>}
          </div>}
        </div>}
      </>}
      {modo==="historial"&&<>
        <div className="flex flex-wrap gap-1.5 mb-3">{[["solicitada","Pendientes"],["concedida","Concedidos"],["denegada","Denegados"],["revocada","Revocados"],["","Todos"]].map(([k,l])=><button key={l} className={"chip"+(filtro===k?" on":"")} style={filtro===k?{background:DAP_COLOR}:{}} onClick={()=>setFiltro(k)}>{l}</button>)}</div>
        {lista===null?<div className="card p-5 text-sm text-ink-soft">Cargando…</div>:!lista.length?<div className="card p-6 text-sm text-ink-soft text-center">No hay solicitudes.</div>
          :<div className="space-y-3">{lista.map(s=><Tarjeta key={s.id} s={s} acciones={<AccionesDir s={s}/>}/>)}</div>}
      </>}
      {modo==="registro"&&(registro===null?<div className="card p-5 text-sm text-ink-soft">Cargando…</div>
        :!registro.length?<div className="card p-6 text-sm text-ink-soft text-center">Todavía no hay movimientos.</div>
        :<div className="card p-4"><ul className="divide-y divide-divider">{registro.map(e=>{
          const T={solicitud:["Solicitud","#b45309"],concesion:["Concesión","#166534"],denegacion:["Denegación","#9f1239"],revocacion:["Revocación","#9f1239"],anulacion:["Retirada","#475569"]}[e.tipo]||[e.tipo,"#475569"];
          return <li key={e.id} className="py-2.5 flex flex-wrap items-center gap-2 text-sm">
            {e.nuevo&&<span className="w-2 h-2 rounded-full bg-[#be123c]" title="Nuevo"/>}
            <span className="pill" style={{background:T[1]+"18",color:T[1]}}>{T[0]}</span>
            <b className="text-ink">{nomNat(e.profesor)}</b><span className="text-ink-soft">· DAP del {fmtCorta(e.fecha)}</span>
            <span className="ml-auto text-xs text-ink-soft">{e.creado.slice(8,10)}/{e.creado.slice(5,7)} {e.creado.slice(11)} · {e.por}</span></li>;})}</ul></div>)}
    </Seccion>
  );
}
/* Resoluciones de DAP en «Mi cuenta» (perfil de usuario) */
function DapEnCuenta(){
  const[d,setD]=useState(null);
  useEffect(()=>{pedir("GET","/dap/mio").then(setD).catch(()=>{});},[]);
  const res=d&&d.solicitudes?d.solicitudes.filter(s=>!s.origen&&["concedida","denegada","revocada"].includes(s.estado)).slice(0,4):[];
  if(!res.length)return null;
  return(
    <div className="rounded-xl border border-divider p-3 text-xs space-y-1.5">
      <div className="font-bold text-ink">Mis DAP (resoluciones de la Dirección)</div>
      {res.map(s=><div key={s.id} className="flex items-center gap-2"><ChipDap e={s.estado}/><span className="flex-1">{fmtCorta(s.fecha)}</span><a className="font-semibold underline text-[#0e7490]" href={dapPdf(s.id)} target="_blank" rel="noopener noreferrer">PDF</a></div>)}
    </div>
  );
}

/* Mis ausencias del curso: notificadas (pendientes de grabar), grabadas (sin justificar) y justificadas */
const SIT_AUS={notificada:["Notificada","#fef3c7","#92400e","Pendiente de que Jefatura la grabe"],grabada:["Grabada","#ffe4e6","#9f1239","Registrada por Jefatura · sin justificar"],justificada:["Justificada","#dcfce7","#166534",""]};
function PantallaMisAusencias({tile,onBack,arriba,onJustificar}){
  const[d,setD]=useState(null);const[f,setF]=useState("");
  useEffect(()=>{pedir("GET","/ausencias/historial").then(setD).catch(()=>setD({ausencias:[]}));},[]);
  if(!d)return <Seccion tile={tile} onBack={onBack}>{arriba}<div className="card p-5 text-sm text-ink-soft">Cargando…</div></Seccion>;
  if(!d.profesor)return <Seccion tile={tile} onBack={onBack}>{arriba}<div className="card p-5 text-sm text-ink-soft">Tu cuenta no está vinculada a ningún horario: pide a Jefatura de Estudios que la vincule en «Usuarios».</div></Seccion>;
  const n=k=>d.ausencias.filter(a=>a.situacion===k).length;
  const vis=d.ausencias.filter(a=>!f||a.situacion===f);
  return(
    <Seccion tile={tile} onBack={onBack}>
      {arriba}
      <div className="grid grid-cols-3 gap-2 mb-4">{["notificada","grabada","justificada"].map(k=>{const x=SIT_AUS[k];return(
        <button key={k} onClick={()=>setF(f===k?"":k)} className="card p-3 text-center transition hover:shadow-md" style={f===k?{boxShadow:"0 0 0 2px "+x[2]}:{}}>
          <div className="font-display font-bold text-2xl" style={{color:x[2]}}>{n(k)}</div><div className="text-[11px] font-semibold text-ink-soft">{x[0]}s</div></button>);})}</div>
      <p className="text-xs text-ink-soft mb-3">Tus ausencias del curso {d.curso&&d.curso.nombre}. Toca un recuadro para filtrar.{f?" Mostrando solo: "+SIT_AUS[f][0].toLowerCase()+"s.":""}</p>
      {!vis.length?<div className="card p-6 text-sm text-ink-soft text-center">{f?"No hay ausencias en este estado.":"No tienes ausencias registradas este curso."}</div>
        :<div className="space-y-2">{vis.map(a=>{const x=SIT_AUS[a.situacion];return(
        <div key={a.id} className="card p-4 flex flex-wrap items-center gap-3 border-l-4" style={{borderLeftColor:x[2]}}>
          <div className="flex-1 min-w-[14rem] leading-tight">
            <div className="flex items-center gap-2 flex-wrap"><b className="font-display text-ink">{a.hasta&&a.hasta!==a.fecha?"Del "+fmtCorta(a.fecha)+" al "+fmtCorta(a.hasta):cap(fmtLarga(a.fecha))}</b>
              <span className="pill" style={{background:x[1],color:x[2]}}>{x[0]}</span>
              {a.canal==="fuera de plazo"&&<span className="pill" style={{background:"#fff7ed",color:"#9a3412"}}>Fuera de plazo</span>}</div>
            <div className="text-xs text-ink-soft mt-0.5">{a.modo==="horas"?"Horas: "+(a.horas||[]).map(labelHora).join(", "):"Todo el día"} · {a.motivo}</div>
            <div className="text-[11px] font-semibold mt-0.5" style={{color:x[2]}}>{a.situacion==="justificada"?(a.justificacion_id?"Justificada"+(a.articulo?" · "+a.articulo:"")+(a.justificada_el?" · el "+a.justificada_el.slice(8,10)+"/"+a.justificada_el.slice(5,7):""):"No necesita justificante (asuntos propios o actividad)"):x[3]}
              {a.creado?<span className="text-ink-soft font-medium"> · {a.situacion==="notificada"?"notificada":"registrada"} el {a.creado.slice(8,10)}/{a.creado.slice(5,7)}</span>:null}</div>
          </div>
          {a.situacion==="grabada"&&<button className="btn btn-dark !min-h-[36px] text-xs" style={{background:"#be123c"}} onClick={onJustificar}><Ico n="informe" s={15}/>Justificar</button>}
        </div>);})}</div>}
    </Seccion>);
}

function PestanasAusencias({modo,onModo,pendientes,admin,porConfirmar}){
  const P=[["notificar","Notificar ausencia","ausencia"],["justificar","Justificar ausencia","informe"],["mias","Mis ausencias","calendario"]].concat(admin?[["gestion","Confirmar y registrar (Jefatura)","escudo"],["informes","Informes y dossier","imprimir"]]:[]);
  return(
    <div className="flex flex-wrap gap-2 mb-5 no-print" role="tablist">
      {P.map(([k,l,ico])=><button key={k} role="tab" aria-selected={modo===k} onClick={()=>onModo(k)} className={"chip flex items-center gap-2"+(modo===k?" on":"")} style={modo===k?{background:"#be123c"}:{}}>
        <Ico n={ico} s={16}/>{l}{k==="gestion"&&porConfirmar>0&&<span className="min-w-[20px] h-5 px-1.5 rounded-full text-[11px] font-bold flex items-center justify-center" style={{background:modo===k?"#fff":"#be123c",color:modo===k?"#be123c":"#fff"}}>{porConfirmar}</span>}{k==="justificar"&&pendientes>0&&<span className="min-w-[20px] h-5 px-1.5 rounded-full text-[11px] font-bold flex items-center justify-center" style={{background:modo===k?"#fff":"#be123c",color:modo===k?"#be123c":"#fff"}}>{pendientes}</span>}
      </button>)}
    </div>
  );
}

/* ── Justificación de ausencias ──
   El docente elige sus ausencias sin justificar, marca en su cuadrante semanal las horas de cada día (la app
   calcula horas lectivas y complementarias, que puede corregir), elige el artículo de la Orden de 29/08/2024
   y sube los justificantes en PDF. Lectivas: docencia y tutoría con alumnado; el resto, complementarias. */
const tipoHora=e=>e.cat==="docencia"||(e.cat==="tutoria"&&/tutor[ií]a (con alumn|bachillerato)/i.test(e.materia||""))?"lectiva":"complementaria";
const lunesSemana=iso=>{const d=new Date(iso+"T12:00:00");d.setDate(d.getDate()-((d.getDay()+6)%7));return isoDe(d);};
const sumarDias=(iso,n)=>{const d=new Date(iso+"T12:00:00");d.setDate(d.getDate()+n);return isoDe(d);};
const diasDeAusencia=a=>{const out=[];let d=a.fecha;const fin=a.hasta||a.fecha;while(d<=fin){const w=diaSemanaDe(d);if(w>=1&&w<=5)out.push(d);d=sumarDias(d,1);}return out;};
const rangoTxt=a=>a.hasta?"del "+fmtCorta(a.fecha)+" al "+fmtCorta(a.hasta):fmtLarga(a.fecha);
const horasAus=a=>a.modo==="horas"?a.horas.map(labelHora).join(", "):"Todo el día";
async function abrirPDF(jid,docId,onToast){
  try{
    const r=await fetch(API_BASE+"/justificaciones/"+jid+"/documentos/"+docId+"/archivo",{credentials:"include"});
    if(!(r.headers.get("content-type")||"").includes("pdf")){const d=await r.json().catch(()=>({}));throw new Error(d.error||"No se pudo abrir el PDF");}
    const url=URL.createObjectURL(await r.blob());window.open(url,"_blank");setTimeout(()=>URL.revokeObjectURL(url),120000);
  }catch(e){onToast(e.message);}
}
async function enviarFormulario(ruta,campos,archivos){
  const fd=new FormData();
  Object.keys(campos).forEach(k=>fd.append(k,campos[k]));
  archivos.forEach(f=>fd.append("archivos",f,f.name));
  let r;
  try{r=await fetch(API_BASE+ruta,{method:"POST",credentials:"include",body:fd});}catch(e){throw new Error("No se pudo conectar con el servidor");}
  const d=await r.json().catch(()=>({}));
  if(!r.ok||!d.ok)throw new Error(d.error||"No se pudo guardar");
  return d;
}
function ElegirPDF({archivos,onCambio,maxMb}){
  const[err,setErr]=useState("");
  const add=fs=>{
    const malos=[...fs].filter(f=>!/\.pdf$/i.test(f.name)||(f.type&&f.type!=="application/pdf"));
    const grandes=[...fs].filter(f=>f.size>maxMb*1024*1024);
    let nuevos=archivos.concat([...fs].filter(f=>malos.indexOf(f)<0&&grandes.indexOf(f)<0)).slice(0,10);
    /* el servidor web admite hasta 20 MB por envío: si se pasan, se quedan fuera los últimos */
    let total=0,fuera=false;nuevos=nuevos.filter(f=>{total+=f.size;if(total>19*1024*1024){fuera=true;return false;}return true;});
    setErr(malos.length?"Solo se admiten archivos PDF: "+malos.map(f=>f.name).join(", "):grandes.length?"Cada PDF puede ocupar como máximo "+maxMb+" MB":fuera?"Entre todos los PDF de un envío no pueden pasar de 19 MB: envía el resto después con «Añadir PDF».":"");
    onCambio(nuevos);
  };
  return(
    <div>
      <label className="btn btn-ghost cursor-pointer"><Ico n="subir" s={16}/>Añadir PDF<input type="file" accept="application/pdf,.pdf" multiple className="hidden" onChange={e=>{add(e.target.files);e.target.value="";}}/></label>
      {err&&<p className="text-xs font-semibold text-[#be123c] mt-2" role="alert">{err}</p>}
      {archivos.length>0&&<ul className="mt-2 space-y-1">{archivos.map((f,i)=><li key={i} className="flex items-center gap-2 text-sm"><Ico n="informe" s={16}/><span className="truncate">{f.name}</span><span className="text-[11px] text-ink-soft">{Math.max(1,Math.round(f.size/1024))} KB</span>
        <button className="text-[#be123c] ml-auto" aria-label={"Quitar "+f.name} onClick={()=>onCambio(archivos.filter((x,j)=>j!==i))}><Ico n="cerrar" s={16}/></button></li>)}</ul>}
    </div>
  );
}
function PantallaJustificar({tile,onBack,arriba,onToast,onDatos}){
  const[d,setD]=useState(null);
  const[err,setErr]=useState("");
  const[sel,setSel]=useState([]);
  const[marcas,setMarcas]=useState({});        /* fecha -> [tramos] */
  const[ajuste,setAjuste]=useState({});        /* fecha -> {l,c} si el docente corrige el cómputo */
  const[semana,setSemana]=useState("");
  const[art,setArt]=useState("");
  const[obs,setObs]=useState("");
  const[archivos,setArchivos]=useState([]);
  const[enviando,setEnviando]=useState(false);
  const[extra,setExtra]=useState({});           /* justificación -> PDF que se van a añadir */
  const aplicar=x=>{setD(x);onDatos&&onDatos(x);};
  const cargar=()=>pedir("GET","/justificaciones/mias").then(aplicar).catch(e=>setErr(e.message));
  useEffect(()=>{cargar();},[]);
  const prof=d&&d.profesor;
  const sesiones=useMemo(()=>{const m={};if(prof)ENTRADAS.filter(e=>e.profesor===prof).forEach(e=>{((m[e.dia]=m[e.dia]||{})[e.slot]=m[e.dia][e.slot]||[]).push(e);});return m;},[prof]);
  const elegidas=d?d.ausencias.filter(a=>sel.indexOf(a.id)>=0):[];
  const dias=useMemo(()=>[...new Set(elegidas.flatMap(diasDeAusencia))].sort(),[sel,d]);
  const semanas=[...new Set(dias.map(lunesSemana))];
  const semAct=semanas.indexOf(semana)>=0?semana:semanas[0];
  const tarde=Object.values(sesiones).some(x=>Object.keys(x).some(t=>+t>=7));
  const filas=HORAS.filter(h=>!h.t||tarde);
  /* al elegir ausencias se marcan sus horas: todo el día = todas las horas con actividad */
  const elegir=id=>{
    const n=sel.indexOf(id)>=0?sel.filter(x=>x!==id):sel.concat(id);
    setSel(n);
    const m={};
    d.ausencias.filter(a=>n.indexOf(a.id)>=0).forEach(a=>diasDeAusencia(a).forEach(f=>{
      const ses=sesiones[diaSemanaDe(f)]||{};
      const tr=a.modo==="horas"?a.horas.filter(h=>ses[h]):Object.keys(ses);
      m[f]=[...new Set((m[f]||[]).concat(tr))];
    }));
    setMarcas(m);setAjuste({});
  };
  const calc=f=>{let l=0,c=0;(marcas[f]||[]).forEach(t=>{const ses=(sesiones[diaSemanaDe(f)]||{})[t]||[];if(!ses.length)return;if(ses.some(e=>tipoHora(e)==="lectiva"))l++;else c++;});return{l,c};};
  const valor=(f,k)=>ajuste[f]&&ajuste[f][k]!=null?ajuste[f][k]:calc(f)[k];
  const alternar=(f,t)=>{const m=marcas[f]||[];setMarcas({...marcas,[f]:m.indexOf(t)>=0?m.filter(x=>x!==t):m.concat(t)});setAjuste({...ajuste,[f]:undefined});};
  const diasMarcados=dias.filter(f=>(marcas[f]||[]).length);
  const totL=diasMarcados.reduce((t,f)=>t+(+valor(f,"l")||0),0),totC=diasMarcados.reduce((t,f)=>t+(+valor(f,"c")||0),0);
  const artSel=d&&d.articulos.find(a=>String(a.n)===String(art));
  const listo=elegidas.length&&diasMarcados.length&&artSel&&archivos.length;
  const enviar=async()=>{
    setEnviando(true);
    try{
      const detalle=diasMarcados.map(f=>({fecha:f,tramos:marcas[f],lectivas:valor(f,"l"),complementarias:valor(f,"c")}));
      const r=await enviarFormulario("/justificaciones",{datos:JSON.stringify({ausencias:sel,articulo:+art,detalle,observaciones:obs})},archivos);
      aplicar(r);setSel([]);setMarcas({});setAjuste({});setArt("");setObs("");setArchivos([]);
      onToast("Justificación enviada");window.scrollTo(0,0);
    }catch(e){onToast(e.message);}
    setEnviando(false);
  };
  const añadir=async j=>{try{aplicar(await enviarFormulario("/justificaciones/"+j.id+"/documentos",{},extra[j.id]||[]));setExtra({...extra,[j.id]:[]});onToast("Documentos añadidos");}catch(e){onToast(e.message);}};
  const borrarDoc=async(j,doc)=>{if(!confirm("¿Borrar «"+doc.nombre+"»?"))return;try{aplicar(await pedir("DELETE","/justificaciones/"+j.id+"/documentos/"+doc.id));}catch(e){onToast(e.message);}};
  const deshacer=async j=>{if(!confirm("¿Deshacer esta justificación? Sus ausencias volverán a quedar sin justificar y se borrarán sus PDF."))return;try{aplicar(await pedir("DELETE","/justificaciones/"+j.id));onToast("Justificación deshecha");}catch(e){onToast(e.message);}};

  if(err)return <Seccion tile={tile} onBack={onBack}>{arriba}<div className="card p-6 text-sm font-semibold text-[#be123c]">{err}</div></Seccion>;
  if(!d)return <Seccion tile={tile} onBack={onBack}>{arriba}<div className="card p-6 text-sm text-ink-soft">Cargando tus ausencias…</div></Seccion>;
  if(!prof)return <Seccion tile={tile} onBack={onBack}>{arriba}<div className="card p-6 text-sm text-ink-soft">Esta cuenta no está vinculada a ningún profesor/a del horario, así que no tiene ausencias que justificar. Jefatura revisa las justificaciones del profesorado en Ausencias → Informes y dossier.</div></Seccion>;
  const sinJ=d.ausencias.filter(a=>!a.justificacion_id&&!(a.exenta||a.dap));   /* DAP y actividades complementarias/extraescolares no se justifican */
  const justificables=sinJ.filter(a=>a.justificable),futuras=sinJ.filter(a=>!a.justificable);
  const fmtLim=iso=>new Date(iso+"T12:00:00").toLocaleDateString("es-ES",{day:"numeric",month:"long"});
  return(
    <Seccion tile={tile} onBack={onBack}>
      {arriba}
      {d.alerta&&<div className="rounded-xl p-4 mb-4 text-sm font-semibold" style={d.alerta.enPlazo?{background:"#fffbeb",color:"#92400e"}:{background:"#fff1f2",color:"#9f1239"}}>
        {d.alerta.enPlazo?"Tienes "+d.alerta.n+" ausencia(s) de meses anteriores sin justificar. Justifícalas antes del "+fmtLim(d.alerta.limite)+".":"El plazo para justificar las ausencias del mes pasado terminó el "+fmtLim(d.alerta.limite)+". Justifícalas cuanto antes y habla con Jefatura de Estudios."}
      </div>}
      <div className="card p-5 mb-4">
        <div className="font-display font-bold text-ink">1 · Ausencias pendientes de justificar</div>
        <p className="text-xs text-ink-soft mt-1 mb-3">Elige una o varias ausencias del mismo motivo. Aparecen las que notificaste tú y las que registró Jefatura de Estudios.</p>
        {justificables.length===0&&<p className="text-sm text-ink-soft">No tienes ausencias pendientes de justificar.</p>}
        <div className="space-y-2">
          {justificables.map(a=>{const on=sel.indexOf(a.id)>=0;return(
            <label key={a.id} className={"flex items-start gap-3 rounded-xl p-3 cursor-pointer border "+(on?"border-[#be123c] bg-[#fff1f2]":"border-divider bg-white")}>
              <input type="checkbox" className="mt-1" checked={on} onChange={()=>elegir(a.id)}/>
              <span className="flex-1"><span className="font-semibold text-ink block">{cap(rangoTxt(a))}</span>
                <span className="text-xs text-ink-soft">{a.anticipada&&<b className="text-[#b45309]">Por adelantado · </b>}{horasAus(a)} · {a.estado==="Pendiente"?"notificada, pendiente de grabar por Jefatura":"grabada"}{a.registrado_por&&a.registrado_por!=="hoja de Google"?" · registrada por "+a.registrado_por:""}</span></span>
            </label>);})}
        </div>
        {futuras.length>0&&<p className="text-[11px] text-ink-soft mt-3">Próximas notificadas (se podrán justificar cuando Jefatura las grabe o llegue el día): {futuras.map(a=>rangoTxt(a)).join(" · ")}</p>}
        {d.ausencias.some(a=>a.dap&&!a.justificacion_id)&&<p className="text-[11px] text-olive font-semibold mt-2">Tus días de asuntos propios (DAP) no necesitan justificación: cuentan ya como justificados ({d.ausencias.filter(a=>a.dap&&!a.justificacion_id).map(a=>rangoTxt(a)).join(" · ")}).</p>}
        {d.ausencias.some(a=>a.exenta&&!a.dap&&!a.justificacion_id)&&<p className="text-[11px] text-olive font-semibold mt-2">Tus ausencias por actividad complementaria o extraescolar no necesitan justificación: cuentan ya como justificadas ({d.ausencias.filter(a=>a.exenta&&!a.dap&&!a.justificacion_id).map(a=>rangoTxt(a)).join(" · ")}).</p>}
      </div>

      {elegidas.length>0&&<div className="card p-5 mb-4 fade-in">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="font-display font-bold text-ink">2 · Marca en tu horario las horas de ausencia</div>
          {semanas.length>1&&<div className="flex gap-2">{semanas.map(w=><button key={w} className={"chip "+(w===semAct?"on":"")} style={w===semAct?{background:"#be123c"}:{}} onClick={()=>setSemana(w)}>Semana del {fmtCorta(w)}</button>)}</div>}
        </div>
        <p className="text-xs text-ink-soft mt-1 mb-3">Toca una casilla para marcarla o desmarcarla. Verde: hora lectiva · ámbar: complementaria. Solo cuentan los días de las ausencias elegidas.</p>
        <div className="overflow-x-auto">
          <table className="w-full border-separate" style={{borderSpacing:4,minWidth:640}}>
            <thead><tr><th></th>{[0,1,2,3,4].map(i=>{const f=sumarDias(semAct,i);return <th key={i} className={"text-xs font-semibold "+(dias.indexOf(f)>=0?"text-ink":"text-ink-soft opacity-50")}>{cap(fmtCorta(f))}</th>;})}</tr></thead>
            <tbody>{filas.map(h=><tr key={h.n}>
              <td className="text-[11px] font-semibold text-ink-soft pr-1 whitespace-nowrap">{labelHora(h.n)}<div className="font-medium opacity-70">{h.l}</div></td>
              {[0,1,2,3,4].map(i=>{const f=sumarDias(semAct,i);const activo=dias.indexOf(f)>=0;const ses=(sesiones[i+1]||{})[h.n]||[];const on=(marcas[f]||[]).indexOf(h.n)>=0;
                const tipo=ses.length?(ses.some(e=>tipoHora(e)==="lectiva")?"lectiva":"complementaria"):"";
                const col=tipo==="lectiva"?["#dcfce7","#15803d"]:tipo==="complementaria"?["#fef3c7","#b45309"]:["#f5f4f0","#9a968a"];
                return <td key={i}>
                  <button disabled={!activo} onClick={()=>alternar(f,h.n)} aria-pressed={on} className="w-full rounded-lg text-left px-2 py-1.5 text-[11px] leading-tight transition"
                    style={{minHeight:40,opacity:activo?1:.35,background:on?col[1]:col[0],color:on?"#fff":col[1],outline:on?"2px solid "+col[1]:"none",cursor:activo?"pointer":"default"}}>
                    {ses.length?<><b className="block truncate">{ses[0].cat==="docencia"?ses[0].materia:ETIQUETA[ses[0].cat]}</b><span className="opacity-80 truncate block">{[...new Set(ses.map(e=>e.grupo).filter(Boolean))].join(", ")||(ses[0].cat!=="docencia"?ses[0].materia:"")}</span></>:<span className="opacity-60">—</span>}
                  </button></td>;})}
            </tr>)}</tbody>
          </table>
        </div>
        <div className="mt-4">
          <div className="lbl">Horas de cada día (calculadas; puedes corregirlas)</div>
          {diasMarcados.length===0&&<p className="text-sm text-ink-soft">Marca al menos una hora.</p>}
          <div className="grid sm:grid-cols-2 gap-2">
            {diasMarcados.map(f=><div key={f} className="flex items-center gap-2 rounded-xl bg-paper-warm p-2.5 text-sm">
              <span className="flex-1 font-semibold text-ink">{cap(fmtLarga(f))}</span>
              <label className="text-xs text-ink-soft">Lectivas <input type="number" min="0" max="15" className="field !w-16 !min-h-0 !py-1 !px-2 inline-block" value={valor(f,"l")} onChange={e=>setAjuste({...ajuste,[f]:{...(ajuste[f]||{}),l:e.target.value===""?"":+e.target.value}})}/></label>
              <label className="text-xs text-ink-soft">Compl. <input type="number" min="0" max="15" className="field !w-16 !min-h-0 !py-1 !px-2 inline-block" value={valor(f,"c")} onChange={e=>setAjuste({...ajuste,[f]:{...(ajuste[f]||{}),c:e.target.value===""?"":+e.target.value}})}/></label>
            </div>)}
          </div>
          {diasMarcados.length>0&&<p className="text-sm font-semibold text-ink mt-3">Total: {totL} horas lectivas y {totC} complementarias en {diasMarcados.length} día(s).</p>}
        </div>
      </div>}

      {elegidas.length>0&&diasMarcados.length>0&&<div className="card p-5 mb-4 fade-in space-y-4">
        <div>
          <div className="font-display font-bold text-ink">3 · Motivo de la ausencia</div>
          <p className="text-xs text-ink-soft mt-1 mb-2">Según la {d.orden}.</p>
          <select className="field" value={art} onChange={e=>setArt(e.target.value)}>
            <option value="">— Elige el artículo —</option>
            {d.articulos.map(a=><option key={a.n} value={a.n}>Art. {a.n}. {a.t}</option>)}
          </select>
          {artSel&&<p className="text-xs text-ink-soft mt-2"><b>Documentación orientativa:</b> {artSel.doc}</p>}
        </div>
        {artSel&&<div>
          <div className="font-display font-bold text-ink">4 · Documentación justificativa (solo PDF)</div>
          <p className="text-xs text-ink-soft mt-1 mb-2">Sube uno o varios PDF (máximo 5 por envío y 10 en total, hasta {d.maxMb} MB cada uno). Si tienes el justificante en papel, escanéalo o fotografíalo y guárdalo como PDF.</p>
          <ElegirPDF archivos={archivos} onCambio={setArchivos} maxMb={d.maxMb}/>
          <CapaRGPD className="mt-3">Los justificantes pueden contener datos de salud: solo los ven tú y Jefatura de Estudios, se guardan en el servidor del centro y se borran al vencer el plazo de conservación. Si puedes, aporta justificantes sin diagnóstico (por ejemplo, de asistencia a consulta).</CapaRGPD>
          <div className="mt-3"><label className="lbl">Observaciones (opcional)</label><textarea className="field" rows={2} value={obs} onChange={e=>setObs(e.target.value)}/></div>
        </div>}
        <button className="btn btn-dark w-full !py-3" disabled={!listo||enviando} onClick={enviar}>{enviando?"Enviando…":"Enviar justificación"}</button>
        {!listo&&<p className="text-[11px] text-ink-soft text-center">Para enviar: ausencias elegidas, horas marcadas, artículo y al menos un PDF.</p>}
      </div>}

      <div className="card p-5">
        <div className="font-display font-bold text-ink mb-3">Ausencias justificadas</div>
        {d.justificaciones.length===0&&<p className="text-sm text-ink-soft">Todavía no has justificado ninguna ausencia.</p>}
        <div className="space-y-3">
          {d.justificaciones.slice().reverse().map(j=><div key={j.id} className="rounded-xl border border-divider p-4">
            <div className="flex flex-wrap items-start gap-2">
              <div className="flex-1 min-w-[12rem]"><div className="font-semibold text-ink">Art. {j.articulo}. {j.articuloTxt}</div>
                <div className="text-xs text-ink-soft mt-0.5">{j.detalle.map(x=>fmtCorta(x.fecha)).join(", ")} · {j.lectivas} lectivas y {j.complementarias} complementarias · enviada el {j.creado}</div></div>
              <button className="btn btn-ghost !px-3 text-xs" onClick={()=>deshacer(j)}>Deshacer</button>
            </div>
            <ul className="mt-2 space-y-1">{j.documentos.map(doc=><li key={doc.id} className="flex items-center gap-2 text-sm">
              <button className="flex items-center gap-2 text-left font-semibold text-[#be123c] hover:underline" onClick={()=>abrirPDF(j.id,doc.id,onToast)}><Ico n="informe" s={16}/>{doc.nombre}</button>
              <span className="text-[11px] text-ink-soft">{doc.subido}</span>
              {j.documentos.length>1&&<button className="ml-auto text-ink-soft hover:text-[#be123c]" aria-label={"Borrar "+doc.nombre} onClick={()=>borrarDoc(j,doc)}><Ico n="papelera" s={16}/></button>}
            </li>)}</ul>
            <div className="mt-3 flex flex-wrap items-start gap-2"><ElegirPDF archivos={extra[j.id]||[]} onCambio={l=>setExtra({...extra,[j.id]:l})} maxMb={d.maxMb}/>
              {(extra[j.id]||[]).length>0&&<button className="btn btn-dark" onClick={()=>añadir(j)}>Subir</button>}</div>
          </div>)}
        </div>
      </div>
    </Seccion>
  );
}

/* ── Ausencias → Confirmar y registrar (Jefatura, modo administrador) ──
   Confirma (graba) las notificadas por el profesorado, las corrige o las rechaza, y registra las que
   llegan por otros medios (teléfono, correo, en persona…), que quedan confirmadas al momento. */
/* Calendario de asuntos propios (DAP) → ausencias: estado de la sincronización y títulos sin reconocer */
function TarjetaDAP({ops,profs,onCambio}){
  const[d,setD]=useState(null);const[ocupado,setOcupado]=useState(false);
  const leer=async()=>setD(await ops.dapEstado());
  useEffect(()=>{leer();},[]);
  const sincronizar=async()=>{setOcupado(true);const r=await ops.dapSincronizar();if(r)setD(r);setOcupado(false);onCambio&&onCambio();};
  const asignar=async(titulo,profesor)=>{setOcupado(true);const r=await ops.dapAsignar(titulo,profesor);if(r)setD(r);setOcupado(false);onCambio&&onCambio();};
  if(d===null)return null;
  const cuando=d.fecha?new Date(d.fecha).toLocaleString("es-ES",{day:"numeric",month:"short",hour:"2-digit",minute:"2-digit"}):"";
  const sin=d.sinReconocer||[];
  return(
    <div className="card p-4 mb-4 space-y-3 no-print border-l-4" style={{borderLeftColor:"#0d9488"}}>
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div><div className="font-display font-bold text-ink flex items-center gap-2"><Ico n="calendario" s={18}/>Calendario de asuntos propios (DAP)</div>
          <div className="text-xs text-ink-soft font-medium">Cada día apuntado en el calendario se graba solo como ausencia con motivo «Asuntos propios (DAP)». Se revisa cada 15 minutos; si se borra del calendario, se quita. Está sincronizado con el módulo DAP: los días que concede la Dirección se apuntan solos en el calendario, y los que apuntas aquí cuentan allí como concedidos.</div></div>
        <button className="btn btn-dark" disabled={ocupado||d.configurado===false} onClick={sincronizar}><Ico n="reloj" s={16}/>{ocupado?"Leyendo…":"Sincronizar ahora"}</button>
      </div>
      {d.configurado===false&&<p className="text-sm text-[#b45309] font-semibold">Falta el enlace del calendario «Asuntos propios (DAP)». Ponlo en Calendarios (modo administración) y vuelve aquí.</p>}
      {d.error&&<p className="text-sm text-[#be123c] font-semibold">{d.error}. En Google Calendar, el calendario tiene que estar en «Hacer disponible públicamente».</p>}
      {d.configurado!==false&&!d.error&&d.fecha&&<p className="text-xs text-ink-soft">Última lectura: {cuando} · {d.eventos||0} días en el calendario · {(d.creadas||0)} nuevas, {(d.actualizadas||0)} al día, {(d.quitadas||0)} quitadas{d.duplicadas?" · "+d.duplicadas+" ya estaban grabadas a mano":""}{d.delModulo?" · "+d.delModulo+" concedidos desde el módulo DAP":""}.</p>}
      {sin.length>0&&(
        <div className="rounded-xl bg-amber-50 border border-amber-200 p-3 space-y-2">
          <div className="text-sm font-bold text-[#92400e]">No sé de quién son estos días ({sin.length})</div>
          <div className="text-xs text-[#92400e]">Elige el profesor/a: la app lo recordará para ese título y grabará la ausencia.</div>
          {sin.map(x=><div key={x.clave} className="flex flex-wrap items-center gap-2 text-sm">
            <span className="flex-1 min-w-[12rem]"><b className="text-ink">{x.titulo||"(sin título)"}</b> <span className="text-xs text-ink-soft">· {fmtCorta(x.fecha)}{x.hasta?" → "+fmtCorta(x.hasta):""}</span></span>
            <select className="field !w-auto !min-h-[36px] !py-1 text-sm" disabled={ocupado} value="" onChange={e=>e.target.value&&asignar(x.clave,e.target.value)} aria-label={"Profesor/a de «"+x.titulo+"»"}>
              <option value="">— ¿Quién es? —</option>
              <option value="-">No es una ausencia (ignorar)</option>
              {profs.map(p=><option key={p} value={p}>{p}</option>)}
            </select>
          </div>)}
        </div>
      )}
    </div>
  );
}

function PantallaGestionAusencias({tile,onBack,arriba,ops,profs}){
  const[lista,setLista]=useState(null);
  const[form,setForm]=useState(null);
  const[mes,setMes]=useState(()=>hoyISO().slice(0,7));
  const cargar=async()=>setLista(await ops.ausenciasAdmin());
  useEffect(()=>{cargar();},[]);
  const tras=async p=>{const ok=await p;await cargar();return ok;};
  const confirmar=ids=>tras(ops.ausenciaGrabar(ids));
  const rechazar=a=>{if(confirm("¿Rechazar y eliminar la ausencia notificada por "+nombreHorario(a.prof)+" ("+fmtCorta(a.fecha)+")?"))tras(ops.ausenciaBorrar([a.id]));};
  const borrar=a=>{if(confirm("¿Eliminar la ausencia de "+nombreHorario(a.prof)+" ("+fmtCorta(a.fecha)+")? Se borrará definitivamente."))tras(ops.ausenciaBorrar([a.id]));};
  const guardar=async a=>{const ok=await tras(ops.ausenciaGuardar(a));if(ok)setForm(null);return ok;};
  const editar=a=>setForm({id:a.id,prof:nombreHorario(a.prof),fecha:a.fecha,hasta:a.hasta||"",modo:a.modo,horas:(a.horas||[]).map(String),motivo:a.motivo||"Otro",obs:a.obs||"",canal:a.canal||""});
  const ord=(a,b)=>a.fecha.localeCompare(b.fecha)||a.prof.localeCompare(b.prof,"es");
  const pend=(lista||[]).filter(a=>a.estado==="Pendiente").sort(ord);
  const ini=mes+"-01",fin=mes+"-31";
  const conf=(lista||[]).filter(a=>a.estado!=="Pendiente"&&a.fecha<=fin&&(a.hasta||a.fecha)>=ini).sort(ord);
  const origen=a=>a.registrado_por==="hoja de Google"?"de la hoja de Google":a.registrado_por==="calendario DAP"?"del calendario de asuntos propios":a.canal==="fuera de plazo"?"⚠ notificada fuera de plazo (días anteriores)"+(a.registrado_por?" por "+a.registrado_por:""):a.canal?"comunicada por "+a.canal.toLowerCase()+(a.registrado_por?" · registrada por "+a.registrado_por:""):a.registrado_por?"registrada por "+a.registrado_por:"";
  const acento="#be123c";
  return(
    <Seccion tile={tile} onBack={onBack}>
      {arriba}
      <div className="card p-4 mb-4 space-y-3 no-print border-l-4" style={{borderLeftColor:acento}}>
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div><div className="font-display font-bold text-ink">Notificadas por el profesorado · pendientes de confirmar ({pend.length})</div>
            <div className="text-xs text-ink-soft font-medium">Al confirmarlas aparecen en el parte de Guardias de aula en los días y horas notificados.</div></div>
          {pend.length>1&&<button className="btn btn-dark" onClick={()=>{if(confirm("¿Confirmar las "+pend.length+" ausencias pendientes?"))confirmar(pend.map(a=>a.id));}}><Ico n="check" s={16}/>Confirmar todas</button>}
        </div>
        {lista===null&&<p className="text-xs text-ink-soft">Cargando…</p>}
        {lista!==null&&pend.length===0&&<p className="text-sm text-ink-soft">No hay notificaciones pendientes.</p>}
        <div className="divide-y divide-divider">
          {pend.map(a=><div key={a.id} className="py-2.5 flex items-start gap-2 flex-wrap sm:flex-nowrap">
            <div className="flex-1 min-w-[12rem]">
              <div className="text-sm font-bold text-ink">{nombreHorario(a.prof)}</div>
              <div className="text-xs text-ink-soft font-medium">{fmtCorta(a.fecha)}{a.hasta?" → "+fmtCorta(a.hasta):""} · {textoHoras(a)}{a.motivo?" · "+a.motivo:""}{a.creado?" · notificada el "+fmtCorta(a.creado):""}</div>
              {a.obs&&<div className="text-xs text-ink-soft mt-0.5 italic">Tarea: {a.obs}</div>}
            </div>
            <div className="flex items-center gap-1 flex-shrink-0">
              <button className="btn btn-dark !px-3 !py-1.5 text-xs" onClick={()=>confirmar([a.id])}><Ico n="check" s={14}/>Confirmar</button>
              <button className="p-2 rounded-lg hover:bg-black/5 text-ink-soft" aria-label="Corregir y confirmar" title="Corregir y confirmar" onClick={()=>editar(a)}><Ico n="lapiz" s={18}/></button>
              <button className="p-2 rounded-lg hover:bg-rose-50 text-[#be123c]" aria-label="Rechazar" title="Rechazar" onClick={()=>rechazar(a)}><Ico n="papelera" s={18}/></button>
            </div>
          </div>)}
        </div>
      </div>

      <TarjetaDAP ops={ops} profs={profs} onCambio={cargar}/>

      <div className="card p-4 mb-4 space-y-3 no-print">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div><div className="font-display font-bold text-ink">Registrar una ausencia comunicada por otros medios</div>
            <div className="text-xs text-ink-soft font-medium">Teléfono, correo, en persona… Queda confirmada al guardarla y el profesor/a la verá en «Justificar ausencia».</div></div>
          {!form&&<button className="btn btn-dark" onClick={()=>setForm({id:"",prof:"",fecha:hoyISO(),hasta:"",modo:"dia",horas:[],motivo:"Cita médica",obs:"",canal:"Teléfono"})}><Ico n="mas" s={16}/>Registrar ausencia</button>}
        </div>
        {form&&<FormAusenciaAdmin key={form.id||"nueva"} inicial={form} profs={profs} acento={acento} conCanal onCancel={()=>setForm(null)} onSave={guardar}/>}
      </div>

      <div className="card p-4 space-y-3 no-print">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="font-display font-bold text-ink">Ausencias confirmadas</div>
          <input type="month" className="field !w-auto" value={mes} onChange={e=>setMes(e.target.value||hoyISO().slice(0,7))} aria-label="Mes"/>
        </div>
        {lista!==null&&conf.length===0&&<p className="text-sm text-ink-soft">No hay ausencias confirmadas en este mes.</p>}
        <div className="divide-y divide-divider">
          {conf.map(a=><div key={a.id} className="py-2.5 flex items-start gap-2">
            <div className="flex-1 min-w-0">
              <div className="text-sm font-bold text-ink">{nombreHorario(a.prof)} <span className={"ml-1 px-2 py-0.5 rounded-full text-[11px] font-semibold "+(a.justificacion_id||esDAP(a.motivo)||esActividad(a.motivo)?"bg-olive-light text-olive":"bg-rose-50 text-[#9f1239]")}>{a.justificacion_id?"Justificada":esDAP(a.motivo)?"Justificada · DAP":esActividad(a.motivo)?"Justificada · actividad":"Sin justificar"}</span></div>
              <div className="text-xs text-ink-soft font-medium">{fmtCorta(a.fecha)}{a.hasta?" → "+fmtCorta(a.hasta):""} · {textoHoras(a)}{a.motivo?" · "+a.motivo:""}{origen(a)?" · "+origen(a):""}</div>
            </div>
            <button className="p-2 rounded-lg hover:bg-black/5 text-ink-soft" aria-label="Editar" onClick={()=>editar(a)}><Ico n="lapiz" s={18}/></button>
            <button className="p-2 rounded-lg hover:bg-rose-50 text-[#be123c]" aria-label="Eliminar" onClick={()=>borrar(a)}><Ico n="papelera" s={18}/></button>
          </div>)}
        </div>
      </div>
    </Seccion>
  );
}

/* Aviso del día 1 al 5: ausencias de meses anteriores sin justificar (una vez al día) */
function AvisoJustificar({alerta,onIr,onCerrar}){
  const lim=new Date(alerta.limite+"T12:00:00").toLocaleDateString("es-ES",{day:"numeric",month:"long"});
  return(
    <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 no-print" role="alertdialog" aria-modal="true" aria-label="Ausencias sin justificar">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6 fade-in">
        <div className="flex items-center gap-3 mb-3"><span className="w-11 h-11 rounded-full flex items-center justify-center text-white" style={{background:"#be123c"}}><Ico n="ausencia" s={22}/></span>
          <div className="font-display font-bold text-lg text-ink">Ausencias sin justificar</div></div>
        <p className="text-sm text-ink-soft mb-5">{alerta.enPlazo
          ?<>Tienes <b className="text-ink">{alerta.n}</b> ausencia(s) del mes pasado (o anteriores) sin justificar. Tienes de plazo hasta el <b className="text-ink">{lim}</b>.</>
          :<>El plazo para justificar terminó el <b className="text-ink">{lim}</b> y tienes <b className="text-ink">{alerta.n}</b> ausencia(s) sin justificar. Justifícalas cuanto antes.</>}</p>
        <div className="flex gap-2"><button className="btn btn-ghost flex-1" onClick={onCerrar}>Más tarde</button><button className="btn btn-dark flex-1" onClick={onIr}>Justificar ahora</button></div>
      </div>
    </div>
  );
}

function PestanasGuardias({modo,onModo,admin,registro}){
  const P=[["aula","Guardias de aula","escudo","#d97706"],["recreo","Guardias de recreo","campana","#0d9488"]].concat(registro?[["firmas","Registro de firmas","informe","#334155"]]:[]).concat(admin?[["panel","Pantalla sala de profesores","pantalla","#6B2D8B"]]:[]);
  return(
    <div className="flex flex-wrap gap-2 mb-5 no-print" role="tablist">
      {P.map(([k,l,ico,c])=><button key={k} role="tab" aria-selected={modo===k} onClick={()=>onModo(k)} className={"chip flex items-center gap-2"+(modo===k?" on":"")} style={modo===k?{background:c}:{}}><Ico n={ico} s={16}/>{l}</button>)}
    </div>
  );
}

/* ── Pantalla de la sala de profesores (modo administrador) ──
   Enlace secreto para la TV (no caduca ni pide sesión), vista previa, mensaje fijo y enlaces con QR. */
function PantallaPanelSala({tile,onBack,arriba,esAdminCuenta,onToast}){
  const[c,setC]=useState(null);const[token,setToken]=useState("");const[err,setErr]=useState("");const[ocupado,setOcupado]=useState(false);
  const[recarga,setRecarga]=useState(0);
  useEffect(()=>{if(!esAdminCuenta)return;pedir("GET","/panel/config").then(d=>{setC({...d.config,enlaces:d.config.enlaces.concat([{titulo:"",url:""},{titulo:"",url:""},{titulo:"",url:""}]).slice(0,3)});setToken(d.token);}).catch(e=>setErr(e.message));},[esAdminCuenta]);
  const base=location.origin+location.pathname;
  const url=token?base+"?panel="+encodeURIComponent(token):"";
  const guardar=async(extra={},msg)=>{
    setOcupado(true);
    try{const d=await pedir("PUT","/panel/config",{...c,enlaces:c.enlaces.filter(e=>e.titulo.trim()&&e.url.trim()),...extra});setToken(d.token);setRecarga(r=>r+1);onToast(msg||(extra.regenerar?"Enlace nuevo creado: actualízalo en la pantalla":"Pantalla actualizada"));}
    catch(e){onToast(e.message);}
    setOcupado(false);
  };
  const copiar=()=>{try{navigator.clipboard.writeText(url);onToast("Enlace copiado");}catch(e){prompt("Copia el enlace:",url);}};
  const setE=(i,k,v)=>setC({...c,enlaces:c.enlaces.map((e,j)=>j===i?{...e,[k]:v}:e)});
  return(
    <Seccion tile={tile} onBack={onBack}>
      {arriba}
      {!esAdminCuenta?<div className="card p-6 text-sm text-ink-soft">La pantalla de la sala de profesores la configura una cuenta de administración (Jefatura de Estudios).</div>
      :err?<div className="card p-6 text-sm font-semibold text-[#be123c]">{err}</div>
      :!c?<div className="card p-6 text-sm text-ink-soft">Cargando…</div>:<div className="space-y-4">
        <div className="card p-5">
          <div className="flex flex-wrap items-start gap-4">
            <div className="flex-1 min-w-[16rem]">
              <div className="font-display font-bold text-ink">Panel para la pantalla de la sala de profesores</div>
              <p className="text-xs text-ink-soft font-medium mt-1">Abre este enlace en el ordenador conectado a la pantalla y pulsa <b>F11</b> para verlo a pantalla completa. No pide usuario ni contraseña, no caduca y se actualiza solo cada minuto. Muestra el parte de guardias del día, quién falta (sin el motivo), avisos y próximas actividades.</p>
            </div>
            <div className="flex flex-wrap gap-2">
              <button className="btn btn-dark" onClick={()=>window.open(url,"panel_sala")}><Ico n="pantalla" s={16}/>Abrir pantalla</button>
              <button className="btn btn-ghost" onClick={copiar}><Ico n="enlace" s={16}/>Copiar enlace</button>
            </div>
          </div>
          <div className="mt-3 flex items-center gap-2 rounded-xl px-3 py-2 text-xs font-mono break-all" style={{background:"#F7F2FA",border:"1px solid #CDAEE0",color:"#522270"}}>{url}</div>
        </div>

        <div className="card p-3">
          <div className="text-[11px] font-bold uppercase tracking-wider text-ink-soft px-2 pb-2">Vista previa</div>
          <div className="relative w-full overflow-hidden rounded-xl border border-divider" style={{aspectRatio:"16/9"}}>
            <iframe key={recarga} title="Vista previa de la pantalla" src={url} className="absolute top-0 left-0 border-0 origin-top-left" style={{width:"1920px",height:"1080px",transform:"scale(var(--esc))"}} ref={el=>{if(el&&el.parentElement)el.style.setProperty("--esc",String(el.parentElement.clientWidth/1920));}}/>
          </div>
        </div>

        <div className="card p-5 space-y-4">
          <div>
            <label className="lbl" htmlFor="pn-msg">Mensaje fijo (opcional, franja bajo la cabecera)</label>
            <input id="pn-msg" className="field" maxLength={300} value={c.mensaje} onChange={e=>setC({...c,mensaje:e.target.value})} placeholder="p. ej. Claustro el jueves a las 17:00 en el salón de actos"/>
          </div>
          <div>
            <div className="lbl">Enlaces con código QR (hasta 3)</div>
            <div className="space-y-2">
              {c.enlaces.map((e,i)=>(
                <div key={i} className="grid grid-cols-1 sm:grid-cols-[14rem_1fr] gap-2">
                  <input className="field" maxLength={40} value={e.titulo} onChange={x=>setE(i,"titulo",x.target.value)} placeholder={["Planos del centro","Moodle","Web del centro"][i]} aria-label={"Título del enlace "+(i+1)}/>
                  <input className="field" value={e.url} onChange={x=>setE(i,"url",x.target.value)} placeholder="https://…" aria-label={"Dirección del enlace "+(i+1)}/>
                </div>
              ))}
            </div>
          </div>
          <div className="flex flex-wrap items-end gap-4">
            <div><label className="lbl" htmlFor="pn-seg">Segundos por aviso</label>
              <input id="pn-seg" type="number" min={5} max={60} className="field !w-28" value={c.segundosAviso} onChange={e=>setC({...c,segundosAviso:e.target.value})}/></div>
            <p className="text-xs text-ink-soft font-medium flex-1 min-w-[14rem] pb-2">Los avisos son los de «Avisos importantes» que no hayan caducado; las actividades, las de la Cronología y las extraescolares del calendario de Google «Actividades extraescolares» (próximos 30 días).</p>
            <button className="btn btn-dark" disabled={ocupado} onClick={()=>guardar()}><Ico n="check" s={16}/>Guardar</button>
          </div>
        </div>

        <div className="card p-4 flex flex-wrap items-center gap-3 justify-between">
          <p className="text-xs text-ink-soft font-medium flex-1 min-w-[16rem]">¿Se ha difundido el enlace por error? Crea uno nuevo: el anterior dejará de funcionar y tendrás que abrir el nuevo en la pantalla.</p>
          <button className="btn btn-ghost" disabled={ocupado} onClick={()=>{if(confirm("¿Crear un enlace nuevo? La pantalla que use el actual dejará de mostrar datos hasta que abras el nuevo."))guardar({regenerar:true});}}><Ico n="llave" s={16}/>Crear enlace nuevo</button>
        </div>
      </div>}
    </Seccion>
  );
}

/* ── Informes mensuales de ausencias (modo administrador) ──
   Resumen del mes en pantalla y descarga en PDF generado por el servidor. */
const MESES_LARGOS=["enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"];
const mesActual=()=>{const d=new Date();return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0");};
function PantallaInformes({tile,onBack,clave,arriba,esAdminCuenta,onToast}){
  const[mes,setMes]=useState(mesActual);
  const[motivo,setMotivo]=useState(true);
  const[inf,setInf]=useState(null);
  const[err,setErr]=useState("");
  const[ocupado,setOcupado]=useState("");
  useEffect(()=>{
    if(!esAdminCuenta||!/^\d{4}-\d{2}$/.test(mes))return;
    let vivo=true;setInf(null);setErr("");
    pedir("POST","/ausencias/informe",{mes,clave,formato:"json"}).then(d=>{if(vivo)setInf(d);}).catch(e=>{if(vivo)setErr(e.message);});
    return()=>{vivo=false;};
  },[mes,clave,esAdminCuenta]);
  const descargar=async(tipo)=>{
    setOcupado(tipo);
    try{
      const ruta=tipo==="dossier"?"/ausencias/dossier":"/ausencias/informe";
      const r=await fetch(API_BASE+ruta,{method:"POST",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify({mes,clave,formato:"pdf",motivo})});
      if(!(r.headers.get("content-type")||"").includes("pdf")){const d=await r.json().catch(()=>({}));throw new Error(d.error||"No se pudo generar el PDF");}
      const url=URL.createObjectURL(await r.blob());
      const a=document.createElement("a");a.href=url;a.download=(tipo==="dossier"?"Ausencias_y_justificantes_":"Informe_ausencias_")+mes+".pdf";document.body.appendChild(a);a.click();a.remove();
      setTimeout(()=>URL.revokeObjectURL(url),60000);
      onToast(tipo==="dossier"?"Dossier descargado":"Informe descargado");
    }catch(e){onToast(e.message);}
    setOcupado("");
  };
  const importar=async()=>{
    if(!confirm("¿Copiar a la app las ausencias, avisos y calendarios que haya en la hoja de Google «Ausencias 2026-27»? No se borra nada de lo que ya está en la app."))return;
    setOcupado("imp");
    try{const r=await pedir("POST","/ausencias/importar-hoja",{clave});onToast("Importado: "+r.ausencias+" ausencias, "+r.avisos+" avisos, "+r.calendarios+" calendarios");setMes(m=>m);setInf(null);
      const d=await pedir("POST","/ausencias/informe",{mes,clave,formato:"json"});setInf(d);}
    catch(e){onToast(e.message);}
    setOcupado("");
  };
  const nombreMes=m=>{const p=m.split("-");return cap(MESES_LARGOS[+p[1]-1]||"")+" "+p[0];};
  const t=inf&&inf.totales;
  return(
    <Seccion tile={tile} onBack={onBack}>
      {arriba}
      {!esAdminCuenta?<div className="card p-6 text-sm text-ink-soft">Los informes de ausencias solo los puede generar una cuenta de administración (Jefatura de Estudios) con el modo administrador activo.</div>:<>
      <div className="card p-5 mb-4 no-print">
        <div className="flex flex-wrap items-end gap-4">
          <div><label className="lbl" htmlFor="inf-mes">Mes del informe</label>
            <input id="inf-mes" type="month" className="field !w-auto" value={mes} max={mesActual()} onChange={e=>setMes(e.target.value)}/></div>
          <label className="flex items-center gap-2 text-sm font-medium text-ink-soft pb-3 cursor-pointer"><input type="checkbox" checked={motivo} onChange={e=>setMotivo(e.target.checked)}/>Incluir el motivo de cada ausencia</label>
          <div className="flex flex-wrap gap-2 ml-auto">
            <button className="btn btn-ghost" onClick={()=>descargar("pdf")} disabled={!inf||!!ocupado}><Ico n="descargar" s={16}/>{ocupado==="pdf"?"Generando…":"Informe PDF"}</button>
            <button className="btn btn-dark" onClick={()=>descargar("dossier")} disabled={!inf||!!ocupado} title="Informe del mes, hoja de cada justificación y todos sus PDF en un único documento"><Ico n="imprimir" s={16}/>{ocupado==="dossier"?"Preparando…":"Dossier con justificantes"}</button>
          </div>
        </div>
        <p className="text-[11px] text-ink-soft mt-3">Las cifras cuentan solo las ausencias grabadas. Días lectivos de lunes a viernes dentro del mes; sesiones según el horario cargado en la app.{motivo?" Con el motivo, el PDF es un documento interno con datos personales.":""}</p>
      </div>
      {err&&<div className="card p-5 text-sm font-semibold text-[#be123c]">{err}</div>}
      {!inf&&!err&&<div className="card p-5 text-sm text-ink-soft">Preparando el informe…</div>}
      {inf&&<div className="space-y-4 fade-in">
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          {[["Ausencias grabadas",t.ausencias],["Profesores/as",t.profesores],["Días lectivos",t.dias],["Sesiones de clase",t.clases],["Guardias afectadas",t.guardias]].map(([l,v])=>(
            <div key={l} className="card p-4 text-center"><div className="font-display font-bold text-2xl" style={{color:"#6B2D8B"}}>{v}</div><div className="text-[11px] text-ink-soft font-semibold mt-1">{l}</div></div>))}
        </div>
        <div className="rounded-xl p-3 text-xs font-semibold" style={t.justificadas<t.ausencias?{background:"#fff1f2",color:"#9f1239"}:{background:"#f0fdf4",color:"#166534"}}>Justificadas por el profesorado: {t.justificadas} de {t.ausencias} ausencias grabadas.{t.justificadas<t.ausencias?" El dossier incluye la hoja y los PDF de cada justificación; el informe marca las que faltan.":""}</div>
        {t.pendientes>0&&<div className="rounded-xl p-3 text-xs font-semibold" style={{background:"#fffbeb",color:"#92400e"}}>{t.pendientes} ausencia(s) de {nombreMes(mes).toLowerCase()} pendiente(s) de grabar: no cuentan en las cifras. Grábalas en «Guardias de aula».</div>}
        <div className="card overflow-x-auto">
          <div className="p-4 pb-2 font-display font-bold text-ink">Resumen por profesor/a · {nombreMes(mes)}</div>
          {inf.porProfesor.length===0?<p className="px-4 pb-4 text-sm text-ink-soft">No hay ausencias grabadas en este mes.</p>:
          <table className="w-full text-sm">
            <thead><tr className="text-left text-xs text-ink-soft"><th className="px-4 py-2">Profesor/a</th><th className="px-2 py-2 text-center">Ausencias</th><th className="px-2 py-2 text-center">Días lectivos</th><th className="px-2 py-2 text-center">Sesiones de clase</th><th className="px-4 py-2 text-center">Guardias</th></tr></thead>
            <tbody>{inf.porProfesor.map((p,i)=><tr key={p.profesor} className={i%2?"bg-paper":""}><td className="px-4 py-2 font-semibold text-ink">{p.profesor}</td><td className="px-2 py-2 text-center">{p.ausencias}</td><td className="px-2 py-2 text-center">{p.dias}</td><td className="px-2 py-2 text-center">{p.clases}</td><td className="px-4 py-2 text-center">{p.guardias}</td></tr>)}</tbody>
          </table>}
        </div>
      </div>}
      <details className="mt-6 text-xs text-ink-soft no-print">
        <summary className="cursor-pointer font-semibold">Datos anteriores de la hoja de Google</summary>
        <p className="mt-2 leading-relaxed">Al instalar esta versión, el servidor copia una vez lo que había en la hoja «Ausencias 2026-27» (ausencias, avisos y calendarios). Si no pudo hacerlo, o quieres repetirlo, pulsa el botón: no borra nada de lo que ya está en la app.</p>
        <button className="btn btn-ghost mt-2" onClick={importar} disabled={ocupado==="imp"}>{ocupado==="imp"?"Importando…":"Importar desde la hoja de Google"}</button>
      </details>
      </>}
    </Seccion>
  );
}

function PestanasAulas({modo,onModo,tile}){
  const P=[["horario","Horario de las aulas","aula"],["reservas","Reserva de espacios","calendario"]];
  return(
    <div className="flex flex-wrap gap-2 mb-5 no-print" role="tablist">
      {P.map(([k,l,ico])=><button key={k} role="tab" aria-selected={modo===k} onClick={()=>onModo(k)} className={"chip flex items-center gap-2"+(modo===k?" on":"")} style={modo===k?{background:tile.g[0]}:{}}><Ico n={ico} s={16}/>{l}</button>)}
    </div>
  );
}

/* ── Reserva de espacios ──
   Cualquier docente reserva periodos libres de UNA semana (de un día de inicio a uno de fin) indicando
   docente y materia; lo reservado se ve en el cuadrante para todos. Jefatura (cuenta de administración)
   añade espacios, fija periodos que nunca se pueden reservar y puede reservar varias semanas. */
const DIAS_RES=["Lunes","Martes","Miércoles","Jueves","Viernes"];
/* icono y color de cada espacio (por su identificador o por el nombre, para los que añada Jefatura) */
const ESTILO_ESPACIO=e=>{const n=quitarTildes((e.id||"")+" "+(e.nombre||""));
  if(/bibliot/.test(n))return{ico:"libro",g:["#7c4a1d","#c98a3d"]};
  if(/\bsum\b|usos multiples/.test(n))return{ico:"sum",g:["#6B2D8B","#b062d6"]};
  if(/infolab|a106|a118|informatica/.test(n))return{ico:"infolab",g:["#1d4ed8","#60a5fa"]};
  if(/portatil|a100|carro|armario/.test(n))return{ico:"portatil",g:["#0d9488","#34d3be"]};
  if(/jjee|jefatura/.test(n))return{ico:"jjee",g:["#334155","#64748b"]};
  return{ico:"aula",g:["#a85a3f","#e08f6c"]};};
/* estados de una casilla del cuadrante */
const ESTADO_RES={
  libre:{l:"Libre",ico:"libre",c:"#15803d"},
  reservada:{l:"Reservada",ico:"reservada",c:"#b45309"},
  mia:{l:"Tu reserva (pulsa para anular)",ico:"reservada",c:"#4338ca"},
  prohibida:{l:"Periodo fijo · no reservable",ico:"prohibida",c:"#be123c"},
  sel:{l:"Seleccionada",ico:"check",c:"#14532d"}};
const isoLocal=d=>d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");
const lunesDe=iso=>{const d=new Date(iso+"T12:00:00");d.setDate(d.getDate()-((d.getDay()+6)%7));return isoLocal(d);};
const masDias=(iso,n)=>{const d=new Date(iso+"T12:00:00");d.setDate(d.getDate()+n);return isoLocal(d);};
const nombreNatural=n=>{const[a,b]=String(n||"").split(", ");return b?b+" "+a:String(n||"");};
const fechaCorta=iso=>new Date(iso+"T12:00:00").toLocaleDateString("es-ES",{day:"numeric",month:"short"});

function PantallaReservas({tile,onBack,profs,onToast,arriba}){
  const[base,setBase]=useState(null);const[esp,setEsp]=useState("");
  const[semana,setSemana]=useState(()=>{const h=isoLocal(new Date());const d=new Date().getDay();return d===0||d===6?masDias(lunesDe(h),7):lunesDe(h);});
  const[datos,setDatos]=useState(null);const[tarde,setTarde]=useState(false);
  const[f,setF]=useState({ini:"",fin:"",docente:"",materia:""});const[sel,setSel]=useState(new Set());
  const[msg,setMsg]=useState(null);const[ocupado,setOcupado]=useState(false);
  const[gestion,setGestion]=useState(false);const[modoFijo,setModoFijo]=useState(false);
  const cargarBase=async()=>{try{const d=await pedir("GET","/reservas/espacios");setBase(d);
    setEsp(e=>e&&d.espacios.some(x=>x.id===e)?e:((d.espacios.find(x=>x.activo)||{}).id||""));
    setF(x=>x.docente?x:{...x,docente:nombreNatural(d.docente)});}catch(e){setMsg({t:e.message,err:1});}};
  const cargar=async()=>{if(!esp)return;try{setDatos(await pedir("GET","/reservas?espacio="+encodeURIComponent(esp)+"&desde="+semana));}catch(e){setMsg({t:e.message,err:1});}};
  useEffect(()=>{cargarBase();},[]);
  useEffect(()=>{setDatos(null);cargar();},[esp,semana]);
  useEffect(()=>{const t=setInterval(()=>{if(!document.hidden)cargar();},60000);return()=>clearInterval(t);},[esp,semana]);
  const admin=base&&base.admin;
  const tramos=base?base.tramos.filter(t=>tarde||t.turno==="mañana"):[];
  const hayTarde=datos&&datos.reservas.some(r=>Number(r.tramo)>6);
  const fijo=useMemo(()=>{const m={};(datos?datos.bloqueos:[]).forEach(b=>{m[b.dia+"|"+b.tramo]=b.etiqueta;});return m;},[datos]);
  const reservada=useMemo(()=>{const m={};(datos?datos.reservas:[]).forEach(r=>{m[r.fecha+"|"+r.tramo]=r;});return m;},[datos]);
  const espActual=base&&base.espacios.find(x=>x.id===esp);
  const elegirEsp=id=>{setEsp(id);setSel(new Set());setMsg(null);};
  const irSemana=n=>{setSemana(masDias(semana,7*n));if(!admin)setSel(new Set());};
  const cambiarIni=v=>{setF(x=>({...x,ini:v,fin:!x.fin||x.fin<v||(!admin&&x.fin>masDias(v,30))?v:x.fin}));if(v)setSemana(lunesDe(v));setSel(new Set());setMsg(null);};
  const cambiarFin=v=>{setF(x=>({...x,fin:v}));setSel(new Set());setMsg(null);};
  /* clic en una celda libre: si aún no hay fechas, se toman las de esa celda; si es de la misma semana, se amplía el rango */
  const marcar=(fecha,tramo)=>{
    setMsg(null);let {ini,fin}=f;
    if(!ini||(!admin&&lunesDe(ini)!==lunesDe(fecha))){ini=fecha;fin=fin&&fin>fecha&&fin<=masDias(fecha,30)&&lunesDe(fin)!==lunesDe(fecha)?fin:fecha;setSel(new Set());}
    else if(fecha<ini)ini=fecha;else if(fecha>fin&&(admin||lunesDe(fecha)===lunesDe(ini)))fin=fecha;
    setF(x=>({...x,ini,fin}));
    setSel(s=>{const n=new Set(lunesDe(fecha)===lunesDe(ini)||admin?s:[]);const k=fecha+"|"+tramo;n.has(k)?n.delete(k):n.add(k);return n;});
  };
  const confirmar=async()=>{
    if(!f.ini)return setMsg({t:"Indica el día de inicio o pulsa un periodo libre del cuadrante.",err:1});
    if(!f.docente.trim()||!f.materia.trim())return setMsg({t:"Escribe el docente y la materia.",err:1});
    if(!sel.size)return setMsg({t:"Marca en el cuadrante al menos un periodo.",err:1});
    if(!admin&&(f.fin||f.ini)>masDias(f.ini,30))return setMsg({t:"La reserva puede durar como mucho un mes. Para periodos más largos, contacta con Jefatura de Estudios.",err:1});
    setOcupado(true);
    try{const celdas=[...sel].map(k=>{const[fecha,tramo]=k.split("|");return{fecha,tramo};});
      const r=await pedir("POST","/reservas",{espacio:esp,ini:f.ini,fin:f.fin||f.ini,docente:f.docente,materia:f.materia,celdas});
      setSel(new Set());setMsg({t:"Reserva confirmada: "+r.reservadas+" periodo"+(r.reservadas>1?"s":"")+(r.conflictos.length?" ("+r.conflictos.length+" no se pudieron reservar: ya estaban ocupados o son fijos)":"")+".",ok:1});
      onToast("Reserva confirmada · "+(espActual?espActual.nombre:""));await cargar();}
    catch(e){setMsg({t:e.message,err:1});await cargar();}
    setOcupado(false);
  };
  const anular=async r=>{
    const todo=confirm("¿Anular la reserva completa de «"+r.docente+" · "+r.materia+"»?\n\nAceptar: toda la reserva (todos sus periodos).\nCancelar: elegir solo este periodo.");
    if(!todo&&!confirm("¿Anular solo el periodo del "+fechaCorta(r.fecha)+" ("+r.tramo+"ª hora)?"))return;
    try{const d=await pedir("DELETE","/reservas/"+r.id+(todo?"?lote=1":""));onToast(d.anuladas+" periodo"+(d.anuladas>1?"s":"")+" anulado"+(d.anuladas>1?"s":""));await cargar();}
    catch(e){alert(e.message);}
  };
  const alternarFijo=async(dia,tramo)=>{
    const ya=fijo[dia+"|"+tramo];let etiqueta="Clase fija";
    if(!ya){const t=prompt("Texto del periodo fijo (se verá en el cuadrante):","Clase fija");if(t===null)return;etiqueta=t||"Clase fija";}
    try{await pedir("PUT","/reservas/espacios/"+esp+"/bloqueo",{dia,tramo,etiqueta,bloqueado:!ya});await cargar();}catch(e){alert(e.message);}
  };
  if(!base)return <Seccion tile={tile} onBack={onBack}>{arriba}<div className="card p-6 text-sm text-ink-soft">{msg?msg.t:"Cargando espacios…"}</div></Seccion>;
  const dias=datos?datos.dias:DIAS_RES.map((_,i)=>masDias(semana,i));
  const hoyIso=datos?datos.hoy:isoLocal(new Date());
  const enRango=fecha=>f.ini&&fecha>=f.ini&&fecha<=(f.fin||f.ini);
  return(
    <Seccion tile={tile} onBack={onBack}>
      {arriba}
      <div className="space-y-4">
        {/* espacios */}
        <div className="card p-4 no-print">
          <div className="flex items-center justify-between gap-2 flex-wrap mb-3">
            <div className="font-display font-bold text-ink">Espacio que quieres reservar</div>
            {admin&&<button className="btn btn-ghost !min-h-[36px] text-xs" onClick={()=>setGestion(!gestion)}><Ico n="ajustes" s={15}/>{gestion?"Cerrar gestión":"Gestionar espacios"}</button>}
          </div>
          <div className="flex flex-wrap gap-2">
            {base.espacios.filter(e=>e.activo).map(e=>{const st=ESTILO_ESPACIO(e),on=e.id===esp;return(
              <button key={e.id} onClick={()=>elegirEsp(e.id)} className={"chip flex items-center gap-2 !pl-2"+(on?" on":"")} style={on?{background:st.g[0]}:{}}>
                <span className="w-7 h-7 rounded-lg flex items-center justify-center text-white flex-shrink-0" style={{background:on?"rgba(255,255,255,.18)":"linear-gradient(135deg,"+st.g[0]+","+st.g[1]+")"}}><Ico n={st.ico} s={17}/></span>{e.nombre}</button>);})}
          </div>
          {admin&&gestion&&<GestionEspacios base={base} esp={espActual} modoFijo={modoFijo} setModoFijo={setModoFijo} onCambio={async()=>{await cargarBase();await cargar();}} onToast={onToast}/>}
        </div>

        {/* datos de la reserva */}
        {!modoFijo&&<div className="card p-4 no-print">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <label className="text-xs font-semibold text-ink-soft">Día de inicio<input type="date" className="field !mt-1" min={admin?undefined:hoyIso} value={f.ini} onChange={e=>cambiarIni(e.target.value)}/></label>
            <label className="text-xs font-semibold text-ink-soft">Día de fin<input type="date" className="field !mt-1" min={f.ini||hoyIso} max={admin||!f.ini?undefined:masDias(f.ini,30)} value={f.fin} onChange={e=>cambiarFin(e.target.value)}/></label>
            <label className="text-xs font-semibold text-ink-soft">Docente<input className="field !mt-1" list="res-profs" value={f.docente} maxLength={80} onChange={e=>setF({...f,docente:e.target.value})}/></label>
            <label className="text-xs font-semibold text-ink-soft">Materia<input className="field !mt-1" value={f.materia} maxLength={80} placeholder="Materia impartida" onChange={e=>setF({...f,materia:e.target.value})}/></label>
          </div>
          <datalist id="res-profs">{profs.map(p=><option key={p} value={nombreNatural(p)}/>)}</datalist>
          <p className="text-xs text-ink-soft font-medium mt-3">{admin
            ?<>Como administración puedes reservar <b>varias semanas</b>: marca los periodos en la primera semana y pon el día de fin; se repiten cada semana hasta esa fecha.</>
            :<>Puedes reservar hasta <b>un mes</b>: marca los periodos en la primera semana y pon el día de fin; <b>se repiten cada semana</b> hasta esa fecha. Para periodos más largos, contacta con <b>Jefatura de Estudios</b>.</>}</p>
        </div>}

        {/* cuadrante */}
        <div className="card p-4">
          <div className="flex items-center justify-between gap-2 flex-wrap mb-3">
            <div className="flex items-center gap-3">
              {espActual&&<TileIcon t={ESTILO_ESPACIO(espActual)} size={42}/>}
              <div><div className="font-display font-bold text-ink">{espActual?espActual.nombre:""}</div>
              <div className="text-xs text-ink-soft font-medium">Semana del {fechaCorta(dias[0])} al {fechaCorta(dias[4])}</div></div>
            </div>
            <div className="flex gap-2 no-print">
              <button className="btn btn-ghost !min-h-[36px] !px-3" onClick={()=>irSemana(-1)} aria-label="Semana anterior">‹ Anterior</button>
              <button className="btn btn-ghost !min-h-[36px] !px-3" onClick={()=>irSemana(1)} aria-label="Semana siguiente">Siguiente ›</button>
            </div>
          </div>
          {modoFijo&&<div className="rounded-xl p-3 mb-3 text-xs font-semibold" style={{background:"#fff7ed",color:"#9a3412"}}>Modo periodos fijos: pulsa una casilla para marcarla o desmarcarla como periodo que nunca se puede reservar (se repite todas las semanas).</div>}
          <div className="overflow-x-auto">
            <table className="w-full border-separate" style={{borderSpacing:4,minWidth:640,tableLayout:"fixed"}}>
              <thead><tr><th className="w-[92px]"></th>{dias.map((d,i)=><th key={d} className={"text-xs font-semibold "+(d===hoyIso?"text-ink":"text-ink-soft")}>{DIAS_RES[i]} {new Date(d+"T12:00:00").getDate()}</th>)}</tr></thead>
              <tbody>{tramos.map(t=>(
                <tr key={t.codigo}>
                  <th className="text-left text-[11px] font-semibold text-ink-soft align-top pt-2">{t.codigo}ª<div className="font-medium">{t.inicio}–{t.fin}</div></th>
                  {dias.map((d,i)=>{const dia=i+1,k=d+"|"+t.codigo,fx=fijo[dia+"|"+t.codigo],r=reservada[k],pasado=d<hoyIso&&!admin;
                    let cls="res-c",cont=null,onClick=null,title="";
                    const IcE=({e})=><span className="res-ico" style={{color:ESTADO_RES[e].c}}><Ico n={ESTADO_RES[e].ico} s={16}/></span>;
                    if(fx){cls+=" res-fijo";cont=<><IcE e="prohibida"/><b>{fx}</b></>;if(modoFijo)onClick=()=>alternarFijo(dia,t.codigo);title="Periodo fijo: no se puede reservar";}
                    else if(modoFijo){cls+=" res-libre";cont=<IcE e="libre"/>;onClick=()=>alternarFijo(dia,t.codigo);title="Marcar como periodo fijo";}
                    else if(r){cls+=r.mia?" res-mia":" res-ocupada";cont=<><IcE e={r.mia?"mia":"reservada"}/><b>{r.docente}</b><small>{r.materia}</small></>;
                      if(r.mia||admin){onClick=()=>anular(r);title="Pulsa para anular";}}
                    else if(pasado){cls+=" res-pasado";}
                    else{const s=sel.has(k);cls+=s?" res-sel":(enRango(d)?" res-libre res-rango":" res-libre");cont=s?<><IcE e="sel"/><b>Reservar</b></>:<><IcE e="libre"/><span className="res-libre-tx">Libre</span></>;onClick=()=>marcar(d,t.codigo);title="Libre: pulsa para seleccionar";}
                    return <td key={d} className={cls} title={title} onClick={onClick} role={onClick?"button":undefined}>{cont}</td>;})}
                </tr>))}</tbody>
            </table>
          </div>
          <div className="flex items-center justify-between gap-2 flex-wrap mt-2">
            <div className="flex flex-wrap gap-2 text-[11px] font-semibold">
              {[["libre","res-libre"],["reservada","res-ocupada"],["mia","res-mia"],["prohibida","res-fijo"],["sel","res-sel"]].map(([e,c])=>(
                <span key={e} className={"res-ley "+c} style={{color:ESTADO_RES[e].c}}><Ico n={ESTADO_RES[e].ico} s={14}/>{ESTADO_RES[e].l}</span>))}
            </div>
            {(base.tramos.some(t=>t.turno!=="mañana"))&&<button className="text-xs font-semibold underline text-ink-soft no-print" onClick={()=>setTarde(!tarde)}>{tarde?"Ocultar la tarde":"Mostrar la tarde"+(hayTarde?" (hay reservas)":"")}</button>}
          </div>
          {!modoFijo&&<div className="flex items-center gap-3 flex-wrap mt-4 no-print">
            <button className="btn btn-dark" disabled={ocupado||!sel.size} onClick={confirmar}><Ico n="check" s={16}/>{ocupado?"Reservando…":"Confirmar reserva"+(sel.size?" ("+sel.size+")":"")}</button>
            {sel.size>0&&<button className="btn btn-ghost" onClick={()=>setSel(new Set())}>Quitar selección</button>}
            {msg&&<span className={"text-sm font-semibold "+(msg.err?"text-[#be123c]":"text-[#15803d]")} role="status">{msg.t}</span>}
          </div>}
        </div>
      </div>
    </Seccion>
  );
}

/* Jefatura: añadir, renombrar y retirar espacios; periodos fijos */
function GestionEspacios({base,esp,modoFijo,setModoFijo,onCambio,onToast}){
  const[nuevo,setNuevo]=useState({nombre:"",aula:""});const[ocupado,setOcupado]=useState(false);
  const accion=async(fn,m)=>{setOcupado(true);try{const r=await fn();if(m)onToast(typeof m==="function"?m(r):m);await onCambio();}catch(e){alert(e.message);}setOcupado(false);};
  return(
    <div className="mt-4 pt-4 border-t border-divider space-y-4">
      <div className="flex flex-wrap gap-2 items-end">
        <label className="text-xs font-semibold text-ink-soft flex-1 min-w-[12rem]">Nuevo espacio reservable<input className="field !mt-1" value={nuevo.nombre} placeholder="Ej.: Aula de Música" onChange={e=>setNuevo({...nuevo,nombre:e.target.value})}/></label>
        <label className="text-xs font-semibold text-ink-soft w-36">Aula en el horario (opcional)<input className="field !mt-1" value={nuevo.aula} placeholder="Ej.: 205" onChange={e=>setNuevo({...nuevo,aula:e.target.value})}/></label>
        <button className="btn btn-dark" disabled={ocupado||!nuevo.nombre.trim()} onClick={()=>accion(()=>pedir("POST","/reservas/espacios",nuevo).then(r=>{setNuevo({nombre:"",aula:""});return r;}),"Espacio añadido")}><Ico n="mas" s={16}/>Añadir</button>
      </div>
      {esp&&<div className="rounded-xl p-3 space-y-2" style={{background:"#F5F3EE"}}>
        <div className="text-sm font-bold text-ink">{esp.nombre}{esp.aula&&<span className="font-medium text-ink-soft"> · aula {esp.aula} del horario</span>}</div>
        <div className="flex flex-wrap gap-2">
          <button className={"btn !min-h-[36px] text-xs "+(modoFijo?"btn-dark":"btn-ghost")} onClick={()=>setModoFijo(!modoFijo)}><Ico n="candado" s={15}/>{modoFijo?"Terminar periodos fijos":"Marcar periodos fijos"}</button>
          {esp.aula&&<button className="btn btn-ghost !min-h-[36px] text-xs" disabled={ocupado} onClick={()=>{if(confirm("¿Marcar como fijos todos los periodos en que el horario tiene clase en el aula "+esp.aula+"?"))accion(()=>pedir("POST","/reservas/espacios/"+esp.id+"/bloqueo-horario"),r=>r.bloqueados+" periodos fijos tomados del horario");}}><Ico n="aula" s={15}/>Fijar las clases del horario</button>}
          <button className="btn btn-ghost !min-h-[36px] text-xs" disabled={ocupado} onClick={()=>{const n=prompt("Nuevo nombre del espacio:",esp.nombre);if(n&&n.trim())accion(()=>pedir("PUT","/reservas/espacios/"+esp.id,{nombre:n}),"Nombre cambiado");}}><Ico n="lapiz" s={15}/>Renombrar</button>
          <button className="btn btn-ghost !min-h-[36px] text-xs text-[#be123c]" disabled={ocupado} onClick={()=>{if(confirm("¿Retirar «"+esp.nombre+"» de los espacios reservables? Sus reservas se conservan y puedes volver a activarlo."))accion(()=>pedir("PUT","/reservas/espacios/"+esp.id,{activo:false}),"Espacio retirado");}}><Ico n="papelera" s={15}/>Retirar</button>
        </div>
      </div>}
      {base.espacios.some(e=>!e.activo)&&<div className="text-xs text-ink-soft font-medium">Retirados: {base.espacios.filter(e=>!e.activo).map(e=><button key={e.id} className="underline font-semibold mr-2" onClick={()=>accion(()=>pedir("PUT","/reservas/espacios/"+e.id,{activo:true}),"«"+e.nombre+"» vuelve a ser reservable")}>{e.nombre} (activar)</button>)}</div>}
    </div>
  );
}

/* ── Reunión con familias (tutores/as): generador de la presentación con los datos de su grupo ──
   El generador (public/presentacion.html) recibe el grupo y pide al servidor el horario del grupo,
   el tutor/a, las materias con su profesorado y la fecha de la reunión que fija Jefatura. */
const MESES_L=["enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"];
const textoReunion=r=>{if(!r||!r.fecha)return"";const d=new Date(r.fecha+"T12:00:00");
  return d.toLocaleDateString("es-ES",{weekday:"long"})+" "+d.getDate()+" de "+MESES_L[d.getMonth()]+(r.hora?" a las "+r.hora+" h":"")+(r.lugar?" · "+r.lugar:"");};
function PantallaFamilias({tile,onBack,esAdmin,profs,onToast}){
  const[datos,setDatos]=useState(null);const[err,setErr]=useState("");const[grupo,setGrupo]=useState("");
  const[conf,setConf]=useState(false);const[ver,setVer]=useState(0);
  const cargar=async()=>{try{const d=await pedir("GET","/tutoria/mia");setDatos(d);setErr("");
    setGrupo(g=>g&&d.grupos.some(x=>x.grupo===g)?g:(d.grupos[0]?d.grupos[0].grupo:""));}catch(e){setErr(e.message);}};
  useEffect(()=>{cargar();},[]);
  const reunion=datos&&datos.reunion;
  return(
    <Seccion tile={tile} onBack={onBack}>
      <div className="space-y-4">
        <div className="card p-4 flex flex-wrap items-center gap-3 justify-between no-print">
          <div>
            <div className="font-display font-bold text-ink">Reunión de tutores con padres y madres</div>
            <div className="text-xs text-ink-soft font-medium">{reunion&&reunion.fecha?<>El <b className="text-ink">{textoReunion(reunion)}</b></>:"Fecha y hora pendientes de fijar por Jefatura de Estudios"}</div>
          </div>
          {esAdmin&&<button className="btn btn-ghost" onClick={()=>setConf(!conf)}><Ico n="ajustes" s={16}/>{conf?"Cerrar configuración":"Fecha y tutores"}</button>}
        </div>
        {err&&<div className="card p-4 text-sm font-semibold text-[#be123c]">{err}</div>}
        {esAdmin&&conf&&datos&&<ConfigFamilias reunion={reunion||{}} profs={profs} onCambio={()=>{cargar();}} onToast={onToast}/>}
        {datos&&datos.grupos.length===0&&<div className="card p-6 text-center text-sm text-ink-soft font-medium">No figuras como tutor/a de ningún grupo. Si es un error, avisa a Jefatura de Estudios.</div>}
        {datos&&datos.grupos.length>1&&<div className="flex flex-wrap gap-2 no-print">
          {datos.grupos.map(g=><button key={g.grupo} onClick={()=>setGrupo(g.grupo)} className={"chip"+(g.grupo===grupo?" on":"")} style={g.grupo===grupo?{background:"#c2410c",color:"#fff",borderColor:"#c2410c"}:{}}>{g.nombreGrupo||g.grupo}{esAdmin&&g.profesor?" · "+g.profesor.split(", ")[0]:""}</button>)}
        </div>}
        {grupo&&datos&&<Delegados key={"d"+grupo} g={datos.grupos.find(x=>x.grupo===grupo)} onToast={onToast} onGuardado={()=>{cargar();setVer(v=>v+1);}}/>}
        {grupo&&<div className="card overflow-hidden">
          <iframe key={grupo+"_"+ver} title={"Presentación para la reunión con familias · "+grupo} allow="fullscreen" allowFullScreen
            src={new URL("presentacion.html?grupo="+encodeURIComponent(grupo),location.href).href}
            style={{width:"100%",height:"calc(100dvh - 190px)",minHeight:620,border:0,display:"block"}}></iframe>
        </div>}
      </div>
    </Seccion>
  );
}
/* Delegado/a y subdelegado/a del grupo: los escribe el tutor/a (también salen en la presentación) */
function Delegados({g,onToast,onGuardado}){
  const[d,setD]=useState({delegado:(g&&g.delegado)||"",subdelegado:(g&&g.subdelegado)||""});const[ocupado,setOcupado]=useState(false);
  if(!g)return null;
  const cambiado=d.delegado!==(g.delegado||"")||d.subdelegado!==(g.subdelegado||"");
  const guardar=async e=>{e.preventDefault();setOcupado(true);
    try{await pedir("PUT","/tutoria/grupo/"+encodeURIComponent(g.grupo)+"/delegados",d);onToast("Delegados de "+(g.nombreGrupo||g.grupo)+" guardados");onGuardado();}
    catch(x){alert(x.message);}setOcupado(false);};
  return(
    <form onSubmit={guardar} className="card p-4 no-print">
      <div className="font-display font-bold text-ink">Delegado/a y subdelegado/a · {g.nombreGrupo||g.grupo}</div>
      <p className="text-xs text-ink-soft font-medium mb-3">Escribe sus nombres cuando se elijan. Se guardan en la app y aparecen en la diapositiva «El grupo» de la presentación.</p>
      <div className="flex flex-wrap gap-2 items-end">
        <label className="text-xs font-semibold text-ink-soft flex-1 min-w-[14rem]">Delegado/a<input className="field !mt-1" value={d.delegado} maxLength={80} placeholder="Nombre y apellidos" onChange={e=>setD({...d,delegado:e.target.value})}/></label>
        <label className="text-xs font-semibold text-ink-soft flex-1 min-w-[14rem]">Subdelegado/a<input className="field !mt-1" value={d.subdelegado} maxLength={80} placeholder="Nombre y apellidos" onChange={e=>setD({...d,subdelegado:e.target.value})}/></label>
        <button className="btn btn-dark" disabled={ocupado||!cambiado}><Ico n="check" s={16}/>{ocupado?"Guardando…":"Guardar"}</button>
      </div>
    </form>
  );
}
/* Jefatura: fecha y hora de la reunión, y tutor/a de cada grupo */
function ConfigFamilias({reunion,profs,onCambio,onToast}){
  const[r,setR]=useState({fecha:reunion.fecha||"",hora:reunion.hora||"",lugar:reunion.lugar||""});
  const[lista,setLista]=useState(null);const[ocupado,setOcupado]=useState(false);
  const cargar=async()=>{try{setLista(await pedir("GET","/tutorias"));}catch(e){alert(e.message);}};
  useEffect(()=>{cargar();},[]);
  const guardar=async()=>{setOcupado(true);try{await pedir("PUT","/tutoria/reunion",r);onToast("Fecha de la reunión guardada");onCambio();}catch(e){alert(e.message);}setOcupado(false);};
  const asignar=async(grupo,profesor)=>{try{await pedir("PUT","/tutorias/"+encodeURIComponent(grupo),{profesor});onToast(profesor?"Tutor/a de "+grupo+" guardado":"Tutoría de "+grupo+" quitada");await cargar();onCambio();}catch(e){alert(e.message);}};
  const tut=g=>{const t=lista&&lista.tutorias.find(x=>x.grupo===g);return t?t.profesor:"";};
  const grupos=lista?[...new Set([...lista.grupos,...lista.tutorias.map(t=>t.grupo)])].sort((a,b)=>a.localeCompare(b,"es",{numeric:true})):[];
  return(
    <div className="card p-4 space-y-4 no-print fade-in" style={{borderColor:"#fed7aa",background:"#fff7ed"}}>
      <div>
        <div className="font-bold text-sm text-[#9a3412] mb-2">Fecha y hora de la reunión (aparece en la portada de todas las presentaciones)</div>
        <div className="flex flex-wrap gap-2 items-end">
          <label className="text-xs font-semibold text-ink-soft">Día<input type="date" className="field !mt-1" value={r.fecha} onChange={e=>setR({...r,fecha:e.target.value})}/></label>
          <label className="text-xs font-semibold text-ink-soft">Hora<input type="time" className="field !mt-1" value={r.hora} onChange={e=>setR({...r,hora:e.target.value})}/></label>
          <label className="text-xs font-semibold text-ink-soft flex-1 min-w-[12rem]">Lugar (opcional)<input className="field !mt-1" value={r.lugar} placeholder="p. ej. aula de cada grupo" onChange={e=>setR({...r,lugar:e.target.value})}/></label>
          <button className="btn btn-dark" disabled={ocupado} onClick={guardar}><Ico n="check" s={16}/>Guardar</button>
        </div>
      </div>
      <details>
        <summary className="font-bold text-sm text-[#9a3412] cursor-pointer">Tutores de cada grupo ({lista?lista.tutorias.length:"…"})</summary>
        <p className="text-xs text-ink-soft mt-1 mb-2">Solo el tutor/a asignado ve el mosaico «Reunión con familias» y la presentación de su grupo.</p>
        {lista&&<div className="grid sm:grid-cols-2 gap-x-4 gap-y-1.5">{grupos.map(g=>(
          <div key={g}><label className="flex items-center gap-2 text-sm"><span className="w-20 font-bold text-ink flex-shrink-0">{g}</span>
            <select className="field !py-1.5 !min-h-[36px] text-sm" value={tut(g)} onChange={e=>asignar(g,e.target.value)}>
              <option value="">— sin tutor/a —</option>{profs.map(p=><option key={p} value={p}>{p}</option>)}
            </select></label>
            {(()=>{const t=lista.tutorias.find(x=>x.grupo===g);return t&&(t.delegado||t.subdelegado)?<div className="text-[11px] text-ink-soft font-medium pl-[5.5rem] mt-0.5">Delegado/a: <b className="text-ink">{t.delegado||"—"}</b> · Subdelegado/a: <b className="text-ink">{t.subdelegado||"—"}</b></div>:null;})()}
          </div>))}</div>}
      </details>
    </div>
  );
}

/* ── Actualizar horario (solo administración): subir el CSV completo y cargarlo en la base de datos ──
   1) se elige el fichero  2) el servidor lo comprueba y resume los cambios (sin aplicar nada)
   3) al confirmar, se guarda una copia del horario actual y se sustituye  4) se puede volver a una copia */
function PantallaCargaHorario({tile,onBack,onCambio}){
  const[estado,setEstado]=useState(null);const[err,setErr]=useState("");
  const[fichero,setFichero]=useState(null);const[previa,setPrevia]=useState(null);
  const[ocupado,setOcupado]=useState("");const[hecho,setHecho]=useState(null);const[arrastre,setArrastre]=useState(false);
  const ref=React.useRef(null);
  const cargarEstado=async()=>{try{setEstado(await pedir("GET","/horario/carga"));setErr("");}catch(e){setErr(e.message);}};
  useEffect(()=>{cargarEstado();},[]);
  const elegir=async file=>{
    if(!file)return;
    if(!/\.(csv|txt)$/i.test(file.name)){setErr("El fichero debe ser .csv (en Excel: Archivo → Guardar como → CSV).");return;}
    setErr("");setHecho(null);setPrevia(null);setFichero({nombre:file.name,texto:await file.text()});
  };
  useEffect(()=>{
    if(!fichero)return;
    let vivo=true;setOcupado("Comprobando el fichero…");
    pedir("POST","/horario/previa",{csv:fichero.texto}).then(d=>{if(vivo)setPrevia(d);}).catch(e=>{if(vivo)setErr(e.message);}).finally(()=>{if(vivo)setOcupado("");});
    return()=>{vivo=false;};
  },[fichero]);
  const terminar=(d,msg)=>{
    if(d.csv)aplicarHorario(d.csv);
    setHecho({...d,msg});setFichero(null);setPrevia(null);onCambio(msg);cargarEstado();
  };
  const aplicar=async()=>{
    if(!confirm("Se sustituirá el horario COMPLETO del centro por el de «"+fichero.nombre+"».\n\nAntes se guarda una copia del horario actual, por si hay que volver atrás. ¿Continuar?"))return;
    setOcupado("Actualizando la base de datos…");
    try{const d=await pedir("POST","/horario/importar",{csv:fichero.texto});terminar(d,"Horario actualizado: "+d.sesiones+" sesiones de "+d.profesores+" profesores");}
    catch(e){setErr(e.message);}finally{setOcupado("");}
  };
  const restaurar=async c=>{
    if(!confirm("¿Volver al horario guardado el "+c.fecha+" ("+c.sesiones+" sesiones)?\n\nEl horario actual también se guarda como copia antes."))return;
    setOcupado("Restaurando…");
    try{const d=await pedir("POST","/horario/restaurar",{copia:c.nombre});terminar(d,"Horario restaurado: "+d.sesiones+" sesiones");}
    catch(e){setErr(e.message);}finally{setOcupado("");}
  };
  const cancelar=()=>{setFichero(null);setPrevia(null);setErr("");};
  const Dif=({antes,despues})=>{const d=despues-antes;return <span className={"text-xs font-bold "+(d===0?"text-ink-soft":d>0?"text-[#15803d]":"text-[#be123c]")}>{d===0?"sin cambios":(d>0?"+":"")+d}</span>;};
  const Lista=({titulo,items,color})=>items.length?(
    <details className="mt-2"><summary className="text-sm font-semibold cursor-pointer" style={{color}}>{titulo} ({items.length})</summary>
      <ul className="mt-1 text-xs text-ink-soft font-medium columns-1 sm:columns-2">{items.map(n=><li key={n} className="py-0.5">{n}</li>)}</ul></details>):null;
  return(
    <Seccion tile={tile} onBack={onBack}>
      <div className="space-y-4">
        {/* horario actual */}
        <div className="card p-4 flex flex-wrap items-center gap-3 justify-between">
          <div>
            <div className="font-display font-bold text-ink">Horario actual</div>
            <div className="text-xs text-ink-soft font-medium">{estado?estado.sesiones+" sesiones · "+estado.profesores+" profesores · "+estado.grupos+" grupos · "+estado.aulas+" aulas":"Cargando…"}</div>
            {estado&&estado.ultima&&<div className="text-xs text-ink-soft font-medium">Última carga: {estado.ultima.fecha} · {estado.ultima.origen==="importacion-app"?"subida desde la app":estado.ultima.origen==="restauracion-app"?"restauración de copia":"carga automática del fichero"}</div>}
          </div>
          <button className="btn btn-ghost" onClick={descargarHorarioCSV}><Ico n="descargar" s={16}/>Descargar horario actual (Excel)</button>
        </div>

        {hecho&&<div className="card p-4 fade-in" style={{borderColor:"#86efac",background:"#f0fdf4"}}>
          <div className="flex items-center gap-2 font-bold text-sm text-[#15803d]"><Ico n="check" s={18}/>{hecho.msg}</div>
          <p className="text-xs text-ink-soft mt-1">{hecho.grupos} grupos · {hecho.aulas} aulas{hecho.descartadas?" · "+hecho.descartadas+" filas descartadas":""}. Los cambios ya se ven en Profesores, Grupos, Aulas y Guardias.{hecho.copia?" El horario anterior quedó guardado como copia (abajo).":""}</p>
        </div>}

        {err&&<div className="card p-4 text-sm font-semibold text-[#be123c]" role="alert">{err}</div>}

        {/* 1. fichero */}
        {!fichero&&<div className={"card p-6 text-center transition "+(arrastre?"ring-2 ring-[#15803d]":"")}
          onDragOver={e=>{e.preventDefault();setArrastre(true);}} onDragLeave={()=>setArrastre(false)}
          onDrop={e=>{e.preventDefault();setArrastre(false);elegir(e.dataTransfer.files&&e.dataTransfer.files[0]);}}>
          <div className="mx-auto w-14 h-14 rounded-2xl flex items-center justify-center text-white mb-3" style={{background:"linear-gradient(135deg,#15803d,#4ade80)"}}><Ico n="subir" s={28}/></div>
          <div className="font-display font-bold text-ink">Sube el nuevo horario (CSV)</div>
          <p className="text-xs text-ink-soft font-medium mt-1 max-w-md mx-auto">Arrastra aquí el fichero o elígelo. Antes de cambiar nada se comprueba y verás un resumen de los cambios para confirmarlos.</p>
          <button className="btn btn-dark mt-4" onClick={()=>ref.current&&ref.current.click()}><Ico n="subir" s={16}/>Elegir fichero CSV</button>
          <input ref={ref} type="file" accept=".csv,text/csv,.txt" className="hidden" onChange={e=>{const f=e.target.files&&e.target.files[0];e.target.value="";elegir(f);}}/>
          <details className="text-left mt-5 max-w-xl mx-auto"><summary className="text-xs font-semibold text-ink-soft cursor-pointer">Formato del fichero</summary>
            <div className="text-xs text-ink-soft font-medium mt-2 space-y-1">
              <p>Una fila por sesión, con 7 columnas: <b>Profesor/a</b> («Apellidos, Nombre») · <b>Día</b> (1 lunes … 5 viernes) · <b>Hora</b> (1-13, R1, R2 para recreos) · <b>Materia</b> · <b>Grupo</b> · <b>Aula</b> · <b>Tipo</b> (Docencia, Guardia de Aula, Guardia de Recreo, Tutoría…).</p>
              <p>Debe contener el horario <b>completo</b> de todo el profesorado. Lo más fácil: descarga el horario actual, modifícalo en Excel y guárdalo como CSV. Vale con comas o con punto y coma.</p>
            </div></details>
        </div>}

        {/* 2. comprobación */}
        {fichero&&<div className="card p-4 fade-in">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div className="font-display font-bold text-ink">Fichero: <span className="font-body">{fichero.nombre}</span></div>
            <button className="btn btn-ghost !min-h-[36px]" disabled={!!ocupado} onClick={cancelar}><Ico n="cerrar" s={15}/>Cancelar</button>
          </div>
          {ocupado&&<p className="text-sm text-ink-soft font-medium mt-3">{ocupado}</p>}
          {previa&&!previa.valido&&<div className="mt-3 p-3 rounded-xl text-sm font-semibold text-[#be123c]" style={{background:"#fff1f2"}}>No se puede cargar: {previa.error}</div>}
          {previa&&previa.valido&&<div className="mt-3">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[["Sesiones",previa.antes.sesiones,previa.sesiones],["Profesores",previa.antes.profesores,previa.profesores]].map(([l,a,b])=>(
                <div key={l} className="rounded-xl p-3" style={{background:"#F5F3EE"}}><div className="text-[11px] font-semibold text-ink-soft uppercase tracking-wide">{l}</div>
                  <div className="font-display font-bold text-xl text-ink">{b}</div><div className="text-xs text-ink-soft">antes {a} · <Dif antes={a} despues={b}/></div></div>))}
              <div className="rounded-xl p-3" style={{background:"#F5F3EE"}}><div className="text-[11px] font-semibold text-ink-soft uppercase tracking-wide">Grupos</div><div className="font-display font-bold text-xl text-ink">{previa.grupos}</div></div>
              <div className="rounded-xl p-3" style={{background:"#F5F3EE"}}><div className="text-[11px] font-semibold text-ink-soft uppercase tracking-wide">Aulas</div><div className="font-display font-bold text-xl text-ink">{previa.aulas}</div></div>
            </div>
            <Lista titulo="Profesores nuevos" items={previa.altas} color="#15803d"/>
            <Lista titulo="Profesores que dejan de aparecer" items={previa.bajas} color="#be123c"/>
            {previa.descartadas>0&&<details className="mt-2"><summary className="text-sm font-semibold cursor-pointer text-[#b45309]">Filas que se ignorarán ({previa.descartadas})</summary>
              <ul className="mt-1 text-xs text-ink-soft font-medium">{previa.ejemplosDescartadas.map(d=><li key={d.linea} className="py-0.5">Línea {d.linea}: {d.texto||"(vacía)"}</li>)}</ul>
              <p className="text-[11px] text-ink-soft mt-1">Revisa día (1-5) y hora (1-13, R1, R2) en esas filas.</p></details>}
            {previa.bajas.length>0&&<p className="text-xs font-semibold text-[#b45309] mt-3">Atención: los profesores que dejan de aparecer pierden su horario en la app (sus cuentas de acceso no se borran).</p>}
            <div className="flex flex-wrap gap-2 mt-4">
              <button className="btn btn-dark" disabled={!!ocupado} onClick={aplicar}><Ico n="check" s={16}/>Aplicar y actualizar la base de datos</button>
              <button className="btn btn-ghost" disabled={!!ocupado} onClick={cancelar}>Cancelar</button>
            </div>
          </div>}
        </div>}

        {/* copias */}
        {estado&&estado.copias.length>0&&<div className="card">
          <div className="p-4 pb-2"><div className="font-display font-bold text-ink">Copias anteriores</div>
            <div className="text-xs text-ink-soft font-medium">Se guarda una automáticamente antes de cada carga. Puedes volver a cualquiera.</div></div>
          <div className="divide-y divide-divider">{estado.copias.map(c=>(
            <div key={c.nombre} className="px-4 py-2.5 flex items-center gap-3 flex-wrap">
              <div className="flex-1 min-w-[10rem] text-sm"><b className="text-ink">{c.fecha}</b> <span className="text-xs text-ink-soft">· {c.sesiones} sesiones</span></div>
              <button className="btn btn-ghost !px-2.5 !py-1.5 !min-h-[36px] text-xs" disabled={!!ocupado} onClick={()=>restaurar(c)}><Ico n="reloj" s={15}/>Restaurar</button>
            </div>))}</div>
        </div>}
      </div>
    </Seccion>
  );
}

/* Perfiles que Jefatura puede asignar a una cuenta. «sinDatos»: no se le pide correo de Educarex, móvil ni años trabajados */
const PERFILES_CUENTA=[
  {k:"profesor",l:"Profesor/a",d:"Personal docente del centro: se le piden correo de Educarex, móvil y años trabajados (para sus DAP)",c:["#e0f2fe","#075985"]},
  {k:"no_docente",l:"Personal no docente",d:"Administración, conserjería, limpieza, educadores…",c:["#f1f5f9","#334155"],sinDatos:true},
  {k:"biblioteca",l:"Biblioteca",d:"Edita los cuadrantes de G.B. y MAY55",c:["#ccfbf1","#0f766e"]},
  {k:"tutor",l:"Tutor/a",d:"Elige su grupo o grupos de tutoría (se actualiza la lista de tutores)",c:["#dbeafe","#1e40af"]},
  {k:"jefe_estudios",l:"Jefe/a de Estudios",d:"Recibe los partes de disciplina de su etapa y ve su carpeta",c:["#ede9fe","#5b21b6"]},
  {k:"jefe_departamento",l:"Jefe/a de departamento",d:"Indica el departamento que dirige",c:["#fef3c7","#92400e"]},
  {k:"ccp",l:"Miembro de la CCP",d:"Recibe las convocatorias de la CCP sin ser jefe/a de departamento (p. ej. Rosa Sánchez)",c:["#ffedd5","#9a3412"]},
  {k:"consejo_escolar",l:"Consejo Escolar",d:"Representante del profesorado en el Consejo Escolar (se indica en su horario)",c:["#fee2e2","#991b1b"]},
  {k:"coordinador_proyectos",l:"Coordinador/a de proyectos",d:"Indica los proyectos que coordina",c:["#fce7f3","#9d174d"]},
  {k:"conserjeria",l:"Conserjería",d:"Cuenta del personal de conserjería",c:["#ecfccb","#3f6212"],sinDatos:true},
  {k:"administracion",l:"Administración · DAP",d:"Ve todas las solicitudes de DAP y recibe sus avisos",c:["#e0e7ff","#3730a3"],sinDatos:true},
  {k:"direccion",l:"Dirección · DAP",d:"Concede, deniega y revoca los DAP",c:["#cffafe","#0e7490"],sinDatos:true}];
const ETAPAS_JE=[["todas","Todas las etapas (Jefe/a de Estudios)"],["eso","ESO (adjunto/a)"],["bach","Bachillerato (adjunto/a)"],["fpd","FP · turno diurno (adjunto/a)"],["fp","FP · tarde y a distancia (adjunto/a)"]];
const sinDatosDocente=u=>(u.perfiles||[]).some(p=>PERFILES_CUENTA.some(x=>x.k===p&&x.sinDatos));
const etiquetaCuenta=u=>u.rol==="admin"?"administración":(u.perfiles||[]).includes("direccion")?"Dirección":(u.perfiles||[]).includes("administracion")?"Administración":(u.perfiles||[]).includes("conserjeria")?"Conserjería":(u.perfiles||[]).includes("no_docente")?"personal no docente":"profesorado";

/* ── Mapa de perfiles y permisos (solo administración) ──
   Para cada perfil: qué iconos de la portada ve y qué notificaciones recibe. Un usuario ve la unión de sus perfiles. */
const NOTIFS=[
  {k:"aus_grabar",l:"Ausencias notificadas pendientes de grabar (Jefatura)",i:"ausencia"},
  {k:"incidencias",l:"Incidencias en las aulas (Jefatura y Conserjería)",i:"aula"},
  {k:"ccp",l:"Convocatorias de la CCP y del Consejo Escolar",i:"grupos"},
  {k:"datos",l:"Completar mis datos (correo, móvil, años)",i:"lapiz"},
  {k:"disc_jefatura",l:"Conductas contrarias pendientes de recibir (solo Jefatura de Estudios de la etapa)",i:"disciplina",fija:1},
  {k:"disc_tutoria",l:"Conductas contrarias en su tutoría (solo el tutor/a del grupo)",i:"disciplina",fija:1},
  {k:"dap_resol",l:"Resoluciones de sus DAP",i:"dap"},
  {k:"dap_gestion",l:"Solicitudes y novedades de DAP (Dirección y Administración)",i:"dap"},
  {k:"justificar",l:"Ausencias pendientes de justificar",i:"informe"}];
function PantallaPermisos({tile,onBack,onToast}){
  const[d,setD]=useState(null);const[m,setM]=useState(null);const[err,setErr]=useState("");const[vista,setVista]=useState("perfil");
  const[abierto,setAbierto]=useState("profesor");const[ocupado,setOcupado]=useState(false);const[sucio,setSucio]=useState(false);
  useEffect(()=>{pedir("GET","/permisos").then(x=>{setD(x);setM(x.mapa);}).catch(e=>setErr(e.message));},[]);
  if(err)return <Seccion tile={tile} onBack={onBack}><div className="card p-5 text-sm font-semibold text-[#9f1239]">{err}</div></Seccion>;
  if(!d||!m)return <Seccion tile={tile} onBack={onBack}><div className="card p-5 text-sm text-ink-soft">Cargando…</div></Seccion>;
  const perfiles=PERFILES_CUENTA.concat((d.perfilesExtra||[]).map(x=>({k:x.k,l:x.l,d:x.d||"Perfil creado por Jefatura",c:[x.c+"22",x.c]}))).filter(p=>m[p.k]);
  const mosaicos=TILES.filter(t=>d.mosaicos.includes(t.id));
  const alt=(p,campo,v)=>{const l=m[p][campo];setM({...m,[p]:{...m[p],[campo]:l.includes(v)?l.filter(x=>x!==v):l.concat(v)}});setSucio(true);};
  const todos=(p,campo,on)=>{setM({...m,[p]:{...m[p],[campo]:on?(campo==="tiles"?d.mosaicos:NOTIFS.map(n=>n.k)).slice():[]}});setSucio(true);};
  const guardar=async(rest)=>{if(rest&&!confirm("¿Volver a los valores por defecto en todos los perfiles?"))return;setOcupado(true);
    try{const r=await pedir("PUT","/permisos",rest?{restablecer:true}:{mapa:Object.fromEntries(Object.entries(m).map(([k,v])=>[k,{tiles:v.tiles,avisos:v.avisos}]))});setM(r.mapa);setSucio(false);onToast(rest?"Valores por defecto restablecidos":"Mapa de perfiles guardado: se aplica al volver a entrar o recargar");}
    catch(e){onToast(e.message);}setOcupado(false);};
  const Chk=({on,onClick,c,label})=><button type="button" onClick={onClick} aria-pressed={on} aria-label={label} className="w-7 h-7 rounded-lg border-2 flex items-center justify-center mx-auto transition" style={on?{background:c,borderColor:c,color:"#fff"}:{borderColor:"#d6d0dc",background:"#fff"}}>{on&&<Ico n="check" s={15}/>}</button>;
  return(
    <Seccion tile={tile} onBack={onBack}>
      <div className="card p-4 mb-4 flex flex-wrap items-center gap-3">
        <p className="text-sm text-ink-soft flex-1 min-w-[16rem]">Elige, para cada perfil, los <b className="text-ink">iconos</b> que verá en la portada y las <b className="text-ink">notificaciones</b> que recibirá. Cada usuario ve la suma de sus perfiles; la cuenta de administración lo ve todo. Los permisos de cada módulo (quién concede DAP, quién recibe partes…) no cambian.</p>
        <div className="flex gap-1.5">{[["perfil","Por perfil"],["mapa","Mapa"]].map(([k,l])=><button key={k} className={"chip"+(vista===k?" on":"")} style={vista===k?{background:"#6d28d9"}:{}} onClick={()=>setVista(k)}>{l}</button>)}</div>
        <button className="btn btn-ghost !min-h-[38px] text-xs" disabled={ocupado} onClick={()=>guardar(true)}>Valores por defecto</button>
        <button className="btn btn-dark !min-h-[38px]" style={{background:"#6d28d9"}} disabled={ocupado||!sucio} onClick={()=>guardar(false)}>{sucio?"Guardar cambios":"Guardado"}</button>
      </div>
      {vista==="perfil"&&<div className="space-y-3">{perfiles.map(p=>{const on=abierto===p.k;const v=m[p.k];return(
        <div key={p.k} className="card overflow-hidden">
          <button className="w-full flex items-center gap-3 p-4 text-left" onClick={()=>setAbierto(on?"":p.k)} aria-expanded={on}>
            <span className="pill !text-sm" style={{background:p.c[0],color:p.c[1]}}>{p.l}</span>
            <span className="text-xs text-ink-soft flex-1">{d.recuento[p.k]||0} cuenta{(d.recuento[p.k]||0)===1?"":"s"} · {v.tiles.length} icono{v.tiles.length===1?"":"s"} · {v.avisos.length} notificacion{v.avisos.length===1?"":"es"}{v.propio?"":" · por defecto"}</span>
            <span className="hidden sm:flex -space-x-2">{mosaicos.filter(t=>v.tiles.includes(t.id)).slice(0,8).map(t=><span key={t.id} className="ring-2 ring-white rounded-lg"><TileIcon t={t} size={26}/></span>)}</span>
            <span className="text-ink-soft text-lg transition" style={{transform:on?"rotate(90deg)":"none"}}>›</span>
          </button>
          {on&&<div className="px-4 pb-4 fade-in">
            <p className="text-xs text-ink-soft mb-3">{p.d}</p>
            <div className="flex items-center justify-between mb-2"><div className="lbl !mb-0">Iconos de la portada</div>
              <div className="flex gap-2 text-[11px] font-semibold"><button className="underline" onClick={()=>todos(p.k,"tiles",true)}>Todos</button><button className="underline" onClick={()=>todos(p.k,"tiles",false)}>Ninguno</button></div></div>
            <div className="grid grid-cols-3 sm:grid-cols-5 lg:grid-cols-7 gap-2 mb-4">{mosaicos.map(t=>{const sel=v.tiles.includes(t.id);return(
              <button key={t.id} type="button" onClick={()=>alt(p.k,"tiles",t.id)} aria-pressed={sel} className="rounded-xl border-2 p-2 flex flex-col items-center gap-1.5 transition" style={sel?{borderColor:t.g[0],background:t.g[0]+"12"}:{borderColor:"#ece7f0",opacity:.45,filter:"grayscale(1)"}}>
                <TileIcon t={t} size={44}/><span className="text-[11px] font-bold text-ink text-center leading-tight">{t.l}</span>
                <span className="text-[10px] font-semibold" style={{color:sel?"#166534":"#94a3b8"}}>{sel?"✓ visible":"oculto"}</span></button>);})}</div>
            <div className="flex items-center justify-between mb-2"><div className="lbl !mb-0">Notificaciones en la portada</div>
              <div className="flex gap-2 text-[11px] font-semibold"><button className="underline" onClick={()=>todos(p.k,"avisos",true)}>Todas</button><button className="underline" onClick={()=>todos(p.k,"avisos",false)}>Ninguna</button></div></div>
            <div className="grid sm:grid-cols-2 gap-2">{NOTIFS.map(n=>{const sel=v.avisos.includes(n.k);return(
              <label key={n.k} className={"flex items-center gap-3 rounded-xl border px-3 py-2 text-sm "+(n.fija?"cursor-not-allowed opacity-80":"cursor-pointer")} title={n.fija?"Fija por protección de datos: no se puede cambiar":undefined} style={sel?{borderColor:"#c4b5fd",background:"#f5f3ff"}:{borderColor:"#ece7f0"}}>
                <input type="checkbox" className="w-4 h-4" style={{accentColor:"#6d28d9"}} checked={sel} disabled={!!n.fija} onChange={()=>alt(p.k,"avisos",n.k)}/>
                <Ico n={n.i} s={16}/><span className="flex-1">{n.l}</span>{n.fija&&<span className="text-[10px] font-bold uppercase text-ink-soft">Fija</span>}</label>);})}</div>
          </div>}
        </div>);})}</div>}
      {vista==="mapa"&&<div className="card p-3 overflow-auto">
        <table className="text-xs border-separate" style={{borderSpacing:"4px"}}>
          <thead><tr><th className="sticky left-0 bg-white z-[1]"></th>{perfiles.map(p=><th key={p.k} className="align-bottom pb-1"><div className="mx-auto font-bold leading-tight text-center rounded-lg px-1.5 py-1 w-[5.2rem]" style={{background:p.c[0],color:p.c[1]}}>{p.l}<div className="font-semibold opacity-75">{d.recuento[p.k]||0}</div></div></th>)}</tr></thead>
          <tbody>
            <tr><td colSpan={perfiles.length+1} className="pt-2 pb-1 lbl !mb-0">Iconos de la portada</td></tr>
            {mosaicos.map(t=><tr key={t.id}><td className="sticky left-0 bg-white z-[1] pr-2"><span className="flex items-center gap-2 whitespace-nowrap font-semibold text-ink"><TileIcon t={t} size={26}/>{t.l}</span></td>
              {perfiles.map(p=><td key={p.k} className="text-center"><Chk on={m[p.k].tiles.includes(t.id)} c={t.g[0]} label={t.l+" · "+p.l} onClick={()=>alt(p.k,"tiles",t.id)}/></td>)}</tr>)}
            <tr><td colSpan={perfiles.length+1} className="pt-4 pb-1 lbl !mb-0">Notificaciones</td></tr>
            {NOTIFS.map(n=><tr key={n.k}><td className="sticky left-0 bg-white z-[1] pr-2"><span className="flex items-center gap-2 font-semibold text-ink max-w-[16rem]"><Ico n={n.i} s={16}/>{n.l}</span></td>
              {perfiles.map(p=><td key={p.k} className="text-center"><Chk on={m[p.k].avisos.includes(n.k)} c="#6d28d9" label={n.l+" · "+p.l} onClick={()=>{if(!n.fija)alt(p.k,"avisos",n.k);}}/></td>)}</tr>)}
          </tbody></table>
      </div>}
    </Seccion>);
}

function PantallaUsuarios({tile,onBack,yo,profs,onToast}){
  const[lista,setLista]=useState(null);const[err,setErr]=useState("");
  const[q,setQ]=useState("");const[form,setForm]=useState(null);const[creds,setCreds]=useState(null);
  const[ocupado,setOcupado]=useState(false);const[renombrar,setRenombrar]=useState(null);
  const[bib,setBib]=useState(null);const[claveBib,setClaveBib]=useState(null);   /* perfil Biblioteca: estado de la clave y diálogo para cambiarla */
  const[dap,setDap]=useState({});   /* contador de días de asuntos propios por cuenta */
  const[datosU,setDatosU]=useState(null);const[vinc,setVinc]=useState(null);   /* el administrador edita datos y vincula horarios */
  const[deps,setDeps]=useState([]);const[perf,setPerf]=useState(null);   /* departamentos y diálogo de perfiles */
  const[grupos,setGrupos]=useState([]);const[extra,setExtra]=useState([]);const[gestPerf,setGestPerf]=useState(null);   /* grupos, perfiles creados por el administrador */
  const todosPerfiles=PERFILES_CUENTA.concat(extra.map(x=>({k:x.k,l:x.l,d:x.d||"Perfil creado por Jefatura",c:[x.c+"22",x.c],extra:true})));
  useEffect(()=>{pedir("GET","/dap/contadores").then(d=>setDap(d.contadores||{})).catch(()=>{});},[]);
  const cargar=async()=>{try{const d=await pedir("GET","/usuarios");setLista(d.usuarios);setDeps(d.departamentos||[]);setGrupos(d.grupos||[]);setExtra(d.perfilesExtra||[]);setErr("");}catch(e){setErr(e.message);}
    try{setBib(await pedir("GET","/biblioteca/clave"));}catch(e){}};
  useEffect(()=>{cargar();},[]);
  const conCuenta=new Set((lista||[]).map(u=>u.nombre));
  const sinCuenta=profs.filter(p=>!conCuenta.has(p));
  const qn=quitarTildes(q.trim());
  const vis=(lista||[]).filter(u=>!qn||quitarTildes(u.nombre+" "+u.usuario).indexOf(qn)>=0);
  const accion=async(fn,msg)=>{if(ocupado)return;setOcupado(true);try{const r=await fn();if(msg)onToast(msg);await cargar();return r;}catch(e){alert(e.message);}finally{setOcupado(false);}};
  const lote=async()=>{
    if(!sinCuenta.length)return;
    if(!confirm("Se crearán "+sinCuenta.length+" cuentas (una por cada profesor/a del horario sin cuenta) con contraseñas provisionales. ¿Continuar?"))return;
    const r=await accion(()=>pedir("POST","/usuarios/lote",{nombres:sinCuenta}),null);
    if(r){setCreds(r.creados);onToast(r.creados.length+" cuentas creadas");}
  };
  const restablecer=async u=>{
    if(!confirm("¿Restaurar el acceso de "+(u.nombre||u.usuario)+"? Se generará una contraseña provisional, se reactivará la cuenta si estaba desactivada, se quitará el bloqueo por intentos fallidos y se cerrarán sus sesiones abiertas."))return;
    const r=await accion(()=>pedir("POST","/usuarios/"+u.id+"/restablecer"),null);
    if(r)setCreds([{nombre:u.nombre,usuario:u.usuario,clave:r.clave}]);
  };
  const cambiar=(u,datos,msg)=>accion(()=>pedir("PUT","/usuarios/"+u.id,datos),msg);
  const borrar=u=>{if(confirm("¿Borrar la cuenta de "+(u.nombre||u.usuario)+"? Ya no podrá entrar en la app."))accion(()=>pedir("DELETE","/usuarios/"+u.id),"Cuenta borrada");};
  return(
    <Seccion tile={tile} onBack={onBack}>
      <div className="space-y-4">
        <div className="card p-4 flex flex-wrap items-center gap-3 justify-between no-print">
          <div>
            <div className="font-display font-bold text-ink">Cuentas de acceso a la app</div>
            <div className="text-xs text-ink-soft font-medium">{lista?lista.length+" cuentas · "+lista.filter(u=>u.activo).length+" activas":"Cargando…"}{sinCuenta.length>0&&lista?" · "+sinCuenta.length+" profesores del horario sin cuenta":""}</div>
          </div>
          <div className="flex flex-wrap gap-2">
            <button className="btn btn-ghost" onClick={()=>setForm({nombre:"",usuario:"",rol:"profesor",clave:""})}><Ico n="mas" s={16}/>Nueva cuenta</button>
            <button className="btn btn-ghost" onClick={()=>setGestPerf({nombre:"",descripcion:"",color:"#475569"})}><Ico n="escudo" s={16}/>Crear perfiles</button>
            <button className="btn btn-dark" disabled={!sinCuenta.length||ocupado} onClick={lote}><Ico n="grupos" s={16}/>Crear cuentas del profesorado ({sinCuenta.length})</button>
          </div>
        </div>
        {err&&<div className="card p-4 text-sm font-semibold text-[#be123c]">{err}</div>}
        {bib&&(
          <div className="card p-4 flex flex-wrap items-center gap-3 justify-between no-print" style={{borderLeft:"4px solid #0d9488"}}>
            <div className="flex-1 min-w-[16rem]">
              <div className="font-display font-bold text-ink flex items-center gap-2"><Ico n="libro" s={18}/>Perfil Biblioteca</div>
              <div className="text-xs text-ink-soft font-medium mt-0.5">Las cuentas con este perfil pueden editar G.B. y MAY55 en Biblioteca escribiendo la clave de la biblioteca. Asígnalo con el botón «Perfiles» de cada cuenta.</div>
              <div className="text-xs font-semibold mt-1.5 flex flex-wrap gap-x-3">
                <span className={bib.definida?"text-olive":"text-[#b45309]"}>{bib.definida?"✓ Clave de la biblioteca fijada":"Aún no hay clave de la biblioteca"}</span>{bib.debil&&<span className="block font-bold text-[#be123c]">⚠ La clave actual es débil: cámbiala por una de 8 caracteres o más.</span>}
                <span className="text-ink-soft">{bib.gestores.length?bib.gestores.length+" con el perfil: "+bib.gestores.map(g=>g.nombre||g.usuario).join(" · "):"Nadie tiene el perfil todavía"}</span>
              </div>
            </div>
            <button className="btn btn-dark" onClick={()=>setClaveBib({nueva:"",rep:"",err:""})}><Ico n="llave" s={16}/>{bib.definida?"Cambiar clave de la biblioteca":"Fijar clave de la biblioteca"}</button>
          </div>
        )}
        <div className="relative no-print">
          <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-soft"><Ico n="buscar" s={18}/></span>
          <input className="field !pl-11" value={q} onChange={e=>setQ(e.target.value)} placeholder="Buscar por nombre o usuario…" aria-label="Buscar cuenta"/>
        </div>
        {lista&&(
          <div className="card divide-y divide-divider">
            {vis.length===0&&<p className="p-4 text-sm text-ink-soft">No hay cuentas{qn?" con ese nombre":""}.</p>}
            {vis.map(u=>(
              <div key={u.id} className={"p-3 sm:p-4 flex items-center gap-3 flex-wrap"+(u.activo?"":" opacity-60")}>
                <div className="flex-1 min-w-[12rem]">
                  <div className="text-sm font-bold text-ink">{u.nombre||"—"} {u.id===yo.id&&<span className="text-[11px] font-semibold text-ink-soft">(tú)</span>}</div>
                  <div className="text-xs text-ink-soft font-medium flex flex-wrap gap-x-2">
                    <span>usuario <b className="text-ink">{u.usuario}</b></span>
                    <span>{u.ultimoAcceso?"último acceso "+u.ultimoAcceso:"nunca ha entrado"}</span>
                    {u.cambiarClave&&<span className="text-[#b45309] font-semibold">contraseña provisional</span>}
                    {u.rol!=="admin"&&!u.profesor&&!sinDatosDocente(u)&&<span className="text-[#be123c] font-semibold">sin vincular al horario: no podrá notificar ausencias</span>}
                  </div>
                  {u.profesorHorario&&u.profesorHorario!==u.nombre&&<div className="text-xs font-semibold mt-0.5" style={{color:"#4338ca"}}>Horario vinculado: {u.profesorHorario}</div>}
                  {!sinDatosDocente(u)&&(u.email||u.movil||u.aniosServicio!=null
                    ?<div className="text-xs text-ink-soft font-medium flex flex-wrap gap-x-3 mt-0.5">
                      <span>✉ {u.email||"—"}</span><span>📱 {u.movil||"—"}</span><span><b className="text-ink">{u.aniosServicio??"—"}</b> años trabajados</span>{u.datosFecha&&<span className="opacity-70">(al {u.datosFecha})</span>}
                      {dap[u.id]&&dap[u.id].derecho!=null&&<span className="font-semibold" style={{color:dap[u.id].restantes>0?"#0f766e":"#be123c"}}>DAP {dap[u.id].usados}/{dap[u.id].derecho} · quedan {dap[u.id].restantes}</span>}</div>
                    :<div className="text-[11px] font-semibold text-[#b45309] mt-0.5">Datos de contacto pendientes: se le pedirán al entrar</div>)}
                </div>
                {u.rol==="admin"&&<span className="pill MAY">Administrador/a de la app</span>}
                {todosPerfiles.filter(x=>(u.perfiles||[]).includes(x.k)).map(x=><span key={x.k} className="pill" style={{background:x.c[0],color:x.c[1]}} title={x.k==="jefe_departamento"?u.departamentoJefe:x.k==="coordinador_proyectos"?u.proyectos:x.d}>{x.k==="tutor"?"Tutor/a"+((u.tutorDe||[]).length?" · "+u.tutorDe.join(", "):""):x.k==="jefe_estudios"?"Jefe/a de Estudios"+(u.jefeEstudios&&u.jefeEstudios!=="todas"?" · "+((ETAPAS_JE.find(e=>e[0]===u.jefeEstudios)||[,""])[1].replace(" (adjunto/a)","")):""):x.k==="jefe_departamento"?"Jefe/a dpto."+(u.departamentoJefe?" · "+u.departamentoJefe:""):x.k==="coordinador_proyectos"?"Coord. proyectos"+(u.proyectos?" · "+(u.proyectos.length>28?u.proyectos.slice(0,28)+"…":u.proyectos):""):x.l}</span>)}
                {!u.activo&&<span className="pill" style={{background:"#f1f0ec",color:"#4b4a44"}}>Desactivada</span>}
                <div className="flex flex-wrap items-center gap-1 max-w-full">
                  <button className="btn btn-ghost !px-2.5 !py-1.5 !min-h-[36px] text-xs" disabled={ocupado} onClick={()=>setRenombrar({u,nombre:u.nombre})} title="Nombre como aparece en el horario"><Ico n="lapiz" s={15}/>Nombre</button>
                  <button className="btn btn-ghost !px-2.5 !py-1.5 !min-h-[36px] text-xs" disabled={ocupado} onClick={()=>restablecer(u)} title="Contraseña provisional nueva, cuenta activa y sin bloqueo"><Ico n="llave" s={15}/>Restaurar acceso</button>
                  <button className="btn btn-ghost !px-2.5 !py-1.5 !min-h-[36px] text-xs" disabled={ocupado} onClick={()=>setDatosU({u,email:u.email||"",movil:u.movil||"",anios:u.aniosServicio??""})} title="Correo de Educarex, móvil y años trabajados"><Ico n="lapiz" s={15}/>Datos</button>
                  <button className="btn btn-ghost !px-2.5 !py-1.5 !min-h-[36px] text-xs" disabled={ocupado} style={u.rol!=="admin"&&!u.profesor&&!sinDatosDocente(u)?{borderColor:"#be123c",color:"#be123c"}:{}} onClick={()=>setVinc({u,horario:u.profesorHorario||""})} title="Vincular la cuenta a un horario"><Ico n="calendario" s={15}/>Horario</button>
                  <button className="btn btn-ghost !px-2.5 !py-1.5 !min-h-[36px] text-xs" disabled={ocupado} onClick={()=>setPerf({u,perfiles:(u.perfiles||[]).slice(),departamentoJefe:u.departamentoJefe||"",proyectos:u.proyectos||"",jefeEstudios:u.jefeEstudios||"",tutorGrupos:(u.tutorDe||[]).slice()})} title="Biblioteca, jefe/a de departamento, coordinador/a de proyectos, conserjería…"><Ico n="escudo" s={15}/>Perfiles</button>
                  {u.id!==yo.id&&<>
                    <button className="btn btn-ghost !px-2.5 !py-1.5 !min-h-[36px] text-xs" disabled={ocupado} onClick={()=>cambiar(u,{activo:!u.activo},u.activo?"Cuenta desactivada":"Cuenta activada")}>{u.activo?"Desactivar":"Activar"}</button>
                    <button className="btn btn-ghost !px-2.5 !py-1.5 !min-h-[36px] text-xs" disabled={ocupado} onClick={()=>cambiar(u,{rol:u.rol==="admin"?"profesor":"admin"},"Rol cambiado")}>{u.rol==="admin"?"Quitar admin.":"Hacer admin."}</button>
                    <button className="p-2 rounded-lg hover:bg-rose-50 text-[#be123c]" disabled={ocupado} aria-label={"Borrar cuenta de "+u.usuario} onClick={()=>borrar(u)}><Ico n="papelera" s={17}/></button>
                  </>}
                </div>
              </div>
            ))}
          </div>
        )}
        <p className="text-xs text-ink-soft font-medium no-print">Las contraseñas provisionales solo se muestran una vez: imprímelas o descárgalas al crearlas. Al entrar, cada profesor/a elige la suya. Si alguien la olvida o no puede entrar, «Restaurar acceso» le da una nueva, reactiva la cuenta y quita el bloqueo.</p>
      </div>

      {form&&(
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 no-print" onClick={()=>setForm(null)}>
          <form className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6 fade-in space-y-3" onClick={e=>e.stopPropagation()} onSubmit={async e=>{
            e.preventDefault();if(!form.nombre.trim())return;
            const r=await accion(()=>pedir("POST","/usuarios",{nombre:form.nombre,usuario:form.usuario,rol:form.rol,clave:form.clave}),"Cuenta creada");
            if(r){setForm(null);setCreds([{nombre:r.nombre,usuario:r.usuario,clave:r.clave}]);}
          }}>
            <h2 className="font-display font-bold text-lg text-ink">Nueva cuenta</h2>
            <div><label className="lbl" htmlFor="nu-n">Nombre (Apellidos, Nombre)</label>
              <input id="nu-n" className="field" list="nu-profs" value={form.nombre} onChange={e=>setForm({...form,nombre:e.target.value})} autoFocus/>
              <datalist id="nu-profs">{sinCuenta.map(p=><option key={p} value={p}/>)}</datalist></div>
            <div><label className="lbl" htmlFor="nu-u">Usuario (vacío = se propone solo)</label>
              <input id="nu-u" className="field" autoCapitalize="none" value={form.usuario} onChange={e=>setForm({...form,usuario:e.target.value})} placeholder="p. ej. mamor"/></div>
            <div><label className="lbl" htmlFor="nu-c">Contraseña provisional (vacío = se genera)</label>
              <input id="nu-c" className="field" value={form.clave} onChange={e=>setForm({...form,clave:e.target.value})}/></div>
            <div className="flex gap-2">
              {["profesor","admin"].map(r=><button type="button" key={r} className={"bb-seg "+(r==="admin"?"MAY":"GB")+(form.rol===r?" on":"")} onClick={()=>setForm({...form,rol:r})}>{r==="admin"?"Administración":"Profesorado"}</button>)}
            </div>
            <div className="flex gap-2 pt-1"><button type="button" className="btn btn-ghost flex-1" onClick={()=>setForm(null)}>Cancelar</button><button className="btn btn-dark flex-1" disabled={ocupado}>Crear</button></div>
          </form>
        </div>
      )}

      {gestPerf&&(
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 no-print" onClick={()=>setGestPerf(null)}>
          <form className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 fade-in space-y-3 max-h-[92vh] overflow-auto" onClick={e=>e.stopPropagation()} onSubmit={async e=>{
            e.preventDefault();
            try{const r=await pedir("POST","/perfiles",{k:gestPerf.k,nombre:gestPerf.nombre,descripcion:gestPerf.descripcion,color:gestPerf.color});setExtra(r.perfilesExtra);onToast(gestPerf.k?"Perfil modificado":"Perfil creado: ya se puede asignar con «Perfiles»");setGestPerf({nombre:"",descripcion:"",color:"#475569"});}
            catch(x){alert(x.message);}
          }}>
            <h2 className="font-display font-bold text-lg text-ink">Perfiles del centro</h2>
            <p className="text-xs text-ink-soft">Además de los perfiles de la app (Profesor/a, Personal no docente, Tutor/a, Jefe/a de Estudios, Jefe/a de departamento, Coordinador/a de proyectos, Biblioteca, Conserjería, Administración y Dirección) puedes crear otros, p. ej. «Coordinador/a TIC», «Orientación» o «Responsable de convivencia». Se asignan a cada cuenta con el botón «Perfiles».</p>
            {extra.length>0&&<ul className="divide-y divide-divider rounded-xl border border-divider">{extra.map(x=><li key={x.k} className="p-2.5 flex items-center gap-2 text-sm">
              <span className="pill" style={{background:x.c+"22",color:x.c}}>{x.l}</span><span className="flex-1 text-xs text-ink-soft truncate">{x.d}</span>
              <button type="button" className="text-xs font-semibold underline" onClick={()=>setGestPerf({k:x.k,nombre:x.l,descripcion:x.d,color:x.c})}>Editar</button>
              <button type="button" className="p-1.5 rounded-lg hover:bg-rose-50 text-[#be123c]" aria-label={"Borrar el perfil "+x.l} onClick={async()=>{if(!confirm("¿Borrar el perfil «"+x.l+"»? Se quitará de todas las cuentas que lo tengan."))return;try{const r=await pedir("DELETE","/perfiles/"+encodeURIComponent(x.k));setExtra(r.perfilesExtra);cargar();onToast("Perfil borrado");}catch(e){alert(e.message);}}}><Ico n="papelera" s={15}/></button></li>)}</ul>}
            <div className="rounded-xl bg-paper-warm p-3 space-y-2">
              <div className="text-xs font-bold text-ink">{gestPerf.k?"Modificar «"+gestPerf.nombre+"»":"Nuevo perfil"}</div>
              <input className="field !min-h-[38px] text-sm" maxLength={40} placeholder="Nombre del perfil (p. ej. Coordinador/a TIC)" value={gestPerf.nombre} onChange={e=>setGestPerf({...gestPerf,nombre:e.target.value})} aria-label="Nombre del perfil"/>
              <input className="field !min-h-[38px] text-sm" maxLength={160} placeholder="Descripción (opcional)" value={gestPerf.descripcion} onChange={e=>setGestPerf({...gestPerf,descripcion:e.target.value})} aria-label="Descripción del perfil"/>
              <div className="flex items-center gap-2 flex-wrap"><span className="text-xs font-semibold text-ink-soft">Color</span>{["#475569","#0f766e","#1d4ed8","#7c3aed","#be185d","#b45309","#15803d","#b91c1c"].map(c=><button type="button" key={c} aria-label={"Color "+c} className="w-7 h-7 rounded-full border-2" style={{background:c,borderColor:gestPerf.color===c?"#111":"#fff",boxShadow:"0 0 0 1px #e5e7eb"}} onClick={()=>setGestPerf({...gestPerf,color:c})}/>)}</div>
            </div>
            <div className="flex gap-2 pt-1"><button type="button" className="btn btn-ghost flex-1" onClick={()=>setGestPerf(null)}>Cerrar</button><button className="btn btn-dark flex-1" disabled={gestPerf.nombre.trim().length<3}>{gestPerf.k?"Guardar cambios":"Crear perfil"}</button></div>
          </form>
        </div>
      )}

      {perf&&(
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 no-print" onClick={()=>setPerf(null)}>
          <form className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 fade-in space-y-3 max-h-[92vh] overflow-auto" onClick={e=>e.stopPropagation()} onSubmit={async e=>{
            e.preventDefault();
            if(perf.perfiles.includes("profesor")&&perf.perfiles.includes("no_docente"))return alert("Marca «Profesor/a» o «Personal no docente», no los dos");
            if(perf.perfiles.includes("jefe_departamento")&&!perf.departamentoJefe)return alert("Elige el departamento que dirige");
            if(perf.perfiles.includes("tutor")&&!perf.tutorGrupos.length)return alert("Elige el grupo o grupos de tutoría");
            if(perf.perfiles.includes("jefe_estudios")&&!perf.jefeEstudios)return alert("Elige la etapa que lleva el Jefe/a de Estudios");
            const r=await cambiar(perf.u,{perfiles:perf.perfiles,departamentoJefe:perf.departamentoJefe,proyectos:perf.proyectos,jefeEstudios:perf.jefeEstudios,tutorGrupos:perf.tutorGrupos},"Perfiles guardados");if(r!==undefined)setPerf(null);
          }}>
            <h2 className="font-display font-bold text-lg text-ink">Perfiles de {perf.u.nombre||perf.u.usuario}</h2>
            <div className="space-y-2">{todosPerfiles.map(x=>{const on=perf.perfiles.includes(x.k);const alt=()=>{const otro=x.k==="profesor"?"no_docente":x.k==="no_docente"?"profesor":"";setPerf({...perf,perfiles:on?perf.perfiles.filter(p=>p!==x.k):perf.perfiles.filter(p=>p!==otro).concat(x.k)});};return(
              <div key={x.k} className="rounded-xl border p-3" style={on?{borderColor:x.c[1],background:x.c[0]+"80"}:{borderColor:"#e7e1ec"}}>
                <label className="flex items-start gap-3 cursor-pointer"><input type="checkbox" className="mt-1" checked={on} onChange={alt}/>
                  <span className="flex-1"><b className="text-sm text-ink">{x.l}</b><span className="block text-[11px] text-ink-soft">{x.d}{x.sinDatos?" · no se le piden correo, móvil ni años trabajados":""}</span></span></label>
                {on&&x.k==="jefe_departamento"&&<select className="field !min-h-[38px] mt-2 text-sm" value={perf.departamentoJefe} onChange={e=>setPerf({...perf,departamentoJefe:e.target.value})} aria-label="Departamento que dirige">
                  <option value="">— Departamento —</option>{deps.map(d=><option key={d}>{d}</option>)}</select>}
                {on&&x.k==="tutor"&&<div className="mt-2"><div className="flex flex-wrap gap-1.5 max-h-40 overflow-auto">{grupos.map(g=>{const t=perf.tutorGrupos.includes(g);return <button type="button" key={g} className={"chip !px-2.5 !py-1 text-xs"+(t?" on":"")} style={t?{background:x.c[1]}:{}} onClick={()=>setPerf({...perf,tutorGrupos:t?perf.tutorGrupos.filter(y=>y!==g):perf.tutorGrupos.concat(g)})}>{g}</button>;})}</div>
                  <p className="text-[11px] text-ink-soft mt-1">Si el grupo ya tenía otro tutor/a, se sustituye.</p></div>}
                {on&&x.k==="jefe_estudios"&&<select className="field !min-h-[38px] mt-2 text-sm" value={perf.jefeEstudios} onChange={e=>setPerf({...perf,jefeEstudios:e.target.value})} aria-label="Etapa que lleva">
                  <option value="">— Etapa —</option>{ETAPAS_JE.map(([k,l])=><option key={k} value={k}>{l}</option>)}</select>}
                {on&&x.k==="coordinador_proyectos"&&<input className="field !min-h-[38px] mt-2 text-sm" maxLength={300} value={perf.proyectos} onChange={e=>setPerf({...perf,proyectos:e.target.value})} placeholder="Proyectos que coordina (p. ej. Erasmus+, Bilingüe, Plan de Lectura)" aria-label="Proyectos que coordina"/>}
              </div>);})}</div>
            <div className="flex gap-2 pt-1"><button type="button" className="btn btn-ghost flex-1" onClick={()=>setPerf(null)}>Cancelar</button><button className="btn btn-dark flex-1" disabled={ocupado}>Guardar</button></div>
          </form>
        </div>
      )}

      {claveBib&&(
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 no-print" onClick={()=>setClaveBib(null)}>
          <form className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6 fade-in space-y-3" onClick={e=>e.stopPropagation()} onSubmit={async e=>{
            e.preventDefault();
            if(claveBib.nueva!==claveBib.rep)return setClaveBib({...claveBib,err:"Las dos claves no coinciden"});
            try{await pedir("PUT","/biblioteca/clave",{nueva:claveBib.nueva});setClaveBib(null);onToast("Clave de la biblioteca guardada");cargar();}
            catch(x){setClaveBib({...claveBib,err:x.message});}
          }}>
            <h2 className="font-display font-bold text-lg text-ink">Clave de la biblioteca</h2>
            <p className="text-xs text-ink-soft font-medium">La usarán las cuentas con perfil Biblioteca para editar G.B. y MAY55. Mínimo 4 caracteres. Comunícasela tú: la app no la muestra después.</p>
            <div><label className="lbl" htmlFor="cb-1">Clave nueva</label><input id="cb-1" type="password" className="field" autoComplete="new-password" value={claveBib.nueva} onChange={e=>setClaveBib({...claveBib,nueva:e.target.value,err:""})} autoFocus/></div>
            <div><label className="lbl" htmlFor="cb-2">Repite la clave</label><input id="cb-2" type="password" className="field" autoComplete="new-password" value={claveBib.rep} onChange={e=>setClaveBib({...claveBib,rep:e.target.value,err:""})}/></div>
            {claveBib.err&&<p className="text-xs font-semibold text-[#be123c]">{claveBib.err}</p>}
            <div className="flex gap-2 pt-1"><button type="button" className="btn btn-ghost flex-1" onClick={()=>setClaveBib(null)}>Cancelar</button><button className="btn btn-dark flex-1" disabled={!claveBib.nueva}>Guardar</button></div>
          </form>
        </div>
      )}

      {datosU&&(
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 no-print" onClick={()=>setDatosU(null)}>
          <form className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6 fade-in space-y-3" onClick={e=>e.stopPropagation()} onSubmit={async e=>{
            e.preventDefault();
            const r=await accion(()=>pedir("PUT","/usuarios/"+datosU.u.id+"/datos",{email:datosU.email,movil:datosU.movil,anios:datosU.anios}),"Datos de "+(datosU.u.nombre||datosU.u.usuario)+" guardados");
            if(r)setDatosU(null);
          }}>
            <h2 className="font-display font-bold text-lg text-ink">Datos de {datosU.u.nombre||datosU.u.usuario}</h2>
            <p className="text-xs text-ink-soft">Como administrador puedes completarlos o corregirlos. Lo que se deje en blanco queda pendiente.</p>
            <div><label className="lbl" htmlFor="ad-e">Correo de Educarex</label><input id="ad-e" className="field" type="email" placeholder="nombre@educarex.es" value={datosU.email} onChange={e=>setDatosU({...datosU,email:e.target.value})}/></div>
            <div><label className="lbl" htmlFor="ad-m">Móvil</label><input id="ad-m" className="field" type="tel" placeholder="600 000 000" value={datosU.movil} onChange={e=>setDatosU({...datosU,movil:e.target.value})}/></div>
            <div><label className="lbl" htmlFor="ad-a">Años trabajados</label><input id="ad-a" className="field" type="number" min="0" max="50" value={datosU.anios} onChange={e=>setDatosU({...datosU,anios:e.target.value})}/></div>
            <div className="flex gap-2 pt-1"><button type="button" className="btn btn-ghost flex-1" onClick={()=>setDatosU(null)}>Cancelar</button><button className="btn btn-dark flex-1" disabled={ocupado}>Guardar</button></div>
          </form>
        </div>
      )}
      {vinc&&(
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 no-print" onClick={()=>setVinc(null)}>
          <form className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 fade-in space-y-3" onClick={e=>e.stopPropagation()} onSubmit={async e=>{
            e.preventDefault();
            const r=await cambiar(vinc.u,{profesorHorario:vinc.horario},vinc.horario?"Horario vinculado: "+vinc.horario:"Vínculo quitado: se usa el nombre de la cuenta");
            if(r!==undefined)setVinc(null);
          }}>
            <h2 className="font-display font-bold text-lg text-ink">Horario de {vinc.u.nombre||vinc.u.usuario}</h2>
            <p className="text-xs text-ink-soft">Para profesorado nuevo o sustituto cuyo nombre no coincide con el del horario: elige el horario que ocupa. Con ese horario notificará ausencias, firmará guardias, verá su DAP, etc.</p>
            <select className="field" value={vinc.horario} onChange={e=>setVinc({...vinc,horario:e.target.value})} aria-label="Horario">
              <option value="">— Sin vincular (según el nombre de la cuenta{vinc.u.profesor&&!vinc.u.profesorHorario?": "+vinc.u.profesor:""}) —</option>
              {profs.map(p=><option key={p} value={p}>{p}{(lista||[]).some(x=>x.id!==vinc.u.id&&(x.profesorHorario===p||(!x.profesorHorario&&x.profesor===p)))?" · ya tiene cuenta":""}</option>)}
            </select>
            <div className="flex gap-2 pt-1"><button type="button" className="btn btn-ghost flex-1" onClick={()=>setVinc(null)}>Cancelar</button><button className="btn btn-dark flex-1" disabled={ocupado}>Guardar</button></div>
          </form>
        </div>
      )}
      {renombrar&&(
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 no-print" onClick={()=>setRenombrar(null)}>
          <form className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6 fade-in space-y-3" onClick={e=>e.stopPropagation()} onSubmit={async e=>{
            e.preventDefault();if(!renombrar.nombre.trim())return;
            const r=await cambiar(renombrar.u,{nombre:renombrar.nombre.trim()},"Nombre actualizado");if(r!==undefined)setRenombrar(null);
          }}>
            <h2 className="font-display font-bold text-lg text-ink">Nombre de la cuenta «{renombrar.u.usuario}»</h2>
            <p className="text-xs text-ink-soft font-medium">Debe coincidir con el del horario (Apellidos, Nombre) para que pueda notificar sus ausencias.</p>
            <input className="field" list="ren-profs" value={renombrar.nombre} onChange={e=>setRenombrar({...renombrar,nombre:e.target.value})} autoFocus/>
            <datalist id="ren-profs">{profs.map(p=><option key={p} value={p}/>)}</datalist>
            {renombrar.nombre.trim()&&<p className={"text-xs font-semibold "+(profs.some(p=>quitarTildes(p)===quitarTildes(renombrar.nombre.trim()))?"text-olive":"text-[#b45309]")}>{profs.some(p=>quitarTildes(p)===quitarTildes(renombrar.nombre.trim()))?"✓ Coincide con el horario":"No coincide con ningún nombre del horario"}</p>}
            <div className="flex gap-2 pt-1"><button type="button" className="btn btn-ghost flex-1" onClick={()=>setRenombrar(null)}>Cancelar</button><button className="btn btn-dark flex-1" disabled={ocupado}>Guardar</button></div>
          </form>
        </div>
      )}

      {creds&&(
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 no-print">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg p-6 fade-in">
            <h2 className="font-display font-bold text-lg text-ink mb-1">{creds.length===1?"Contraseña provisional":creds.length+" cuentas creadas"}</h2>
            <p className="text-xs text-ink-soft font-medium mb-3">Apúntalas ahora: no se volverán a mostrar. Al entrar se pedirá cambiarlas.</p>
            <div className="max-h-[50vh] overflow-y-auto border border-divider rounded-xl divide-y divide-divider">
              {creds.length===0&&<p className="p-3 text-sm text-ink-soft">No había profesores sin cuenta.</p>}
              {creds.map(c=>(
                <div key={c.usuario} className="px-3 py-2 grid grid-cols-[1fr_auto_auto] gap-3 items-center text-sm">
                  <span className="truncate">{c.nombre}</span><b className="font-mono">{c.usuario}</b><b className="font-mono bg-paper-warm rounded px-2">{c.clave}</b>
                </div>
              ))}
            </div>
            <div className="flex flex-wrap gap-2 mt-4">
              <button className="btn btn-ghost" disabled={!creds.length} onClick={()=>abrirCredenciales(creds)}><Ico n="imprimir" s={16}/>Imprimir</button>
              <button className="btn btn-ghost" disabled={!creds.length} onClick={()=>descargarCredenciales(creds)}><Ico n="descargar" s={16}/>Descargar (Excel/CSV)</button>
              <button className="btn btn-dark ml-auto" onClick={()=>setCreds(null)}>Hecho</button>
            </div>
          </div>
        </div>
      )}
    </Seccion>
  );
}

/* ============================================================
   APP
   ============================================================ */
function App({usuario}){
  const esAdminCuenta=!!usuario&&usuario.rol==="admin";
  /* «Reunión con familias» solo se ve (profesorado) desde 14 días antes de una reunión con familias de la Cronología
     hasta el último día de la reunión; el día siguiente desaparece (p. ej. reuniones del 20 y 21 de octubre → hasta el 21) */
  const[reunionesFam,setReunionesFam]=useState(null);
  useEffect(()=>{pedir("GET","/cronologia").then(d=>setReunionesFam((d.eventos||[]).filter(e=>e.subtipo==="reunion"))).catch(()=>setReunionesFam(null));},[]);
  const familiasVisible=useMemo(()=>{
    const hoy=hoyISO();
    const lista=reunionesFam&&reunionesFam.length?reunionesFam:[{inicio:"2026-10-20",fin:"2026-10-21"}];
    return lista.some(e=>{const fin=e.fin||e.inicio;const desde=sumarDias(e.inicio,-14);return hoy>=desde&&hoy<=fin;});
  },[reunionesFam]);
  const[cuenta,setCuenta]=useState(false);
  const leerRuta=()=>decodeURIComponent((location.hash||"").slice(1));
  const[ruta,setRuta]=useState(leerRuta);
  const[admin,setAdmin]=useState(false);
  const[clave,setClave]=useState("");           /* solo en memoria, nunca se guarda: pase personal del modo administrador */
  const paseRef=useRef("");
  /* protección de datos: se borran los motivos que versiones anteriores guardaron en este navegador */
  useEffect(()=>{try{const l=LS.get("vj_hor_ausencias",[]);if(l.some(x=>x&&(x.motivo||x.obs)))LS.set("vj_hor_ausencias",l.map(({motivo,obs,...r})=>r));}catch(e){}},[]);
  /* equipo compartido: la sesión se cierra tras 20 minutos sin actividad */
  useEffect(()=>{
    if(!usuario||!usuario.compartido)return;
    let t;const rearmar=()=>{clearTimeout(t);t=setTimeout(()=>{cerrarSesion();},20*60*1000);};
    const ev=["pointerdown","keydown","scroll","touchstart"];ev.forEach(e=>addEventListener(e,rearmar,{passive:true}));rearmar();
    return()=>{clearTimeout(t);ev.forEach(e=>removeEventListener(e,rearmar));};
  },[usuario&&usuario.compartido]);
  const[login,setLogin]=useState(false);
  const[remoto,setRemoto]=useState(()=>({...REMOTO_VACIO,...LS.get("vj_hor_remoto",{})}));
  const[estado,setEstado]=useState(SERVICIO_URL?"cargando":"local");
  const[toast,setToast]=useState("");
  const[verHor,setVerHor]=useState(0);
  const[modoGuardias,setModoGuardias]=useState("aula");
  const[modoAusencias,setModoAusencias]=useState("notificar");   /* Ausencias: «notificar» o «justificar» */
  const[tutorial,setTutorial]=useState(false);
  const[misDatos,setMisDatos]=useState(null);   /* datos de contacto guardados en esta sesión (correo, móvil, años) */
  const faltanDatos=((misDatos&&misDatos.datosFaltan)||(usuario&&usuario.datosFaltan)||[]);
  const[dapAv,setDapAv]=useState(null);         /* DAP: resoluciones sin ver, pendientes (Dirección), novedades (Administración) */
  const[disc,setDisc]=useState(null);           /* partes de disciplina: pendientes (Jefes adjuntos) y recibidos sin ver */
  const[justif,setJustif]=useState(null);       /* resumen de justificaciones del docente (alerta y pendientes) */
  const[avisoJ,setAvisoJ]=useState(false);   /* Guardias: «aula» o «recreo» */
  const[modoAulas,setModoAulas]=useState("horario");   /* Aulas: «horario» o «reservas» */   /* sube cada vez que se edita el horario */
  const horarioCambiado=m=>{setVerHor(v=>v+1);if(m)setToast(m);};

  const aplicar=d=>{
    const n={avisos:d.avisos||[],calendarios:{...REMOTO_VACIO.calendarios,...(d.calendarios||{})},ausencias:d.ausencias||[],pendientes:+d.pendientes||0};
    setRemoto(n);LS.set("vj_hor_remoto",n);
  };
  const refrescar=async()=>{
    if(!SERVICIO_URL)return;
    try{aplicar(await Servicio.get());setEstado("ok");}catch(e){setEstado("error");}
  };
  useEffect(()=>{
    const f=()=>{setRuta(leerRuta());window.scrollTo(0,0);};
    window.addEventListener("hashchange",f);return()=>window.removeEventListener("hashchange",f);
  },[]);
  useEffect(()=>{if(["","avisos","calendarios","guardias","recreos"].indexOf(ruta)>=0)refrescar();},[ruta]);
  /* ausencias sin justificar del docente: contador del mosaico y aviso del 1 al 5 de cada mes (una vez al día) */
  useEffect(()=>{
    if(!usuario||!usuario.profesor||(ruta!==""&&ruta!=="ausencia"))return;
    pedir("GET","/justificaciones/mias").then(d=>{
      setJustif(d);
      const k="vj_aviso_justif_"+hoyISO();
      if(d.alerta&&ruta===""&&!LS.get(k,false)){LS.set(k,true);setAvisoJ(true);}
    }).catch(()=>{});
  },[ruta]);
  const[perm,setPerm]=useState(null);   /* iconos y notificaciones que permite el mapa de perfiles a esta cuenta */
  useEffect(()=>{if(usuario)pedir("GET","/permisos/mios").then(d=>{if(d&&d.ok!==false)setPerm(d);}).catch(()=>{});},[usuario&&usuario.id]);
  const av=k=>!perm||perm.avisos.includes(k);
  const esJefatura=!!usuario&&(usuario.rol==="admin"||(usuario.perfiles||[]).includes("jefe_estudios"));   /* perfil Jefatura: ausencias por grabar */
  const[incAv,setIncAv]=useState(null);   /* incidencias abiertas en las aulas */
  useEffect(()=>{if(usuario&&(ruta===""||ruta==="aulas"))pedir("GET","/incidencias/resumen").then(d=>{if(d&&d.ok!==false)setIncAv(d);}).catch(()=>{});},[ruta,usuario&&usuario.id]);
  const[ccpAv,setCcpAv]=useState(null);   /* CCP: convocatorias sin confirmar y si es miembro o convoca */
  const cargarCcp=()=>pedir("GET","/ccp/avisos").then(d=>{if(d&&d.ok!==false)setCcpAv(d);}).catch(()=>{});
  useEffect(()=>{if(usuario&&(ruta===""||ruta==="ccp"))cargarCcp();},[ruta]);
  const veFirmas=!!usuario&&(usuario.rol==="admin"||(usuario.perfiles||[]).some(p=>p==="jefe_estudios"||p==="direccion"));
  const cargarDap=()=>pedir("GET","/dap/avisos").then(d=>{if(d&&d.ok!==false)setDapAv(d);}).catch(()=>{});
  useEffect(()=>{if(usuario&&(ruta===""||ruta==="dap"))cargarDap();},[ruta]);
  const cargarDisc=()=>pedir("GET","/disciplina/resumen").then(d=>{if(d&&d.ok!==false)setDisc(d);}).catch(()=>{});
  useEffect(()=>{if(usuario&&(ruta===""||ruta==="disciplina"))cargarDisc();},[ruta]);
  useEffect(()=>{
    const f=()=>{if(!document.hidden)refrescar();};
    document.addEventListener("visibilitychange",f);return()=>document.removeEventListener("visibilitychange",f);
  },[]);
  useEffect(()=>{
    if(ruta!=="guardias")return;
    const t=setInterval(()=>{if(!document.hidden)refrescar();},60000);  /* Guardias de aula se actualiza sola cada minuto */
    return()=>clearInterval(t);
  },[ruta]);
  useEffect(()=>{if(toast){const t=setTimeout(()=>setToast(""),2800);return()=>clearTimeout(t);}},[toast]);

  const escribir=async(accion,datos,msg)=>{
    setEstado("busy");
    try{
      const r=await Servicio.post({accion,clave,...datos});
      if(r.error){setEstado("ok");setToast(r.error);return false;}
      if(r.datos)aplicar(r.datos);
      setEstado("ok");if(msg)setToast(msg);return true;
    }catch(e){setEstado("error");setToast("No se pudo conectar con el servidor");return false;}
  };
  const local=fn=>{const n=fn(remoto);setRemoto(n);LS.set("vj_hor_remoto",n);setToast("Guardado solo en este equipo (modo local)");return true;};
  const ops={
    avisoGuardar:async a=>SERVICIO_URL
      ?escribir("aviso_guardar",{aviso:a},"Aviso guardado")
      :local(r=>({...r,avisos:a.id?r.avisos.map(x=>x.id===a.id?{...x,...a}:x):[{...a,id:nuevoId(),fecha:hoyISO()}].concat(r.avisos)})),
    avisoBorrar:async id=>SERVICIO_URL
      ?escribir("aviso_borrar",{id},"Aviso eliminado")
      :local(r=>({...r,avisos:r.avisos.filter(x=>x.id!==id)})),
    calGuardar:async(k,c)=>SERVICIO_URL
      ?escribir("calendario_guardar",{clave_cal:k,calendario:c},"Calendario actualizado")
      :local(r=>({...r,calendarios:{...r.calendarios,[k]:c}})),
    ausenciasAdmin:async()=>{
      if(!SERVICIO_URL)return remoto.ausencias;
      try{const r=await Servicio.post({accion:"ausencias_admin",clave});return r.ok?(r.ausencias||[]):remoto.ausencias;}catch(e){return remoto.ausencias;}
    },
    ausenciaGuardar:async a=>SERVICIO_URL
      ?escribir("ausencia_guardar",{ausencia:a},a.id?"Ausencia actualizada":"Ausencia añadida")
      :local(r=>({...r,ausencias:a.id?r.ausencias.map(x=>x.id===a.id?{...x,...a,estado:"Grabada"}:x):r.ausencias.concat([{...a,id:nuevoId(),estado:"Grabada"}])})),
    ausenciasSemana:async d=>SERVICIO_URL
      ?escribir("ausencias_semana",d,"Ausencias de la semana guardadas")
      :local(r=>{const nuevas=d.ausencias.map(a=>({...a,id:a.id||nuevoId(),estado:"Grabada"}));const fuera=new Set(d.borrar.concat(nuevas.map(a=>a.id)));
        return{...r,ausencias:r.ausencias.filter(x=>!fuera.has(x.id)).concat(nuevas)};}),
    dapEstado:async()=>{
      if(!SERVICIO_URL)return null;
      try{const r=await Servicio.post({accion:"dap_estado",clave});return r.ok?r.dap:null;}catch(e){return null;}
    },
    dapSincronizar:async()=>{
      if(!SERVICIO_URL)return null;
      setEstado("busy");
      try{const r=await Servicio.post({accion:"dap_sincronizar",clave});setEstado("ok");if(r.error){setToast(r.error);return null;}if(r.datos)aplicar(r.datos);setToast("Calendario de asuntos propios leído");return r.dap;}
      catch(e){setEstado("error");setToast("No se pudo conectar con el servidor");return null;}
    },
    dapAsignar:async(titulo,profesor)=>{
      if(!SERVICIO_URL)return null;
      try{const r=await Servicio.post({accion:"dap_asignar",clave,titulo,profesor});if(r.error){setToast(r.error);return null;}if(r.datos)aplicar(r.datos);setToast(profesor==="-"?"Título ignorado":"Asignado a "+profesor);return r.dap;}
      catch(e){setToast("No se pudo conectar con el servidor");return null;}
    },
    ausenciaBorrar:async ids=>SERVICIO_URL
      ?escribir("ausencia_borrar",{ids},ids.length>1?ids.length+" ausencias eliminadas":"Ausencia eliminada")
      :local(r=>({...r,ausencias:r.ausencias.filter(x=>ids.indexOf(x.id)<0)})),
    ausenciaGrabar:async ids=>SERVICIO_URL
      ?escribir("ausencia_grabar",{ids},ids.length>1?ids.length+" ausencias grabadas":"Ausencia grabada")
      :local(r=>({...r,ausencias:r.ausencias.map(x=>ids.indexOf(x.id)>=0?{...x,estado:"Grabada"}:x)})),
    /* se envía al servidor de la app, que comprueba que es una ausencia propia (o administración) y la pasa a la hoja */
    ausencia:async a=>{
      try{await pedir("POST","/ausencias/notificar",{ausencia:a,clave:admin?clave:undefined});return{ok:true};}
      catch(e){return e.red?{ok:false}:{ok:false,error:e.message};}
    }
  };
  const verificar=async c=>{
    if(!SERVICIO_URL)return"red";
    /* candado con la contraseña PERSONAL de la cuenta de administración: el servidor devuelve un pase temporal */
    try{const r=await Servicio.post({accion:"login",clave:c});if(r.ok){paseRef.current=r.pase||c;return"ok";}return r.error||"mal";}catch(e){return"red";}
  };

  const profsCon=useMemo(()=>unicos(ENTRADAS,e=>e.profesor).sort((a,b)=>a.localeCompare(b,"es")),[verHor]);
  const profs=useMemo(()=>profsCon.concat(SIN_HORARIO).sort((a,b)=>a.localeCompare(b,"es")),[profsCon]);
  const grupos=useMemo(()=>unicos(ENTRADAS,e=>e.grupo).sort((a,b)=>a.localeCompare(b,"es",{numeric:true})),[verHor]);
  const aulas=useMemo(()=>unicos(ENTRADAS,e=>e.aula).sort((a,b)=>a.localeCompare(b,"es",{numeric:true})),[verHor]);
  const nAvisos=remoto.avisos.filter(avisoVigente).length;

  const ir=r=>{location.hash=r;};
  const home=()=>{location.hash="";};
  const esTutor=!!(usuario&&usuario.tutorDe&&usuario.tutorDe.length);
  const esDireccion=!!usuario&&(usuario.perfiles||[]).includes("direccion");
  const tilesVis=TILES.filter(t=>t.id==="rgpd"?(esAdminCuenta||esDireccion):(esAdminCuenta||(perm?perm.tiles.includes(t.id):(t.id!=="calendarios"&&t.id!=="avisos"&&t.id!=="permisos")))).filter(t=>t.id!=="ccp"||esAdminCuenta||(ccpAv&&(ccpAv.miembro||ccpAv.convoca))).filter(t=>(!t.soloAdmin||(esAdminCuenta&&admin))&&(!t.soloTutor||esTutor||esAdminCuenta)&&(t.id!=="familias"||esAdminCuenta||familiasVisible));
  /* enlaces antiguos a «#recreos»: se abren en Guardias, pestaña de recreo */
  useEffect(()=>{if(ruta==="recreos"){setModoGuardias("recreo");location.replace("#guardias");}},[ruta]);
  const tile=tilesVis.filter(t=>t.id===ruta)[0]||(ruta==="carga"&&esAdminCuenta?TILE_CARGA:undefined)||(ruta==="aulas"&&incAv&&incAv.gestiona?TILES.find(t=>t.id==="aulas"):undefined);   /* Conserjería entra en Aulas desde el aviso de incidencias aunque no tenga el icono */

  let pantalla;
  if(!tile)pantalla=(
    <div className="fade-in">
      <div className="mb-6">
        <h1 className="font-display font-bold text-2xl text-ink tracking-tight [text-wrap:balance]">Bienvenidos al mejor Centro de educación secundaria y FP de Extremadura</h1>
        <p className="text-sm text-ink-soft font-medium mt-1">{new Date().toLocaleDateString("es-ES",{weekday:"long",day:"numeric",month:"long"})}</p>
      </div>
      {av("incidencias")&&incAv&&incAv.gestiona&&incAv.total>0&&<button className="w-full text-left rounded-xl p-4 mb-3 text-sm font-semibold flex items-center gap-3" style={{background:"#eff6ff",color:"#1e3a8a",border:"1px solid #93c5fd"}} onClick={()=>{setModoAulas("horario");ir("aulas");}}>
        <Ico n="aula" s={20}/><span className="flex-1">{incAv.total} incidencia{incAv.total===1?"":"s"} abierta{incAv.total===1?"":"s"} en {incAv.aulas.length===1?"el aula ":"las aulas "}{incAv.aulas.map(a=>a.aula).join(", ")}.</span><span className="underline">Ver</span></button>}
      {av("aus_grabar")&&esJefatura&&remoto.pendientes>0&&<button className="w-full text-left rounded-xl p-4 mb-3 text-sm font-semibold flex items-center gap-3" style={{background:"#fff1f2",color:"#9f1239"}} onClick={()=>{setModoAusencias(admin?"gestion":"notificar");if(!admin)setLogin(true);ir("ausencia");}}>
        <Ico n="ausencia" s={20}/><span className="flex-1">Hay {remoto.pendientes} ausencia{remoto.pendientes===1?"":"s"} notificada{remoto.pendientes===1?"":"s"} por el profesorado pendiente{remoto.pendientes===1?"":"s"} de grabar.{admin?"":" Activa el modo administrador (candado) para grabarlas."}</span><span className="underline">Grabar</span></button>}
      {av("ccp")&&ccpAv&&(ccpAv.pendientes||[]).map(r=><button key={"ccp"+r.id} className="w-full text-left rounded-xl p-4 mb-3 text-sm font-semibold flex items-center gap-3" style={{background:"#fff7ed",color:"#9a3412"}} onClick={()=>ir("ccp")}>
        <Ico n="grupos" s={20}/><span className="flex-1">Convocatoria {r.organo==="consejo"?"del Consejo Escolar":"de la CCP"}: {fmtLarga(r.fecha)} a las {r.hora}{r.lugar?" · "+r.lugar:""}.</span><span className="underline">Ver y confirmar</span></button>)}
      {av("datos")&&faltanDatos.length>0&&<button className="w-full text-left rounded-xl p-4 mb-3 text-sm font-semibold flex items-center gap-3" style={{background:"#fff7ed",color:"#9a3412"}} onClick={()=>setCuenta("datos")}>
        <Ico n="lapiz" s={20}/><span className="flex-1">Te falta completar en tu cuenta: <b>{faltanDatos.join(", ")}</b>.{faltanDatos.includes("años trabajados")?" Los años son necesarios para calcular tus DAP.":""}</span><span className="underline">Completar</span></button>}
      {av("disc_jefatura")&&disc&&disc.responsable&&disc.pendientes>0&&<button className="w-full text-left rounded-xl p-4 mb-5 text-sm font-semibold flex items-center gap-3" style={{background:"#eff6ff",color:"#1d4ed8"}} onClick={()=>{abrirBandejaDisc="bandeja";ir("disciplina");}}>
        <Ico n="disciplina" s={20}/><span className="flex-1">Tienes {disc.pendientes} parte{disc.pendientes===1?"":"s"} de disciplina pendiente{disc.pendientes===1?"":"s"} de recibir.</span><span className="underline">Revisar</span></button>}
      {av("dap_resol")&&dapAv&&(dapAv.resoluciones||[]).map(r=><button key={"dap"+r.id} className="w-full text-left rounded-xl p-4 mb-3 text-sm font-semibold flex items-center gap-3" style={r.estado==="concedida"?{background:"#ecfdf5",color:"#166534"}:{background:"#fff1f2",color:"#9f1239"}} onClick={()=>{abrirDapEn="mias";ir("dap");}}>
        <Ico n="dap" s={20}/><span className="flex-1">La Dirección ha {r.estado==="concedida"?"concedido":r.estado==="revocada"?"revocado":"denegado"} tu día de asuntos particulares del {fmtLarga(r.fecha)}.</span><span className="underline">Ver resolución</span></button>)}
      {av("dap_gestion")&&dapAv&&dapAv.pendientes>0&&<button className="w-full text-left rounded-xl p-4 mb-3 text-sm font-semibold flex items-center gap-3" style={{background:"#ecfeff",color:"#0e7490"}} onClick={()=>{abrirDapEn="pendientes";ir("dap");}}>
        <Ico n="dap" s={20}/><span className="flex-1">Hay {dapAv.pendientes} solicitud{dapAv.pendientes===1?"":"es"} de DAP pendiente{dapAv.pendientes===1?"":"s"} de resolver.</span><span className="underline">Resolver</span></button>}
      {av("dap_gestion")&&dapAv&&!dapAv.pendientes&&dapAv.novedades>0&&<button className="w-full text-left rounded-xl p-4 mb-3 text-sm font-semibold flex items-center gap-3" style={{background:"#ecfeff",color:"#0e7490"}} onClick={()=>{abrirDapEn="registro";ir("dap");}}>
        <Ico n="dap" s={20}/><span className="flex-1">{dapAv.novedades} novedad{dapAv.novedades===1?"":"es"} en los DAP (solicitudes y resoluciones).</span><span className="underline">Ver</span></button>}
      {av("disc_tutoria")&&disc&&disc.tutoria>0&&<button className="w-full text-left rounded-xl p-4 mb-5 text-sm font-semibold flex items-center gap-3" style={{background:"#eff6ff",color:"#1d4ed8"}} onClick={()=>{abrirBandejaDisc="tutoria";ir("disciplina");}}>
        <Ico n="grupos" s={20}/><span className="flex-1">Hay {disc.tutoria} parte{disc.tutoria===1?"":"s"} de disciplina nuevo{disc.tutoria===1?"":"s"} del alumnado de tu tutoría.</span><span className="underline">Ver</span></button>}
      {av("justificar")&&justif&&justif.alerta&&<button className="w-full text-left rounded-xl p-4 mb-5 text-sm font-semibold flex items-center gap-3" style={justif.alerta.enPlazo?{background:"#fffbeb",color:"#92400e"}:{background:"#fff1f2",color:"#9f1239"}} onClick={()=>{setModoAusencias("justificar");ir("ausencia");}}>
        <Ico n="ausencia" s={20}/><span className="flex-1">{justif.alerta.enPlazo?"Tienes "+justif.alerta.n+" ausencia(s) del mes pasado sin justificar: el plazo termina el "+new Date(justif.alerta.limite+"T12:00:00").toLocaleDateString("es-ES",{day:"numeric",month:"long"})+".":"Tienes "+justif.alerta.n+" ausencia(s) sin justificar fuera de plazo."}</span><span className="underline">Justificar</span></button>}
      <Panal tiles={tilesVis} onPick={id=>{if(id==="ausencia")setModoAusencias(admin?"gestion":"notificar");ir(id);}} badgeDe={t=>t.id==="guardias"&&admin?remoto.pendientes:t.id==="aulas"&&incAv&&incAv.gestiona&&av("incidencias")?incAv.total:t.id==="avisos"?nAvisos:t.id==="ausencia"?(admin||(esJefatura&&av("aus_grabar"))?remoto.pendientes:(justif?justif.sinJustificar:0)):t.id==="dap"&&dapAv?(dapAv.pendientes||0)+(dapAv.novedades||0)+(dapAv.resoluciones||[]).length:t.id==="disciplina"&&disc?(av("disc_jefatura")&&disc.responsable?disc.pendientes||0:0)+(av("disc_tutoria")?disc.tutoria||0:0):0}/>
    </div>
  );
  else if(tile.id==="profesores")pantalla=<PantallaConsulta key="p" tile={tile} onBack={home} ver={verHor} editable={admin} clave={clave} onCambio={horarioCambiado} items={profs} campo="profesor" mostrar="prof" porLetras sinHorario={SIN_HORARIO} pregunta="Elige la inicial del primer apellido o escribe el nombre del profesor/a"/>;
  else if(tile.id==="grupos")pantalla=<PantallaConsulta key="g" tile={tile} onBack={home} ver={verHor} items={grupos} campo="grupo" mostrar="grupo" pregunta="Elige un grupo"/>;
  else if(tile.id==="aulas")pantalla=modoAulas==="reservas"
    ?<PantallaReservas tile={tile} onBack={home} profs={profsCon} onToast={setToast} arriba={<PestanasAulas modo={modoAulas} onModo={setModoAulas} tile={tile}/>}/>
    :<PantallaConsulta key="a" tile={tile} onBack={home} ver={verHor} items={aulas} campo="aula" mostrar="aula" prefijo="Aula " pregunta="Elige un aula" arriba={<PestanasAulas modo={modoAulas} onModo={setModoAulas} tile={tile}/>}/>;
  else if(tile.id==="guardias"&&modoGuardias==="firmas"&&veFirmas)pantalla=<PantallaFirmas tile={tile} onBack={home} arriba={<PestanasGuardias modo={modoGuardias} onModo={setModoGuardias} admin={admin} registro={veFirmas}/>}/>;
  else if(tile.id==="guardias")pantalla=modoGuardias==="panel"&&admin
    ?<PantallaPanelSala tile={tile} onBack={home} esAdminCuenta={esAdminCuenta} onToast={setToast} arriba={<PestanasGuardias modo={modoGuardias} onModo={setModoGuardias} admin={admin} registro={veFirmas}/>}/>
    :modoGuardias==="recreo"
    ?<PantallaGuardias key="re" yo={usuario&&usuario.profesor} esAdminCuenta={esAdminCuenta} clave={clave} tile={TILE_RECREO} onBack={home} tipo="recreo" remotas={remoto.ausencias} conectado={estado==="ok"||estado==="busy"} admin={admin} ops={ops} profs={profsCon} arriba={<PestanasGuardias modo={modoGuardias} onModo={setModoGuardias} admin={admin} registro={veFirmas}/>}/>
    :<PantallaGuardias key="gu" tile={tile} onBack={home} tipo="guardia" remotas={remoto.ausencias} conectado={estado==="ok"||estado==="busy"} admin={admin} ops={ops} profs={profsCon} arriba={<PestanasGuardias modo={modoGuardias} onModo={setModoGuardias} admin={admin} registro={veFirmas}/>}/>;
  else if(tile.id==="calendarios")pantalla=<PantallaCalendarios tile={tile} onBack={home} remoto={remoto} admin={admin} ops={ops}/>;
  else if(tile.id==="ausencia")pantalla=modoAusencias==="informes"&&admin
    ?<PantallaInformes tile={tile} onBack={home} clave={clave} esAdminCuenta={esAdminCuenta} onToast={setToast} arriba={<PestanasAusencias modo={modoAusencias} onModo={setModoAusencias} pendientes={justif?justif.sinJustificar:0} admin={admin} porConfirmar={remoto.pendientes}/>}/>
    :modoAusencias==="gestion"&&admin
    ?<PantallaGestionAusencias tile={tile} onBack={home} ops={ops} profs={profsCon} arriba={<PestanasAusencias modo={modoAusencias} onModo={setModoAusencias} pendientes={justif?justif.sinJustificar:0} admin={admin} porConfirmar={remoto.pendientes}/>}/>
    :modoAusencias==="mias"
    ?<PantallaMisAusencias tile={tile} onBack={home} onJustificar={()=>setModoAusencias("justificar")} arriba={<PestanasAusencias modo={modoAusencias} onModo={setModoAusencias} pendientes={justif?justif.sinJustificar:0} admin={admin} porConfirmar={remoto.pendientes}/>}/>
    :modoAusencias==="justificar"
    ?<PantallaJustificar tile={tile} onBack={home} onToast={setToast} onDatos={setJustif} arriba={<PestanasAusencias modo={modoAusencias} onModo={setModoAusencias} pendientes={justif?justif.sinJustificar:0} admin={admin} porConfirmar={remoto.pendientes}/>}/>
    :<PantallaAusencia tile={tile} onBack={home} ops={ops} profs={profsCon} usuario={usuario} esAdmin={esAdminCuenta||admin} arriba={<PestanasAusencias modo={modoAusencias} onModo={setModoAusencias} pendientes={justif?justif.sinJustificar:0} admin={admin} porConfirmar={remoto.pendientes}/>}/>;
  else if(tile.id==="cronologia")pantalla=<PantallaCronologia tile={tile} onBack={home}/>;
  else if(tile.id==="biblioteca")pantalla=<PantallaBiblioteca tile={tile} onBack={home}/>;
  else if(tile.id==="ccp")pantalla=<PantallaCcp tile={tile} onBack={home} onToast={setToast} onAvisos={cargarCcp}/>;
  else if(tile.id==="dap")pantalla=<PantallaDap tile={tile} onBack={home} onToast={setToast} onAvisos={cargarDap}/>;
  else if(tile.id==="disciplina")pantalla=<PantallaDisciplina tile={tile} onBack={home} onToast={setToast} onResumen={cargarDisc}/>;
  else if(tile.id==="familias")pantalla=<PantallaFamilias tile={tile} onBack={home} esAdmin={esAdminCuenta} profs={profsCon} onToast={setToast}/>;
  else if(tile.id==="carga")pantalla=<PantallaCargaHorario tile={tile} onBack={home} onCambio={horarioCambiado}/>;
  else if(tile.id==="rgpd")pantalla=<PantallaRgpd tile={tile} onBack={home} onToast={setToast} esAdminCuenta={esAdminCuenta}/>;
  else if(tile.id==="permisos"&&esAdminCuenta)pantalla=<PantallaPermisos tile={tile} onBack={home} onToast={setToast}/>;
  else if(tile.id==="usuarios")pantalla=<PantallaUsuarios tile={tile} onBack={home} yo={usuario} profs={profsCon} onToast={setToast}/>;
  else pantalla=<PantallaAvisos tile={tile} onBack={home} remoto={remoto} admin={admin} ops={ops}/>;

  return(
    <div id="shell" className="min-h-screen flex flex-col">
      <Header onTutorial={()=>setTutorial(true)} admin={admin} estado={estado} onHome={home} usuario={usuario} onCuenta={()=>setCuenta(true)} onCarga={esAdminCuenta?()=>ir("carga"):null} onLogin={()=>setLogin(true)} onLogout={()=>{Servicio.post({accion:"logout_admin",clave}).catch(()=>{});setAdmin(false);setClave("");paseRef.current="";setToast("Modo administrador cerrado");}}/>
      <main className="max-w-5xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 flex-1">{pantalla}</main>
      <footer className="text-center py-6 text-xs text-[#522270] font-semibold no-print bg-[#E4CFF0] border-t border-[#CDAEE0] mt-6">IES Valle del Jerte · Plasencia · Jefatura de Estudios · Curso 2026-27
        <div className="mt-1.5 space-x-3 font-medium"><button className="underline underline-offset-2" onClick={()=>verPrivacidad("datos")}>Protección de datos</button>{usuario&&usuario.compartido&&<span>· Equipo compartido: la sesión se cierra tras 20 min sin uso</span>}</div></footer>
      <VisorPrivacidad/>
      {avisoJ&&justif&&justif.alerta&&<AvisoJustificar alerta={justif.alerta} onCerrar={()=>setAvisoJ(false)} onIr={()=>{setAvisoJ(false);setModoAusencias("justificar");ir("ausencia");}}/>}
      {tutorial&&<ModalTutorial onClose={()=>setTutorial(false)}/>}
      {cuenta&&usuario&&<ModalCuenta usuario={{...usuario,...(misDatos||{})}} abrirDatos={cuenta==="datos"} onDatos={u=>setMisDatos(m=>({...(m||{}),...u}))} onClose={()=>setCuenta(false)} onToast={setToast}/>}
      {login&&<ModalLogin verificar={verificar} onClose={()=>setLogin(false)} onOk={()=>{setClave(paseRef.current);setAdmin(true);setLogin(false);if(ruta==="ausencia")setModoAusencias("gestion");setToast("Sesión de administrador iniciada");}}/>}
      {toast&&<div className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-ink text-white px-5 py-3 rounded-xl shadow-lg text-sm font-semibold fade-in z-50 no-print">{toast}</div>}
    </div>
  );
}

export default App;
