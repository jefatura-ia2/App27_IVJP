import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import cors from 'cors';
import { config } from './config.js';
import { rutas } from './routes.js';

export function crearApp() {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', 'loopback');   /* detrás de nginx: IP real y HTTPS (cookie Secure) */
  /* además de los orígenes configurados, se admiten siempre los de la app de móvil (Capacitor) */
  const ORIGENES_APP = ['capacitor://localhost', 'ionic://localhost', 'https://localhost', 'http://localhost'];
  /* Protección de datos: ya no se acepta cualquier origen con credenciales. Vacío o «*» = solo la propia app
     (mismo origen, que no necesita CORS) y la app de móvil; si no, los orígenes indicados en CORS_ORIGIN */
  const lista = config.corsOrigin && config.corsOrigin.trim() !== '*' ? config.corsOrigin.split(',').map(s => s.trim()).filter(Boolean) : [];
  if (config.corsOrigin.trim() === '*') console.log('CORS_ORIGIN=* ya no abre la API a cualquier web: solo la propia app y la app de móvil.');
  const origenes = [...lista, ...ORIGENES_APP];
  app.use(cors({ origin: origenes, credentials: true }));
  /* cabeceras de seguridad (RGPD art. 32 · ENS mp.com / mp.s) */
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=(), usb=()');
    /* v69: todo se sirve desde el propio servidor (sin CDN ni Google Fonts): solo se permite cargar código de aquí */
    res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; font-src 'self' data:; img-src 'self' data: blob: https:; connect-src 'self'; frame-src 'self' https:; media-src 'self' blob:; worker-src 'self' blob:; frame-ancestors 'self'; object-src 'none'; base-uri 'self'; form-action 'self'");
    if (req.secure) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    if (req.path.startsWith('/api/')) res.setHeader('Cache-Control', 'no-store');
    next();
  });
  /* que los buscadores no indexen nada de la app (incluidas las páginas públicas de familias y verificación) */
  app.use((req, res, next) => { res.setHeader('X-Robots-Tag', 'noindex, nofollow'); next(); });
  app.get('/robots.txt', (req, res) => res.type('text/plain').send('User-agent: *\nDisallow: /\n'));
  /* CSRF: las peticiones que cambian datos solo se aceptan desde la propia app (mismo origen) o la app de móvil */
  app.use('/api', (req, res, next) => {
    if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
    const origen = req.get('Origin');
    const sitio = req.get('Sec-Fetch-Site');
    let mismo = false;
    try { mismo = !!origen && new URL(origen).host === req.get('host'); } catch { /* origen no válido */ }
    const permitido = !origen || mismo || origenes.includes(origen);
    if (!permitido || (sitio && !['same-origin', 'none'].includes(sitio) && !mismo && !origenes.includes(origen)))
      return res.status(400).json({ ok: false, error: 'Petición rechazada: no viene de la app del centro' });
    next();
  });
  app.use(express.json({ limit: '5mb' }));
  app.use('/api', rutas);

  /* Versión compilada de la app (frontend/dist, creada con «npm run build»): si existe, la sirve
     este mismo servidor, de modo que basta abrir http://<este-ordenador>:3000 */
  const dist = config.frontendDist;
  if (dist && fs.existsSync(path.join(dist, 'index.html'))) {
    app.use(express.static(dist, {
      index: false,
      setHeaders: (res, f) => {
        if (/[\\/]assets[\\/]/.test(f)) res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
        else res.setHeader('Cache-Control', 'no-cache');
      },
    }));
    app.get(/^\/(?!api\/).*/, (req, res) => { res.setHeader('Cache-Control', 'no-cache'); res.sendFile(path.join(dist, 'index.html')); });
    console.log(`App compilada servida desde ${dist}`);
  }

  app.use((req, res) => res.status(404).json({ error: 'Ruta no encontrada' }));
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    console.error(err);
    res.status(err.status || 500).json({ error: err.status ? err.message : 'Error interno' });
  });
  return app;
}
