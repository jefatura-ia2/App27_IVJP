import * as Auth from '../services/authService.js';
import { gruposDe } from '../services/tutoriaService.js';

const COOKIE = 'vj_sesion';
const leerCookie = req => {
  const c = req.headers.cookie || '';
  const m = c.split(';').map(s => s.trim()).find(s => s.startsWith(COOKIE + '='));
  if (m) return decodeURIComponent(m.slice(COOKIE.length + 1));
  /* app de móvil (Android/iOS): envía la sesión en la cabecera Authorization */
  const h = req.headers.authorization || '';
  return h.startsWith('Bearer ') ? h.slice(7).trim() : '';
};
const ponerCookie = (req, res, token, maxAgeDias) => {
  const partes = [`${COOKIE}=${encodeURIComponent(token)}`, 'Path=/', 'HttpOnly', 'SameSite=Lax', `Max-Age=${Math.round(maxAgeDias * 86400)}`];
  if (req.secure) partes.push('Secure');
  res.setHeader('Set-Cookie', partes.join('; '));
};

/** Exige sesión iniciada en todas las rutas de /api salvo las públicas */
/** GET /api/panel/hoy — el cuadrante de la sala de profesores para quien ha iniciado sesión (respuesta 200 siempre) */
export async function panelHoy(req, res) {
  const u = await Auth.deSesion(leerCookie(req));
  if (!u) return res.json({ ok: false, error: 'Inicia sesión en la app para ver el cuadrante de guardias.' });
  const P = await import('../services/panelService.js');
  res.set('Cache-Control', 'no-store');
  res.json(await P.datos());
}
/** GET /api/panel/biblioteca-hoy — cuadrante de la Biblioteca para quien ha iniciado sesión (200 siempre) */
export async function panelBibliotecaHoy(req, res) {
  const u = await Auth.deSesion(leerCookie(req));
  if (!u) return res.json({ ok: false, error: 'Inicia sesión en la app para ver el cuadrante de la biblioteca.' });
  const P = await import('../services/panelService.js');
  res.set('Cache-Control', 'no-store');
  res.json(await P.datosBiblioteca());
}
export async function requiereSesion(req, res, next) {
  try {
    const u = await Auth.deSesion(leerCookie(req));
    if (!u) return res.status(401).json({ ok: false, error: 'Inicia sesión', sesion: false });
    req.usuario = { ...u, ip: req.ip };
    /* contexto de la petición: el usuario queda disponible para las comprobaciones de los servicios */
    const { contexto } = await import('../services/contexto.js');
    /* con la contraseña provisional solo se puede cambiar la contraseña o salir */
    if (u.cambiarClave && !['/auth/cambiar-clave', '/auth/yo', '/auth/logout'].includes(req.path))
      return res.status(403).json({ ok: false, error: 'Cambia tu contraseña provisional para continuar', cambiarClave: true });
    return contexto.run({ usuario: req.usuario }, next);
  } catch (e) { next(e); }
}
export function soloAdminCuenta(req, res, next) {
  if (!req.usuario || req.usuario.rol !== 'admin') return res.status(403).json({ ok: false, error: 'Solo administración' });
  next();
}

export async function login(req, res) {
  const { usuario, clave, compartido } = req.body || {};
  const r = await Auth.login(usuario, clave, req.ip, { compartido: !!compartido });
  ponerCookie(req, res, r.token, r.compartido ? Auth.HORAS_COMPARTIDO / 24 : Auth.DIAS_SESION);
  /* la app de móvil no puede usar la cookie (otro origen): recibe el token para enviarlo en Authorization */
  const esApp = req.headers['x-cliente'] === 'app';
  res.json({ ok: true, usuario: r.usuario, ...(esApp ? { token: r.token } : {}) });
}
export async function logout(req, res) {
  await Auth.logout(leerCookie(req));
  if (req.usuario) (await import('../services/modoAdmin.js')).revocarDe(req.usuario.id);   /* cierra también el modo administrador */
  ponerCookie(req, res, '', 0);
  res.json({ ok: true });
}
export async function yo(req, res) {
  const profesor = await Auth.profesorDeCuenta(req.usuario.nombre);
  /* grupos de los que es tutor/a (muestra el mosaico «Reunión con familias») */
  const tutorDe = (await gruposDe(profesor)).map(g => g.grupo);
  res.json({ ok: true, usuario: { ...req.usuario, profesor, tutorDe } });
}
export async function cambiarClave(req, res) {
  await Auth.cambiarClave(req.usuario.id, req.body && req.body.actual, req.body && req.body.nueva, leerCookie(req));
  (await import('../services/modoAdmin.js')).revocarDe(req.usuario.id);
  res.json({ ok: true });
}

export async function listar(req, res) {
  const { listaDepartamentos } = await import('../services/departamentoProfesor.js');
  const { rows: g } = await (await import('../db.js')).query('SELECT codigo FROM grupo ORDER BY codigo');
  res.json({ ok: true, usuarios: await Auth.listar(), departamentos: await listaDepartamentos(), grupos: g.map(r => r.codigo), perfilesExtra: await Auth.perfilesExtra() });
}
/** Perfiles creados por el administrador */
export async function guardarPerfil(req, res) { res.json({ ok: true, perfilesExtra: await Auth.guardarPerfil(req.body || {}) }); }
export async function borrarPerfil(req, res) { res.json({ ok: true, perfilesExtra: await Auth.borrarPerfil(String(req.params.k || '')) }); }
export async function crear(req, res) { res.json({ ok: true, ...(await Auth.crear(req.body || {})) }); }
export async function lote(req, res) { res.json({ ok: true, creados: await Auth.crearLote(req.body && req.body.nombres) }); }
export async function actualizar(req, res) { await Auth.actualizar(Number(req.params.id), req.body || {}, req.usuario); res.json({ ok: true }); }
/** PUT /api/usuarios/:id/datos — el administrador completa o corrige el correo, el móvil y los años de una cuenta */
export async function datosDe(req, res) { const b = req.body || {}; res.json({ ok: true, usuario: await Auth.guardarDatos(Number(req.params.id), { email: b.email, movil: b.movil, anios: b.anios, parcial: true }) }); }
export async function restablecer(req, res) { res.json({ ok: true, ...(await Auth.restablecer(Number(req.params.id))) }); }
export async function borrar(req, res) { await Auth.borrar(Number(req.params.id), req.usuario); res.json({ ok: true }); }
/** PUT /api/auth/mis-datos { email, movil, anios } — el docente completa o corrige sus datos de contacto */
export async function misDatos(req, res) {
  const b = req.body || {};
  res.json({ ok: true, usuario: await Auth.guardarDatos(req.usuario.id, { email: b.email, movil: b.movil, anios: b.anios, parcial: !!b.parcial }) });
}
/** GET /api/dap/ficha?profesor=… — correo, móvil, años y contador DAP (solo el propio docente o administración) */
export async function fichaDap(req, res) {
  const { ficha } = await import('../services/contadorDap.js');
  res.json({ ok: true, ficha: await ficha(String(req.query.profesor || ''), req.usuario) });
}
/** GET /api/dap/contadores — administración: contador DAP de cada cuenta */
export async function contadoresDap(req, res) {
  const { contadores } = await import('../services/contadorDap.js');
  res.json({ ok: true, ...(await contadores()) });
}
/** GET /api/departamento-de?profesor=… — departamento del docente (lo ve todo el claustro) */
export async function departamentoDe(req, res) {
  const D = await import('../services/departamentoProfesor.js');
  const r = await D.departamentoDe(String(req.query.profesor || ''));
  res.json({ ok: true, ...r, ...(req.usuario.rol === 'admin' ? { lista: await D.listaDepartamentos() } : {}) });
}
/** PUT /api/departamento-de { profesor, departamento } — administración */
export async function asignarDepartamento(req, res) {
  const D = await import('../services/departamentoProfesor.js');
  const b = req.body || {};
  res.json({ ok: true, ...(await D.asignar(b.profesor, b.departamento)), lista: await D.listaDepartamentos() });
}
/** GET /api/consejo-escolar — profesorado miembro del Consejo Escolar (todo el claustro) */
export async function consejoEscolar(req, res) { res.json({ ok: true, miembros: await Auth.consejoEscolar() }); }
/** Mapa de perfiles y permisos */
export async function permisosMios(req, res) { const P = await import('../services/permisosService.js'); res.json({ ok: true, ...(await P.deUsuario(req.usuario)) }); }
export async function permisos(req, res) {
  const P = await import('../services/permisosService.js');
  res.json({ ok: true, mapa: await P.mapa(), recuento: await P.recuento(), perfilesExtra: await Auth.perfilesExtra(), mosaicos: P.MOSAICOS, notificaciones: P.NOTIFICACIONES });
}
export async function guardarPermisos(req, res) {
  const P = await import('../services/permisosService.js'); const b = req.body || {};
  res.json({ ok: true, mapa: await P.guardar(b.mapa, !!b.restablecer), recuento: await P.recuento() });
}
