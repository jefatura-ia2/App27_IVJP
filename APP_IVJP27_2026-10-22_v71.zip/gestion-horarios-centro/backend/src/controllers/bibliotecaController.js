import * as B from '../services/bibliotecaService.js';
import { query } from '../db.js';
import { GuardiaBiblioteca } from '../models/index.js';

/** GET /api/biblioteca/recreos — guardias de recreo que se hacen en la biblioteca */
export async function listar(req, res) {
  res.json({ ok: true, recreos: await GuardiaBiblioteca.listar({ query }) });
}

/** POST /api/biblioteca/recreos  { clave, dia, tramo, profesor, marcado }  (solo administración) */
export async function marcar(req, res) {
  const { dia, tramo, profesor, marcado } = req.body || {};
  const d = Number(dia), t = String(tramo || '').toUpperCase(), p = String(profesor || '').trim();
  if (!(d >= 1 && d <= 5) || !['R1', 'R2'].includes(t) || !p) return res.status(400).json({ ok: false, error: 'Datos no válidos' });
  if (marcado) await query(`INSERT INTO guardia_biblioteca (dia, tramo, profesor, zona) VALUES ($1,$2,$3,'biblioteca') ON CONFLICT (dia, tramo, profesor) DO UPDATE SET zona = 'biblioteca'`, [d, t, p]);
  else await query('DELETE FROM guardia_biblioteca WHERE dia=$1 AND tramo=$2 AND profesor=$3', [d, t, p]);
  res.json({ ok: true, recreos: await GuardiaBiblioteca.listar({ query }) });
}

/* ---------- G.B. y MAY55 (antes en la hoja de Google) ---------- */

/** GET /api/biblioteca/registros — para todo el claustro; indica si la cuenta puede gestionar */
export async function registros(req, res) {
  res.json({ ok: true, records: await B.listar(), puedeGestionar: B.puedeGestionar(req.usuario) });
}
/** POST /api/biblioteca/acceso { clave } — perfil Biblioteca o administración + clave de la biblioteca */
export async function acceso(req, res) {
  await B.comprobar(req.usuario, String((req.body || {}).clave || ''));
  res.json({ ok: true });
}
/** PUT /api/biblioteca/registros { clave, records } — guarda la lista completa */
export async function guardar(req, res) {
  const { clave, records } = req.body || {};
  await B.comprobar(req.usuario, String(clave || ''));
  res.json({ ok: true, records: await B.guardarTodo(records, { deUsuario: true }) });
}
/** POST /api/biblioteca/importar-hoja { clave } — vuelve a traer los datos de la hoja de Google anterior */
export async function importarHoja(req, res) {
  await B.comprobar(req.usuario, String((req.body || {}).clave || ''));
  const n = await B.importarDeHoja();
  res.json({ ok: true, importados: n, records: await B.listar() });
}
/** GET /api/biblioteca/clave — (Jefatura) si hay clave y qué cuentas tienen el perfil */
export async function estadoClave(req, res) {
  res.json({ ok: true, definida: await B.claveDefinida(), debil: await B.claveDebil(), gestores: await B.gestores() });
}
/** PUT /api/biblioteca/clave { nueva } — (Jefatura) fija la clave de la biblioteca */
export async function fijarClave(req, res) {
  await B.fijarClave(String((req.body || {}).nueva || ''));
  res.json({ ok: true });
}

/**
 * POST /api/recreo/zona { dia, tramo, profesor, zona }  — zona de vigilancia del recreo (zona1, zona2, zona3, biblioteca;
 * vacía = quitar). Cada docente se apunta él mismo en sus guardias de recreo; la administración, a cualquiera.
 */
export async function zonaRecreo(req, res) {
  const { dia, tramo, profesor, zona } = req.body || {};
  const d = Number(dia), t = String(tramo || '').toUpperCase(), p = String(profesor || '').trim(), z = String(zona || '');
  if (!(d >= 1 && d <= 5) || !['R1', 'R2'].includes(t) || !p || (z && !GuardiaBiblioteca.ZONAS.includes(z)))
    return res.status(400).json({ ok: false, error: 'Datos no válidos' });
  const norm = x => String(x || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
  if (req.usuario.rol !== 'admin' && norm(req.usuario.nombre) !== norm(p))
    return res.status(400).json({ ok: false, error: 'Solo puedes apuntarte tú (Jefatura puede asignar a cualquiera)' });
  const { rowCount } = await query(`SELECT 1 FROM clase c JOIN profesor pr ON pr.id = c.profesor_id
    WHERE c.dia = $1 AND c.tramo = $2 AND c.categoria = 'recreo' AND pr.nombre_norm = $3`, [d, t, norm(p)]);
  if (!rowCount) return res.status(400).json({ ok: false, error: 'Ese profesor/a no tiene guardia de recreo en ese día y recreo' });
  if (z) await query(`INSERT INTO guardia_biblioteca (dia, tramo, profesor, zona) VALUES ($1,$2,$3,$4)
    ON CONFLICT (dia, tramo, profesor) DO UPDATE SET zona = EXCLUDED.zona, creado = now()`, [d, t, p, z]);
  else await query('DELETE FROM guardia_biblioteca WHERE dia=$1 AND tramo=$2 AND profesor=$3', [d, t, p]);
  res.json({ ok: true, recreos: await GuardiaBiblioteca.listar({ query }) });
}
