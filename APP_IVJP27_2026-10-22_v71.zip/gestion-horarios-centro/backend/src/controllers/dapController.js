/** Módulo DAP (solicitud de días de asuntos particulares). Errores 400/404 para no cerrar la sesión. */
import * as D from '../services/dapSolicitudes.js';
import { generarPdfDap, textoVerificable } from '../services/pdfDap.js';
import { codigoVerificacion } from '../services/firma.js';
import { generarImpresoDap } from '../services/pdfDapImpreso.js';
import { query } from '../db.js';
import { igualSeguro } from '../services/contexto.js';

export async function mio(req, res) { res.json({ ok: true, ...(await D.mio(req.usuario)) }); }
export async function calendario(req, res) { res.json({ ok: true, ...(await D.calendario(req.usuario, req.query.desde, req.query.hasta)) }); }
export async function solicitar(req, res) { const s = await D.solicitar(req.usuario, req.body || {}); res.json({ ok: true, solicitud: s, ...(await D.mio(req.usuario)) }); }
export async function anular(req, res) { await D.anular(req.usuario, Number(req.params.id)); res.json({ ok: true, ...(await D.mio(req.usuario)) }); }
export async function lista(req, res) { res.json({ ok: true, solicitudes: await D.lista(req.usuario, req.query) }); }
export async function resolver(req, res) {
  const b = req.body || {};
  res.json({ ok: true, solicitud: await D.resolver(req.usuario, Number(req.params.id), String(b.accion || ''), b) });
}
export async function bloquear(req, res) { const b = req.body || {}; await D.bloquear(req.usuario, b.fecha, b.motivo, !!b.quitar); res.json({ ok: true }); }
export async function avisos(req, res) { res.json({ ok: true, ...(await D.avisos(req.usuario)) }); }
export async function registro(req, res) { res.json({ ok: true, eventos: await D.registro(req.usuario, req.query.marcar !== '0') }); }
export async function visto(req, res) { await D.marcarVisto(req.usuario, Number(req.params.id)); res.json({ ok: true }); }
export async function pdf(req, res) {
  const s = await D.paraPdf(req.usuario, Number(req.params.id));
  const nombre = `Resolucion_DAP_${String(s.id).padStart(4, '0')}_${s.fecha}.pdf`;
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `${req.query.descargar ? 'attachment' : 'inline'}; filename="${nombre}"`);
  res.end(await generarPdfDap(s));
}
/** GET /api/dap/verificar?registro=12&csv=XXXX-… (público): comprueba que una resolución es auténtica */
export async function verificar(req, res) {
  const id = Number(String(req.query.registro || '').replace(/\D/g, ''));
  const { rows } = await query(`SELECT id, profesor, to_char(fecha,'YYYY-MM-DD') AS fecha, estado, to_char(resuelto AT TIME ZONE 'Europe/Madrid','YYYY-MM-DD HH24:MI') AS resuelto FROM dap_solicitud WHERE id = $1`, [id]);
  const s = rows[0];
  const ok = !!s && igualSeguro(await codigoVerificacion(textoVerificable(s)), String(req.query.csv || '').trim().toUpperCase());
  res.json({ ok: true, valido: ok, ...(ok ? { profesor: s.profesor, fecha: s.fecha, estado: s.estado, resuelto: s.resuelto } : {}) });
}

/** POST /api/dap/sincronizar: escribe en el calendario de Google lo pendiente y relee el calendario */
export async function sincronizar(req, res) {
  res.json({ ok: true, ...(await D.sincronizar(req.usuario)) });
}

/** GET /api/dap/solicitudes/:id/impreso — impreso oficial «Permiso por asuntos particulares (Art. 12)», ya resuelto.
 *  Lo imprimen Administración 1 y 2 (también Dirección y Jefatura): ejemplar para registro y para el interesado. */
export async function impreso(req, res) {
  if (!D.veTodo(req.usuario)) throw Object.assign(new Error('El impreso lo imprime Administración (o la Dirección)'), { status: 404 });
  const s = await D.paraPdf(req.usuario, Number(req.params.id));
  const { rows } = await query('SELECT movil FROM usuario WHERE usuario = $1', [s.usuario || '']);
  const nombre = `Permiso_asuntos_particulares_DAP-${String(s.id).padStart(4, '0')}_${s.fecha}.pdf`;
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Content-Disposition', `${req.query.descargar ? 'attachment' : 'inline'}; filename="${nombre}"`);
  res.end(await generarImpresoDap(s, { telefono: rows[0] ? rows[0].movil : '' }));
}

/** GET/PUT /api/dap/servicio-google — URL del script de Google (la cambia la cuenta de administración desde la app) */
export async function servicioGoogle(req, res) {
  const G = await import('../services/googleServicio.js');
  if (!D.veTodo(req.usuario)) throw Object.assign(new Error('Solo Dirección, Administración y Jefatura'), { status: 404 });
  res.json({ ok: true, ...(await G.leer(req.usuario)) });
}
export async function guardarServicioGoogle(req, res) {
  const G = await import('../services/googleServicio.js');
  const r = await G.guardar(req.usuario, (req.body || {}).url);
  (await import('../services/registroAccesos.js')).registrar(req, 'servicio_google', r.url);
  (await import('../services/dapGoogle.js'))._vaciarCache();
  res.json({ ok: true, ...r });
}
/** GET /api/dap/diagnostico-calendario — comprueba paso a paso la escritura en el calendario de Google y reintenta lo pendiente */
export async function diagnosticoCalendario(req, res) {
  if (!D.veTodo(req.usuario)) throw Object.assign(new Error('Solo Dirección, Administración y Jefatura'), { status: 404 });
  const G = await import('../services/dapGoogle.js');
  const d = await G.diagnostico();
  const todoBien = d.pasos.length && d.pasos.every(p => p.ok);
  const reintento = todoBien ? await G.reintentar() : null;
  const { rows } = await query(`SELECT id, profesor, to_char(fecha,'YYYY-MM-DD') AS fecha, gcal_error AS error FROM dap_solicitud WHERE gcal_error <> '' ORDER BY fecha LIMIT 20`);
  res.json({ ok: true, ...d, reintento, pendientes: rows });
}
