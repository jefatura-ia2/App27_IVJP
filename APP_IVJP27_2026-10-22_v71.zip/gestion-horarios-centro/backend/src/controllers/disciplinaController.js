/** Módulo Disciplina (partes de conductas contrarias). Errores con estado 400/404 para no cerrar la sesión. */
import * as D from '../services/disciplinaService.js';

export async function config(req, res) { res.json({ ok: true, ...(await D.configuracion(req.usuario)) }); }
export async function crear(req, res) {
  const parte = await D.crear(req.usuario, req.body || {});
  res.json({ ok: true, parte, mios: await D.mios(req.usuario) });
}
export async function mios(req, res) { res.json({ ok: true, profesor: await D.quienSoy(req.usuario), partes: await D.mios(req.usuario) }); }
export async function bandeja(req, res) { res.json({ ok: true, partes: await D.bandeja(req.usuario) }); }
export async function resumen(req, res) { res.json({ ok: true, ...(await D.resumen(req.usuario)) }); }
export async function recibido(req, res) {
  /* seguridad: hay que decirlo explícitamente (true = recibido, false = deshacer); un POST vacío no hace nada */
  const ok = req.body ? req.body.ok : undefined;
  if (ok !== true && ok !== false) return res.status(400).json({ ok: false, error: 'Petición no válida' });
  const parte = await D.marcarRecibido(Number(req.params.id), req.usuario, ok);
  res.json({ ok: true, parte });
}
export async function visto(req, res) {
  await D.marcarVisto(Number(req.params.id), req.usuario);
  res.json({ ok: true });
}
export async function pdf(req, res) {
  const r = await D.pdf(Number(req.params.id), req.usuario, req.query.copia);
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `${req.query.descargar ? 'attachment' : 'inline'}; filename="${r.nombre.normalize('NFD').replace(/[^\x20-\x7e]/g, '').replace(/"/g, '')}"; filename*=UTF-8''${encodeURIComponent(r.nombre)}`);
  res.end(r.buffer);
}
export async function carpeta(req, res) { res.json({ ok: true, carpetas: await D.carpeta(req.usuario) }); }
export async function archivoCarpeta(req, res) {
  const r = D.archivoCarpeta(req.usuario, req.query.etapa, req.query.nombre);
  res.setHeader('Content-Type', r.nombre.toLowerCase().endsWith('.pdf') ? 'application/pdf' : 'application/octet-stream');
  res.setHeader('Content-Disposition', `${req.query.descargar ? 'attachment' : 'inline'}; filename="${r.nombre.normalize('NFD').replace(/[^\x20-\x7e]/g, '').replace(/"/g, '')}"; filename*=UTF-8''${encodeURIComponent(r.nombre)}`);
  res.sendFile(r.ruta);
}
export async function tutoria(req, res) { res.json({ ok: true, ...(await D.deMiTutoria(req.usuario)) }); }
export async function leidoTutor(req, res) {
  await D.marcarLeidoTutor(Number(req.params.id), req.usuario);
  res.json({ ok: true, ...(await D.deMiTutoria(req.usuario)) });
}
