/** Firma de guardias y convocatorias de la CCP. Errores 400/404 (no 401/403) para no cerrar la sesión. */
import * as F from '../services/firmasGuardia.js';
import * as C from '../services/ccpService.js';

export async function misFirmas(req, res) { res.json({ ok: true, ...(await F.mias(req.usuario)) }); }
export async function firmar(req, res) { res.json({ ok: true, ...(await F.firmar(req.usuario, (req.body || {}).tramo)) }); }
export async function registro(req, res) {
  const r = await F.registro(req.usuario, req.query);
  if (req.query.formato === 'csv') {
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="Firmas_guardias_${r.desde}_${r.hasta}.csv"`);
    return res.end(F.csv(r));
  }
  res.json({ ok: true, ...r });
}
export async function ccp(req, res) { res.json({ ok: true, ...(await C.datos(req.usuario, req.query.organo)) }); }
export async function ccpGuardar(req, res) { res.json({ ok: true, ...(await C.guardar(req.usuario, req.body || {})) }); }
export async function ccpAnular(req, res) { res.json({ ok: true, ...(await C.anular(req.usuario, req.params.id)) }); }
export async function ccpEnterado(req, res) { res.json({ ok: true, ...(await C.enterado(req.usuario, req.params.id)) }); }
export async function ccpAvisos(req, res) { res.json({ ok: true, ...(await C.avisos(req.usuario)), miembro: C.esMiembro(req.usuario, 'ccp') || C.esMiembro(req.usuario, 'consejo'), convoca: C.puedeConvocar(req.usuario) }); }
/* Incidencias en las aulas */
import * as I from '../services/incidenciasService.js';
export async function incidencias(req, res) { res.json({ ok: true, ...(await I.lista(req.usuario, { aula: req.query.aula, todas: req.query.todas === '1' })) }); }
export async function incidenciaCrear(req, res) { res.json({ ok: true, ...(await I.crear(req.usuario, req.body || {})) }); }
export async function incidenciaResolver(req, res) { res.json({ ok: true, ...(await I.resolver(req.usuario, req.params.id, (req.body || {}).nota)) }); }
export async function incidenciasResumen(req, res) { res.json({ ok: true, ...(await I.resumen(req.usuario)) }); }
