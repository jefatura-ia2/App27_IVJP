import { ARTICULOS, ORDEN } from '../services/articulosPermisos.js';
/**
 * Módulo Ausencias → Justificar ausencia. Cada docente trabaja con SUS ausencias (las de la cuenta con la que
 * ha entrado); las cuentas de administración pueden ver y gestionar cualquier justificación.
 * Los errores van con estado 400/404 (nunca 401/403) para que la app no cierre la sesión.
 */
import fs from 'node:fs';
import multer from 'multer';
import { config } from '../config.js';
import { profesorDeCuenta } from '../services/authService.js';
import * as J from '../services/justificacionService.js';

export const subirPDFs = (req, res, next) => multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: config.maxPdfMb * 1024 * 1024, files: J.MAX_POR_SUBIDA, fields: 20, parts: J.MAX_POR_SUBIDA + 20 },
}).array('archivos', J.MAX_POR_SUBIDA)(req, res, e => {
  if (!e) return next();
  const msg = e.code === 'LIMIT_FILE_SIZE' ? `Cada PDF puede ocupar como máximo ${config.maxPdfMb} MB`
    : e.code === 'LIMIT_FILE_COUNT' || e.code === 'LIMIT_UNEXPECTED_FILE' ? `Como máximo ${J.MAX_DOCS} documentos` : e.message;
  res.status(400).json({ ok: false, error: msg });
});

const err = (msg, status = 400) => Object.assign(new Error(msg), { status });
const esAdmin = req => req.usuario.rol === 'admin';
async function profesor(req) {
  const p = await profesorDeCuenta(req.usuario.nombre);
  if (!p && !esAdmin(req)) throw err('Tu cuenta no está vinculada a ningún profesor/a del horario. Pide a Jefatura que revise el nombre de tu cuenta.');
  return p;
}

export async function mias(req, res) {
  const p = await profesor(req);
  if (!p) return res.json({ ok: true, profesor: null, ausencias: [], justificaciones: [], sinJustificar: 0, alerta: null, articulos: ARTICULOS, orden: ORDEN, maxMb: config.maxPdfMb });
  res.json({ ok: true, ...(await J.mias(p)) });
}

export async function crear(req, res) {
  const p = await profesor(req);
  if (!p) throw err('Esta cuenta no tiene horario: no puede justificar ausencias');
  let datos;
  try { datos = JSON.parse(req.body.datos || '{}'); } catch { throw err('Datos no válidos'); }
  const id = await J.crear(p, datos, req.files || [], req.usuario.usuario);
  res.json({ ok: true, id, ...(await J.mias(p)) });
}

export async function añadirDocs(req, res) {
  const p = await profesor(req);
  await J.añadirDocs(Number(req.params.id), p, esAdmin(req), req.files || []);
  res.json({ ok: true, ...(p ? await J.mias(p) : {}) });
}
export async function borrarDoc(req, res) {
  const p = await profesor(req);
  await J.borrarDoc(Number(req.params.id), Number(req.params.docId), p, esAdmin(req));
  res.json({ ok: true, ...(p ? await J.mias(p) : {}) });
}
export async function borrar(req, res) {
  const p = await profesor(req);
  await J.borrar(Number(req.params.id), p, esAdmin(req));
  res.json({ ok: true, ...(p ? await J.mias(p) : {}) });
}
export async function archivo(req, res) {
  const p = await profesor(req);
  const d = await J.documento(Number(req.params.id), Number(req.params.docId), p, esAdmin(req));
  if (!fs.existsSync(d.ruta)) throw err('El archivo ya no está en el servidor', 404);
  res.set({ 'Content-Type': 'application/pdf', 'Content-Disposition': `inline; filename*=UTF-8''${encodeURIComponent(d.nombre)}`, 'Cache-Control': 'no-store' });
  fs.createReadStream(d.ruta).pipe(res);
}
