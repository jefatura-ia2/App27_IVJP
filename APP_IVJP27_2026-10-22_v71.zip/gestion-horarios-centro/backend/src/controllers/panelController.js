import * as P from '../services/panelService.js';

/** GET /api/panel/datos?t=… — sin sesión, con el enlace secreto del panel (respuesta 200 siempre) */
export async function datos(req, res) {
  /* opcional: PANEL_IPS=10.0.0.5,10.0.0.6 limita la pantalla sin sesión a los equipos de la sala de profesores */
  const ips = (process.env.PANEL_IPS || '').split(',').map(x => x.trim()).filter(Boolean);
  if (ips.length && !ips.some(ip => String(req.ip || '').replace(/^::ffff:/, '').startsWith(ip))) return res.json({ ok: false, error: 'Este equipo no puede mostrar el panel. Pide a Jefatura que lo autorice.' });
  if (!(await P.tokenValido(req.query.t))) return res.json({ ok: false, error: 'Enlace del panel no válido o cambiado. Pide el nuevo a Jefatura de Estudios.' });
  res.set('Cache-Control', 'no-store');
  res.json(await P.datos());
}
/** GET /api/panel/config — (administración) enlace y ajustes del panel */
export async function config(req, res) {
  res.json({ ok: true, token: await P.token(), config: await P.leerConfig() });
}
/** PUT /api/panel/config { mensaje, enlaces, segundosAviso, regenerar } */
export async function guardar(req, res) {
  const b = req.body || {};
  res.json({ ok: true, ...(await P.guardarConfig(b, { regenerar: !!b.regenerar })) });
}
