/** Protección de datos: información de privacidad (pública), plazos, cierre de curso y registro de accesos */
import * as R from '../services/rgpdService.js';
import * as Reg from '../services/registroAccesos.js';

/* pública (también antes de iniciar sesión) */
export async function privacidad(req, res) { res.json({ ok: true, ...(await R.privacidad()) }); }
export async function guardarPrivacidad(req, res) {
  const r = await R.guardarPrivacidad(req.usuario, req.body || {});
  Reg.registrar(req, 'privacidad');
  res.json({ ok: true, ...r });
}
export async function guardarPlazos(req, res) { res.json({ ok: true, plazos: await R.guardarPlazos(req.usuario, (req.body || {}).plazos) }); }
export async function previsualizar(req, res) { res.json({ ok: true, ...(await R.previsualizar(req.usuario)) }); }
export async function cierre(req, res) {
  if ((req.body || {}).confirmar !== 'BORRAR') return res.status(400).json({ ok: false, error: 'Escribe BORRAR para confirmar' });
  const r = await R.cierreDeCurso(req.usuario);
  Reg.registrar(req, 'cierre_curso', Object.entries(r.borrado).map(([k, n]) => k + ': ' + n).join(', '));
  res.json({ ok: true, ...r });
}
export async function registro(req, res) { res.json({ ok: true, ...(await Reg.listar(req.usuario, req.query)) }); }
