/**
 * Avisos, calendarios y ausencias con la misma interfaz que tenía el servicio de Apps Script
 * (GET ?accion=datos · POST {accion, clave, …}), ahora resuelta con la base de datos de la app.
 * Las respuestas de error van con estado 200 y {error}, como antes, para que la app no cierre la sesión.
 */
import { claveAdminOk } from '../services/programacionesService.js';
import * as S from '../services/servicioService.js';
import { verificarPropia } from '../services/authService.js';
import { emitir, revocar } from '../services/modoAdmin.js';
import { registrar } from '../services/registroAccesos.js';
import * as DAP from '../services/dapService.js';


export async function get(req, res) {
  const accion = req.query.accion || 'datos';
  if (accion === 'ping') return res.json({ ok: true, version: 'base de datos de la app' });
  if (accion !== 'datos') return res.json({ error: 'Acción no válida' });
  res.json(await S.datosPublicos());
}

export async function post(req, res) {
  const p = req.body || {};
  if (p.accion === 'login') {
    /* candado con la contraseña personal de una cuenta de administración → pase temporal */
    const u = req.usuario;
    if (u && u.rol === 'admin') {
      let ok = false;
      try { ok = await verificarPropia(u.id, String(p.clave || ''), req.ip); } catch (e) { return res.json({ ok: false, error: e.message }); }
      if (ok) { registrar(req, 'modo_admin'); return res.json({ ok: true, pase: emitir(u) }); }
    }
    if (claveAdminOk(p.clave)) { registrar(req, 'modo_admin', 'clave común'); return res.json({ ok: true }); }
    registrar(req, 'modo_admin_fallido');
    return res.json({ ok: false, error: u && u.rol === 'admin' ? 'Contraseña incorrecta: escribe la contraseña de tu cuenta' : 'Tu cuenta no es de administración' });
  }
  if (p.accion === 'logout_admin') { revocar(p.clave); return res.json({ ok: true }); }
  if (!claveAdminOk(p.clave)) return res.json({ error: 'Contraseña incorrecta' });
  const por = req.usuario ? req.usuario.usuario : '';
  const conDatos = async extra => res.json({ ok: true, datos: await S.datosPublicos(), ...extra });
  try {
    switch (p.accion) {
      case 'ausencias_admin': registrar(req, 'ausencias_admin'); return res.json({ ok: true, ausencias: await S.ausenciasAdmin() });
      case 'ausencia_guardar': await S.guardarAusencia(p.ausencia, por); return conDatos({ ausencias: await S.ausenciasAdmin() });
      case 'ausencias_semana': await S.guardarSemana(p, por); return conDatos({ ausencias: await S.ausenciasAdmin() });
      case 'ausencia_grabar': await S.grabarAusencias(p.ids || [p.id]); return conDatos({ ausencias: await S.ausenciasAdmin() });
      case 'ausencia_borrar': await S.borrarAusencias(p.ids || [p.id]); return conDatos({ ausencias: await S.ausenciasAdmin() });
      case 'aviso_guardar': await S.guardarAviso(p.aviso); return conDatos();
      case 'aviso_borrar': await S.borrarAviso(p.id); return conDatos();
      case 'calendario_guardar': {
        await S.guardarCalendario(p.clave_cal, p.calendario);
        if (p.clave_cal === 'dap') await DAP.sincronizar({ forzar: true }).catch(() => {});
        return conDatos();
      }
      /* calendario de asuntos propios → ausencias */
      case 'dap_estado': return res.json({ ok: true, dap: await DAP.leerEstado() });
      case 'dap_sincronizar': await DAP.sincronizar({ forzar: true }); return conDatos({ dap: await DAP.leerEstado(), ausencias: await S.ausenciasAdmin() });
      case 'dap_asignar': await DAP.asignar(p.titulo, p.profesor); return conDatos({ dap: await DAP.leerEstado(), ausencias: await S.ausenciasAdmin() });
    }
  } catch (e) { if (!e.status) console.error(e); return res.json({ error: e.status ? e.message : 'Error interno' }); }
  res.json({ error: 'Acción no válida' });
}
