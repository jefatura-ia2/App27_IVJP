import { config } from '../config.js';
import { igualSeguro } from '../services/contexto.js';
import { sincronizarHorarios, ultimasSincronizaciones } from '../ingestors/index.js';

export function soloAdmin(req, res, next) {
  if (!config.adminToken || config.adminToken === 'cambia-este-token' || !igualSeguro(req.get('X-Admin-Token') || '', config.adminToken)) return res.status(401).json({ error: 'No autorizado' });
  next();
}

/** POST /api/sync  { origen: 'horarios' | 'todo' }  (las ausencias ya están en la base de datos) */
export async function sincronizar(req, res) {
  const origen = (req.body && req.body.origen) || 'horarios';
  const r = {};
  if (origen === 'horarios' || origen === 'todo') r.horarios = await sincronizarHorarios();
  res.json(r);
}

/** GET /api/sync/estado — última sincronización de cada origen */
export async function estado(req, res) { res.json(await ultimasSincronizaciones()); }
