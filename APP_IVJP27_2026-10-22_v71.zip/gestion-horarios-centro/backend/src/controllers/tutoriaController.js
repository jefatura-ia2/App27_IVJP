import * as T from '../services/tutoriaService.js';
import { profesorDeCuenta } from '../services/authService.js';

const esAdmin = req => req.usuario.rol === 'admin';

/** GET /api/tutoria/mia — grupos de los que es tutor/a la cuenta, y fecha de la reunión */
export async function mia(req, res) {
  const profesor = await profesorDeCuenta(req.usuario.nombre);
  const grupos = esAdmin(req) ? (await T.listar()).tutorias : await T.gruposDe(profesor);
  res.json({ ok: true, grupos, reunion: await T.reunion(), admin: esAdmin(req) });
}
/** GET /api/tutoria/grupo/:grupo — datos para la presentación (solo su tutor/a o administración) */
export async function grupo(req, res) {
  const profesor = await profesorDeCuenta(req.usuario.nombre);
  if (!(await T.puedeVer(req.params.grupo, { esAdmin: esAdmin(req), profesor })))
    return res.status(403).json({ ok: false, error: 'Solo el tutor/a de este grupo puede preparar su presentación' });
  res.json({ ok: true, ...(await T.datosGrupo(req.params.grupo)) });
}
/* administración */
export async function listar(req, res) { res.json({ ok: true, ...(await T.listar()), reunion: await T.reunion() }); }
export async function asignar(req, res) { await T.asignar(req.params.grupo, req.body.profesor, req.body.nombreGrupo); res.json({ ok: true }); }
export async function guardarReunion(req, res) { res.json({ ok: true, reunion: await T.guardarReunion(req.body || {}) }); }

/** PUT /api/tutoria/grupo/:grupo/delegados  { delegado, subdelegado } — su tutor/a o administración */
export async function delegados(req, res) {
  const profesor = await profesorDeCuenta(req.usuario.nombre);
  if (!(await T.puedeVer(req.params.grupo, { esAdmin: esAdmin(req), profesor })))
    return res.status(403).json({ ok: false, error: 'Solo el tutor/a de este grupo puede cambiar sus delegados' });
  res.json({ ok: true, ...(await T.guardarDelegados(req.params.grupo, req.body || {})) });
}

/** GET /api/grupo-info?grupo=E1A — cabecera del horario del grupo: tutor/a, delegado/a y subdelegado/a (todo el claustro) */
export async function info(req, res) {
  const { query } = await import('../db.js');
  const g = String(req.query.grupo || '').trim();
  const { rows } = await query('SELECT profesor, nombre_grupo AS "nombreGrupo", delegado, subdelegado FROM tutoria WHERE grupo = $1', [g]);
  const GA = await import('../services/grupoAlumnosService.js');
  res.json({ ok: true, grupo: g, alumnos: await GA.uno(g), puedeEditarAlumnos: GA.puedeEditar(req.usuario), tutor: rows[0] ? rows[0].profesor : '', nombreGrupo: rows[0] ? rows[0].nombreGrupo : '',
    delegado: rows[0] ? rows[0].delegado : '', subdelegado: rows[0] ? rows[0].subdelegado : '' });
}

/** GET /api/grupos/alumnos — nº de alumnos por grupo (todo el claustro) */
export async function alumnos(req, res) {
  const GA = await import('../services/grupoAlumnosService.js');
  res.json({ ok: true, ...(await GA.todos(req.usuario)) });
}
/** PUT /api/grupos/alumnos { valores: { E1A: 25 } } — Jefatura de Estudios */
export async function guardarAlumnos(req, res) {
  const GA = await import('../services/grupoAlumnosService.js');
  res.json({ ok: true, ...(await GA.guardar(req.usuario, (req.body || {}).valores)) });
}
