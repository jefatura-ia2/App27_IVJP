import { config, ficheroEnv } from './config.js';
console.log(ficheroEnv ? `Configuración leída de: ${ficheroEnv}` : '*** No encuentro backend/.env: se usan los valores por defecto ***');
import { pool } from './db.js';
import { migrar } from './models/index.js';
import { crearApp } from './app.js';
import { importacionInicial } from './services/importacionInicial.js';
import { iniciar as iniciarBiblioteca } from './services/bibliotecaService.js';
import { programar as programarDap } from './services/dapService.js';
import { prepararCarpetas as carpetasDisciplina, carpetaBase as carpetaDisciplina, purgarRecibidos } from './services/disciplinaService.js';

try {
  await migrar(pool);
} catch (e) {
  console.error('\n*** No se pudo arrancar: fallo al conectar o preparar la base de datos ***');
  console.error('Motivo:', e.message);
  if (e.code === 'ECONNREFUSED') console.error('-> PostgreSQL no está en marcha. Arráncalo (Servicios de Windows: «postgresql») y vuelve a intentarlo.');
  else if (e.code === '28P01') console.error('-> La contraseña de DATABASE_URL en backend/.env no es la del usuario de PostgreSQL.');
  else if (e.code === '3D000') console.error('-> La base de datos de DATABASE_URL no existe. Créala en SQL Shell: CREATE DATABASE horarios OWNER horarios;');
  else if (e.code === '42501') console.error('-> El usuario de la base de datos no tiene permisos. En SQL Shell: ALTER DATABASE horarios OWNER TO horarios;');
  console.error('Revisa la línea DATABASE_URL de backend/.env\n');
  process.exit(1);
}
import('./services/programacionesService.js').then(m => m.protegerClavesDep()).then(n => { if (n) console.log(`Programaciones: ${n} claves de departamento guardadas ya cifradas`); }).catch(e => console.log('Programaciones:', e.message));
if (!process.env.GOOGLE_CLAVE) console.log('Aviso de seguridad: define GOOGLE_CLAVE (distinta de ADMIN_PASSWORD) para el script de Google de la hoja.');
if (!process.env.ADMIN_TOKEN || process.env.ADMIN_TOKEN === 'cambia-este-token') console.log('Aviso de seguridad: /api/sync está desactivado hasta que pongas un ADMIN_TOKEN propio en .env.');
await import('./services/googleServicio.js').then(m => m.cargar()).catch(e => console.log('Servicio de Google:', e.message));
importacionInicial().catch(() => {});   /* una sola vez: trae a la base de datos lo que había en la hoja de Google */
iniciarBiblioteca().catch(e => console.log('Biblioteca:', e.message));   /* una sola vez: trae los registros G.B./MAY55 de su hoja */
try { carpetasDisciplina(); console.log('Partes de disciplina en:', carpetaDisciplina()); } catch (e) { console.log('Disciplina: no se pudo crear la carpeta:', e.message); }
try { const n = await purgarRecibidos(); if (n) console.log(`Disciplina: ${n} PDF de partes ya recibidos borrados de la carpeta (protección de datos)`); } catch (e) { console.log('Disciplina: no se pudo limpiar la carpeta:', e.message); }
import('./services/dapSolicitudes.js').then(m => m.crearCuentas()).catch(e => console.log('DAP:', e.message));
import('./services/ccpService.js').then(m => m.marcarMiembros()).catch(e => console.log('CCP:', e.message));
import('./services/authService.js').then(m => m.restaurarAdministradores()).catch(e => console.log('Administración:', e.message));
import('./services/authService.js').then(m => m.marcarProfesorado()).then(n => { if (n) console.log(`Perfiles: ${n} cuentas marcadas como profesorado`); }).catch(e => console.log('Perfiles:', e.message));
programarDap();   /* calendario de asuntos propios (DAP) → ausencias, al arrancar y cada 15 minutos */
const server = crearApp().listen(config.port, () => console.log(`API de horarios en http://localhost:${config.port}/api`));
server.on('error', e => {
  if (e.code === 'EADDRINUSE') console.error(`\n*** El puerto ${config.port} ya está ocupado: ¿hay otra ventana con el servidor abierta? Ciérrala o cambia PORT en backend/.env ***\n`);
  else console.error(e);
  process.exit(1);
});

const parar = async () => { server.close(); await pool.end(); process.exit(0); };
process.on('SIGINT', parar);
process.on('SIGTERM', parar);
