/**
 * Ausencia del profesorado. Vive en la base de datos de la app (ya no en la hoja de Google).
 *  · estado 'Pendiente': notificada por el docente desde la app, a la espera de que Jefatura la grabe.
 *  · estado 'Grabada'  : validada por Jefatura; es la que cuenta en Guardias de aula y en los informes.
 * `horas` vacío + modo 'dia' = todo el día. `motivo` es privado: solo lo ve administración.
 */
export const DDL = `
CREATE TABLE IF NOT EXISTS ausencia (
  id          TEXT PRIMARY KEY,
  profesor    TEXT NOT NULL,                   -- nombre tal como está en el horario
  profesor_id INT REFERENCES profesor(id) ON DELETE SET NULL,
  fecha       DATE NOT NULL,
  hasta       DATE,
  modo        TEXT NOT NULL CHECK (modo IN ('dia','horas')),
  horas       TEXT[] NOT NULL DEFAULT '{}',
  tarea       TEXT NOT NULL DEFAULT '',        -- observaciones / tarea para la guardia
  sincronizado TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE ausencia ADD COLUMN IF NOT EXISTS motivo TEXT NOT NULL DEFAULT '';
ALTER TABLE ausencia ADD COLUMN IF NOT EXISTS estado TEXT NOT NULL DEFAULT 'Grabada';
ALTER TABLE ausencia ADD COLUMN IF NOT EXISTS creado TIMESTAMPTZ NOT NULL DEFAULT now();
ALTER TABLE ausencia ADD COLUMN IF NOT EXISTS registrado_por TEXT NOT NULL DEFAULT '';
ALTER TABLE ausencia ADD COLUMN IF NOT EXISTS canal TEXT NOT NULL DEFAULT '';            -- cómo llegó a Jefatura si no la notificó el docente en la app
-- por tramo: aula donde se queda el grupo y tarea para la guardia {"3":{"aula":"209","obs":"…"}}
ALTER TABLE ausencia ADD COLUMN IF NOT EXISTS detalle JSONB NOT NULL DEFAULT '{}'::jsonb;
CREATE INDEX IF NOT EXISTS ausencia_fecha_idx ON ausencia (fecha, hasta);`;

export const PENDIENTE = 'Pendiente', GRABADA = 'Grabada';

/** Ausencias GRABADAS que afectan a una fecha (YYYY-MM-DD): las que usa Guardias de aula */
export async function delDia(db, fecha) {
  const { rows } = await db.query(
    `SELECT id, profesor, profesor_id, to_char(fecha,'YYYY-MM-DD') AS fecha, to_char(hasta,'YYYY-MM-DD') AS hasta,
            modo, horas, tarea, detalle, motivo
     FROM ausencia WHERE estado = 'Grabada' AND fecha <= $1::date AND COALESCE(hasta, fecha) >= $1::date
     ORDER BY profesor`, [fecha]);
  return rows;
}
