/** Módulo DAP: solicitudes de días de asuntos particulares, días bloqueados y registro de avisos */
export const DDL = `
CREATE TABLE IF NOT EXISTS dap_solicitud (
  id            SERIAL PRIMARY KEY,
  profesor      TEXT NOT NULL,                 -- «Apellidos, Nombre» como en el horario
  usuario       TEXT NOT NULL DEFAULT '',
  fecha         DATE NOT NULL,
  turnos        TEXT[] NOT NULL DEFAULT '{diurno}',   -- diurno / vespertino (según su horario ese día)
  estado        TEXT NOT NULL DEFAULT 'solicitada' CHECK (estado IN ('solicitada','concedida','denegada','revocada','anulada')),
  observaciones TEXT NOT NULL DEFAULT '',
  creado        TIMESTAMPTZ NOT NULL DEFAULT now(),
  resuelto      TIMESTAMPTZ,
  resuelto_por  TEXT NOT NULL DEFAULT '',
  nota          TEXT NOT NULL DEFAULT '',      -- motivo de la denegación o revocación
  fuerza_mayor  BOOLEAN NOT NULL DEFAULT false,
  visto         BOOLEAN NOT NULL DEFAULT true  -- el profesor/a ya vio la última resolución
);
-- sincronización con el calendario de Google «Asuntos propios (DAP)» (evento creado al conceder, borrado al revocar)
ALTER TABLE dap_solicitud ADD COLUMN IF NOT EXISTS gcal_id TEXT NOT NULL DEFAULT '';
ALTER TABLE dap_solicitud ADD COLUMN IF NOT EXISTS gcal_error TEXT NOT NULL DEFAULT '';
CREATE INDEX IF NOT EXISTS dap_solicitud_fecha_idx ON dap_solicitud (fecha, estado);
CREATE TABLE IF NOT EXISTS dap_bloqueo (
  fecha   DATE PRIMARY KEY,
  motivo  TEXT NOT NULL DEFAULT '',
  por     TEXT NOT NULL DEFAULT '',
  creado  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS dap_evento (
  id           SERIAL PRIMARY KEY,
  solicitud_id INT NOT NULL,
  tipo         TEXT NOT NULL,                  -- solicitud · concesion · denegacion · revocacion · anulacion
  por          TEXT NOT NULL DEFAULT '',
  creado       TIMESTAMPTZ NOT NULL DEFAULT now()
);`;
