/** Firma de las guardias (aula y recreo) por el profesorado, y convocatorias de la CCP */
export const DDL = `
CREATE TABLE IF NOT EXISTS guardia_firma (
  id        SERIAL PRIMARY KEY,
  fecha     DATE NOT NULL,
  tramo     TEXT NOT NULL,
  tipo      TEXT NOT NULL CHECK (tipo IN ('aula','recreo')),
  profesor  TEXT NOT NULL,                 -- «Apellidos, Nombre» como en el horario
  usuario   TEXT NOT NULL DEFAULT '',
  zona      TEXT NOT NULL DEFAULT '',
  firmado   TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (fecha, tramo, profesor)
);
CREATE TABLE IF NOT EXISTS ccp_reunion (
  id        SERIAL PRIMARY KEY,
  fecha     DATE NOT NULL,
  hora      TEXT NOT NULL,
  lugar     TEXT NOT NULL DEFAULT '',
  orden     TEXT NOT NULL DEFAULT '',      -- orden del día
  convoca   TEXT NOT NULL DEFAULT '',
  anulada   BOOLEAN NOT NULL DEFAULT false,
  creado    TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- órgano convocado: 'ccp' (Comisión de Coordinación Pedagógica) o 'consejo' (Consejo Escolar)
ALTER TABLE ccp_reunion ADD COLUMN IF NOT EXISTS organo TEXT NOT NULL DEFAULT 'ccp';
-- incidencias en las aulas: las marca cualquier usuario; las ven y resuelven Jefatura de Estudios y Conserjería
CREATE TABLE IF NOT EXISTS aula_incidencia (
  id          SERIAL PRIMARY KEY,
  aula        TEXT NOT NULL,
  descripcion TEXT NOT NULL,
  usuario     TEXT NOT NULL DEFAULT '',
  nombre      TEXT NOT NULL DEFAULT '',
  creado      TIMESTAMPTZ NOT NULL DEFAULT now(),
  resuelta    BOOLEAN NOT NULL DEFAULT false,
  resuelto    TIMESTAMPTZ,
  resuelto_por TEXT NOT NULL DEFAULT '',
  nota        TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS aula_incidencia_idx ON aula_incidencia (resuelta, aula);
CREATE TABLE IF NOT EXISTS ccp_enterado (
  reunion_id INT NOT NULL,
  usuario    TEXT NOT NULL,
  nombre     TEXT NOT NULL DEFAULT '',
  cuando     TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (reunion_id, usuario)
);`;
