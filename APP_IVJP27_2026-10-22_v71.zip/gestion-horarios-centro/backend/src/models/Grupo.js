/** Grupo de alumnado (E1A, B2B, 1º CFGB…) */
export const DDL = `
CREATE TABLE IF NOT EXISTS grupo (
  id     SERIAL PRIMARY KEY,
  codigo TEXT NOT NULL UNIQUE
);
-- nº de alumnos de cada grupo: lo escribe Jefatura de Estudios (no depende del CSV del horario)
CREATE TABLE IF NOT EXISTS grupo_alumnos (
  grupo       TEXT PRIMARY KEY,
  alumnos     INTEGER NOT NULL CHECK (alumnos >= 0 AND alumnos <= 999),
  actualizado TIMESTAMPTZ NOT NULL DEFAULT now(),
  por         TEXT NOT NULL DEFAULT ''
);`;

export async function upsert(db, codigo) {
  const { rows } = await db.query(
    `INSERT INTO grupo (codigo) VALUES ($1) ON CONFLICT (codigo) DO UPDATE SET codigo = EXCLUDED.codigo RETURNING id`, [codigo]);
  return rows[0].id;
}

export async function listar(db) {
  const { rows } = await db.query(`SELECT id, codigo FROM grupo ORDER BY codigo`);
  return rows;
}
