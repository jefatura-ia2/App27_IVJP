/**
 * Cuentas de acceso a la app (profesorado y administración) y sus sesiones.
 * Las contraseñas se guardan con scrypt + sal; las sesiones, como hash SHA-256 del token
 * (el token solo viaja en una cookie HttpOnly).
 */
export const DDL = `
CREATE TABLE IF NOT EXISTS usuario (
  id             SERIAL PRIMARY KEY,
  usuario        TEXT NOT NULL UNIQUE,
  nombre         TEXT NOT NULL DEFAULT '',
  rol            TEXT NOT NULL DEFAULT 'profesor' CHECK (rol IN ('profesor','admin')),
  clave_hash     TEXT NOT NULL,
  cambiar_clave  BOOLEAN NOT NULL DEFAULT TRUE,
  activo         BOOLEAN NOT NULL DEFAULT TRUE,
  creado         TIMESTAMPTZ NOT NULL DEFAULT now(),
  ultimo_acceso  TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS sesion (
  token_hash  TEXT PRIMARY KEY,
  usuario_id  INT NOT NULL REFERENCES usuario(id) ON DELETE CASCADE,
  creada      TIMESTAMPTZ NOT NULL DEFAULT now(),
  caduca      TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS sesion_usuario_idx ON sesion (usuario_id);
-- datos de contacto que cada docente rellena al entrar; los años trabajados sirven para calcular sus días de asuntos propios
ALTER TABLE usuario ADD COLUMN IF NOT EXISTS email TEXT NOT NULL DEFAULT '';
ALTER TABLE usuario ADD COLUMN IF NOT EXISTS movil TEXT NOT NULL DEFAULT '';
ALTER TABLE usuario ADD COLUMN IF NOT EXISTS anios_servicio INT;
ALTER TABLE usuario ADD COLUMN IF NOT EXISTS datos_fecha DATE;
-- perfil «jefe_departamento»: departamento que dirige · perfil «coordinador_proyectos»: proyectos que coordina
ALTER TABLE usuario ADD COLUMN IF NOT EXISTS departamento_jefe TEXT NOT NULL DEFAULT '';
ALTER TABLE usuario ADD COLUMN IF NOT EXISTS proyectos TEXT NOT NULL DEFAULT '';
-- perfil «jefe_estudios»: etapa que lleva (eso, bach, fpd, fp) o «todas» (Jefe/a de Estudios)
ALTER TABLE usuario ADD COLUMN IF NOT EXISTS jefe_estudios_etapa TEXT NOT NULL DEFAULT '';
-- horario vinculado a mano por el administrador (p. ej. profesorado nuevo o sustituto que ocupa el horario de otro nombre)
ALTER TABLE usuario ADD COLUMN IF NOT EXISTS profesor_horario TEXT NOT NULL DEFAULT '';
-- protección de datos: sesión en equipo compartido (corta) y caducidad de la contraseña provisional (72 h)
ALTER TABLE sesion ADD COLUMN IF NOT EXISTS compartido BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE usuario ADD COLUMN IF NOT EXISTS provisional_hasta TIMESTAMPTZ;
-- registro de accesos a datos personales sensibles (RGPD art. 5.2 y 32 · ENS op.exp.8)
CREATE TABLE IF NOT EXISTS registro_acceso (
  id      BIGSERIAL PRIMARY KEY,
  cuando  TIMESTAMPTZ NOT NULL DEFAULT now(),
  usuario TEXT NOT NULL DEFAULT '',
  nombre  TEXT NOT NULL DEFAULT '',
  accion  TEXT NOT NULL,
  objeto  TEXT NOT NULL DEFAULT '',
  ip      TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS registro_acceso_cuando_idx ON registro_acceso (cuando DESC);`;
