import * as Tramo from './Tramo.js';
import * as Profesor from './Profesor.js';
import * as Grupo from './Grupo.js';
import * as Aula from './Aula.js';
import * as Clase from './Clase.js';
import * as Ausencia from './Ausencia.js';
import * as Departamento from './Departamento.js';
import * as Documento from './Documento.js';
import * as GuardiaBiblioteca from './GuardiaBiblioteca.js';
import * as Usuario from './Usuario.js';
import * as BibliotecaRegistro from './BibliotecaRegistro.js';
import * as Ajuste from './Ajuste.js';
import * as Tutoria from './Tutoria.js';
import * as Reserva from './Reserva.js';
import * as Aviso from './Aviso.js';
import * as Justificacion from './Justificacion.js';
import * as ParteDisciplina from './ParteDisciplina.js';
import * as DapSolicitud from './DapSolicitud.js';
import * as FirmaGuardia from './FirmaGuardia.js';
import { sembrar as sembrarUsuarios } from '../services/authService.js';

export { Tramo, Profesor, Grupo, Aula, Clase, Ausencia, Departamento, Documento, GuardiaBiblioteca, Usuario, Ajuste, Tutoria, Reserva, Aviso, Justificacion, BibliotecaRegistro, ParteDisciplina, DapSolicitud, FirmaGuardia };

/* Orden de creación: primero las tablas referenciadas */
const MODELOS = [Tramo, Profesor, Grupo, Aula, Clase, Ausencia, Departamento, Documento, GuardiaBiblioteca, Usuario, Ajuste, Tutoria, Reserva, Aviso, Justificacion, BibliotecaRegistro, ParteDisciplina, DapSolicitud, FirmaGuardia];

export const DDL_SINCRONIZACION = `
CREATE TABLE IF NOT EXISTS sincronizacion (
  id        SERIAL PRIMARY KEY,
  origen    TEXT NOT NULL,            -- 'csv-horarios' | 'hoja-ausencias'
  inicio    TIMESTAMPTZ NOT NULL DEFAULT now(),
  fin       TIMESTAMPTZ,
  ok        BOOLEAN,
  detalle   JSONB
);`;

export async function migrar(db) {
  for (const m of MODELOS) await db.query(m.DDL);
  await db.query(DDL_SINCRONIZACION);
  await Tramo.sembrar(db);
  await Departamento.sembrar(db);
  await Tutoria.sembrar(db);
  await Reserva.sembrar(db);
  await sembrarUsuarios(db);
}
