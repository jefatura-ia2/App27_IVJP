import { Router } from 'express';
import * as horarios from './controllers/horariosController.js';
import * as aulas from './controllers/aulasController.js';
import * as guardias from './controllers/guardiasController.js';
import * as sync from './controllers/syncController.js';
import * as prog from './controllers/programacionesController.js';
import * as edicion from './controllers/edicionController.js';
import * as biblioteca from './controllers/bibliotecaController.js';
import * as auth from './controllers/authController.js';
import * as ausencias from './controllers/ausenciasController.js';
import * as tutoria from './controllers/tutoriaController.js';
import * as reserva from './controllers/reservaController.js';
import * as meet from './controllers/meetController.js';
import * as servicio from './controllers/servicioController.js';
import * as justif from './controllers/justificacionController.js';
import * as panel from './controllers/panelController.js';
import * as crono from './controllers/cronologiaController.js';
import * as disciplina from './controllers/disciplinaController.js';
import * as dap from './controllers/dapController.js';
import * as fc from './controllers/firmasCcpController.js';
import { validarDoc } from './services/firma.js';
import { registrar } from './services/registroAccesos.js';
import * as rgpd from './controllers/rgpdController.js';

/* Express 4 no captura promesas rechazadas: este envoltorio las pasa al manejador de errores */
/* registro de accesos a datos sensibles (no frena la petición) */
const reg = (accion, objeto = () => '') => (req, res, next) => { registrar(req, accion, objeto(req)); next(); };
const a = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

export const rutas = Router();
rutas.get('/salud', (req, res) => res.json({ ok: true }));

/* Acceso: lo único público es /salud y el inicio de sesión; todo lo demás exige sesión */
rutas.post('/auth/login', a(auth.login));
rutas.post('/sync', sync.soloAdmin, a(sync.sincronizar));   /* para scripts: protegido con X-Admin-Token */
/* PDF de programaciones con enlace firmado (?f=…): se abren sin sesión desde el navegador del móvil */
rutas.get('/programaciones/:id/documentos/:docId/archivo', a(async (req, res, next) => {
  if (req.query.f && await validarDoc(Number(req.params.docId), req.query.f)) return prog.archivo(req, res);
  next();
}));
/* Panel de la sala de profesores: pantalla sin sesión con enlace secreto (solo lectura) */
rutas.get('/panel/datos', a(panel.datos));
rutas.get('/panel/hoy', a(auth.panelHoy));
rutas.get('/panel/biblioteca-hoy', a(auth.panelBibliotecaHoy));   /* cuadrante de la Biblioteca (módulo Biblioteca) */   /* cuadrante del día para el profesorado con sesión (Guardias y Biblioteca) */
rutas.get('/cronologia/reunion/:id', a(crono.reunion));   /* pública: página de las familias */
rutas.get('/dap/verificar', a(dap.verificar));   /* pública: autenticidad de una resolución de DAP */
rutas.get('/privacidad', a(rgpd.privacidad));   /* pública: información de protección de datos */
rutas.use(auth.requiereSesion);
rutas.put('/privacidad', auth.soloAdminCuenta, a(rgpd.guardarPrivacidad));
rutas.put('/privacidad/plazos', auth.soloAdminCuenta, a(rgpd.guardarPlazos));
rutas.get('/privacidad/cierre', auth.soloAdminCuenta, a(rgpd.previsualizar));
rutas.post('/privacidad/cierre', auth.soloAdminCuenta, a(rgpd.cierre));
rutas.get('/registro-accesos', a(rgpd.registro));
rutas.get('/auth/yo', a(auth.yo));
rutas.post('/auth/logout', a(auth.logout));
rutas.post('/auth/cambiar-clave', a(auth.cambiarClave));
rutas.put('/auth/mis-datos', a(auth.misDatos));
rutas.get('/dap/ficha', a(auth.fichaDap));
rutas.get('/departamento-de', a(auth.departamentoDe));
rutas.put('/departamento-de', auth.soloAdminCuenta, a(auth.asignarDepartamento));
rutas.get('/dap/contadores', auth.soloAdminCuenta, a(auth.contadoresDap));
/* Módulo DAP: solicitudes (profesorado), resolución (Dirección) y seguimiento (Administración y Jefatura) */
rutas.get('/dap/mio', a(dap.mio));
rutas.get('/dap/calendario', a(dap.calendario));
rutas.get('/dap/avisos', a(dap.avisos));
rutas.get('/dap/solicitudes', a(dap.lista));
rutas.get('/dap/registro', a(dap.registro));
rutas.post('/dap/solicitudes', a(dap.solicitar));
rutas.post('/dap/solicitudes/:id/anular', a(dap.anular));
rutas.post('/dap/solicitudes/:id/resolver', a(dap.resolver));
rutas.post('/dap/solicitudes/:id/visto', a(dap.visto));
rutas.get('/dap/solicitudes/:id/pdf', a(dap.pdf));
rutas.get('/dap/solicitudes/:id/impreso', reg('dap_impreso', r => 'DAP ' + r.params.id), a(dap.impreso));
rutas.post('/dap/bloqueos', a(dap.bloquear));
rutas.post('/dap/sincronizar', a(dap.sincronizar));
rutas.get('/dap/diagnostico-calendario', a(dap.diagnosticoCalendario));
rutas.get('/dap/servicio-google', a(dap.servicioGoogle));
rutas.put('/dap/servicio-google', auth.soloAdminCuenta, a(dap.guardarServicioGoogle));

/* Disciplina: partes de conductas contrarias (profesorado) y bandeja de los Jefes/as de Estudios adjuntos */
rutas.get('/disciplina/config', a(disciplina.config));
rutas.get('/disciplina/mios', a(disciplina.mios));
rutas.get('/disciplina/bandeja', reg('partes_bandeja'), a(disciplina.bandeja));
rutas.get('/disciplina/resumen', a(disciplina.resumen));
rutas.get('/disciplina/carpeta', a(disciplina.carpeta));
rutas.get('/disciplina/tutoria', a(disciplina.tutoria));
rutas.post('/disciplina/:id/leido-tutor', a(disciplina.leidoTutor));
rutas.get('/disciplina/carpeta/archivo', reg('parte_carpeta', r => r.query.nombre), a(disciplina.archivoCarpeta));
rutas.post('/disciplina', a(disciplina.crear));
rutas.post('/disciplina/:id/recibido', a(disciplina.recibido));
rutas.post('/disciplina/:id/visto', a(disciplina.visto));
rutas.get('/disciplina/:id/pdf', reg('parte_pdf', r => 'parte ' + r.params.id + (r.query.copia ? ' (' + r.query.copia + ')' : '')), a(disciplina.pdf));

/* Cuentas de usuario (solo cuentas con rol administración) */
rutas.get('/usuarios', auth.soloAdminCuenta, a(auth.listar));
rutas.post('/usuarios', auth.soloAdminCuenta, a(auth.crear));
rutas.post('/usuarios/lote', auth.soloAdminCuenta, a(auth.lote));
rutas.put('/usuarios/:id', auth.soloAdminCuenta, a(auth.actualizar));
rutas.post('/usuarios/:id/restablecer', auth.soloAdminCuenta, a(auth.restablecer));
rutas.put('/usuarios/:id/datos', auth.soloAdminCuenta, reg('datos_usuario', r => 'cuenta ' + r.params.id), a(auth.datosDe));
rutas.delete('/usuarios/:id', auth.soloAdminCuenta, a(auth.borrar));
rutas.post('/perfiles', auth.soloAdminCuenta, a(auth.guardarPerfil));
rutas.get('/permisos/mios', a(auth.permisosMios));
rutas.get('/permisos', auth.soloAdminCuenta, a(auth.permisos));
rutas.put('/permisos', auth.soloAdminCuenta, a(auth.guardarPermisos));
rutas.delete('/perfiles/:k', auth.soloAdminCuenta, a(auth.borrarPerfil));

rutas.get('/tramos', a(horarios.tramos));
rutas.get('/profesores', a(horarios.profesores));
rutas.get('/grupos/alumnos', a(tutoria.alumnos));
rutas.put('/grupos/alumnos', a(tutoria.guardarAlumnos));
rutas.get('/grupos', a(horarios.grupos));
rutas.get('/buscar', a(horarios.buscar));
rutas.get('/horario.csv', a(horarios.csv));
rutas.get('/horarios/:tipo/:id', a(horarios.horarioDe));

rutas.get('/aulas', a(aulas.listar));
rutas.get('/aulas/libres', a(aulas.libres));
rutas.get('/aulas/:id/ocupacion', a(aulas.ocupacion));

rutas.get('/guardias/firmas/mias', a(fc.misFirmas));
rutas.post('/guardias/firmas', a(fc.firmar));
rutas.get('/guardias/firmas', reg('firmas_registro', r => [r.query.desde, r.query.hasta].filter(Boolean).join(' – ')), a(fc.registro));
rutas.get('/incidencias', a(fc.incidencias));
rutas.get('/incidencias/resumen', a(fc.incidenciasResumen));
rutas.post('/incidencias', a(fc.incidenciaCrear));
rutas.post('/incidencias/:id/resolver', a(fc.incidenciaResolver));
rutas.get('/ccp', a(fc.ccp));
rutas.get('/ccp/avisos', a(fc.ccpAvisos));
rutas.post('/ccp', a(fc.ccpGuardar));
rutas.post('/ccp/:id/anular', a(fc.ccpAnular));
rutas.post('/ccp/:id/enterado', a(fc.ccpEnterado));
rutas.get('/guardias/ahora', a(guardias.ahora));
rutas.get('/guardias', a(guardias.delDia));
rutas.get('/panel/config', auth.soloAdminCuenta, a(panel.config));
rutas.put('/panel/config', auth.soloAdminCuenta, a(panel.guardar));

rutas.get('/sync/estado', a(sync.estado));

/* Programaciones didácticas: login de admin y de jefes/as de departamento, subida de PDF */
rutas.get('/programaciones', a(prog.listar));
rutas.post('/programaciones', a(prog.crear));
rutas.post('/programaciones/login-admin', a(prog.loginAdmin));
rutas.post('/programaciones/:id/login', a(prog.loginJefe));
rutas.post('/programaciones/:id/documentos', prog.subirMiddleware, a(prog.subir));
rutas.get('/programaciones/:id/documentos/:docId/archivo', a(prog.archivo));
rutas.delete('/programaciones/:id/documentos/:docId', a(prog.borrarDoc));
rutas.put('/programaciones/:id/observaciones', a(prog.obs));
rutas.put('/programaciones/:id/jefe', a(prog.jefe));
rutas.put('/programaciones/:id/clave', a(prog.clave));
rutas.put('/programaciones/:id/estado', a(prog.estado));
rutas.post('/programaciones/:id/anular', a(prog.anular));

/* Edición del horario desde la app (administración) */
rutas.post('/sesiones/cambiar', edicion.soloAdmin, a(edicion.cambiar));
rutas.post('/horario/importar', edicion.soloAdmin, a(edicion.importar));
/* Enlaces de Meet de las evaluaciones (Cronología) */
/* Cronograma de la Cronología (evaluaciones, reuniones…): lo graba Jefatura, lo ve todo el claustro */
rutas.get('/cronologia', a(crono.leer));
rutas.put('/cronologia', a(crono.guardar));
rutas.get('/meet', a(meet.listar));
rutas.put('/meet/:evento', a(meet.guardar));

/* Reserva de espacios (pestaña de Aulas) */
rutas.get('/reservas/espacios', a(reserva.inicio));
rutas.get('/reservas', a(reserva.semana));
rutas.post('/reservas', a(reserva.reservar));
rutas.delete('/reservas/:id', a(reserva.anular));
rutas.post('/reservas/espacios', auth.soloAdminCuenta, a(reserva.crearEspacio));
rutas.put('/reservas/espacios/:id', auth.soloAdminCuenta, a(reserva.cambiarEspacio));
rutas.put('/reservas/espacios/:id/bloqueo', auth.soloAdminCuenta, a(reserva.bloquear));
rutas.post('/reservas/espacios/:id/bloqueo-horario', auth.soloAdminCuenta, a(reserva.bloquearDesdeHorario));

/* Reunión con familias: presentación del tutor/a con los datos de su grupo */
rutas.get('/tutoria/mia', a(tutoria.mia));
rutas.get('/grupo-info', a(tutoria.info));
rutas.get('/consejo-escolar', a(auth.consejoEscolar));
rutas.get('/tutoria/grupo/:grupo', a(tutoria.grupo));
rutas.put('/tutoria/grupo/:grupo/delegados', a(tutoria.delegados));
rutas.get('/tutorias', auth.soloAdminCuenta, a(tutoria.listar));
rutas.put('/tutorias/:grupo', auth.soloAdminCuenta, a(tutoria.asignar));
rutas.put('/tutoria/reunion', auth.soloAdminCuenta, a(tutoria.guardarReunion));
rutas.get('/horario/carga', auth.soloAdminCuenta, a(edicion.estado));
rutas.post('/horario/previa', edicion.soloAdmin, a(edicion.previa));
rutas.post('/horario/restaurar', edicion.soloAdmin, a(edicion.restaurar));

/* Guardia de recreo en biblioteca (se marca en Guardias de recreo, se ve en Biblioteca) */
rutas.get('/biblioteca/recreos', a(biblioteca.listar));
rutas.post('/biblioteca/recreos', edicion.soloAdmin, a(biblioteca.marcar));
rutas.post('/recreo/zona', a(biblioteca.zonaRecreo));   /* zonas de vigilancia del recreo: cada docente se apunta */
/* G.B. y MAY55: lo ve todo el claustro; lo editan las cuentas con perfil Biblioteca (y Jefatura) con la clave */
rutas.get('/biblioteca/registros', a(biblioteca.registros));
rutas.put('/biblioteca/registros', a(biblioteca.guardar));
rutas.post('/biblioteca/acceso', a(biblioteca.acceso));
rutas.post('/biblioteca/importar-hoja', a(biblioteca.importarHoja));
rutas.get('/biblioteca/clave', auth.soloAdminCuenta, a(biblioteca.estadoClave));
rutas.put('/biblioteca/clave', auth.soloAdminCuenta, a(biblioteca.fijarClave));

/* Notificar ausencia: cada profesor/a solo las suyas; administración, de cualquiera */
rutas.post('/ausencias/notificar', a(ausencias.notificar));
rutas.get('/ausencias/mias', a(ausencias.mias));
rutas.get('/ausencias/historial', a(ausencias.historial));
rutas.put('/ausencias/:id/tareas', a(ausencias.tareas));
rutas.post('/ausencias/informe', reg('informe_ausencias', r => (r.body || {}).mes), a(ausencias.informe));
rutas.post('/ausencias/importar-hoja', a(ausencias.importarHoja));
rutas.post('/ausencias/dossier', reg('dossier_ausencias', r => (r.body || {}).mes), a(ausencias.dossier));
/* Justificación de ausencias (cada docente, las suyas) */
rutas.get('/justificaciones/mias', a(justif.mias));
rutas.post('/justificaciones', justif.subirPDFs, a(justif.crear));
rutas.post('/justificaciones/:id/documentos', justif.subirPDFs, a(justif.añadirDocs));
rutas.delete('/justificaciones/:id/documentos/:docId', a(justif.borrarDoc));
rutas.delete('/justificaciones/:id', a(justif.borrar));
rutas.get('/justificaciones/:id/documentos/:docId/archivo', reg('justificante', r => 'justificación ' + r.params.id), a(justif.archivo));
/* Avisos, calendarios y ausencias (antes en la hoja de Google, ahora en la base de datos) */
rutas.get('/servicio', a(servicio.get));
rutas.post('/servicio', a(servicio.post));
