/**
 * Acceso a la app con usuario y contraseña (cuentas creadas por la administración).
 */
import crypto from 'node:crypto';
import { promisify } from 'node:util';
import { query } from '../db.js';
import { Ajuste } from '../models/index.js';
import { config } from '../config.js';

const scrypt = promisify(crypto.scrypt);
const err = (msg, status = 400) => Object.assign(new Error(msg), { status });
const sha = t => crypto.createHash('sha256').update(t).digest('hex');
export const DIAS_SESION = 30;
export const HORAS_COMPARTIDO = 8;   /* «equipo compartido»: sesión corta */
export const HORAS_PROVISIONAL = 72;   /* la contraseña provisional caduca a las 72 h */
/* cuentas con acceso a datos sensibles (partes, salud): contraseña de 12 caracteres */
export const esPrivilegiada = u => !!u && (u.rol === 'admin' || (u.perfiles || []).some(p => ['jefe_estudios', 'direccion', 'administracion'].includes(p)));

/* ---------- contraseñas ---------- */
export async function hashClave(clave) {
  const sal = crypto.randomBytes(16);
  const h = await scrypt(String(clave), sal, 64);
  return 'scrypt$' + sal.toString('hex') + '$' + h.toString('hex');
}
export async function verificarClave(clave, guardado) {
  const [tipo, salHex, hHex] = String(guardado || '').split('$');
  if (tipo !== 'scrypt' || !salHex || !hHex) return false;
  const h = await scrypt(String(clave), Buffer.from(salHex, 'hex'), 64);
  const esperado = Buffer.from(hHex, 'hex');
  return esperado.length === h.length && crypto.timingSafeEqual(esperado, h);
}
/** Contraseña fácil de dictar: sin 0/O ni 1/l/I */
export function claveAleatoria(n = 8) {
  const abc = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  return Array.from(crypto.randomBytes(n), b => abc[b % abc.length]).join('');
}
export function validarClaveNueva(c, u) {
  c = String(c || '');
  const min = esPrivilegiada(u) ? 12 : 8;
  if (c.length < min) throw err(`La contraseña debe tener al menos ${min} caracteres` + (min > 8 ? ' (cuentas con acceso a datos sensibles)' : ''));
  if (!/[A-Za-z]/.test(c) || !/[0-9]/.test(c)) throw err('La contraseña debe tener letras y números');
}
const normUsuario = u => String(u || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9._-]/g, '');

/* ---------- freno a los intentos fallidos (por usuario+IP, en memoria) ---------- */
const fallos = new Map();
const MAX_FALLOS = 5, BLOQUEO_MS = 15 * 60 * 1000;
function comprobarBloqueo(k) {
  const f = fallos.get(k);
  if (f && f.n >= MAX_FALLOS && Date.now() - f.t < BLOQUEO_MS) throw err('Demasiados intentos. Espera 15 minutos o pide a Jefatura que restablezca tu contraseña.', 429);
}
function anotarFallo(k) {
  if (fallos.size > 20000) for (const [x, v] of fallos) if (Date.now() - v.t > BLOQUEO_MS) fallos.delete(x);   /* acotado */
  const f = fallos.get(k); const n = f && Date.now() - f.t < BLOQUEO_MS ? f.n + 1 : 1; fallos.set(k, { n, t: Date.now() });
}
/* además del freno por usuario+IP, un freno por IP: muchos fallos desde la misma IP (con distintos usuarios) */
const MAX_FALLOS_IP = 30;
function comprobarIp(ip) {
  const f = fallos.get('ip|' + ip);
  if (f && f.n >= MAX_FALLOS_IP && Date.now() - f.t < BLOQUEO_MS) throw err('Demasiados intentos desde este equipo. Espera 15 minutos.', 429);
}
export const frenoComprobar = k => { comprobarBloqueo(k); comprobarIp(String(k).split('|')[1] || ''); };
export const frenoFallo = k => { anotarFallo(k); anotarFallo('ip|' + (String(k).split('|')[1] || '')); };
export const frenoExito = k => { fallos.delete(k); };

/* ---------- sesiones ---------- */
/* Cuentas que no son de profesorado: no se les pide correo de Educarex, móvil ni años trabajados */
export const PERFILES_SIN_DATOS = ['direccion', 'administracion', 'conserjeria', 'no_docente'];
export const sinDatosDocente = u => (u.perfiles || []).some(p => PERFILES_SIN_DATOS.includes(p));
/* qué le falta por rellenar a un docente (vacío si nada o si su cuenta no lo necesita) */
export const datosFaltan = u => (u.rol === 'admin' && !(u.perfiles || []).includes('profesor')) || sinDatosDocente(u) ? []
  /* el móvil es voluntario (protección de datos): no se reclama */
  : [!u.email && 'correo', (u.anios_servicio === null || u.anios_servicio === undefined) && 'años trabajados'].filter(Boolean);
const faltanDatos = u => u.rol !== 'admin' && !sinDatosDocente(u) && (!u.email || u.anios_servicio === null || u.anios_servicio === undefined);
const publico = u => ({ id: u.id, usuario: u.usuario, nombre: u.nombre, rol: u.rol, cambiarClave: u.cambiar_clave, perfiles: u.perfiles || [],
  departamentoJefe: u.departamento_jefe || '', proyectos: u.proyectos || '', jefeEstudios: u.jefe_estudios_etapa || '', datosFaltan: datosFaltan(u),
  email: u.email || '', movil: u.movil || '', aniosServicio: u.anios_servicio ?? null, datosPendientes: faltanDatos(u) });

/* ---------- datos del docente: correo de Educarex, móvil y años trabajados ---------- */
/** Con «parcial» se puede dejar en blanco lo que aún no se tiene (se completa más tarde); lo escrito se valida igual */
export function limpiarDatos({ email, movil, anios } = {}, { parcial = false } = {}) {
  const e = String(email || '').trim().toLowerCase();
  if (!(parcial && !e) && !/^[a-z0-9._%+-]+@educarex\.es$/.test(e)) throw err('Escribe tu cuenta de correo de Educarex (termina en @educarex.es)');
  let m = String(movil || '').replace(/[\s.()-]/g, '').replace(/^(\+|00)34/, '');
  /* el móvil es voluntario: si se escribe, tiene que ser válido */
  if (m && !/^[67]\d{8}$/.test(m)) throw err('Escribe un teléfono móvil de 9 cifras (empieza por 6 o 7)');
  const a = String(anios ?? '').trim();
  if (!(parcial && !a) && (!/^\d{1,2}$/.test(a) || +a > 50)) throw err('Escribe los años trabajados (un número entre 0 y 50)');
  if (parcial && !e && !m && !a) throw err('Escribe al menos uno de los datos');
  return { email: e, movil: m ? m.replace(/(\d{3})(\d{3})(\d{3})/, '$1 $2 $3') : '', anios: a === '' ? null : +a };
}
export async function guardarDatos(id, datos) {
  const d = limpiarDatos(datos, { parcial: !!datos.parcial });
  const { rows } = await query(`UPDATE usuario SET email = $2, movil = $3, anios_servicio = $4, datos_fecha = CURRENT_DATE WHERE id = $1 RETURNING *`,
    [id, d.email, d.movil, d.anios]);
  if (!rows[0]) throw err('Usuario no encontrado', 404);
  return publico(rows[0]);
}
/** Perfiles extra que Jefatura puede dar a una cuenta */
export const PERFILES = ['profesor', 'no_docente', 'biblioteca', 'direccion', 'administracion', 'conserjeria', 'jefe_departamento', 'coordinador_proyectos', 'tutor', 'jefe_estudios', 'consejo_escolar', 'ccp'];

/** Una sola vez: las cuentas del profesorado (vinculadas al horario) reciben el perfil «profesor» */
export async function marcarProfesorado() {
  if (await Ajuste.leer({ query }, 'perfil_profesor_v1')) return 0;
  const { rows } = await query(`SELECT id, nombre, perfiles FROM usuario WHERE rol <> 'admin'`);
  let n = 0;
  for (const u of rows) {
    if ((u.perfiles || []).some(p => PERFILES_SIN_DATOS.includes(p) || p === 'profesor')) continue;
    if (!(await profesorDeCuenta(u.nombre))) continue;
    await query(`UPDATE usuario SET perfiles = array_append(perfiles, 'profesor') WHERE id = $1`, [u.id]); n++;
  }
  await Ajuste.guardar({ query }, 'perfil_profesor_v1', new Date().toISOString());
  return n;
}

/** Profesorado miembro del Consejo Escolar (cuentas con ese perfil), con el nombre como en el horario */
export async function consejoEscolar() {
  const { rows } = await query(`SELECT nombre FROM usuario WHERE activo AND 'consejo_escolar' = ANY(perfiles) ORDER BY nombre`);
  const out = [];
  for (const r of rows) out.push((await profesorDeCuenta(r.nombre)) || r.nombre);
  return [...new Set(out)].sort((a, b) => a.localeCompare(b, 'es'));
}
export const ETAPAS_JEFATURA = ['todas', 'eso', 'bach', 'fpd', 'fp'];

/* ---------- perfiles que crea el administrador (además de los de la app) ---------- */
const CLAVE_PERF = 'perfiles_personalizados';
export async function perfilesExtra() {
  try { const l = JSON.parse((await Ajuste.leer({ query }, CLAVE_PERF)) || '[]'); return Array.isArray(l) ? l : []; } catch { return []; }
}
const slug = t => 'p_' + String(t).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '').slice(0, 30);
export async function guardarPerfil({ k, nombre, descripcion, color } = {}) {
  const l = String(nombre || '').trim().slice(0, 40);
  if (l.length < 3) throw err('Escribe el nombre del perfil (al menos 3 letras)');
  const lista = await perfilesExtra();
  const clave = k && lista.some(p => p.k === k) ? k : slug(l);
  if (PERFILES.includes(clave) || clave === 'p_') throw err('Ese nombre no se puede usar');
  if (!k && lista.some(p => p.k === clave)) throw err('Ya hay un perfil con ese nombre');
  if (lista.some(p => p.k !== clave && p.l.toLowerCase() === l.toLowerCase())) throw err('Ya hay un perfil con ese nombre');
  const p = { k: clave, l, d: String(descripcion || '').trim().slice(0, 160), c: /^#[0-9a-f]{6}$/i.test(String(color || '')) ? color : '#475569' };
  const nueva = lista.some(x => x.k === clave) ? lista.map(x => x.k === clave ? p : x) : lista.concat(p);
  await Ajuste.guardar({ query }, CLAVE_PERF, JSON.stringify(nueva));
  return nueva;
}
export async function borrarPerfil(k) {
  const lista = await perfilesExtra();
  if (!lista.some(p => p.k === k)) throw err('Ese perfil no existe', 404);
  await query('UPDATE usuario SET perfiles = array_remove(perfiles, $1)', [k]);
  const nueva = lista.filter(p => p.k !== k);
  await Ajuste.guardar({ query }, CLAVE_PERF, JSON.stringify(nueva));
  return nueva;
}

export async function login(usuario, clave, ip, { compartido = false } = {}) {
  const u0 = normUsuario(usuario);
  const k = u0 + '|' + ip;
  comprobarBloqueo(k); comprobarIp(ip);
  const { rows } = await query('SELECT * FROM usuario WHERE usuario = $1', [u0]);
  const u = rows[0];
  if (!u || !u.activo || !(await verificarClave(clave, u.clave_hash))) { anotarFallo(k); anotarFallo('ip|' + ip); throw err('Usuario o contraseña incorrectos', 401); }
  fallos.delete(k);
  if (u.cambiar_clave && u.provisional_hasta && new Date(u.provisional_hasta) < new Date())
    throw err('Tu contraseña provisional ha caducado (72 horas). Pide a Jefatura de Estudios que restaure tu acceso.', 401);
  const token = crypto.randomBytes(32).toString('base64url');
  await query(`INSERT INTO sesion (token_hash, usuario_id, caduca, compartido) VALUES ($1,$2, now() + $3::interval, $4)`,
    [sha(token), u.id, compartido ? HORAS_COMPARTIDO + ' hours' : DIAS_SESION + ' days', !!compartido]);
  await query('UPDATE usuario SET ultimo_acceso = now() WHERE id = $1', [u.id]);
  await query('DELETE FROM sesion WHERE caduca < now()');
  return { token, compartido: !!compartido, usuario: { ...publico(u), compartido: !!compartido } };
}
/** Comprueba la contraseña propia de una cuenta (para abrir el modo administrador con credencial personal) */
export async function verificarPropia(id, clave, ip) {
  const k = 'admin#' + id + '|' + ip;
  comprobarBloqueo(k); comprobarIp(ip);
  const { rows } = await query('SELECT clave_hash FROM usuario WHERE id = $1 AND activo', [id]);
  const ok = !!rows[0] && await verificarClave(clave, rows[0].clave_hash);
  if (ok) fallos.delete(k); else { anotarFallo(k); anotarFallo('ip|' + ip); }
  return ok;
}

/** Usuario de la sesión (o null). Renueva la caducidad al usarse. */
export async function deSesion(token) {
  if (!token) return null;
  const { rows } = await query(
    `UPDATE sesion s SET caduca = now() + (CASE WHEN s.compartido THEN $3 ELSE $2 END)::interval
     FROM usuario u WHERE s.token_hash = $1 AND s.usuario_id = u.id AND s.caduca > now() AND u.activo
       AND s.creada > now() - interval '90 days'   /* tope absoluto: hay que volver a entrar cada 90 días */
     RETURNING u.*, s.compartido AS sesion_compartida`, [sha(token), DIAS_SESION + ' days', HORAS_COMPARTIDO + ' hours']);
  return rows[0] ? { ...publico(rows[0]), compartido: !!rows[0].sesion_compartida } : null;
}
export async function logout(token) { if (token) await query('DELETE FROM sesion WHERE token_hash = $1', [sha(token)]); }

export async function cambiarClave(id, actual, nueva, tokenActual = '') {
  const { rows } = await query('SELECT clave_hash, rol, perfiles FROM usuario WHERE id = $1', [id]);
  if (!rows[0] || !(await verificarClave(actual, rows[0].clave_hash))) throw err('La contraseña actual no es correcta', 401);
  validarClaveNueva(nueva, rows[0]);
  if (actual === nueva) throw err('La nueva contraseña debe ser distinta de la actual');
  await query('UPDATE usuario SET clave_hash = $2, cambiar_clave = FALSE, provisional_hasta = NULL WHERE id = $1', [id, await hashClave(nueva)]);
  /* se cierran las demás sesiones abiertas con la contraseña anterior */
  await query('DELETE FROM sesion WHERE usuario_id = $1 AND token_hash <> $2', [id, tokenActual ? sha(tokenActual) : '']);
}

/** Nombre del profesor/a del horario que corresponde a la cuenta (por su nombre, sin tildes ni mayúsculas) */
const normProf = t => String(t || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
export async function profesorDeCuenta(nombre) {
  const n = normProf(nombre);
  if (!n) return null;
  /* horario vinculado a mano por el administrador */
  const { rows: v } = await query(`SELECT p.nombre FROM usuario u JOIN profesor p ON p.nombre = u.profesor_horario AND p.activo
    WHERE u.nombre = $1 AND u.profesor_horario <> '' LIMIT 1`, [nombre]);
  if (v[0]) return v[0].nombre;
  const { rows } = await query('SELECT nombre FROM profesor WHERE nombre_norm = $1 AND activo', [n]);
  return rows[0] ? rows[0].nombre : null;
}

/* ---------- administración de cuentas ---------- */
export async function listar() {
  const { rows } = await query(
    `SELECT id, usuario, nombre, rol, activo, cambiar_clave AS "cambiarClave", perfiles, email, movil, anios_servicio AS "aniosServicio",
            departamento_jefe AS "departamentoJefe", proyectos, jefe_estudios_etapa AS "jefeEstudios", profesor_horario AS "profesorHorario",
            COALESCE(to_char(datos_fecha, 'DD/MM/YYYY'), '') AS "datosFecha",
            to_char(ultimo_acceso AT TIME ZONE $1, 'DD/MM/YYYY HH24:MI') AS "ultimoAcceso"
     FROM usuario ORDER BY (rol = 'admin') DESC, nombre, usuario`, [config.tz]);
  const { rows: profs } = await query('SELECT nombre, nombre_norm FROM profesor WHERE activo');
  const mapa = new Map(profs.map(p => [p.nombre_norm, p.nombre]));
  const { rows: tut } = await query('SELECT grupo, profesor FROM tutoria ORDER BY grupo');
  return rows.map(u => {
    const profesor = (u.profesorHorario && [...mapa.values()].includes(u.profesorHorario) ? u.profesorHorario : null) || mapa.get(normProf(u.nombre)) || null;
    const tutorDe = tut.filter(t => normProf(t.profesor) === normProf(u.nombre)).map(t => t.grupo);
    /* quien tiene una tutoría en la tabla de tutores lleva el perfil Tutor aunque no se le haya marcado */
    const perfiles = tutorDe.length && !(u.perfiles || []).includes('tutor') ? (u.perfiles || []).concat('tutor') : (u.perfiles || []);
    return { ...u, perfiles, profesor, tutorDe };
  });
}

/** Propone un nombre de usuario a partir de «Apellidos, Nombre»: inicial del nombre + primer apellido */
export function proponerUsuario(nombre) {
  const [ap, no] = String(nombre).split(',').map(s => s.trim());
  const base = normUsuario(((no || '')[0] || '') + (ap || nombre).split(/\s+/)[0]);
  return base || 'usuario';
}
async function libre(base) {
  let u = base, i = 2;
  while ((await query('SELECT 1 FROM usuario WHERE usuario = $1', [u])).rowCount) u = base + i++;
  return u;
}

export async function crear({ usuario, nombre, rol, clave }) {
  nombre = String(nombre || '').trim();
  let u = normUsuario(usuario) || proponerUsuario(nombre);
  if (normUsuario(usuario)) {
    if ((await query('SELECT 1 FROM usuario WHERE usuario = $1', [u])).rowCount) throw err('Ya existe el usuario «' + u + '»');
  } else u = await libre(u);
  const c = clave ? String(clave) : claveAleatoria();
  const r = rol === 'admin' ? 'admin' : 'profesor';
  if (clave) validarClaveNueva(c, { rol: r });
  const { rows } = await query(
    `INSERT INTO usuario (usuario, nombre, rol, clave_hash, cambiar_clave, provisional_hasta) VALUES ($1,$2,$3,$4,TRUE, now() + interval '${HORAS_PROVISIONAL} hours') RETURNING id`,
    [u, nombre, r, await hashClave(c)]);
  /* si el nombre está en el horario, es profesorado */
  if (r !== 'admin' && await profesorDeCuenta(nombre)) await query(`UPDATE usuario SET perfiles = '{profesor}' WHERE id = $1`, [rows[0].id]);
  return { id: rows[0].id, usuario: u, nombre, rol: r, clave: c };
}

/** Crea de una vez las cuentas del profesorado que aún no tiene (por nombre) */
export async function crearLote(nombres) {
  const { rows } = await query('SELECT nombre FROM usuario');
  const ya = new Set(rows.map(r => r.nombre));
  const hechas = [];
  for (const n of [...new Set((nombres || []).map(s => String(s).trim()).filter(Boolean))]) {
    if (ya.has(n)) continue;
    hechas.push(await crear({ nombre: n, rol: 'profesor' }));
  }
  return hechas;
}

export async function actualizar(id, { nombre, rol, activo, perfiles, departamentoJefe, proyectos, jefeEstudios, tutorGrupos, profesorHorario }, yo) {
  const { rows } = await query('SELECT * FROM usuario WHERE id = $1', [id]);
  const u = rows[0];
  if (!u) throw err('Usuario no encontrado', 404);
  const nRol = rol === undefined ? u.rol : (rol === 'admin' ? 'admin' : 'profesor');
  const nAct = activo === undefined ? u.activo : !!activo;
  if (u.id === yo.id && (nRol !== 'admin' || !nAct)) throw err('No puedes quitarte a ti mismo el acceso de administración');
  const validos = PERFILES.concat((await perfilesExtra()).map(p => p.k));
  const nPerf = Array.isArray(perfiles) ? validos.filter(p => perfiles.includes(p)) : (u.perfiles || []);
  if (nPerf.includes('profesor') && nPerf.includes('no_docente')) throw err('Una cuenta no puede ser a la vez de profesor/a y de personal no docente');
  let etapa = jefeEstudios === undefined ? u.jefe_estudios_etapa || '' : String(jefeEstudios || '');
  if (!nPerf.includes('jefe_estudios')) etapa = '';
  else if (!ETAPAS_JEFATURA.includes(etapa)) throw err('Elige la etapa que lleva el Jefe/a de Estudios');
  /* jefe/a de departamento: el departamento debe existir; coordinador/a: texto libre con sus proyectos */
  let dep = departamentoJefe === undefined ? u.departamento_jefe || '' : String(departamentoJefe || '').trim();
  if (!nPerf.includes('jefe_departamento')) dep = '';
  if (dep) {
    const { listaDepartamentos } = await import('./departamentoProfesor.js');
    if (!(await listaDepartamentos()).includes(dep)) throw err('Ese departamento no existe');
  }
  let proy = proyectos === undefined ? u.proyectos || '' : String(proyectos || '').trim().slice(0, 300);
  if (!nPerf.includes('coordinador_proyectos')) proy = '';
  const nNombre = nombre === undefined ? u.nombre : String(nombre).trim();
  /* tutor/a: los grupos se guardan en la tabla de tutorías (la que usan Reunión con familias, Disciplina y Mi horario) */
  if (Array.isArray(tutorGrupos) || (Array.isArray(perfiles) && !nPerf.includes('tutor'))) {
    const prof = (await profesorDeCuenta(nNombre)) || nNombre;
    const gs = nPerf.includes('tutor') ? [...new Set((tutorGrupos || []).map(g => String(g).trim()).filter(Boolean))] : [];
    if (nPerf.includes('tutor') && !gs.length) throw err('Elige al menos un grupo de tutoría');
    if (gs.length) {
      const { rows: ex } = await query('SELECT codigo FROM grupo WHERE codigo = ANY($1::text[])', [gs]);
      const malos = gs.filter(g => !ex.some(r => r.codigo === g));
      if (malos.length) throw err('Grupo no encontrado en el horario: ' + malos.join(', '));
    }
    const { rows: suyas } = await query('SELECT grupo, profesor FROM tutoria');
    const quitar = suyas.filter(t => normProf(t.profesor) === normProf(prof) && !gs.includes(t.grupo)).map(t => t.grupo);
    if (quitar.length) await query('DELETE FROM tutoria WHERE grupo = ANY($1::text[])', [quitar]);
    for (const g of gs) await query(`INSERT INTO tutoria (grupo, profesor) VALUES ($1,$2) ON CONFLICT (grupo) DO UPDATE SET profesor = EXCLUDED.profesor`, [g, prof]);
  }
  /* vincular la cuenta a un horario (o quitar el vínculo con '') */
  let ph = profesorHorario === undefined ? u.profesor_horario || '' : String(profesorHorario || '').trim();
  if (ph) {
    const { rows: p } = await query('SELECT nombre FROM profesor WHERE nombre = $1 AND activo', [ph]);
    if (!p[0]) throw err('Ese horario no existe');
    if (profesorHorario !== undefined && !nPerf.includes('profesor') && !nPerf.some(x => PERFILES_SIN_DATOS.includes(x))) nPerf.push('profesor');
  }
  await query('UPDATE usuario SET nombre = $2, rol = $3, activo = $4, perfiles = $5, departamento_jefe = $6, proyectos = $7, jefe_estudios_etapa = $8, profesor_horario = $9 WHERE id = $1',
    [id, nNombre, nRol, nAct, nPerf, dep, proy, etapa, ph]);
  /* el jefe/a queda anotado también en el departamento (Programaciones didácticas, cabecera del horario) */
  if (dep && dep !== (u.departamento_jefe || '')) await query('UPDATE departamento SET jefe = $2 WHERE nombre = $1', [dep, nNombre]);
  if (!nAct) await query('DELETE FROM sesion WHERE usuario_id = $1', [id]);
}

export async function restablecer(id) {
  const { rows: r0 } = await query('SELECT usuario FROM usuario WHERE id = $1', [id]);
  if (r0[0]) for (const k of fallos.keys()) if (k.startsWith(r0[0].usuario + '|')) fallos.delete(k);   /* desbloquea */
  const c = claveAleatoria();
  /* restaurar el acceso: contraseña provisional nueva, cuenta activa y sin bloqueo por intentos fallidos */
  const { rowCount } = await query(`UPDATE usuario SET clave_hash = $2, cambiar_clave = TRUE, activo = TRUE, provisional_hasta = now() + interval '${HORAS_PROVISIONAL} hours' WHERE id = $1`, [id, await hashClave(c)]);
  if (!rowCount) throw err('Usuario no encontrado', 404);
  await query('DELETE FROM sesion WHERE usuario_id = $1', [id]);
  return { clave: c };
}

export async function borrar(id, yo) {
  if (Number(id) === yo.id) throw err('No puedes borrar tu propia cuenta');
  await query('DELETE FROM usuario WHERE id = $1', [id]);
}

/** Primera instalación: si no hay ninguna cuenta, crea «jefatura» (admin) con ADMIN_PASSWORD */
export async function sembrar(db) {
  const { rows } = await db.query('SELECT COUNT(*)::int AS n FROM usuario');
  if (rows[0].n > 0) return;
  await db.query(
    "INSERT INTO usuario (usuario, nombre, rol, clave_hash, cambiar_clave) VALUES ('jefatura','Jefatura de Estudios','admin',$1,TRUE)",
    [await hashClave(config.adminPasswords[0] || (sembrar.clave = claveAleatoria(14)))]);
  console.log('Creada la cuenta inicial «jefatura» (se pedirá cambiar la contraseña al entrar). Contraseña: ' + (config.adminPasswords[0] ? 'la de ADMIN_PASSWORD' : sembrar.clave));
}

/* Cuentas que deben tener el perfil de administración (rol «admin»): Jefatura de Estudios y Dirección.
   Se aplica UNA vez por versión al arrancar (si después se le quita a alguien en Usuarios, no se vuelve a poner).
   Se puede cambiar la lista con ADMIN_PERSONAS en .env («Apellidos, Nombre» separados por «;»). */
export const ADMIN_PERSONAS = (process.env.ADMIN_PERSONAS || 'Rufo Mendo, Francisco Javier; Páramo Vicente, Delia Esther; Calderón de Arriba, Fernando; Ortega Ávila, Claudia')
  .split(';').map(x => x.trim()).filter(Boolean);
const sinTildes = t => String(t || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
export async function restaurarAdministradores({ forzar = false, marca = 'admins_restaurados_v66' } = {}) {
  if (!forzar && await Ajuste.leer({ query }, marca)) return [];
  const { rows } = await query('SELECT id, usuario, nombre, profesor_horario, rol, activo FROM usuario');
  const hechos = [];
  for (const persona of ADMIN_PERSONAS) {
    const n = sinTildes(persona);
    const u = rows.find(r => sinTildes(r.nombre) === n || sinTildes(r.profesor_horario) === n);
    if (!u) { console.log(`Administración: no hay ninguna cuenta de «${persona}»`); continue; }
    if (u.rol !== 'admin' || !u.activo) {
      await query("UPDATE usuario SET rol = 'admin', activo = TRUE WHERE id = $1", [u.id]);
      hechos.push(u.usuario);
    }
  }
  await Ajuste.guardar({ query }, marca, new Date().toISOString());
  if (hechos.length) console.log('Administración: perfil de administración restaurado a ' + hechos.join(', '));
  return hechos;
}
