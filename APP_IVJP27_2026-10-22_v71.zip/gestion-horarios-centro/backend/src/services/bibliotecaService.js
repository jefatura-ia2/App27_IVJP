/**
 * Biblioteca (G.B. y MAY55) en la base de datos del centro.
 * Quién puede editar: las cuentas con el perfil «biblioteca» (lo asigna Jefatura en Usuarios) y las de
 * administración, introduciendo además la clave de la biblioteca. Jefatura fija esa clave desde Usuarios;
 * mientras no exista, solo administración puede editar (con la contraseña de administración).
 */
import fs from 'node:fs';
import { query, transaccion } from '../db.js';
import { Ajuste } from '../models/index.js';
import { hashClave, verificarClave } from './authService.js';
import { claveAdminOk } from './programacionesService.js';

const err = (msg, status = 400) => Object.assign(new Error(msg), { status });
const CLAVE_HASH = 'biblioteca_clave';
const IMPORTADA = 'biblioteca_importada';
const COPIA = 'biblioteca_copia_inicial';   /* hay datos de la copia inicial: se reintenta traer la hoja */
const SLOT = /^[1-9][ªº] (Diurno|Recreo)$/;
/* Hoja de Google anterior: solo se usa una vez para traer los datos */
export const URL_HOJA_ANTERIOR = (process.env.BIBLIOTECA_SHEET_URL || '').trim()
  || 'https://script.google.com/macros/s/AKfycbyc4FTXE8BOle-o5dUwZ8b5QbgQrrvrB8Gu2d8r3SwH6nnUA9lO0G3Czp3P6aDLipC2JA/exec';

/* ---------- registros ---------- */
export async function listar(db = { query }) {
  const { rows } = await db.query('SELECT id, nombre AS name, dept, act, dia AS day, slot FROM biblioteca_registro ORDER BY dia, slot, act, nombre');
  return rows;
}
export function limpiar(recs) {
  if (!Array.isArray(recs)) throw err('Faltan los registros');
  const vistos = new Set(), out = [];
  for (const r of recs) {
    if (!r) continue;
    const x = { name: String(r.name || '').trim().slice(0, 120), dept: String(r.dept || '').trim().slice(0, 120),
      act: r.act === 'MAY' ? 'MAY' : r.act === 'GB' ? 'GB' : '', day: Number(r.day), slot: String(r.slot || '') };
    if (!x.name || !x.act || !(x.day >= 0 && x.day <= 4) || !SLOT.test(x.slot)) continue;
    const k = [x.name, x.act, x.day, x.slot].join('|');
    if (vistos.has(k)) continue;
    vistos.add(k); out.push(x);
  }
  return out;
}
/** Sustituye todos los registros (la app envía la lista completa, como hacía con la hoja) */
export async function guardarTodo(recs, { deUsuario = false } = {}) {
  const l = limpiar(recs);
  if (deUsuario) {   /* lo que se edita en la app manda: ya no se trae nada de la hoja */
    await query('DELETE FROM ajuste WHERE clave = $1', [COPIA]);
    if (!(await Ajuste.leer({ query }, IMPORTADA))) await Ajuste.guardar({ query }, IMPORTADA, JSON.stringify({ origen: 'editado en la app', fecha: new Date().toISOString() }));
  }
  await transaccion(async db => {
    await db.query('DELETE FROM biblioteca_registro');
    for (const r of l) await db.query('INSERT INTO biblioteca_registro (nombre, dept, act, dia, slot) VALUES ($1,$2,$3,$4,$5)', [r.name, r.dept, r.act, r.day, r.slot]);
  });
  return listar();
}

/* ---------- acceso ---------- */
export const puedeGestionar = u => !!u && (u.rol === 'admin' || (u.perfiles || []).includes('biblioteca'));
export async function claveDefinida() { return !!(await Ajuste.leer({ query }, CLAVE_HASH)); }

const fallos = new Map();
export async function comprobar(usuario, clave) {
  if (!puedeGestionar(usuario)) throw err('Tu cuenta no tiene el perfil de Biblioteca. Pídeselo a Jefatura de Estudios.');
  const k = usuario.id;
  const f = fallos.get(k);
  if (f && f.n >= 5 && Date.now() - f.t < 15 * 60 * 1000) throw err('Demasiados intentos. Espera 15 minutos.', 429);
  const hash = await Ajuste.leer({ query }, CLAVE_HASH);
  let ok = !!hash && clave && await verificarClave(clave, hash);
  if (!ok && usuario.rol === 'admin') ok = claveAdminOk(clave, usuario);   /* Jefatura también entra con la de administración */
  if (!ok) {
    fallos.set(k, { n: f && Date.now() - f.t < 15 * 60 * 1000 ? f.n + 1 : 1, t: Date.now() });
    throw err(hash || usuario.rol === 'admin' ? 'Clave de la biblioteca incorrecta' : 'Jefatura aún no ha fijado la clave de la biblioteca');
  }
  fallos.delete(k);
}
/* La clave de la biblioteca es una segunda llave (antes hay que entrar en la app con una cuenta con el perfil
   Biblioteca), así que basta con 4 caracteres; los intentos fallidos siguen frenándose. */
function validarClaveBiblioteca(c) {
  c = String(c || '');
  if (c.trim().length < 8) throw err('La clave de la biblioteca debe tener al menos 8 caracteres');
  if (c.length > 100) throw err('La clave es demasiado larga');
}
export async function fijarClave(nueva) {
  validarClaveBiblioteca(nueva);
  await Ajuste.guardar({ query }, CLAVE_HASH, await hashClave(nueva));
}
export async function gestores() {
  const { rows } = await query("SELECT nombre, usuario FROM usuario WHERE activo AND 'biblioteca' = ANY(perfiles) ORDER BY nombre");
  return rows;
}

/* ---------- paso desde la hoja de Google (una sola vez) ---------- */
const conTiempo = (url, opc = {}) => fetch(url, { ...opc, signal: AbortSignal.timeout(30000) });
export async function importarDeHoja(url = URL_HOJA_ANTERIOR, fetchImpl = conTiempo) {
  const r = await fetchImpl(url + (url.includes('?') ? '&' : '?') + 't=' + Date.now(), { redirect: 'follow', cache: 'no-store' });
  const j = await r.json();
  if (!j || !Array.isArray(j.records)) throw err('La hoja de Google no devolvió registros', 502);
  const l = limpiar(j.records);
  if (!l.length) throw err('La hoja de Google está vacía', 502);
  await guardarTodo(l);
  await query('DELETE FROM ajuste WHERE clave = $1', [COPIA]);
  await Ajuste.guardar({ query }, IMPORTADA, JSON.stringify({ origen: 'hoja de Google', registros: l.length, fecha: new Date().toISOString() }));
  return l.length;
}
/** Al arrancar: si la tabla está vacía, trae la hoja; si no responde, carga la copia inicial del horario */
/* Seguridad (v69): ya no hay ninguna clave escrita en el código. Si la clave actual es la antigua de 5 letras, se avisa
   en la app (Usuarios → Perfil Biblioteca) para que Jefatura la cambie por una de 8 caracteres o más. */
export async function claveDebil() {
  const h = await Ajuste.leer({ query }, CLAVE_HASH);
  return !!h && await verificarClave('raton', h);
}
export async function iniciar() {
  try { if (await claveDebil()) console.log('Biblioteca: la clave de la biblioteca es débil; cámbiala en Usuarios → Perfil Biblioteca.'); } catch { /* nada */ }
  if (await Ajuste.leer({ query }, IMPORTADA)) return;
  const hay = (await query('SELECT 1 FROM biblioteca_registro LIMIT 1')).rowCount;
  if (hay && !(await Ajuste.leer({ query }, COPIA))) return;
  try {
    const n = await importarDeHoja();
    console.log(`Biblioteca: ${n} registros traídos de la hoja de Google`);
  } catch (e) {
    if (hay) { console.log('Biblioteca: la hoja de Google sigue sin responder (' + e.message + '); se mantiene la copia inicial.'); return; }
    const ini = JSON.parse(fs.readFileSync(new URL('./bibliotecaInicial.json', import.meta.url), 'utf8'));
    await guardarTodo(ini);
    await Ajuste.guardar({ query }, COPIA, '1');
    console.log(`Biblioteca: no se pudo leer la hoja de Google (${e.message}); cargada la copia inicial (${ini.length} registros). Se reintentará al reiniciar.`);
  }
}
