/**
 * Comisión de Coordinación Pedagógica (CCP): convocatorias de reunión.
 *  · Miembros: jefes/as de departamento (perfil «jefe_departamento»), la Directora («direccion»), el Jefe/a de Estudios
 *    («jefe_estudios» de todas las etapas) y quien tenga el perfil «ccp» (p. ej. Rosa Sánchez).
 *  · Solo convocan la Directora (perfil «direccion») y los Jefes/as de Estudios (perfil «jefe_estudios», cualquier etapa).
 *    La cuenta de administración puede consultar, pero no convocar.
 *  · Cada miembro recibe el aviso en la portada y marca «Enterado/a»; quien convoca ve quién lo ha confirmado.
 *  · Igual para el Consejo Escolar (organo = 'consejo'): miembros = perfil «consejo_escolar», la Directora y los Jefes/as de Estudios.
 *  · Las reuniones próximas de ambos órganos se proyectan resaltadas en rojo en «Avisos» del panel de la sala de profesores.
 */
import { query } from '../db.js';
import { Ajuste } from '../models/index.js';
import { ahora } from './tiempo.js';

const err = (m, s = 400) => Object.assign(new Error(m), { status: s });
const ISO = /^\d{4}-\d{2}-\d{2}$/;
const tiene = (u, p) => (u.perfiles || []).includes(p);
export const ORGANOS = { ccp: 'CCP', consejo: 'Consejo Escolar' };
const organoDe = o => (o === 'consejo' ? 'consejo' : 'ccp');
export const esMiembroConsejo = u => !!u && (tiene(u, 'consejo_escolar') || tiene(u, 'direccion') || tiene(u, 'jefe_estudios'));
export const esMiembro = (u, organo = 'ccp') => organoDe(organo) === 'consejo' ? esMiembroConsejo(u)
  : !!u && (tiene(u, 'jefe_departamento') || tiene(u, 'direccion') || tiene(u, 'ccp') || (tiene(u, 'jefe_estudios') && u.jefeEstudios === 'todas'));
export const puedeConvocar = u => !!u && (tiene(u, 'direccion') || tiene(u, 'jefe_estudios'));

export async function miembros(organo = 'ccp') {
  const consejo = organoDe(organo) === 'consejo';
  const { rows } = await query(`SELECT usuario, nombre, perfiles, departamento_jefe AS dep, jefe_estudios_etapa AS je FROM usuario
    WHERE activo AND ${consejo ? `perfiles && ARRAY['consejo_escolar','direccion','jefe_estudios']`
      : `(perfiles && ARRAY['jefe_departamento','direccion','ccp'] OR ('jefe_estudios' = ANY(perfiles) AND jefe_estudios_etapa = 'todas'))`}
    ORDER BY nombre`);
  return rows.map(r => ({ usuario: r.usuario, nombre: r.nombre,
    cargo: r.perfiles.includes('direccion') ? 'Directora' : r.perfiles.includes('jefe_estudios') ? 'Jefe/a de Estudios'
      : consejo ? 'Representante del profesorado'
      : r.perfiles.includes('jefe_departamento') ? 'Jefe/a de departamento' + (r.dep ? ' · ' + r.dep : '') : 'Miembro de la CCP' }));
}

const SEL = `SELECT id, organo, to_char(fecha,'YYYY-MM-DD') AS fecha, hora, lugar, orden, convoca, anulada,
  to_char(creado AT TIME ZONE 'Europe/Madrid','YYYY-MM-DD HH24:MI') AS creado FROM ccp_reunion`;

export async function datos(usuario, organo = 'ccp') {
  organo = organoDe(organo);
  const miembro = esMiembro(usuario, organo), convoca = puedeConvocar(usuario);
  const accesos = { ccp: esMiembro(usuario, 'ccp') || convoca || usuario.rol === 'admin', consejo: esMiembroConsejo(usuario) || convoca || usuario.rol === 'admin' };
  if (!accesos[organo]) throw err('Solo para los miembros de ' + (organo === 'consejo' ? 'el Consejo Escolar' : 'la CCP'), 404);
  const hoy = ahora().fecha;
  const { rows: prox } = await query(SEL + ` WHERE organo = $2 AND fecha >= $1 ORDER BY fecha, hora`, [hoy, organo]);
  const { rows: pas } = await query(SEL + ` WHERE organo = $2 AND fecha < $1 ORDER BY fecha DESC, hora DESC LIMIT 6`, [hoy, organo]);
  const reuniones = prox.concat(pas);
  const { rows: ent } = reuniones.length ? await query(`SELECT reunion_id, usuario, nombre, to_char(cuando AT TIME ZONE 'Europe/Madrid','YYYY-MM-DD HH24:MI') AS cuando
    FROM ccp_enterado WHERE reunion_id = ANY($1::int[])`, [reuniones.map(r => r.id)]) : { rows: [] };
  const lista = await miembros(organo);
  return { hoy, organo, accesos, miembro, convoca, miembros: lista,
    reuniones: reuniones.map(r => ({ ...r, proxima: r.fecha >= hoy, enterados: ent.filter(e => e.reunion_id === r.id),
      yoEnterado: ent.some(e => e.reunion_id === r.id && e.usuario === usuario.usuario) })) };
}

export async function guardar(usuario, { id, fecha, hora, lugar, orden, organo } = {}) {
  organo = organoDe(organo);
  if (!puedeConvocar(usuario)) throw err('Solo la Directora o los Jefes/as de Estudios pueden convocar la CCP');
  if (!ISO.test(String(fecha || ''))) throw err('Elige la fecha de la reunión');
  if (!/^\d{2}:\d{2}$/.test(String(hora || ''))) throw err('Indica la hora (hh:mm)');
  if (fecha < ahora().fecha) throw err('La fecha ya ha pasado');
  const v = [fecha, hora, String(lugar || '').trim().slice(0, 120), String(orden || '').trim().slice(0, 3000), usuario.nombre];
  if (id) {
    const { rows: [r] } = await query('SELECT organo FROM ccp_reunion WHERE id = $1', [Number(id)]);
    if (!r) throw err('Esa reunión no existe', 404);
    organo = r.organo;
    await query(`UPDATE ccp_reunion SET fecha=$2, hora=$3, lugar=$4, orden=$5, convoca=$6, anulada=false WHERE id=$1`, [Number(id), ...v]);
    await query(`DELETE FROM ccp_enterado WHERE reunion_id = $1`, [Number(id)]);   /* si cambia, hay que volver a confirmarla */
  } else await query(`INSERT INTO ccp_reunion (fecha, hora, lugar, orden, convoca, organo) VALUES ($1,$2,$3,$4,$5,$6)`, [...v, organo]);
  return datos(usuario, organo);
}
export async function anular(usuario, id) {
  if (!puedeConvocar(usuario)) throw err('Solo la Directora o los Jefes/as de Estudios pueden convocar la CCP');
  const { rows: [r] } = await query(`UPDATE ccp_reunion SET anulada = NOT anulada WHERE id = $1 RETURNING organo`, [Number(id)]);
  return datos(usuario, r ? r.organo : 'ccp');
}
export async function enterado(usuario, id) {
  const { rows: [r] } = await query('SELECT organo FROM ccp_reunion WHERE id = $1', [Number(id)]);
  if (!r) throw err('Esa reunión no existe', 404);
  if (!esMiembro(usuario, r.organo) && !puedeConvocar(usuario)) throw err('Solo para sus miembros', 404);
  await query(`INSERT INTO ccp_enterado (reunion_id, usuario, nombre) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING`, [Number(id), usuario.usuario, usuario.nombre]);
  return datos(usuario, r.organo);
}
/** Para la portada: convocatorias próximas que el miembro aún no ha confirmado */
export async function avisos(usuario) {
  const organos = ['ccp', 'consejo'].filter(o => esMiembro(usuario, o));
  if (!organos.length) return { pendientes: [] };
  const { rows } = await query(SEL + ` r WHERE NOT anulada AND organo = ANY($3::text[]) AND fecha >= $1 AND NOT EXISTS (SELECT 1 FROM ccp_enterado e WHERE e.reunion_id = r.id AND e.usuario = $2) ORDER BY fecha, hora`,
    [ahora().fecha, usuario.usuario, organos]);
  return { pendientes: rows.map(r => ({ ...r, nombreOrgano: ORGANOS[r.organo] })) };
}

/** Para el panel de la sala de profesores: reuniones de la CCP y del Consejo Escolar de hoy a 14 días */
export async function proximasParaPanel(fecha = ahora().fecha) {
  const hasta = new Date(new Date(fecha + 'T12:00:00Z').getTime() + 14 * 864e5).toISOString().slice(0, 10);
  const { rows } = await query(SEL + ` WHERE NOT anulada AND fecha BETWEEN $1 AND $2 ORDER BY fecha, hora`, [fecha, hasta]);
  return rows.map(r => ({ organo: r.organo, nombreOrgano: ORGANOS[r.organo], fecha: r.fecha, hora: r.hora, lugar: r.lugar }));
}

/** Una sola vez: Rosa Sánchez (miembro de la CCP por designación) recibe el perfil «ccp» */
export async function marcarMiembros() {
  if (await Ajuste.leer({ query }, 'ccp_miembros_v1')) return;
  await query(`UPDATE usuario SET perfiles = array_append(perfiles, 'ccp') WHERE nombre ILIKE 'Sánchez Riaño, Rosa%' AND NOT 'ccp' = ANY(perfiles)`);
  await Ajuste.guardar({ query }, 'ccp_miembros_v1', new Date().toISOString());
}
