/**
 * Contador de días de asuntos propios (DAP) de cada docente en el curso escolar.
 *  · Días retribuidos según los años trabajados: menos de 18 → 4; de 18 a 22 → 5; 23 o más → 6.
 *    Los años son los que el docente declaró al entrar más los años completos pasados desde entonces.
 *  · Usados: días lectivos (lunes a viernes) de las ausencias grabadas con motivo «Asuntos propios (DAP)»
 *    del curso (1 de septiembre – 31 de agosto), vengan del calendario DAP o grabadas por Jefatura.
 *  · Lo ve el propio docente y la administración (correo, móvil, años y contador en la cabecera de su horario).
 */
import { query } from '../db.js';
import { esDAP } from './motivos.js';
import { ahora } from './tiempo.js';

const normProf = t => String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();

export const diasDerecho = anios => (anios == null ? null : anios < 18 ? 4 : anios < 23 ? 5 : 6);

export function cursoDe(hoyIso) {
  const y = +hoyIso.slice(0, 4), m = +hoyIso.slice(5, 7);
  const ini = m >= 9 ? y : y - 1;
  return { desde: `${ini}-09-01`, hasta: `${ini + 1}-08-31`, nombre: `${ini}-${String(ini + 1).slice(2)}` };
}
export function aniosActuales(anios, desdeIso, hoyIso) {
  if (anios == null) return null;
  if (!desdeIso) return anios;
  const a = new Date(desdeIso + 'T12:00:00Z'), b = new Date(hoyIso + 'T12:00:00Z');
  let n = b.getUTCFullYear() - a.getUTCFullYear();
  if (b.getUTCMonth() < a.getUTCMonth() || (b.getUTCMonth() === a.getUTCMonth() && b.getUTCDate() < a.getUTCDate())) n--;
  return anios + Math.max(0, n);
}
/** Días de lunes a viernes de una ausencia dentro del curso */
export function diasDe(a, curso) {
  const out = [];
  let d = a.fecha < curso.desde ? curso.desde : a.fecha;
  const fin = (a.hasta || a.fecha) > curso.hasta ? curso.hasta : (a.hasta || a.fecha);
  while (d <= fin) {
    const wd = new Date(d + 'T12:00:00Z').getUTCDay();
    if (wd >= 1 && wd <= 5) out.push(d);
    const x = new Date(d + 'T12:00:00Z'); x.setUTCDate(x.getUTCDate() + 1); d = x.toISOString().slice(0, 10);
  }
  return out;
}

async function cuentasDocentes() {
  const { rows } = await query(`SELECT id, usuario, nombre, email, movil, anios_servicio, to_char(datos_fecha,'YYYY-MM-DD') AS datos_fecha, profesor_horario
    FROM usuario WHERE activo AND (rol <> 'admin' OR anios_servicio IS NOT NULL)`);
  return rows;
}
async function dapDelCurso(curso) {
  const { rows } = await query(`SELECT a.profesor, p.nombre AS prof_horario, to_char(a.fecha,'YYYY-MM-DD') AS fecha,
      COALESCE(to_char(a.hasta,'YYYY-MM-DD'),'') AS hasta, a.motivo
    FROM ausencia a LEFT JOIN profesor p ON p.id = a.profesor_id
    WHERE a.estado = 'Grabada' AND a.fecha <= $2::date AND COALESCE(a.hasta, a.fecha) >= $1::date`, [curso.desde, curso.hasta]);
  return rows.filter(a => esDAP(a.motivo));
}
function fichaDe(nombreProf, cuenta, ausDap, curso, hoy) {
  const n = normProf(nombreProf);
  const dias = [...new Set(ausDap.filter(a => normProf(a.prof_horario || a.profesor) === n).flatMap(a => diasDe(a, curso)))].sort();
  const anios = cuenta ? aniosActuales(cuenta.anios_servicio, cuenta.datos_fecha, hoy) : null;
  const derecho = diasDerecho(anios);
  return {
    profesor: nombreProf, cuenta: !!cuenta, email: cuenta ? cuenta.email : '', movil: cuenta ? cuenta.movil : '',
    anios, derecho, usados: dias.length, restantes: derecho == null ? null : derecho - dias.length,
    dias, futuros: dias.filter(d => d > hoy).length, curso,
  };
}

/** Ficha del docente para la cabecera de su horario; null si quien pregunta no es él/ella ni administración */
export async function ficha(nombreProf, usuario, hoy = ahora().fecha) {
  if (!usuario || !nombreProf) return null;
  const esAdmin = usuario.rol === 'admin';
  if (!esAdmin && normProf(usuario.nombre) !== normProf(nombreProf)) return null;
  const curso = cursoDe(hoy);
  const cs = await cuentasDocentes();
  const cuenta = cs.find(u => u.profesor_horario && normProf(u.profesor_horario) === normProf(nombreProf))
    || cs.find(u => normProf(u.nombre) === normProf(nombreProf)) || null;
  return fichaDe(nombreProf, cuenta, await dapDelCurso(curso), curso, hoy);
}

/** Para Usuarios (administración): contador de cada cuenta de profesorado, por id de usuario */
export async function contadores(hoy = ahora().fecha) {
  const curso = cursoDe(hoy);
  const [cuentas, aus] = await Promise.all([cuentasDocentes(), dapDelCurso(curso)]);
  const out = {};
  for (const c of cuentas) { const f = fichaDe(c.profesor_horario || c.nombre, c, aus, curso, hoy); out[c.id] = { derecho: f.derecho, usados: f.usados, restantes: f.restantes, anios: f.anios }; }
  return { curso, contadores: out };
}
