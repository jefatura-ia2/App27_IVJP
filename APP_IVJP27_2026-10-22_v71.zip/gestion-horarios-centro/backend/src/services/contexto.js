/** Contexto de la petición en curso (usuario con sesión), disponible en cualquier servicio sin pasarlo a mano */
import { AsyncLocalStorage } from 'node:async_hooks';
import crypto from 'node:crypto';
export const contexto = new AsyncLocalStorage();
export const usuarioActual = () => (contexto.getStore() || {}).usuario || null;
/** Comparación de secretos en tiempo constante */
export function igualSeguro(a, b) {
  const h = x => crypto.createHash('sha256').update(String(x ?? '')).digest();
  return crypto.timingSafeEqual(h(a), h(b)) && String(a ?? '').length > 0;
}
/** Enlace seguro para mostrar en la app: solo http(s) (o webcal) o rutas relativas; nunca javascript:, data:… */
export function enlaceSeguro(u, { webcal = false } = {}) {
  const s = String(u || '').trim();
  if (!s) return '';
  if (/^https?:\/\//i.test(s) || (webcal && /^webcal:\/\//i.test(s))) return s;
  if (/^[\w][\w./#?=&%~+-]*$/.test(s) && !s.includes('..')) return s;   /* relativa (p. ej. reunion-familias.html?id=3) */
  return '';
}
