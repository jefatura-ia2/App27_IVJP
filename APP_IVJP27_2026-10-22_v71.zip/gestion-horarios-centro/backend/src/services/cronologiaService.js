import { enlaceSeguro } from './contexto.js';
/**
 * Cronograma de la Cronología (evaluaciones, reuniones, entregas de notas…) guardado en el servidor.
 * Antes solo vivía en el navegador de quien lo editaba (localStorage) y había que «publicar» descargando
 * el HTML. Ahora Jefatura lo graba desde la propia Cronología y todo el claustro ve la misma versión.
 */
import { query } from '../db.js';
import { Ajuste } from '../models/index.js';

const CLAVE = 'cronologia_eventos';
const err = (msg, status = 400) => Object.assign(new Error(msg), { status });
const ISO = /^\d{4}-\d{2}-\d{2}$/;
const txt = (v, n) => String(v == null ? '' : v).slice(0, n);
const MAX_EVENTOS = 400, MAX_GRUPOS = 80;

/** Deja cada evento con los campos que usa la Cronología y longitudes razonables */
export function limpiarEventos(lista) {
  if (!Array.isArray(lista)) throw err('Faltan los eventos');
  if (lista.length > MAX_EVENTOS) throw err('Demasiados eventos (máximo ' + MAX_EVENTOS + ')');
  const ids = new Set();
  return lista.map((e, i) => {
    if (!e || typeof e !== 'object') throw err('Evento ' + (i + 1) + ' no válido');
    const inicio = txt(e.inicio, 10), fin = txt(e.fin || e.inicio, 10);
    if (!ISO.test(inicio) || !ISO.test(fin)) throw err('El evento «' + txt(e.titulo, 60) + '» no tiene fechas válidas');
    let id = Number(e.id); if (!Number.isFinite(id) || ids.has(id)) id = Math.max(0, ...ids) + 1;
    ids.add(id);
    const grupos = (Array.isArray(e.grupos) ? e.grupos : []).slice(0, MAX_GRUPOS).map(g => ({
      code: txt(g && g.code, 30), lugar: txt(g && g.lugar, 80), fechaHora: txt(g && g.fechaHora, 20),
      ...(g && ISO.test(String(g.fecha || '')) ? { fecha: g.fecha } : {}),
      alumnos: Number.isFinite(Number(g && g.alumnos)) ? Number(g.alumnos) : '', tutor: txt(g && g.tutor, 80),
    }));
    return { id, titulo: txt(e.titulo, 160), desc: txt(e.desc, 600), inicio, fin: fin < inicio ? inicio : fin,
      trim: [1, 2, 3].includes(Number(e.trim)) ? Number(e.trim) : 1, subtipo: txt(e.subtipo || 'inicio', 30),
      grupos, enlace: enlaceSeguro(txt(e.enlace, 500)) };   /* seguridad: sin javascript: ni data: */
  });
}

/** null si Jefatura aún no ha grabado nada en el servidor (la Cronología usa entonces sus datos de fábrica) */
export async function leer() {
  try {
    const v = JSON.parse(await Ajuste.leer({ query }, CLAVE) || 'null');
    return v && Array.isArray(v.eventos) ? v : null;
  } catch { return null; }
}
export async function guardar(eventos, por) {
  const v = { eventos: limpiarEventos(eventos), actualizado: new Date().toISOString(), por: txt(por, 60) };
  await Ajuste.guardar({ query }, CLAVE, JSON.stringify(v));
  return v;
}
