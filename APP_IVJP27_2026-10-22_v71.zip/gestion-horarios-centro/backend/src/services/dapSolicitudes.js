/**
 * Módulo DAP · solicitud de Días de Asuntos Particulares.
 *  · El profesorado los pide en un calendario, hasta con tres meses de antelación, dentro de los días que le
 *    corresponden por su experiencia (contador DAP: 4, 5 o 6 según los años trabajados).
 *  · No se pueden pedir los días bloqueados: sesiones de evaluación y claustros (se leen de la Cronología) y los
 *    que añada la Dirección.
 *  · Solo la Directora (cuenta con el perfil «direccion») concede, deniega o revoca. Como norma general, dos DAP
 *    por día en el turno diurno y dos en el vespertino; por encima de eso, solo marcando «fuerza mayor».
 *    La prioridad es el orden de llegada de las solicitudes.
 *  · Al concederse se graba la ausencia (motivo «Asuntos propios (DAP)»): sale en Ausencias, Guardias y el panel.
 *    Al revocarse, se quita.
 *  · Administración 1 y 2 (perfil «administracion») y Jefatura ven todas las solicitudes y resoluciones.
 *  · El profesor/a recibe el aviso en la app y la resolución en PDF firmada por la Dirección.
 *  · Sincronizado con el calendario de Google «Asuntos propios (DAP)» de Calendarios:
 *      app → calendario: cada concesión crea su evento y cada revocación lo borra (dapGoogle.js);
 *      calendario → app: los días apuntados allí por Jefatura (ausencias «dap-…» que graba dapService.js) y las
 *      ausencias DAP grabadas a mano cuentan como concedidos: ocupan cupo, salen en los calendarios del módulo y en
 *      «Mis solicitudes», y descuentan del saldo.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { query } from '../db.js';
import { Ajuste, Profesor } from '../models/index.js';
import { hashClave, profesorDeCuenta, claveAleatoria } from './authService.js';
import { ficha, cursoDe } from './contadorDap.js';
import { ahora } from './tiempo.js';
import * as S from './servicioService.js';
import { leer as leerCronologia } from './cronologiaService.js';
import { esDAP } from './motivos.js';
import * as G from './dapGoogle.js';

const err = (msg, status = 400) => Object.assign(new Error(msg), { status });
const norm = Profesor.normalizar;
const ISO = /^\d{4}-\d{2}-\d{2}$/;
const hoy = () => ahora().fecha;
const sumarDias = (iso, n) => { const d = new Date(iso + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const sumarMeses = (iso, n) => { const d = new Date(iso + 'T12:00:00Z'); d.setUTCMonth(d.getUTCMonth() + n); return d.toISOString().slice(0, 10); };
const diaSemana = iso => ((new Date(iso + 'T12:00:00Z').getUTCDay() + 6) % 7) + 1;   /* 1 lunes … 7 domingo */
export const MOTIVO = 'Asuntos propios (DAP)';
export const CUPO_POR_TURNO = 2;
export const MESES_ANTELACION = 3;

/* ---------- quién es quién ---------- */
const tiene = (u, p) => !!u && (u.perfiles || []).includes(p);
export const esDireccion = u => tiene(u, 'direccion');
export const esAdministracion = u => tiene(u, 'administracion');
export const veTodo = u => !!u && (esDireccion(u) || esAdministracion(u) || u.rol === 'admin');

/** Cuentas del módulo (se crean una sola vez, con contraseña provisional ALEATORIA que caduca a las 72 h y se cambia al entrar) */
export const CUENTAS = [
  { usuario: 'direccion', nombre: 'Directora del centro', perfil: 'direccion' },
  { usuario: 'administracion1', nombre: 'Administración 1', perfil: 'administracion' },
  { usuario: 'administracion2', nombre: 'Administración 2', perfil: 'administracion' },
  { usuario: 'conserjeria', nombre: 'Conserjería', perfil: 'conserjeria' },
];
export async function crearCuentas() {
  for (const c of CUENTAS) {
    const { rowCount } = await query('SELECT 1 FROM usuario WHERE usuario = $1', [c.usuario]);
    if (rowCount) continue;
    const clave = claveAleatoria(12);   /* protección de datos: sin contraseñas fijas en el código */
    await query(`INSERT INTO usuario (usuario, nombre, rol, clave_hash, cambiar_clave, perfiles, provisional_hasta) VALUES ($1,$2,'profesor',$3,TRUE,$4, now() + interval '72 hours')`,
      [c.usuario, c.nombre, await hashClave(clave), [c.perfil]]);
    console.log(`DAP: creada la cuenta «${c.usuario}». Para darle contraseña usa «Restaurar acceso» en Usuarios (no se escribe en el registro).`);
  }
}

/* ---------- días bloqueados: evaluaciones y claustros de la Cronología + los que pone la Dirección ---------- */
const RE_BLOQUEO = /evaluaci[oó]n|claustro/i;
let fabrica = null;
function cronologiaDeFabrica() {
  if (fabrica) return fabrica;
  try {
    const dir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..', '..', 'frontend');
    for (const f of [path.join(dir, 'dist', 'cronologia.html'), path.join(dir, 'public', 'cronologia.html')]) {
      if (!fs.existsSync(f)) continue;
      const m = fs.readFileSync(f, 'utf8').match(/<script id="app-data" type="application\/json">([\s\S]*?)<\/script>/);
      if (m) return (fabrica = JSON.parse(m[1]).eventos || []);
    }
  } catch { /* sin datos */ }
  return (fabrica = []);
}
export async function bloqueos(desde, hasta) {
  const out = new Map();
  let eventos = null;
  try { eventos = await leerCronologia(); } catch { /* nada */ }
  for (const e of (Array.isArray(eventos) ? eventos : (eventos && eventos.eventos) || cronologiaDeFabrica())) {
    if (!e || !RE_BLOQUEO.test((e.titulo || '') + ' ' + (e.desc || '')) || /entrega de calificaciones/i.test(e.titulo || '')) continue;
    for (let d = e.inicio; d && d <= (e.fin || e.inicio); d = sumarDias(d, 1))
      if (d >= desde && d <= hasta) out.set(d, { fecha: d, motivo: e.titulo, origen: 'cronologia' });
  }
  const { rows } = await query(`SELECT to_char(fecha,'YYYY-MM-DD') AS fecha, motivo FROM dap_bloqueo WHERE fecha BETWEEN $1 AND $2`, [desde, hasta]);
  for (const r of rows) out.set(r.fecha, { fecha: r.fecha, motivo: r.motivo || 'Bloqueado por la Dirección', origen: 'direccion' });
  return [...out.values()].sort((a, b) => a.fecha.localeCompare(b.fecha));
}
export async function bloquear(usuario, fecha, motivo, quitar = false) {
  if (!esDireccion(usuario)) throw err('Solo la Dirección puede bloquear días');
  if (!ISO.test(String(fecha || ''))) throw err('Fecha no válida');
  if (quitar) await query('DELETE FROM dap_bloqueo WHERE fecha = $1', [fecha]);
  else await query(`INSERT INTO dap_bloqueo (fecha, motivo, por) VALUES ($1,$2,$3) ON CONFLICT (fecha) DO UPDATE SET motivo = EXCLUDED.motivo, por = EXCLUDED.por`,
    [fecha, String(motivo || '').trim().slice(0, 120) || 'Actividad del centro', usuario.nombre]);
}

/* ---------- turno del profesor/a ese día (según su horario) ---------- */
async function turnosDe(prof, fecha) {
  const { rows } = await query(`SELECT DISTINCT t.turno FROM clase c JOIN profesor p ON p.id = c.profesor_id JOIN tramo t ON t.codigo = c.tramo
    WHERE p.nombre_norm = $1 AND c.dia = $2`, [norm(prof), diaSemana(fecha)]);
  const t = rows.map(r => r.turno === 'tarde' ? 'vespertino' : 'diurno');
  return t.length ? [...new Set(t)].sort() : ['diurno'];
}

const SEL = `SELECT id, profesor, usuario, to_char(fecha,'YYYY-MM-DD') AS fecha, turnos, estado, observaciones,
  to_char(creado AT TIME ZONE 'Europe/Madrid','YYYY-MM-DD HH24:MI:SS') AS creado,
  to_char(resuelto AT TIME ZONE 'Europe/Madrid','YYYY-MM-DD HH24:MI') AS resuelto, resuelto_por AS "resueltoPor", nota,
  fuerza_mayor AS "fuerzaMayor", visto, gcal_id <> '' AS "enCalendario", gcal_error AS "errorCalendario" FROM dap_solicitud`;
const una = async id => (await query(SEL + ' WHERE id = $1', [id])).rows[0] || null;
const evento = (id, tipo, por) => query('INSERT INTO dap_evento (solicitud_id, tipo, por) VALUES ($1,$2,$3)', [id, tipo, por || '']);

async function quienSoy(usuario) {
  const p = await profesorDeCuenta(usuario.nombre);
  return p || null;
}

/**
 * DAP que no vienen de una solicitud del módulo: días apuntados en el calendario de Google «Asuntos propios (DAP)»
 * (ausencias «dap-…») y ausencias DAP grabadas a mano. Uno por día lectivo, con el formato de una solicitud concedida.
 */
async function externos(desde, hasta, prof = null) {
  const params = [desde, hasta]; let w = '';
  if (prof) { params.push(prof, norm(prof)); w = ` AND (a.profesor = $3 OR p.nombre_norm = $4)`; }
  const { rows } = await query(`SELECT a.id, COALESCE(p.nombre, a.profesor) AS profesor, to_char(a.fecha,'YYYY-MM-DD') AS fecha,
      COALESCE(to_char(a.hasta,'YYYY-MM-DD'),'') AS hasta, a.motivo, a.registrado_por AS por,
      to_char(a.creado AT TIME ZONE 'Europe/Madrid','YYYY-MM-DD HH24:MI:SS') AS creado
    FROM ausencia a LEFT JOIN profesor p ON p.id = a.profesor_id
    WHERE a.estado = 'Grabada' AND a.id NOT LIKE 'dapm-%' AND a.fecha <= $2::date AND COALESCE(a.hasta, a.fecha) >= $1::date${w}`, params);
  const out = [], vistos = new Set();
  for (const a of rows.filter(r => esDAP(r.motivo))) {
    for (let d = a.fecha; d <= (a.hasta || a.fecha); d = sumarDias(d, 1)) {
      if (d < desde || d > hasta || diaSemana(d) > 5 || vistos.has(a.profesor + '|' + d)) continue;
      vistos.add(a.profesor + '|' + d);
      out.push({ id: 'ext-' + a.id + '-' + d, ausencia: a.id, profesor: a.profesor, usuario: '', fecha: d, turnos: await turnosDe(a.profesor, d),
        estado: 'concedida', observaciones: '', creado: a.creado || '', resuelto: null, resueltoPor: '', nota: '', fuerzaMayor: false, visto: true,
        origen: String(a.id).startsWith('dap-') ? 'calendario' : 'ausencias', registradoPor: a.por || '' });
    }
  }
  /* y lo que hay en el calendario de Google aunque aún no sea ausencia (sin sincronizar o sin reconocer el nombre) */
  const cal = await eventosCalendario(desde, hasta);
  for (const e of cal.lista) {
    if (prof && (!e.profesor || norm(e.profesor) !== norm(prof))) continue;
    const k = (e.profesor || e.titulo) + '|' + e.fecha;
    if (vistos.has(k)) continue;
    vistos.add(k);
    out.push({ id: 'gcal-' + e.uid + '-' + e.fecha, ausencia: '', profesor: e.profesor || e.titulo, usuario: '', fecha: e.fecha,
      turnos: e.profesor ? await turnosDe(e.profesor, e.fecha) : ['diurno'], estado: 'concedida', observaciones: '', creado: '', resuelto: null,
      resueltoPor: '', nota: '', fuerzaMayor: false, visto: true, origen: 'calendario', sinReconocer: !e.profesor, titulo: e.titulo, registradoPor: '' });
  }
  return out;
}

/** Eventos del calendario «Asuntos propios (DAP)» día a día, con el profesor/a reconocido (o null) */
async function eventosCalendario(desde, hasta) {
  let r;
  try { r = await G.leerEventos(desde, hasta); } catch (e) { return { lista: [], error: e.message, fuente: '' }; }
  const lista = [];
  if (r.eventos.length) {
    const D = await import('./dapService.js');
    const [profesores, alias] = await Promise.all([Profesor.listar({ query }), D.leerAlias()]);
    for (const ev of r.eventos) {
      if (G.MARCA.test(ev.desc || '')) continue;            /* evento puesto por el propio módulo */
      const p = D.profesorDelEvento(ev, profesores, alias);
      if (p === '-') continue;
      for (let d = ev.inicio; d <= (ev.fin || ev.inicio); d = sumarDias(d, 1))
        if (d >= desde && d <= hasta && diaSemana(d) <= 5) lista.push({ fecha: d, profesor: p ? p.nombre : null, titulo: ev.titulo || 'DAP', uid: String(ev.uid || ev.titulo).replace(/[^\w-]/g, '').slice(0, 24) });
    }
  }
  return { lista, error: r.error || '', fuente: r.fuente || '', configurado: r.configurado };
}
/* quita los externos que coinciden con un DAP concedido del módulo (mismo profesor/a y día) */
const sinRepetir = (ext, propias) => {
  const k = new Set(propias.filter(s => s.estado === 'concedida').map(s => norm(s.profesor) + '|' + s.fecha));
  return ext.filter(e => !k.has(norm(e.profesor) + '|' + e.fecha));
};

/** Días que le quedan: derecho − (concedidos/grabados en el curso) − solicitudes pendientes */
async function saldo(prof, h = hoy()) {
  const f = await ficha(prof, { rol: 'admin' }, h);
  const curso = cursoDe(h);
  const { rows } = await query(`SELECT count(*)::int AS n FROM dap_solicitud WHERE profesor = $1 AND estado = 'solicitada' AND fecha BETWEEN $2 AND $3`,
    [prof, curso.desde, curso.hasta]);
  const pendientes = rows[0].n;
  return { derecho: f ? f.derecho : null, usados: f ? f.usados : 0, pendientes, dias: f ? f.dias : [],
    disponibles: f && f.derecho != null ? f.derecho - f.usados - pendientes : null, curso, anios: f ? f.anios : null };
}

/** Datos del calendario de un tramo de fechas: bloqueos y ocupación por día (concedidos y pendientes, por turno) */
export async function calendario(usuario, desde, hasta) {
  const h = hoy();
  if (!ISO.test(String(desde || ''))) desde = h.slice(0, 8) + '01';
  if (!ISO.test(String(hasta || '')) || hasta < desde) hasta = sumarMeses(desde, 4);
  const todo = veTodo(usuario);
  const prof = await quienSoy(usuario);
  const { rows } = await query(SEL + ` WHERE fecha BETWEEN $1 AND $2 AND estado IN ('solicitada','concedida') ORDER BY fecha, creado`, [desde, hasta]);
  const dias = {};
  for (const s of rows) {
    const d = (dias[s.fecha] ||= { concedidas: { diurno: 0, vespertino: 0 }, pendientes: 0, solicitudes: [] });
    if (s.estado === 'concedida') for (const t of s.turnos) d.concedidas[t]++;
    else d.pendientes++;
    /* todo el claustro ve quién lo tiene pedido o concedido cada día (sin observaciones ni notas) */
    d.solicitudes.push({ id: s.id, profesor: s.profesor, estado: s.estado, turnos: s.turnos, creado: s.creado, fuerzaMayor: s.fuerzaMayor });
  }
  for (const e of sinRepetir(await externos(desde, hasta), rows)) {
    const d = (dias[e.fecha] ||= { concedidas: { diurno: 0, vespertino: 0 }, pendientes: 0, solicitudes: [] });
    for (const t of e.turnos) d.concedidas[t]++;
    d.solicitudes.push({ id: e.id, profesor: e.profesor, estado: 'concedida', turnos: e.turnos, creado: e.creado, origen: e.origen, sinReconocer: !!e.sinReconocer });
  }
  const est = todo ? await eventosCalendario(desde, hasta) : null;
  return { hoy: h, desde, hasta, limite: sumarMeses(h, MESES_ANTELACION), cupo: CUPO_POR_TURNO, bloqueos: await bloqueos(desde, hasta), dias,
    calendarioGoogle: est ? { configurado: est.configurado !== false, error: est.error, fuente: est.fuente } : null };
}

/** Pantalla del profesor/a: su saldo y sus solicitudes */
export async function mio(usuario) {
  const prof = await quienSoy(usuario);
  const rol = esDireccion(usuario) ? 'direccion' : esAdministracion(usuario) ? 'administracion' : usuario.rol === 'admin' ? 'jefatura' : 'profesor';
  if (!prof) return { profesor: null, rol, saldo: null, solicitudes: [], limite: sumarMeses(hoy(), MESES_ANTELACION), hoy: hoy() };
  const { rows } = await query(SEL + ' WHERE profesor = $1 ORDER BY fecha DESC, creado DESC LIMIT 100', [prof]);
  const curso = cursoDe(hoy());
  const todas = rows.concat(sinRepetir(await externos(curso.desde, curso.hasta, prof), rows))
    .sort((a, b) => b.fecha.localeCompare(a.fecha) || String(b.creado).localeCompare(String(a.creado)));
  return { profesor: prof, rol, saldo: await saldo(prof), solicitudes: todas, limite: sumarMeses(hoy(), MESES_ANTELACION), hoy: hoy() };
}

/** El profesor/a solicita un día */
export async function solicitar(usuario, { fecha, observaciones } = {}) {
  const prof = await quienSoy(usuario);
  if (!prof) throw err('Tu cuenta no está vinculada a ningún profesor/a del horario');
  const h = hoy();
  if (!ISO.test(String(fecha || ''))) throw err('Elige el día en el calendario');
  if (fecha <= h) throw err('Los DAP se solicitan para días posteriores a hoy');
  if (fecha > sumarMeses(h, MESES_ANTELACION)) throw err(`Solo se pueden solicitar con un máximo de ${MESES_ANTELACION} meses de antelación`);
  if (diaSemana(fecha) > 5) throw err('Ese día es fin de semana');
  const curso = cursoDe(h);
  if (fecha > curso.hasta) throw err('Ese día pertenece al curso siguiente');
  const bl = (await bloqueos(fecha, fecha))[0];
  if (bl) throw err(`No se pueden conceder DAP ese día: ${bl.motivo}`);
  const { rowCount: rep } = await query(`SELECT 1 FROM dap_solicitud WHERE profesor = $1 AND fecha = $2 AND estado IN ('solicitada','concedida')`, [prof, fecha]);
  if (rep) throw err('Ya tienes una solicitud para ese día');
  const sal = await saldo(prof, h);
  if (sal.derecho == null) throw err('Faltan tus años trabajados para calcular tus DAP: complétalos en «Mi cuenta».');
  if (sal.dias.includes(fecha)) throw err('Ese día ya figura como DAP en tus ausencias');
  if (sal.disponibles <= 0) throw err(`Ya has usado o solicitado tus ${sal.derecho} DAP de este curso`);
  const { rows } = await query(`INSERT INTO dap_solicitud (profesor, usuario, fecha, turnos, observaciones) VALUES ($1,$2,$3,$4,$5) RETURNING id`,
    [prof, usuario.usuario || '', fecha, await turnosDe(prof, fecha), String(observaciones || '').trim().slice(0, 500)]);
  await evento(rows[0].id, 'solicitud', usuario.nombre);
  return una(rows[0].id);
}

/** El profesor/a retira una solicitud aún pendiente */
export async function anular(usuario, id) {
  const s = await una(id);
  if (!s) throw err('Esa solicitud no existe', 404);
  if (s.profesor !== await quienSoy(usuario)) throw err('Esa solicitud no es tuya');
  if (s.estado !== 'solicitada') throw err('Solo se pueden retirar las solicitudes pendientes. Para un DAP ya concedido, habla con la Dirección.');
  await query(`UPDATE dap_solicitud SET estado = 'anulada', resuelto = now(), resuelto_por = $2 WHERE id = $1`, [id, usuario.nombre]);
  await evento(id, 'anulacion', usuario.nombre);
}

/** Lista para la Dirección, Administración y Jefatura */
export async function lista(usuario, { estado, desde } = {}) {
  if (!veTodo(usuario)) throw err('Solo para la Dirección y Administración', 404);
  const params = []; let w = 'WHERE true';
  if (estado) { params.push(estado); w += ` AND estado = $${params.length}`; }
  if (ISO.test(String(desde || ''))) { params.push(desde); w += ` AND fecha >= $${params.length}`; }
  let { rows } = await query(`${SEL} ${w} ORDER BY ${estado === 'solicitada' ? 'fecha, creado' : 'creado DESC'} LIMIT 400`, params);
  /* concedidos fuera del módulo (calendario de Google / ausencias): se listan con «Concedidos» y «Todos» */
  if (!estado || estado === 'concedida') {
    const c = cursoDe(hoy());
    const ext = sinRepetir(await externos(ISO.test(String(desde || '')) ? desde : c.desde, c.hasta),
      (await query(SEL + ` WHERE estado = 'concedida' AND fecha BETWEEN $1 AND $2`, [c.desde, c.hasta])).rows);
    rows = rows.concat(ext).sort((a, b) => String(b.creado).localeCompare(String(a.creado)));
  }
  /* posición en la cola de su día (orden de entrada) y ocupación del día */
  const fechas = [...new Set(rows.map(r => r.fecha))];
  const { rows: ocup } = fechas.length ? await query(SEL + ` WHERE fecha = ANY($1::date[]) AND estado IN ('solicitada','concedida') ORDER BY creado`, [fechas]) : { rows: [] };
  const f0 = fechas.length ? fechas.reduce((a, b) => a < b ? a : b) : null, f1 = fechas.length ? fechas.reduce((a, b) => a > b ? a : b) : null;
  const extOcup = fechas.length ? sinRepetir(await externos(f0, f1), ocup) : [];
  const bls = new Map((fechas.length ? await bloqueos(f0, f1) : []).map(b => [b.fecha, b]));
  return rows.map(r => {
    const delDia = ocup.filter(o => o.fecha === r.fecha).concat(extOcup.filter(o => o.fecha === r.fecha));
    const concedidas = { diurno: 0, vespertino: 0 };
    delDia.filter(o => o.estado === 'concedida').forEach(o => o.turnos.forEach(t => concedidas[t]++));
    const cola = delDia.filter(o => o.estado === 'solicitada').map(o => o.id);
    return { ...r, concedidasDia: concedidas, posicion: r.estado === 'solicitada' ? cola.indexOf(r.id) + 1 : 0,
      cupoLleno: r.turnos.some(t => concedidas[t] >= CUPO_POR_TURNO), bloqueo: bls.get(r.fecha) || null };
  });
}

const idAusencia = id => 'dapm-' + id;

/** La Directora concede, deniega o revoca */
export async function resolver(usuario, id, accion, { nota = '', fuerzaMayor = false } = {}) {
  if (!esDireccion(usuario)) throw err('Solo la Directora del centro puede conceder, denegar o revocar los DAP');
  const s = await una(id);
  if (!s) throw err('Esa solicitud no existe', 404);
  nota = String(nota || '').trim().slice(0, 500);
  if (accion === 'conceder') {
    if (!['solicitada', 'denegada', 'revocada'].includes(s.estado)) throw err('Esa solicitud no se puede conceder (está ' + s.estado + ')');
    const { rows: prop } = await query(SEL + ` WHERE fecha = $1 AND estado = 'concedida'`, [s.fecha]);
    const rows = prop.filter(r => r.id !== s.id).concat(sinRepetir(await externos(s.fecha, s.fecha), prop)
      .filter(e => norm(e.profesor) !== norm(s.profesor)));
    const lleno = s.turnos.filter(t => rows.filter(r => r.turnos.includes(t)).length >= CUPO_POR_TURNO);
    const bl = (await bloqueos(s.fecha, s.fecha))[0];
    if ((lleno.length || bl) && !fuerzaMayor)
      throw err(bl ? `Ese día está bloqueado (${bl.motivo}). Solo se puede conceder por fuerza mayor.`
        : `Ya hay ${CUPO_POR_TURNO} DAP concedidos ese día en el turno ${lleno.join(' y ')}. Solo se puede conceder por fuerza mayor.`);
    if ((lleno.length || bl) && !nota) throw err('Indica el motivo de fuerza mayor');
    await query(`UPDATE dap_solicitud SET estado = 'concedida', resuelto = now(), resuelto_por = $2, nota = $3, fuerza_mayor = $4, visto = false WHERE id = $1`,
      [id, usuario.nombre, nota, !!(fuerzaMayor && (lleno.length || bl))]);
    await S.guardarAusencia({ id: idAusencia(id), prof: s.profesor, fecha: s.fecha, modo: 'dia', motivo: MOTIVO, obs: '' }, 'Dirección (DAP)');
    await evento(id, 'concesion', usuario.nombre);
    G.publicar(id).catch(() => {});   /* evento en el calendario de Google «Asuntos propios (DAP)» */
  } else if (accion === 'denegar') {
    if (s.estado !== 'solicitada') throw err('Solo se pueden denegar solicitudes pendientes');
    await query(`UPDATE dap_solicitud SET estado = 'denegada', resuelto = now(), resuelto_por = $2, nota = $3, visto = false WHERE id = $1`, [id, usuario.nombre, nota]);
    await evento(id, 'denegacion', usuario.nombre);
  } else if (accion === 'revocar') {
    if (s.estado !== 'concedida') throw err('Solo se pueden revocar DAP concedidos');
    if (!nota) throw err('Indica el motivo de la revocación (necesidades del centro)');
    await query(`UPDATE dap_solicitud SET estado = 'revocada', resuelto = now(), resuelto_por = $2, nota = $3, visto = false WHERE id = $1`, [id, usuario.nombre, nota]);
    await S.borrarAusencias([idAusencia(id)]);
    await evento(id, 'revocacion', usuario.nombre);
    G.publicar(id).catch(() => {});   /* se borra su evento del calendario de Google */
  } else throw err('Acción no válida');
  return una(id);
}

/** Avisos para la entrada de la app */
export async function avisos(usuario) {
  const out = { pendientes: 0, resoluciones: [], novedades: 0 };
  const prof = await quienSoy(usuario);
  if (prof) out.resoluciones = (await query(SEL + ` WHERE profesor = $1 AND NOT visto AND estado IN ('concedida','denegada','revocada') ORDER BY resuelto DESC`, [prof])).rows;
  if (esDireccion(usuario)) out.pendientes = (await query(`SELECT count(*)::int AS n FROM dap_solicitud WHERE estado = 'solicitada' AND fecha > $1`, [hoy()])).rows[0].n;
  if (esAdministracion(usuario) || esDireccion(usuario) || usuario.rol === 'admin') {
    const visto = await Ajuste.leer({ query }, 'dap_visto_' + usuario.usuario);
    out.novedades = (await query(`SELECT count(*)::int AS n FROM dap_evento WHERE creado > COALESCE($1::timestamptz, '-infinity') AND por <> $2`, [visto, usuario.nombre])).rows[0].n;
  }
  return out;
}
/** Registro de movimientos (solicitudes y resoluciones) para Administración; marca como vistos */
export async function registro(usuario, marcar = true) {
  if (!veTodo(usuario)) throw err('Solo para la Dirección y Administración', 404);
  const visto = await Ajuste.leer({ query }, 'dap_visto_' + usuario.usuario);
  const { rows } = await query(`SELECT e.id, e.tipo, e.por, to_char(e.creado AT TIME ZONE 'Europe/Madrid','YYYY-MM-DD HH24:MI') AS creado,
      (e.creado > COALESCE($1::timestamptz, '-infinity')) AS nuevo, s.id AS solicitud, s.profesor, to_char(s.fecha,'YYYY-MM-DD') AS fecha, s.estado, s.nota
    FROM dap_evento e JOIN dap_solicitud s ON s.id = e.solicitud_id ORDER BY e.creado DESC LIMIT 300`, [visto]);
  if (marcar) await Ajuste.guardar({ query }, 'dap_visto_' + usuario.usuario, new Date().toISOString());
  return rows;
}
export async function marcarVisto(usuario, id) {
  const s = await una(id);
  if (s && s.profesor === await quienSoy(usuario)) await query('UPDATE dap_solicitud SET visto = true WHERE id = $1', [id]);
}

/** Para el PDF: la solicitud, si quien lo pide puede verla */
export async function paraPdf(usuario, id) {
  const s = await una(id);
  if (!s) throw err('Esa solicitud no existe', 404);
  if (!veTodo(usuario) && s.profesor !== await quienSoy(usuario)) throw err('No puedes ver esta resolución', 404);
  if (!['concedida', 'revocada', 'denegada'].includes(s.estado)) throw err('Esta solicitud aún no está resuelta');
  const { rows } = await query(`SELECT to_char(creado AT TIME ZONE 'Europe/Madrid','YYYY-MM-DD HH24:MI') AS creado, tipo FROM dap_evento WHERE solicitud_id = $1 ORDER BY creado`, [id]);
  const conc = rows.filter(r => r.tipo === 'concesion').pop();
  const { rows: d } = await query(`SELECT nombre FROM usuario WHERE 'direccion' = ANY(perfiles) AND activo ORDER BY id LIMIT 1`);
  return { ...s, concedido: conc ? conc.creado : null, directora: s.resueltoPor || (d[0] && d[0].nombre) || 'La Dirección' };
}

/** Sincronización manual (Dirección, Administración, Jefatura): escribe lo pendiente y relee el calendario */
export async function sincronizar(usuario) {
  if (!veTodo(usuario)) throw err('Solo para la Dirección y Administración', 404);
  const escritura = await G.reintentar();
  const { sincronizar: leerCal } = await import('./dapService.js');
  const lectura = await leerCal({ forzar: true });
  return { escritura, lectura: { configurado: lectura.configurado, error: lectura.error, eventos: lectura.eventos, creadas: lectura.creadas,
    quitadas: lectura.quitadas, delModulo: lectura.delModulo || 0, sinReconocer: (lectura.sinReconocer || []).length } };
}

