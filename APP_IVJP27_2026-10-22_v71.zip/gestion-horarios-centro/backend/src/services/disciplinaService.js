/**
 * Módulo Disciplina: comunicación a Jefatura de Estudios de faltas de disciplina (Decreto 50/2007).
 *  · El profesor/a rellena el parte (mismo contenido que el impreso del centro). Se le asigna un código de
 *    registro interno (DIS-2627-0001…) y se generan dos PDF: el ejemplar del profesor/a (lo descarga) y el
 *    ejemplar de Jefatura, que se guarda en la carpeta «disciplina» del servidor, en la subcarpeta del
 *    Jefe/a de Estudios adjunto que corresponde según el grupo:
 *      ESO (y PDC) → Delia Esther Páramo Vicente · Bachillerato → Fernando Calderón de Arriba
 *      FP turno diurno → Francisco Javier Rufo Mendo · resto de FP (tarde y online) → Fátima Hontiveros Almaraz
 *  · Ese Jefe/a adjunto lo ve en su bandeja y marca «Recibido (OK)»; el profesor/a ve el recibido en su horario.
 *  · Protección de datos (minimización, art. 5.1.c RGPD): al marcar «Recibido (OK)» el PDF se BORRA de la carpeta
 *    del servidor (los datos quedan solo en la base de datos y Jefatura puede volver a generar el PDF cuando lo
 *    necesite). El tutor/a del grupo recibe solo un aviso de que se ha registrado una conducta contraria en su
 *    grupo, sin datos del alumno/a (ni nombre, ni conductas, ni observaciones) y sin acceso al PDF.
 */
import fs from 'node:fs';
import path from 'node:path';
import { query } from '../db.js';
import { config } from '../config.js';
import { Profesor } from '../models/index.js';
import { profesorDeCuenta } from './authService.js';
import { ahora } from './tiempo.js';
import { generarPdf } from './pdfDisciplina.js';

const norm = Profesor.normalizar;
const err = (msg, status = 400) => Object.assign(new Error(msg), { status });

/* ---------- Conductas del impreso (Decreto 50/2007) ---------- */
export const CONTRARIAS = [
  ['c1', 'Cualquier acto que perturbe el normal desarrollo de la actividad de la clase.'],
  ['c2', 'La falta de colaboración sistemática del alumnado en la realización de las actividades orientadas al desarrollo del currículo.'],
  ['c3', 'Conductas que puedan impedir o dificultar el ejercicio del derecho o el cumplimiento del deber de estudiar por sus compañeros o el ejercicio de la actividad docente.'],
  ['c4', 'Las faltas injustificadas de puntualidad.'],
  ['c5', 'Las faltas injustificadas de asistencia a clase.'],
  ['c6', 'Cualquier acto de incorrección y de desconsideración hacia el profesorado o cualquier otro miembro de la comunidad educativa.'],
  ['c7', 'Causar pequeños daños en las instalaciones, recursos materiales o documentos del Centro, o en las pertenencias de los demás miembros de la comunidad educativa.'],
];
export const GRAVES = [
  ['g1', 'La agresión física a cualquier miembro de la comunidad educativa.'],
  ['g2', 'Las injurias y ofensas a cualquier miembro de la comunidad educativa.'],
  ['g3', 'Las actuaciones perjudiciales para la salud y la integridad personal de los miembros de la comunidad educativa.'],
  ['g4', 'Las vejaciones o humillaciones a cualquier miembro de la comunidad educativa.'],
  ['g5', 'Las amenazas o coacciones a cualquier miembro de la comunidad educativa.'],
  ['g6', 'La suplantación de la personalidad en actos de la vida docente y la falsificación o sustracción de documentos académicos.'],
  ['g7', 'El deterioro grave de las instalaciones, recursos materiales o documentos del centro.'],
  ['g8', 'La reiteración en un mismo curso escolar de conductas contrarias a las normas de convivencia en el Centro.'],
  ['g9', 'El uso indebido de medios electrónicos durante las horas lectivas.'],
  ['g10', 'El incumplimiento de las correcciones impuestas.'],
];

/* ---------- Jefes/as de Estudios adjuntos ---------- */
export const ETAPAS = {
  eso:  { nombre: 'ESO',                          responsable: 'Páramo Vicente, Delia Esther' },
  bach: { nombre: 'Bachillerato',                 responsable: 'Calderón de Arriba, Fernando' },
  fpd:  { nombre: 'FP · turno diurno',            responsable: 'Rufo Mendo, Francisco Javier' },
  fp:   { nombre: 'FP · tarde y a distancia',     responsable: 'Hontiveros Almaraz, Fátima' },
};
/* «Apellidos, Nombre» → «Nombre Apellidos» (nombre de la subcarpeta) */
export const nombreNatural = n => { const [ap, nom] = String(n).split(',').map(s => (s || '').trim()); return nom ? nom + ' ' + ap : ap; };
export const carpetaBase = () => path.resolve(config.disciplinaDir);
export const carpetaDe = etapa => path.join(carpetaBase(), nombreNatural(ETAPAS[etapa].responsable));

/** Crea la carpeta «disciplina» con las 4 subcarpetas (al arrancar) */
export function prepararCarpetas() {
  for (const e of Object.keys(ETAPAS)) fs.mkdirSync(carpetaDe(e), { recursive: true });
}

/** Etapas de las que es responsable una cuenta (por su nombre) */
export const etapasDe = usuario => {
  const porNombre = Object.entries(ETAPAS).filter(([, v]) => norm(v.responsable) === norm(usuario && usuario.nombre)).map(([k]) => k);
  /* perfil «Jefe/a de Estudios» asignado en Usuarios: su etapa, o todas */
  const e = usuario && (usuario.perfiles || []).includes('jefe_estudios') ? usuario.jefeEstudios : '';
  const porPerfil = e === 'todas' ? Object.keys(ETAPAS) : ETAPAS[e] ? [e] : [];
  return [...new Set(porNombre.concat(porPerfil))];
};
const esAdmin = u => u && u.rol === 'admin';

/* ---------- Grupos: etapa, curso y letra como se escriben en el parte ---------- */
export function describirGrupo(codigo, turnos = []) {
  const c = String(codigo || '').trim();
  let m;
  if ((m = c.match(/^E(\d)([A-Z])$/i))) return { etapa: 'eso', curso: m[1] + 'º ESO', letra: m[2].toUpperCase() };
  if ((m = c.match(/^(\d)º?\s*PDC$/i))) return { etapa: 'eso', curso: m[1] + 'º ESO', letra: 'PDC (Diversificación)' };
  if ((m = c.match(/^B(\d)([A-Z])(_GEN)?$/i))) return { etapa: 'bach', curso: m[1] + 'º Bachillerato', letra: m[2].toUpperCase() + (m[3] ? ' (General)' : '') };
  const distancia = /ONLIN/i.test(c);
  const soloManana = turnos.length > 0 && turnos.every(t => t === 'mañana');
  const etapa = !distancia && soloManana ? 'fpd' : 'fp';
  if ((m = c.match(/^(\d)º\s*(.+)$/))) return { etapa, curso: m[1] + 'º FP', letra: m[2].trim() };
  return { etapa, curso: 'FP', letra: c.replace(/_ONLIN$/i, ' (a distancia)') };
}

export async function grupos() {
  const { rows } = await query(`SELECT g.codigo, array_remove(array_agg(DISTINCT t.turno), NULL) AS turnos, min(tu.profesor) AS tutor
    FROM grupo g LEFT JOIN clase c ON c.grupo_id = g.id LEFT JOIN tramo t ON t.codigo = c.tramo LEFT JOIN tutoria tu ON tu.grupo = g.codigo
    GROUP BY g.codigo ORDER BY g.codigo`);
  return rows.map(r => { const d = describirGrupo(r.codigo, r.turnos || []); return { codigo: r.codigo, ...d, responsable: ETAPAS[d.etapa].responsable, tutor: r.tutor || '' }; });
}

export async function quienSoy(usuario) {
  return (await profesorDeCuenta(usuario.nombre)) || usuario.nombre;
}

/** Datos para el formulario */
export async function configuracion(usuario) {
  const prof = await quienSoy(usuario);
  const { rows: mias } = await query(`SELECT DISTINCT c.materia, g.codigo AS grupo FROM clase c
      JOIN profesor p ON p.id = c.profesor_id LEFT JOIN grupo g ON g.id = c.grupo_id
     WHERE p.nombre_norm = $1 AND c.categoria = 'docencia'`, [norm(prof)]);
  const { rows: tramos } = await query(`SELECT codigo, to_char(inicio,'HH24:MI') AS inicio, to_char(fin,'HH24:MI') AS fin, tipo FROM tramo ORDER BY inicio`);
  const etapas = etapasDe(usuario);
  return {
    profesor: prof,
    contrarias: CONTRARIAS, graves: GRAVES,
    grupos: await grupos(),
    misGrupos: [...new Set(mias.map(r => r.grupo).filter(Boolean))],
    misMaterias: [...new Set(mias.map(r => r.materia).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'es')),
    horas: tramos.map(t => (t.tipo === 'recreo' ? (t.codigo === 'R1' ? '1.er recreo' : '2.º recreo') : t.codigo + 'ª hora') + ` (${t.inicio}–${t.fin})`),
    etapas: Object.fromEntries(Object.entries(ETAPAS).map(([k, v]) => [k, { ...v, carpeta: nombreNatural(v.responsable) }])),
    soyResponsable: etapas, esAdmin: esAdmin(usuario),
    soyTutorDe: (await query('SELECT grupo FROM tutoria WHERE profesor = $1 ORDER BY grupo', [prof])).rows.map(r => r.grupo),
  };
}

const SEL = `SELECT id, codigo, profesor, usuario, materia, alumno, grupo, curso, grupo_letra AS "grupoLetra",
  to_char(fecha,'YYYY-MM-DD') AS fecha, hora, contrarias, graves, observaciones, etapa, responsable, archivo,
  to_char(creado AT TIME ZONE 'Europe/Madrid','YYYY-MM-DD HH24:MI') AS creado,
  to_char(recibido AT TIME ZONE 'Europe/Madrid','YYYY-MM-DD HH24:MI') AS recibido, recibido_por AS "recibidoPor", visto,
  tutor, to_char(tutor_visto AT TIME ZONE 'Europe/Madrid','YYYY-MM-DD HH24:MI') AS "tutorVisto"
  FROM parte_disciplina`;

/** Tutor/a del grupo (tabla tutoria) */
export async function tutorDe(grupo) {
  const { rows } = await query('SELECT profesor FROM tutoria WHERE grupo = $1', [grupo]);
  return rows[0] ? rows[0].profesor : '';
}

const limpiar = (v, max = 200) => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, max);
const cursoEscolar = iso => { const [y, m] = iso.split('-').map(Number); const a = m >= 9 ? y : y - 1; return String(a % 100).padStart(2, '0') + String((a + 1) % 100).padStart(2, '0'); };
/* protección de datos: el fichero se llama solo con el código del parte (el nombre del alumno/a va dentro del PDF) */
const nombreArchivo = p => String(p.codigo || ('parte-' + p.id)).replace(/[^A-Za-z0-9._-]+/g, '') + '.pdf';

/** El profesor/a registra un parte */
export async function crear(usuario, d = {}) {
  const profesor = await quienSoy(usuario);
  const alumno = limpiar(d.alumno, 120);
  if (alumno.length < 3) throw err('Escribe el nombre y apellidos del alumno/a');
  const lista = await grupos();
  const g = lista.find(x => x.codigo === d.grupo);
  if (!g) throw err('Elige el grupo del alumno/a');
  const fecha = String(d.fecha || '');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(fecha) || isNaN(new Date(fecha + 'T12:00:00Z'))) throw err('Indica el día de los hechos');
  if (fecha > ahora().fecha) throw err('La fecha de los hechos no puede ser posterior a hoy');
  const contrarias = CONTRARIAS.map(c => c[0]).filter(k => (d.contrarias || []).includes(k));
  const graves = GRAVES.map(c => c[0]).filter(k => (d.graves || []).includes(k));
  if (!contrarias.length && !graves.length) throw err('Marca al menos una conducta');
  const observaciones = String(d.observaciones || '').replace(/\r/g, '').trim().slice(0, 2500);
  const tutor = await tutorDe(g.codigo);
  const { rows } = await query(`INSERT INTO parte_disciplina (profesor, usuario, materia, alumno, grupo, curso, grupo_letra, fecha, hora,
      contrarias, graves, observaciones, etapa, responsable, tutor, tutor_visto) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16) RETURNING id`,
    [profesor, usuario.usuario || '', limpiar(d.materia, 120), alumno, g.codigo, limpiar(d.curso, 60) || g.curso, limpiar(d.grupoLetra, 60) || g.letra,
      fecha, limpiar(d.hora, 60), contrarias, graves, observaciones, g.etapa, g.responsable, tutor,
      /* si quien pone el parte es el propio tutor/a, no hace falta avisarle */
      tutor && norm(tutor) === norm(profesor) ? new Date() : null]);
  const id = rows[0].id;
  const codigo = `DIS-${cursoEscolar(fecha)}-${String(id).padStart(4, '0')}`;
  await query('UPDATE parte_disciplina SET codigo = $2 WHERE id = $1', [id, codigo]);
  const p = await uno(id);
  await guardarCopiaJefatura(p);
  return uno(id);
}

async function uno(id) {
  const { rows } = await query(SEL + ' WHERE id = $1', [id]);
  return rows[0] || null;
}

/** Ejemplar de Jefatura en la carpeta del Jefe/a adjunto (se vuelve a guardar al marcar «recibido») */
async function guardarCopiaJefatura(p) {
  const dir = carpetaDe(p.etapa);
  fs.mkdirSync(dir, { recursive: true });
  const nombre = p.archivo || nombreArchivo(p);
  fs.writeFileSync(path.join(dir, nombre), await generarPdf(p, 'jefatura'));
  if (!p.archivo) await query('UPDATE parte_disciplina SET archivo = $2 WHERE id = $1', [p.id, nombre]);
}

/** Borra el ejemplar de Jefatura de la carpeta (al marcar «Recibido (OK)») */
async function borrarCopiaJefatura(p) {
  if (p.archivo) {
    const ruta = path.join(carpetaDe(p.etapa), path.basename(p.archivo));
    fs.rmSync(ruta, { force: true });
  }
  await query("UPDATE parte_disciplina SET archivo = '', pdf_eliminado = now() WHERE id = $1", [p.id]);
}
/** Al arrancar: borra de la carpeta los PDF de partes ya recibidos (los de antes de esta versión) */
export async function purgarRecibidos() {
  const { rows } = await query(SEL + " WHERE recibido IS NOT NULL AND archivo <> ''");
  for (const p of rows) await borrarCopiaJefatura(p);
  return rows.length;
}

const puedeGestionar = (u, p) => esAdmin(u) || etapasDe(u).includes(p.etapa);
const esSuyo = (u, p, prof) => norm(p.profesor) === norm(prof) || (u.usuario && p.usuario === u.usuario);
const esTutor = (p, prof) => !!p.tutor && norm(p.tutor) === norm(prof);

/** Partes de los grupos de los que es tutor/a */
export async function deMiTutoria(usuario) {
  const prof = await quienSoy(usuario);
  /* solo el aviso: código, grupo y fecha; ningún dato del alumno/a */
  const { rows } = await query(`SELECT id, codigo, grupo, to_char(fecha,'YYYY-MM-DD') AS fecha,
      to_char(creado AT TIME ZONE 'Europe/Madrid','YYYY-MM-DD HH24:MI') AS creado,
      to_char(tutor_visto AT TIME ZONE 'Europe/Madrid','YYYY-MM-DD HH24:MI') AS "tutorVisto"
    FROM parte_disciplina WHERE tutor <> '' AND tutor = $1 ORDER BY (tutor_visto IS NULL) DESC, creado DESC LIMIT 300`, [prof]);
  const { rows: g } = await query('SELECT grupo FROM tutoria WHERE profesor = $1 ORDER BY grupo', [prof]);
  return { grupos: g.map(r => r.grupo), partes: rows };
}
/** El tutor/a marca el parte como leído */
export async function marcarLeidoTutor(id, usuario) {
  const p = await uno(id);
  if (!p) throw err('No encuentro ese parte', 404);
  if (!esTutor(p, await quienSoy(usuario))) throw err('No eres tutor/a de ese grupo');
  await query('UPDATE parte_disciplina SET tutor_visto = COALESCE(tutor_visto, now()) WHERE id = $1', [id]);
}

/** Partes del profesor/a con su estado */
export async function mios(usuario) {
  const prof = await quienSoy(usuario);
  const { rows } = await query(SEL + ' WHERE (profesor = $1 OR (usuario <> \'\' AND usuario = $2)) ORDER BY creado DESC LIMIT 200', [prof, usuario.usuario || '']);
  return rows;
}

/** Bandeja del Jefe/a adjunto (o de Jefatura, que ve todas) */
export async function bandeja(usuario) {
  const etapas = esAdmin(usuario) ? Object.keys(ETAPAS) : etapasDe(usuario);
  if (!etapas.length) return [];
  const { rows } = await query(SEL + ' WHERE etapa = ANY($1::text[]) ORDER BY (recibido IS NULL) DESC, creado DESC LIMIT 500', [etapas]);
  return rows;
}

/** Contadores para los avisos de la entrada */
/* avisos de conductas contrarias: solo Jefatura de Estudios (el Jefe/a de la etapa o la cuenta genérica «jefatura»)
   y el tutor/a del grupo. Otras cuentas de administración (p. ej. la Directora) pueden ver la bandeja, pero sin avisos */
const esCuentaJefatura = u => !!u && u.rol === 'admin' && (u.usuario === 'jefatura' || norm(u.nombre) === norm('Jefatura de Estudios'));
export async function resumen(usuario) {
  const propias = etapasDe(usuario);
  const etapas = propias.length ? propias : esCuentaJefatura(usuario) ? Object.keys(ETAPAS) : [];
  const prof = await quienSoy(usuario);
  const { rows: [r] } = await query(`SELECT
      count(*) FILTER (WHERE recibido IS NULL AND etapa = ANY($1::text[]))::int AS pendientes,
      count(*) FILTER (WHERE recibido IS NOT NULL AND NOT visto AND (profesor = $2 OR (usuario <> '' AND usuario = $3)))::int AS recibidos,
      count(*) FILTER (WHERE tutor_visto IS NULL AND tutor <> '' AND tutor = $2)::int AS tutoria
    FROM parte_disciplina`, [etapas, prof, usuario.usuario || '']);
  const { rowCount } = await query('SELECT 1 FROM tutoria WHERE profesor = $1', [prof]);
  return { ...r, responsable: etapas.length > 0, tutor: rowCount > 0 };
}

/** El Jefe/a adjunto marca «Recibido (OK)» (o lo deshace) */
export async function marcarRecibido(id, usuario, ok = true) {
  const p = await uno(id);
  if (!p) throw err('No encuentro ese parte', 404);
  if (!puedeGestionar(usuario, p)) throw err('Este parte lo recibe ' + nombreNatural(p.responsable));
  if (ok) await query('UPDATE parte_disciplina SET recibido = now(), recibido_por = $2, visto = false WHERE id = $1', [id, usuario.nombre || usuario.usuario]);
  else await query("UPDATE parte_disciplina SET recibido = NULL, recibido_por = '', visto = false WHERE id = $1", [id]);
  try {
    if (ok) await borrarCopiaJefatura(p);                 /* recibido: el PDF sale de la carpeta */
    else await guardarCopiaJefatura(await uno(id));       /* vuelve a pendiente: se repone en la carpeta */
  } catch (e) { console.log('Disciplina: no se pudo actualizar la carpeta:', e.message); }
  return uno(id);
}

/** El profesor/a ya ha visto el recibido */
export async function marcarVisto(id, usuario) {
  const p = await uno(id);
  if (!p) throw err('No encuentro ese parte', 404);
  if (!esSuyo(usuario, p, await quienSoy(usuario))) throw err('Ese parte no es tuyo');
  await query('UPDATE parte_disciplina SET visto = true WHERE id = $1', [id]);
}

/** PDF: ejemplar del profesor/a o de Jefatura */
export async function pdf(id, usuario, copia) {
  const p = await uno(id);
  if (!p) throw err('No encuentro ese parte', 404);
  const yo = await quienSoy(usuario);
  const suyo = esSuyo(usuario, p, yo);
  /* el tutor/a ya no accede al PDF (solo recibe el aviso, sin datos del alumno/a) */
  if (!suyo && !puedeGestionar(usuario, p)) throw err('No puedes ver este parte', 404);
  const tipo = copia === 'jefatura' && puedeGestionar(usuario, p) ? 'jefatura'
    : copia === 'tutor' && puedeGestionar(usuario, p) ? 'tutor'
    : suyo ? 'profesor' : 'jefatura';
  const sufijo = { jefatura: '_Jefatura.pdf', tutor: '_Tutor.pdf', profesor: '_Profesor.pdf' }[tipo];
  return { p, tipo, buffer: await generarPdf(p, tipo), nombre: nombreArchivo(p).replace(/\.pdf$/, sufijo) };
}

/* ---------- Carpeta «disciplina»: los Jefes/as adjuntos ven su subcarpeta; Jefatura, las cuatro ---------- */
function carpetasVisibles(usuario) {
  const etapas = esAdmin(usuario) ? Object.keys(ETAPAS) : etapasDe(usuario);
  return etapas.map(e => ({ etapa: e, nombre: nombreNatural(ETAPAS[e].responsable), etapaNombre: ETAPAS[e].nombre, dir: carpetaDe(e) }));
}
export async function carpeta(usuario) {
  const visibles = carpetasVisibles(usuario);
  if (!visibles.length) throw err('La carpeta de partes es solo para Jefatura de Estudios', 404);
  const { rows } = await query(`SELECT archivo, codigo, alumno, grupo, to_char(recibido,'YYYY-MM-DD') AS recibido FROM parte_disciplina WHERE archivo <> ''`);
  const porArchivo = new Map(rows.map(r => [r.archivo, r]));
  return visibles.map(c => {
    let archivos = [];
    try {
      archivos = fs.readdirSync(c.dir, { withFileTypes: true }).filter(f => f.isFile() && !f.name.startsWith('.')).map(f => {
        const st = fs.statSync(path.join(c.dir, f.name));
        const r = porArchivo.get(f.name);
        return { nombre: f.name, bytes: st.size, fecha: st.mtime.toISOString(), codigo: r?.codigo || '', alumno: r?.alumno || '', grupo: r?.grupo || '', recibido: r?.recibido || null };
      }).sort((a, b) => b.nombre.localeCompare(a.nombre, 'es'));
    } catch { /* carpeta aún sin crear */ }
    return { etapa: c.etapa, nombre: c.nombre, etapaNombre: c.etapaNombre, archivos };
  });
}
/** Un fichero de la carpeta (sin salir de la subcarpeta permitida) */
export function archivoCarpeta(usuario, etapa, nombre) {
  const c = carpetasVisibles(usuario).find(x => x.etapa === etapa);
  if (!c) throw err('No tienes acceso a esa carpeta', 404);
  const n = path.basename(String(nombre || ''));
  if (!n || n !== nombre || n.startsWith('.')) throw err('Nombre de archivo no válido');
  const ruta = path.join(c.dir, n);
  if (!fs.existsSync(ruta)) throw err('Ese archivo ya no está en la carpeta', 404);
  return { ruta, nombre: n };
}
