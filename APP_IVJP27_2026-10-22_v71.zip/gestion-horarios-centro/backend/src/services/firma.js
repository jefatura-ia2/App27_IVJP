/**
 * Enlaces firmados para abrir los PDF de las programaciones sin cookie de sesión
 * (la app de móvil los abre en el navegador del teléfono, que no tiene la sesión).
 * Cada enlace caduca a las 12 horas y solo vale para ese documento.
 */
import crypto from 'node:crypto';
import { query } from '../db.js';
import * as Ajuste from '../models/Ajuste.js';

const db = { query };
const HORAS = 12;
let secreto = null;

async function clave() {
  if (secreto) return secreto;
  let s = await Ajuste.leer(db, 'secreto_enlaces');
  if (!s) { s = crypto.randomBytes(32).toString('hex'); await Ajuste.guardar(db, 'secreto_enlaces', s); }
  return (secreto = s);
}
const hmac = (k, txt) => crypto.createHmac('sha256', k).update(txt).digest('base64url');

export async function firmarDoc(docId) {
  const exp = Math.floor(Date.now() / 1000) + HORAS * 3600;
  return exp + '.' + hmac(await clave(), `doc:${docId}:${exp}`);
}
export async function validarDoc(docId, firma) {
  const [exp, sig] = String(firma || '').split('.');
  if (!exp || !sig || Number(exp) < Date.now() / 1000) return false;
  const ok = hmac(await clave(), `doc:${docId}:${exp}`);
  return ok.length === sig.length && crypto.timingSafeEqual(Buffer.from(ok), Buffer.from(sig));
}

/** Código seguro de verificación de un documento (resoluciones de DAP): 16 caracteres derivados del contenido */
export async function codigoVerificacion(texto) {
  const h = hmac(await clave(), 'csv:' + texto).replace(/[^A-Za-z0-9]/g, '').toUpperCase().slice(0, 16);
  return h.match(/.{4}/g).join('-');
}
