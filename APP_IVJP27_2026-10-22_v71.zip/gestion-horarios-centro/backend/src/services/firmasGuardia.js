/**
 * Firma de las guardias.
 *  · Cada profesor/a «firma» (check) sus guardias de hoy, de aula y de recreo, desde 10 minutos antes de empezar
 *    hasta el final del día. Queda la fecha y la hora exactas.
 *  · Jefatura de Estudios (administración, perfil «jefe_estudios» o «direccion») ve el registro: quién ha firmado,
 *    a qué hora, y quién tenía guardia y no ha firmado. Se puede descargar en CSV.
 */
import { query } from '../db.js';
import { GuardiaBiblioteca } from '../models/index.js';
import { estadoDelDia } from './guardiasService.js';
import { profesorDeCuenta } from './authService.js';
import { ahora, diaSemana } from './tiempo.js';

const err = (m, s = 400) => Object.assign(new Error(m), { status: s });
const ISO = /^\d{4}-\d{2}-\d{2}$/;
const min = h => { const [a, b] = String(h).split(':').map(Number); return a * 60 + (b || 0); };
const sumarDias = (iso, n) => { const d = new Date(iso + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const norm = t => String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();
export const veRegistro = u => !!u && (u.rol === 'admin' || (u.perfiles || []).some(p => p === 'jefe_estudios' || p === 'direccion'));

/** Guardias de un día: [{ tramo, tipo, inicio, fin, profesor, zona }] (aula y recreo, incluida la biblioteca) */
export async function guardiasDelDia(fecha) {
  const e = await estadoDelDia(fecha);
  if (!e.lectivo) return [];
  const dia = diaSemana(fecha);
  const zonas = (await GuardiaBiblioteca.listar({ query })).filter(z => z.dia === dia);
  const out = [];
  for (const t of e.tramos) {
    const tipo = t.tipo === 'recreo' ? 'recreo' : 'aula';
    const nombres = new Set([...t.guardias, ...t.guardiasAusentes].map(g => g.nombre));
    if (tipo === 'recreo') zonas.filter(z => z.tramo === t.tramo).forEach(z => nombres.add(z.profesor));
    for (const n of nombres) {
      const z = tipo === 'recreo' ? zonas.find(x => x.tramo === t.tramo && x.profesor === n) : null;
      out.push({ tramo: t.tramo, tipo, inicio: t.inicio, fin: t.fin, profesor: n, zona: z ? z.zona : '',
        ausente: t.guardiasAusentes.some(g => g.nombre === n) });
    }
  }
  return out.sort((a, b) => a.inicio.localeCompare(b.inicio) || a.profesor.localeCompare(b.profesor, 'es'));
}

async function firmasDe(desde, hasta) {
  const { rows } = await query(`SELECT to_char(fecha,'YYYY-MM-DD') AS fecha, tramo, tipo, profesor, usuario, zona,
      to_char(firmado AT TIME ZONE 'Europe/Madrid','YYYY-MM-DD HH24:MI:SS') AS firmado FROM guardia_firma WHERE fecha BETWEEN $1 AND $2`, [desde, hasta]);
  return rows;
}

/** Mis guardias de hoy, con su firma */
export async function mias(usuario) {
  const prof = await profesorDeCuenta(usuario.nombre);
  const { fecha, hhmm } = ahora();
  if (!prof) return { fecha, profesor: null, guardias: [] };
  const firmas = await firmasDe(fecha, fecha);
  const g = (await guardiasDelDia(fecha)).filter(x => norm(x.profesor) === norm(prof)).map(x => {
    const f = firmas.find(y => y.tramo === x.tramo && norm(y.profesor) === norm(prof));
    return { ...x, firmado: f ? f.firmado : null, puede: min(hhmm) >= min(x.inicio) - 10 };
  });
  return { fecha, hora: hhmm, profesor: prof, guardias: g };
}

/** Firmar una guardia de hoy */
export async function firmar(usuario, tramo) {
  const m = await mias(usuario);
  const g = m.guardias.find(x => x.tramo === String(tramo || ''));
  if (!g) throw err('Hoy no tienes guardia en ese tramo');
  if (g.firmado) throw err('Esa guardia ya está firmada');
  if (!g.puede) throw err(`Podrás firmarla desde las ${String(Math.floor((min(g.inicio) - 10) / 60)).padStart(2, '0')}:${String((min(g.inicio) - 10) % 60).padStart(2, '0')}`);
  await query(`INSERT INTO guardia_firma (fecha, tramo, tipo, profesor, usuario, zona) VALUES ($1,$2,$3,$4,$5,$6) ON CONFLICT DO NOTHING`,
    [m.fecha, g.tramo, g.tipo, m.profesor, usuario.usuario || '', g.zona]);
  return mias(usuario);
}

/** Registro para Jefatura: por día, quién tenía guardia, si firmó y a qué hora */
export async function registro(usuario, { desde, hasta } = {}) {
  if (!veRegistro(usuario)) throw err('Solo para Jefatura de Estudios', 404);
  const { fecha: hoy, hhmm } = ahora();
  if (!ISO.test(String(hasta || ''))) hasta = hoy;
  if (!ISO.test(String(desde || ''))) desde = hasta;
  if (desde > hasta) [desde, hasta] = [hasta, desde];
  if (sumarDias(desde, 31) < hasta) desde = sumarDias(hasta, -31);
  const firmas = await firmasDe(desde, hasta);
  const dias = [];
  for (let d = desde; d <= hasta; d = sumarDias(d, 1)) {
    if (!diaSemana(d)) continue;
    const previstas = d <= hoy ? await guardiasDelDia(d) : [];
    const filas = previstas.map(x => {
      const f = firmas.find(y => y.fecha === d && y.tramo === x.tramo && norm(y.profesor) === norm(x.profesor));
      return { ...x, firmado: f ? f.firmado : null, futura: d === hoy && min(x.inicio) - 10 > min(hhmm) };
    });
    /* firmas que ya no coinciden con el horario (cambios posteriores) también se muestran */
    firmas.filter(y => y.fecha === d && !filas.some(x => x.tramo === y.tramo && norm(x.profesor) === norm(y.profesor)))
      .forEach(y => filas.push({ tramo: y.tramo, tipo: y.tipo, inicio: '', fin: '', profesor: y.profesor, zona: y.zona, ausente: false, firmado: y.firmado }));
    if (filas.length) dias.push({ fecha: d, filas, firmadas: filas.filter(x => x.firmado).length, total: filas.length });
  }
  return { desde, hasta, hoy, dias };
}

export function csv(reg) {
  const L = [['Fecha', 'Tramo', 'Tipo', 'Profesor/a', 'Zona', 'Firmada', 'Fecha y hora de la firma'].join(';')];
  for (const d of reg.dias) for (const f of d.filas)
    L.push([d.fecha, f.tramo, f.tipo === 'recreo' ? 'Recreo' : 'Aula', f.profesor, f.zona, f.firmado ? 'Sí' : (f.ausente ? 'No (ausente)' : 'No'), f.firmado || ''].map(v => '"' + String(v).replace(/"/g, '""') + '"').join(';'));
  return '﻿' + L.join('\r\n');
}
