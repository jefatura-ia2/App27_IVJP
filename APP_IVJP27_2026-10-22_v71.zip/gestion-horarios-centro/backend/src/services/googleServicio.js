/**
 * Dirección del script de Google de la hoja «Ausencias 2026-27» (SHEETS_SERVICE_URL), configurable desde la app
 * por la cuenta de administración: así, si la hoja se mueve o se copia a otra cuenta de Google (p. ej. la de los
 * calendarios), basta con pegar la URL nueva en la app, sin entrar en el servidor.
 * Lo guardado en la app tiene prioridad sobre el .env; vacío = vuelve a usar el del .env.
 */
import { query } from '../db.js';
import { Ajuste } from '../models/index.js';
import { config } from '../config.js';

const CLAVE = 'google_servicio_url';
const DEL_ENV = config.sheetsServiceUrl;
export const URL_VALIDA = /^https:\/\/script\.google\.com\/(a\/[\w.-]+\/)?macros\/s\/[\w-]{20,}\/exec$/;
const err = (m, s = 400) => Object.assign(new Error(m), { status: s });

/** Al arrancar: aplica la URL guardada en la app (si la hay) */
export async function cargar() {
  const u = await Ajuste.leer({ query }, CLAVE);
  if (u && URL_VALIDA.test(u)) config.sheetsServiceUrl = u;
  return config.sheetsServiceUrl;
}
export async function leer(usuario) {
  const guardada = (await Ajuste.leer({ query }, CLAVE)) || '';
  return { url: config.sheetsServiceUrl, origen: guardada ? 'app' : 'servidor', puedeEditar: !!usuario && usuario.rol === 'admin' };
}
export async function guardar(usuario, url) {
  if (!usuario || usuario.rol !== 'admin') throw err('Solo la cuenta de administración', 404);
  const u = String(url || '').trim();
  if (u && !URL_VALIDA.test(u)) throw err('Pega la URL de la implementación del script: empieza por https://script.google.com/macros/s/ y termina en /exec');
  await Ajuste.guardar({ query }, CLAVE, u);
  config.sheetsServiceUrl = u || DEL_ENV;
  return leer(usuario);
}
