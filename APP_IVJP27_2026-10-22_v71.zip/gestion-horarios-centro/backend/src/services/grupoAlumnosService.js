/**
 * Nº de alumnos de cada grupo. Lo escribe Jefatura de Estudios (cuenta de administración o perfil
 * «Jefe/a de Estudios»); lo ve todo el claustro en el módulo Grupos. Es un dato numérico, sin datos personales.
 */
import { query } from '../db.js';

const err = (m, s = 400) => Object.assign(new Error(m), { status: s });
export const puedeEditar = u => !!u && (u.rol === 'admin' || (u.perfiles || []).includes('jefe_estudios'));

export async function todos(usuario) {
  const { rows } = await query(`SELECT grupo, alumnos, to_char(actualizado AT TIME ZONE 'Europe/Madrid','YYYY-MM-DD HH24:MI') AS actualizado, por FROM grupo_alumnos`);
  const total = rows.reduce((s, r) => s + r.alumnos, 0);
  return { grupos: Object.fromEntries(rows.map(r => [r.grupo, r.alumnos])), detalle: rows, total, puedeEditar: puedeEditar(usuario) };
}
export async function uno(grupo) {
  const { rows } = await query('SELECT alumnos FROM grupo_alumnos WHERE grupo = $1', [String(grupo)]);
  return rows[0] ? rows[0].alumnos : null;
}
/** valores: { E1A: 25, E1B: '' (vacío = quitar) } */
export async function guardar(usuario, valores = {}) {
  if (!puedeEditar(usuario)) throw err('Solo Jefatura de Estudios puede cambiar el nº de alumnos', 404);
  const { rows: g } = await query('SELECT codigo FROM grupo');
  const validos = new Set(g.map(r => r.codigo));
  for (const [grupo, v] of Object.entries(valores || {})) {
    if (!validos.has(grupo)) throw err(`El grupo «${grupo}» no está en el horario`);
    if (v === '' || v == null) { await query('DELETE FROM grupo_alumnos WHERE grupo = $1', [grupo]); continue; }
    const n = Number(v);
    if (!Number.isInteger(n) || n < 0 || n > 999) throw err(`Nº de alumnos no válido en ${grupo}`);
    await query(`INSERT INTO grupo_alumnos (grupo, alumnos, por) VALUES ($1,$2,$3)
      ON CONFLICT (grupo) DO UPDATE SET alumnos = EXCLUDED.alumnos, actualizado = now(), por = EXCLUDED.por`, [grupo, n, usuario.nombre || usuario.usuario]);
  }
  return todos(usuario);
}
