import { esDAP, esActividad } from './motivos.js';
/**
 * Lógica de guardias: para una fecha (y opcionalmente un tramo) calcula
 *  · profesorado de guardia disponible (descontando ausentes),
 *  · profesorado ausente,
 *  · grupos que se quedan sin profesor, con la tarea que haya dejado.
 */
import { query } from '../db.js';
import { Ausencia, Clase, Tramo } from '../models/index.js';
import { ahora as ahoraCentro, diaSemana, tramoEn, siguienteTramo } from './tiempo.js';

/** ¿La ausencia afecta a este tramo? */
export const afectaTramo = (a, tramo) => a.modo === 'dia' || (a.horas || []).includes(String(tramo));

/** Cálculo puro (sin BD), fácil de probar */
export function calcularEstado({ tramos, sesiones, ausencias, fecha = '' }) {
  const ausentesEn = tramo => ausencias.filter(a => afectaTramo(a, tramo));
  return tramos.map(t => {
    const fuera = ausentesEn(t.codigo);
    const idsFuera = new Set(fuera.map(a => a.profesor_id).filter(Boolean));
    const nombresFuera = new Set(fuera.map(a => a.profesor));
    const estaFuera = s => idsFuera.has(s.profesor_id) || nombresFuera.has(s.profesor);
    const delTramo = sesiones.filter(s => s.tramo === t.codigo);
    const catGuardia = t.tipo === 'recreo' ? 'recreo' : 'guardia';
    const deGuardia = delTramo.filter(s => s.categoria === catGuardia);
    const unicos = arr => [...new Map(arr.map(x => [x.profesor_id, x])).values()];
    const sinCubrir = [];
    delTramo.filter(s => estaFuera(s) && (s.categoria === 'docencia' || (s.categoria === 'tutoria' && s.grupo)))
      .forEach(s => {
        if (sinCubrir.some(x => x.profesor_id === s.profesor_id && x.grupo === s.grupo)) return;
        const a = fuera.find(x => x.profesor_id === s.profesor_id || x.profesor === s.profesor);
        /* tarea de ese día y hora (la deja el profesor/a) o del tramo (Jefatura); si no, la general */
        const det = (a && a.detalle) || {};
        const d = { ...(det[t.codigo] || {}), ...(det[fecha + '|' + t.codigo] || {}) };
        sinCubrir.push({ profesor_id: s.profesor_id, profesor: s.profesor, grupo: s.grupo, aula: d.aula || s.aula,
          materia: s.materia, tarea: d.obs || (a ? a.tarea : '') });
      });
    return {
      tramo: t.codigo, inicio: t.inicio, fin: t.fin, tipo: t.tipo, turno: t.turno,
      guardias: unicos(deGuardia.filter(s => !estaFuera(s))).map(s => ({ id: s.profesor_id, nombre: s.profesor })),
      guardiasAusentes: unicos(deGuardia.filter(estaFuera)).map(s => ({ id: s.profesor_id, nombre: s.profesor })),
      ausentes: fuera.map(a => ({ id: a.profesor_id, nombre: a.profesor })),
      sinCubrir,
    };
  }).filter(f => f.tipo === 'recreo' || f.guardias.length || f.guardiasAusentes.length || f.sinCubrir.length
    || sesiones.some(s => s.tramo === f.tramo));
}

/** Estado de guardias de una fecha (todos los tramos con actividad) */
export async function estadoDelDia(fecha) {
  const dia = diaSemana(fecha);
  const tramos = await Tramo.listar({ query });
  const ausencias = await Ausencia.delDia({ query }, fecha);
  if (!dia) return { fecha, dia: null, lectivo: false, ausencias: ausencias.map(resumenAusencia), tramos: [] };   /* nunca el motivo */
  const { rows: sesiones } = await query(`${Clase.SELECT_SESIONES} WHERE c.dia = $1`, [dia]);
  return { fecha, dia, lectivo: true, ausencias: ausencias.map(resumenAusencia), tramos: calcularEstado({ tramos, sesiones, ausencias, fecha }) };
}

/** Lo que importa AHORA: tramo en curso y el siguiente */
export async function estadoAhora(fechaBase = new Date()) {
  const { fecha, hhmm } = ahoraCentro(fechaBase);
  const estado = await estadoDelDia(fecha);
  const tramos = await Tramo.listar({ query });
  const actual = tramoEn(hhmm, tramos);
  const siguiente = siguienteTramo(hhmm, tramos);
  const busca = cod => estado.tramos.find(t => t.tramo === cod) || null;
  return { ...estado, hora: hhmm, actual: actual ? busca(actual.codigo) || { tramo: actual.codigo, inicio: actual.inicio, fin: actual.fin, tipo: actual.tipo, guardias: [], guardiasAusentes: [], ausentes: [], sinCubrir: [] } : null,
    siguiente: siguiente ? busca(siguiente.codigo) : null };
}

/* tipo de ausencia para el cuadrante, SIN el motivo concreto (protección de datos: nunca se muestran motivos de salud):
   «dap» (asuntos particulares), «extraescolar» / «complementaria» (actividades con alumnado) u «otros» */
export const tipoAusencia = m => esDAP(m) ? 'dap' : esActividad(m) ? (/complementaria/i.test(String(m || '')) ? 'complementaria' : 'extraescolar') : 'otros';
const resumenAusencia = a => ({ id: a.id, profesor: a.profesor, profesor_id: a.profesor_id, fecha: a.fecha,
  hasta: a.hasta, modo: a.modo, horas: a.horas, tarea: a.tarea, tipo: tipoAusencia(a.motivo) });
