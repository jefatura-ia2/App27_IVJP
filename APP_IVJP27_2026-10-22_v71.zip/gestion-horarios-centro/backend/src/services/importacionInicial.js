/**
 * Paso de la hoja de Google a la base de datos: la primera vez que arranca esta versión, el servidor
 * copia las ausencias (con motivo y estado), los avisos y los enlaces de calendarios que había en la
 * hoja «Ausencias 2026-27». Si falla (sin Internet, contraseña…), lo vuelve a intentar en el siguiente
 * arranque; también se puede lanzar desde la app (Guardias → Informes, modo administrador).
 */
import { config } from '../config.js';
import { query } from '../db.js';
import { Ajuste } from '../models/index.js';
import { importarDeHoja } from './servicioService.js';

const CLAVE = 'hoja_importada';
const conTiempo = (url, opc = {}) => fetch(url, { ...opc, signal: AbortSignal.timeout(30000) });

export async function importacionInicial() {
  if (await Ajuste.leer({ query }, CLAVE)) return null;
  if (!config.sheetsServiceUrl || !config.googleClave) return null;
  try {
    const r = await importarDeHoja(config.sheetsServiceUrl, config.googleClave, conTiempo);
    await Ajuste.guardar({ query }, CLAVE, JSON.stringify({ ...r, fecha: new Date().toISOString() }));
    console.log(`Importado de la hoja de Google: ${r.ausencias} ausencias, ${r.avisos} avisos, ${r.calendarios} calendarios`);
    return r;
  } catch (e) {
    console.log('No se pudo importar todavía la hoja de Google (se reintentará al reiniciar):', e.message);
    return null;
  }
}
export const estadoImportacion = async () => { try { return JSON.parse(await Ajuste.leer({ query }, CLAVE) || 'null'); } catch { return null; } };
export const marcarImportada = r => Ajuste.guardar({ query }, CLAVE, JSON.stringify({ ...r, fecha: new Date().toISOString() }));
