/**
 * Incidencias en las aulas (persiana rota, proyector que no va, calefacción…).
 *  · Cualquier usuario con sesión marca una incidencia en un aula; el aula aparece coloreada en azul mientras esté abierta.
 *  · Reciben el aviso en la portada los Jefes/as de Estudios (perfil «jefe_estudios»), Conserjería («conserjeria»)
 *    y la cuenta de administración; ellos la dan por resuelta (con una nota opcional).
 */
import { query } from '../db.js';

const err = (m, s = 400) => Object.assign(new Error(m), { status: s });
export const gestiona = u => !!u && (u.rol === 'admin' || (u.perfiles || []).some(p => p === 'jefe_estudios' || p === 'conserjeria'));
const SEL = `SELECT id, aula, descripcion, usuario, nombre, to_char(creado AT TIME ZONE 'Europe/Madrid','YYYY-MM-DD HH24:MI') AS creado,
  resuelta, to_char(resuelto AT TIME ZONE 'Europe/Madrid','YYYY-MM-DD HH24:MI') AS resuelto, resuelto_por AS "resueltoPor", nota FROM aula_incidencia`;

export async function lista(usuario, { aula, todas } = {}) {
  const p = [], w = [];
  if (aula) { p.push(String(aula)); w.push(`aula = $${p.length}`); }
  if (!todas) w.push('NOT resuelta');
  const { rows } = await query(`${SEL} ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY resuelta, creado DESC LIMIT 200`, p);
  return { incidencias: rows, gestiona: gestiona(usuario) };
}
export async function crear(usuario, { aula, descripcion } = {}) {
  aula = String(aula || '').trim().slice(0, 40);
  descripcion = String(descripcion || '').trim().slice(0, 500);
  if (!aula) throw err('Falta el aula');
  if (descripcion.length < 4) throw err('Describe la incidencia');
  await query(`INSERT INTO aula_incidencia (aula, descripcion, usuario, nombre) VALUES ($1,$2,$3,$4)`, [aula, descripcion, usuario.usuario || '', usuario.nombre || '']);
  return lista(usuario, { aula });
}
export async function resolver(usuario, id, nota = '') {
  const { rows: [r] } = await query('SELECT id, aula, usuario FROM aula_incidencia WHERE id = $1', [Number(id)]);
  if (!r) throw err('Esa incidencia no existe', 404);
  if (!gestiona(usuario) && r.usuario !== usuario.usuario) throw err('Solo Jefatura de Estudios o Conserjería pueden darla por resuelta', 404);
  await query(`UPDATE aula_incidencia SET resuelta = true, resuelto = now(), resuelto_por = $2, nota = $3 WHERE id = $1`,
    [r.id, usuario.nombre || usuario.usuario, String(nota || '').trim().slice(0, 300)]);
  return lista(usuario, { aula: r.aula });
}
/** Aulas con incidencias abiertas (para colorearlas) y, para quien gestiona, el aviso de la portada */
export async function resumen(usuario) {
  const { rows } = await query(`SELECT aula, count(*)::int AS n FROM aula_incidencia WHERE NOT resuelta GROUP BY aula ORDER BY aula`);
  return { aulas: rows, total: rows.reduce((s, r) => s + r.n, 0), gestiona: gestiona(usuario) };
}
