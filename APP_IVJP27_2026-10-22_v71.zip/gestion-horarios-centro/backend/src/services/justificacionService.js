/**
 * Justificación de ausencias por el profesorado.
 *  · Cada docente ve sus ausencias (notificadas por él o grabadas por Jefatura) y las justifica: marca en su
 *    cuadrante semanal las horas de ausencia de cada día, el sistema computa las horas lectivas y
 *    complementarias, elige el artículo de la Orden de 29/08/2024 y sube los justificantes en PDF.
 *  · Alerta: del día 1 al 5 de cada mes, quien tenga ausencias de meses anteriores sin justificar recibe aviso.
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { query, transaccion } from '../db.js';
import { config } from '../config.js';
import { articulo, ARTICULOS, ORDEN } from './articulosPermisos.js';
import { diasLectivos } from './informeAusencias.js';

const err = (msg, status = 400) => Object.assign(new Error(msg), { status });
const ISO = /^\d{4}-\d{2}-\d{2}$/;
const TRAMOS = ['1', '2', 'R1', '3', '4', 'R2', '5', '6', '7', '8', '9', '10', '11', '12', '13'];
export const MAX_DOCS = 10;
export const MAX_POR_SUBIDA = 5;   /* seguridad: limita la memoria que puede ocupar cada envío */

/**
 * ¿Hora lectiva o complementaria? Lectivas: docencia directa y tutoría con alumnado (ESO, Bachillerato, FP).
 * Complementarias: guardias de aula y de recreo, biblioteca, reuniones, atención a familias, jefaturas,
 * coordinaciones y otras actividades del horario. (La misma regla está en la app, en tipoHora.)
 */
export function tipoHora(s) {
  if (s.categoria === 'docencia') return 'lectiva';
  if (s.categoria === 'tutoria' && /tutor[ií]a (con alumn|bachillerato)/i.test(s.materia || '')) return 'lectiva';
  return 'complementaria';
}

/** Sesiones del horario de un profesor/a, por día (1-5) y tramo */
async function horarioDe(profesor) {
  const { rows } = await query(
    `SELECT c.dia, c.tramo, c.materia, c.categoria FROM clase c JOIN profesor p ON p.id = c.profesor_id WHERE p.nombre = $1`, [profesor]);
  const h = {};
  for (const s of rows) ((h[s.dia] ||= {})[s.tramo] ||= []).push(s);
  return h;
}
/** Horas lectivas y complementarias de unos tramos de un día de la semana (una por tramo con actividad) */
export function computar(h, dia, tramos) {
  let lectivas = 0, complementarias = 0;
  for (const t of tramos) {
    const ses = (h[dia] || {})[t] || [];
    if (!ses.length) continue;
    if (ses.some(s => tipoHora(s) === 'lectiva')) lectivas++; else complementarias++;
  }
  return { lectivas, complementarias };
}

import { esDAP, sinJustificante, motivoExento } from './motivos.js';

const SEL_AUS = `SELECT a.id, a.motivo, to_char(a.fecha,'YYYY-MM-DD') AS fecha, COALESCE(to_char(a.hasta,'YYYY-MM-DD'),'') AS hasta, a.modo, a.horas,
  a.estado, a.justificacion_id, a.registrado_por, to_char(a.creado AT TIME ZONE 'Europe/Madrid','YYYY-MM-DD') AS creado FROM ausencia a`;

async function docsDe(ids) {
  if (!ids.length) return {};
  const { rows } = await query(`SELECT id, justificacion_id, nombre, bytes, to_char(subido AT TIME ZONE 'Europe/Madrid','YYYY-MM-DD HH24:MI') AS subido
    FROM justificante WHERE justificacion_id = ANY($1::int[]) ORDER BY id`, [ids]);
  const m = {};
  for (const d of rows) (m[d.justificacion_id] ||= []).push(d);
  return m;
}
export async function justificaciones(where, params) {
  const { rows } = await query(`SELECT id, profesor, articulo, detalle, lectivas, complementarias, observaciones, usuario,
    to_char(creado AT TIME ZONE 'Europe/Madrid','YYYY-MM-DD HH24:MI') AS creado FROM justificacion ${where} ORDER BY id`, params);
  const docs = await docsDe(rows.map(r => r.id));
  return rows.map(j => ({ ...j, articuloTxt: (articulo(j.articulo) || {}).t || '', documentos: docs[j.id] || [] }));
}

/** Fecha de hoy en el centro (Europe/Madrid), AAAA-MM-DD */
export const hoyCentro = (d = new Date()) => d.toLocaleDateString('sv-SE', { timeZone: 'Europe/Madrid' });

/** Alerta del día 1 al 5: ausencias de meses anteriores sin justificar */
export function alertaDe(ausencias, hoy = hoyCentro()) {
  const inicioMes = hoy.slice(0, 8) + '01';
  const atrasadas = ausencias.filter(a => !a.justificacion_id && !sinJustificante(a.motivo) && a.fecha < inicioMes);
  if (!atrasadas.length) return null;
  const dia = +hoy.slice(8, 10);
  const limite = hoy.slice(0, 8) + '05';
  return { n: atrasadas.length, ids: atrasadas.map(a => a.id), limite, enPlazo: dia <= 5 };
}

/** Ausencias del docente con su justificación, y la alerta si procede */
export async function mias(profesor, hoy = hoyCentro()) {
  const { rows } = await query(`${SEL_AUS} WHERE a.profesor = $1 ORDER BY a.fecha DESC`, [profesor]);
  const lista = await justificaciones('WHERE profesor = $1', [profesor]);
  const pasadas = rows.filter(a => a.fecha <= hoy);
  return {
    profesor, hoy, articulos: ARTICULOS, orden: ORDEN, maxMb: config.maxPdfMb,
    /* asuntos propios (DAP) y actividades complementarias o extraescolares: no se justifican, cuentan ya como justificadas */
    ausencias: rows.map(({ motivo, ...a }) => ({ ...a, dap: esDAP(motivo), exenta: sinJustificante(motivo), exentaMotivo: motivoExento(motivo),
      /* se justifican desde el mismo día; las ya grabadas por Jefatura, también por adelantado (p. ej. con la citación) */
      justificable: (a.fecha <= hoy || a.estado === 'Grabada') && !sinJustificante(motivo), anticipada: a.fecha > hoy })),
    justificaciones: lista,
    sinJustificar: pasadas.filter(a => !a.justificacion_id && !sinJustificante(a.motivo)).length,
    alerta: alertaDe(pasadas, hoy),
  };
}

/* ---------------- ficheros PDF ---------------- */
const esPDF = b => Buffer.isBuffer(b) && b.length > 5 && b.subarray(0, 5).toString('latin1') === '%PDF-';
const nombreLimpio = n => String(n || 'justificante.pdf').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').slice(0, 120);
export function validarPDFs(files = []) {
  for (const f of files) {
    if (!/\.pdf$/i.test(f.originalname || '') || !esPDF(f.buffer)) throw err(`«${f.originalname}» no es un PDF. Solo se admiten justificantes en formato PDF.`);
  }
}
async function guardarPDFs(db, jid, files) {
  const dir = path.join(config.justificantesDir, String(jid));
  await fs.mkdir(dir, { recursive: true });
  for (const f of files) {
    const archivo = Date.now() + '_' + crypto.randomBytes(3).toString('hex') + '.pdf';
    await fs.writeFile(path.join(dir, archivo), f.buffer);
    await db.query('INSERT INTO justificante (justificacion_id, nombre, archivo, bytes) VALUES ($1,$2,$3,$4)', [jid, nombreLimpio(f.originalname), archivo, f.buffer.length]);
  }
}
export const rutaJustificante = (jid, archivo) => path.join(config.justificantesDir, String(jid), archivo);

/* ---------------- crear y modificar ---------------- */
/**
 * datos: { ausencias:[id…], articulo, detalle:[{fecha, tramos:[…], lectivas?, complementarias?}], observaciones }
 * Las horas de cada día las computa el servidor con el horario; si el docente las corrige, se guardan sus cifras.
 */
export async function crear(profesor, datos, files, usuario) {
  const ids = [...new Set((datos.ausencias || []).map(String))];
  if (!ids.length) throw err('Elige al menos una ausencia que justificar');
  const art = articulo(datos.articulo);
  if (!art) throw err('Elige el motivo (artículo de la orden)');
  if (!files || !files.length) throw err('Sube al menos un justificante en PDF');
  if (files.length > MAX_POR_SUBIDA) throw err(`Como máximo ${MAX_POR_SUBIDA} documentos en cada envío`);
  validarPDFs(files);
  const { rows: aus } = await query(`${SEL_AUS} WHERE a.id = ANY($1::text[])`, [ids]);
  if (aus.length !== ids.length) throw err('Alguna de las ausencias ya no existe');
  const { rows: prop } = await query('SELECT profesor FROM ausencia WHERE id = ANY($1::text[])', [ids]);
  if (prop.some(r => r.profesor !== profesor)) throw err('Solo puedes justificar tus propias ausencias');
  if (aus.some(a => a.justificacion_id)) throw err('Alguna de las ausencias elegidas ya está justificada');
  if (aus.some(a => esDAP(a.motivo))) throw err('Los asuntos propios (DAP) no necesitan justificación');
  if (aus.some(a => sinJustificante(a.motivo))) throw err('Las ausencias por actividad complementaria o extraescolar no necesitan justificación');
  const hoy = hoyCentro();
  if (aus.some(a => a.fecha > hoy && a.estado !== 'Grabada')) throw err('Las ausencias futuras se pueden justificar cuando Jefatura las haya grabado');

  /* días válidos: los lectivos dentro de las ausencias elegidas */
  const validos = new Map();
  for (const a of aus) for (const d of diasLectivos(a.fecha, a.hasta || a.fecha)) validos.set(d.iso, d.dia);
  const h = await horarioDe(profesor);
  const detalle = [];
  for (const d of datos.detalle || []) {
    if (!ISO.test(String(d.fecha)) || !validos.has(d.fecha)) throw err(`El día ${d.fecha} no forma parte de las ausencias elegidas`);
    const tramos = TRAMOS.filter(t => (d.tramos || []).map(String).includes(t));
    if (!tramos.length) continue;
    const calc = computar(h, validos.get(d.fecha), tramos);
    const num = (v, def) => Number.isInteger(+v) && +v >= 0 && +v <= 15 && v !== '' && v != null ? +v : def;
    detalle.push({ fecha: d.fecha, tramos, calculadas: calc, lectivas: num(d.lectivas, calc.lectivas), complementarias: num(d.complementarias, calc.complementarias) });
  }
  if (!detalle.length) throw err('Marca en el cuadrante las horas de ausencia de al menos un día');
  detalle.sort((a, b) => a.fecha.localeCompare(b.fecha));
  const lectivas = detalle.reduce((t, d) => t + d.lectivas, 0), complementarias = detalle.reduce((t, d) => t + d.complementarias, 0);

  return transaccion(async db => {
    const { rows } = await db.query(`INSERT INTO justificacion (profesor, articulo, detalle, lectivas, complementarias, observaciones, usuario)
      VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`, [profesor, art.n, JSON.stringify(detalle), lectivas, complementarias, String(datos.observaciones || '').slice(0, 1000), usuario]);
    const jid = rows[0].id;
    await db.query('UPDATE ausencia SET justificacion_id = $1 WHERE id = ANY($2::text[])', [jid, ids]);
    await guardarPDFs(db, jid, files);
    return jid;
  });
}

async function propia(jid, profesor, esAdmin) {
  const { rows } = await query('SELECT id, profesor FROM justificacion WHERE id = $1', [jid]);
  if (!rows.length) throw err('Esa justificación no existe', 404);
  if (!esAdmin && rows[0].profesor !== profesor) throw err('No es una justificación tuya');
  return rows[0];
}
export async function añadirDocs(jid, profesor, esAdmin, files) {
  await propia(jid, profesor, esAdmin);
  if (!files || !files.length) throw err('No se ha recibido ningún PDF');
  validarPDFs(files);
  const { rows } = await query('SELECT count(*)::int AS n FROM justificante WHERE justificacion_id = $1', [jid]);
  if (rows[0].n + files.length > MAX_DOCS) throw err(`Como máximo ${MAX_DOCS} documentos por justificación`);
  await transaccion(db => guardarPDFs(db, jid, files));
  await query('UPDATE justificacion SET actualizado = now() WHERE id = $1', [jid]);
}
export async function borrarDoc(jid, docId, profesor, esAdmin) {
  await propia(jid, profesor, esAdmin);
  const { rows } = await query('SELECT archivo, (SELECT count(*)::int FROM justificante WHERE justificacion_id = $1) AS n FROM justificante WHERE id = $2 AND justificacion_id = $1', [jid, docId]);
  if (!rows.length) throw err('Ese documento no existe', 404);
  if (rows[0].n <= 1) throw err('La justificación debe conservar al menos un PDF: sube otro antes de borrar este');
  await query('DELETE FROM justificante WHERE id = $1', [docId]);
  await fs.unlink(rutaJustificante(jid, rows[0].archivo)).catch(() => {});
}
/** Deshace una justificación: las ausencias vuelven a quedar sin justificar */
export async function borrar(jid, profesor, esAdmin) {
  await propia(jid, profesor, esAdmin);
  await query('DELETE FROM justificacion WHERE id = $1', [jid]);
  await fs.rm(path.join(config.justificantesDir, String(jid)), { recursive: true, force: true });
}
export async function documento(jid, docId, profesor, esAdmin) {
  await propia(jid, profesor, esAdmin);
  const { rows } = await query('SELECT nombre, archivo FROM justificante WHERE id = $1 AND justificacion_id = $2', [docId, jid]);
  if (!rows.length) throw err('Ese documento no existe', 404);
  return { nombre: rows[0].nombre, ruta: rutaJustificante(jid, rows[0].archivo) };
}
