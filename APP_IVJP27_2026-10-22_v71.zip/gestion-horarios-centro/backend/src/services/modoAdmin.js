/**
 * Modo administrador («candado») con credencial personal: la cuenta de administración vuelve a escribir SU
 * contraseña y recibe un pase temporal (8 h, en memoria) que la app envía donde antes iba la clave común.
 * Así cada acción de administración queda ligada a una persona (RGPD art. 32 · ENS op.acc).
 */
import crypto from 'node:crypto';

const HORAS = 8;
const pases = new Map();   /* pase -> { id, usuario, nombre, hasta } */
const limpiar = () => { const t = Date.now(); for (const [k, v] of pases) if (v.hasta < t) pases.delete(k); };

export function emitir(usuario) {
  limpiar();
  const pase = 'adm_' + crypto.randomBytes(24).toString('base64url');
  pases.set(pase, { id: usuario.id, usuario: usuario.usuario, nombre: usuario.nombre, hasta: Date.now() + HORAS * 3600e3 });
  return pase;
}
export function valido(pase) {
  const v = pases.get(String(pase || ''));
  if (!v) return null;
  if (v.hasta < Date.now()) { pases.delete(pase); return null; }
  return v;
}
export function revocar(pase) { pases.delete(String(pase || '')); }
export function revocarDe(id) { for (const [k, v] of pases) if (v.id === id) pases.delete(k); }
