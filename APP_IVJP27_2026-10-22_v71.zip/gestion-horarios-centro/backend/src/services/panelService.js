/**
 * Panel de la sala de profesores: lo que se proyecta en la pantalla (parte de guardias del día,
 * ausencias, avisos y enlaces con QR). Se abre con un enlace secreto (?panel=…) que no caduca y no
 * necesita iniciar sesión; solo da acceso de lectura a estos datos, sin motivos de las ausencias.
 */
import crypto from 'node:crypto';
import { query } from '../db.js';
import { Ajuste, GuardiaBiblioteca } from '../models/index.js';
import { estadoDelDia } from './guardiasService.js';
import { ahora as ahoraCentro, diaSemana } from './tiempo.js';
import { leerAvisos } from './servicioService.js';
import { extraescolares } from './extraescolaresService.js';
import { leer as leerCronologia } from './cronologiaService.js';
import { listar as listarBiblioteca } from './bibliotecaService.js';

const TOKEN = 'panel_token';
const CONFIG = 'panel_config';
const nuevoToken = () => crypto.randomBytes(18).toString('base64url');

export async function token() {
  let t = await Ajuste.leer({ query }, TOKEN);
  if (!t) { t = nuevoToken(); await Ajuste.guardar({ query }, TOKEN, t); }
  return t;
}
export async function tokenValido(t) {
  const bueno = await Ajuste.leer({ query }, TOKEN);
  if (!bueno || !t) return false;
  const a = Buffer.from(String(t)), b = Buffer.from(bueno);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

const POR_DEFECTO = { mensaje: '', enlaces: [], segundosAviso: 12 };
export async function leerConfig() {
  try { const { pantalla, ...c } = JSON.parse(await Ajuste.leer({ query }, CONFIG) || '{}'); void pantalla; return { ...POR_DEFECTO, ...c }; } catch { return { ...POR_DEFECTO }; }
}
export async function guardarConfig(c = {}, { regenerar = false } = {}) {
  const enlaces = (Array.isArray(c.enlaces) ? c.enlaces : []).slice(0, 3)
    .map(e => ({ titulo: String(e && e.titulo || '').trim().slice(0, 40), url: String(e && e.url || '').trim().slice(0, 500) }))
    .filter(e => e.titulo && /^https?:\/\//i.test(e.url));
  const conf = { mensaje: String(c.mensaje || '').trim().slice(0, 300), enlaces,
    segundosAviso: Math.min(60, Math.max(5, Number(c.segundosAviso) || POR_DEFECTO.segundosAviso)) };
  await Ajuste.guardar({ query }, CONFIG, JSON.stringify(conf));
  if (regenerar) await Ajuste.guardar({ query }, TOKEN, nuevoToken());
  return { config: conf, token: await token() };
}

const iso = d => d.toISOString().slice(0, 10);
/** Siguiente día de lunes a viernes después de la fecha */
export function siguienteLectivo(fecha) {
  let d = new Date(fecha + 'T12:00:00Z');
  do d = new Date(d.getTime() + 864e5); while (!diaSemana(iso(d)));
  return iso(d);
}
const resumen = a => ({ profesor: a.profesor, modo: a.modo, horas: a.horas || [], hasta: a.hasta || '', tipo: a.tipo || 'otros' });

/** Todo lo que necesita la pantalla, de una vez */
export async function datos(fechaBase = new Date()) {
  const { fecha, hhmm } = ahoraCentro(fechaBase);
  const hoy = await estadoDelDia(fecha);
  const proxima = siguienteLectivo(fecha);
  const manana = await estadoDelDia(proxima);
  const dia = diaSemana(fecha);
  const biblio = dia ? (await GuardiaBiblioteca.listar({ query })).filter(g => g.dia === dia) : [];
  for (const t of hoy.tramos) {
    if (t.tipo !== 'recreo') continue;
    t.biblioteca = biblio.filter(g => g.tramo === t.tramo && g.zona === 'biblioteca').map(g => g.profesor);
    /* zona de vigilancia de cada profesor/a de guardia de recreo: { nombre: 'zona1' | 'zona2' | 'zona3' | 'biblioteca' } */
    t.zonas = Object.fromEntries(biblio.filter(g => g.tramo === t.tramo).map(g => [g.profesor, g.zona]));
  }
  const avisos = (await leerAvisos()).filter(a => !a.caduca || a.caduca >= fecha)
    .map(({ titulo, texto, nivel, caduca }) => ({ titulo, texto, nivel, caduca }));
  const config = await leerConfig();
  /* actividades extraescolares del calendario de Google: de hoy a 30 días */
  const extra = await extraescolares(fecha, iso(new Date(new Date(fecha + 'T12:00:00Z').getTime() + 30 * 864e5)));
  return {
    ok: true, fecha, hora: hhmm, lectivo: hoy.lectivo,
    tramos: hoy.tramos, ausentes: hoy.ausencias.map(resumen),
    proximo: { fecha: proxima, ausentes: manana.ausencias.map(resumen) },
    avisos, reuniones: await (await import('./ccpService.js')).proximasParaPanel(fecha).catch(() => []), mensaje: config.mensaje, enlaces: config.enlaces, segundosAviso: config.segundosAviso,
    extraescolares: extra.eventos, errorExtraescolares: extra.error,
    cronologia: ((await leerCronologia()) || {}).eventos || null,   /* null: la pantalla lee los datos de fábrica de cronologia.html */
  };
}

/* ---------- Cuadrante de la Biblioteca (mismo formato que el de guardias, para el módulo Biblioteca) ---------- */
const SLOT_TRAMO = { '1ª Diurno': '1', '2ª Diurno': '2', '1º Recreo': 'R1', '3ª Diurno': '3', '4ª Diurno': '4', '2º Recreo': 'R2', '5ª Diurno': '5', '6ª Diurno': '6', '7ª Diurno': '7' };
const normN = t => String(t || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
/** Hoy en la biblioteca: atención a biblioteca (G.B.), mayores de 55 (MAY55) y guardia de recreo en biblioteca, por tramo */
export async function datosBiblioteca(fechaBase = new Date()) {
  const d = await datos(fechaBase);
  const dia = diaSemana(d.fecha);
  const regs = dia ? (await listarBiblioteca()).filter(r => r.day === dia - 1) : [];
  const fuera = (nombre, tramo) => d.ausentes.some(a => normN(a.profesor) === normN(nombre) && (a.modo === 'dia' || (a.horas || []).map(String).includes(String(tramo))));
  const persona = (nombre, dept, tramo) => ({ nombre, dept: dept || '', fuera: fuera(nombre, tramo) });
  for (const t of d.tramos) {
    const rs = regs.filter(r => SLOT_TRAMO[r.slot] === String(t.tramo));
    t.gb = rs.filter(r => r.act === 'GB').map(r => persona(r.name, r.dept, t.tramo));
    t.may = rs.filter(r => r.act === 'MAY').map(r => persona(r.name, r.dept, t.tramo));
    if (t.tipo === 'recreo') t.bibRecreo = (t.biblioteca || []).map(n => persona(n, '', t.tramo));
  }
  return { ...d, modo: 'biblioteca' };
}
