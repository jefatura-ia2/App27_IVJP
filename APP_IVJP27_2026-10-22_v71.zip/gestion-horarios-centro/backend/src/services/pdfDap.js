/**
 * Resolución de la Dirección sobre un Día de Asuntos Particulares (DAP), en PDF normalizado:
 * cabecera del centro, datos de la solicitud, RESUELVO (conceder / denegar / revocar), firma de la Directora
 * y código seguro de verificación (se comprueba en /api/dap/verificar).
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import PDFDocument from 'pdfkit';
import { codigoVerificacion } from './firma.js';

const LOGO = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..', 'assets', 'logo-ivj.png');
const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
const DIAS = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
const TINTA = '#111111', GRIS = '#8a8a8a', MORADO = '#7B3F9E', LILA = '#9b7bb0';
const X = 60, ANCHO = 475;
const natural = n => { const [a, b] = String(n).split(',').map(s => (s || '').trim()); return b ? b + ' ' + a : a; };
const largo = iso => { const d = new Date(iso + 'T12:00:00Z'); return `${DIAS[d.getUTCDay()]}, ${d.getUTCDate()} de ${MESES[d.getUTCMonth()]} de ${d.getUTCFullYear()}`; };
const fecha = iso => { const [a, m, d] = String(iso).slice(0, 10).split('-'); return `${+d} de ${MESES[+m - 1]} de ${a}`; };

export const textoVerificable = s => `${s.id}|${s.profesor}|${s.fecha}|${s.estado}|${s.resuelto || ''}`;

export async function generarPdfDap(s) {
  const csv = await codigoVerificacion(textoVerificable(s));
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A4', margin: 0, info: { Title: `Resolución DAP ${s.id}`, Author: 'IES Valle del Jerte · Dirección' } });
    const trozos = [];
    doc.on('data', b => trozos.push(b)); doc.on('end', () => resolve(Buffer.concat(trozos))); doc.on('error', reject);

    /* cabecera */
    doc.fillColor(LILA).font('Helvetica-Bold').fontSize(13).text('I.E.S. «VALLE DEL JERTE»', X, 34, { lineBreak: false });
    doc.font('Helvetica').fontSize(6.8).fillColor(GRIS);
    ['C/ Pedro y Francisco González, s/n', '10600 PLASENCIA (Cáceres)', 'Teléfono: 927 01 77 74 / Fax: 927 01 77 75']
      .forEach((l, i) => doc.text(l, X, 52 + i * 8.5, { lineBreak: false }));
    if (fs.existsSync(LOGO)) doc.image(LOGO, 297.5 - 28, 28, { width: 56 });
    doc.fillColor(MORADO).fontSize(8.5).text('IES Valle del Jerte', 247.5, 80, { width: 100, align: 'center', characterSpacing: 0.6 });
    doc.fillColor('#9c9c9c').fontSize(12.5).text('JUNTA DE EXTREMADURA', 330, 32, { width: 205, align: 'right', lineBreak: false });
    doc.fontSize(6.8).fillColor(GRIS).text('Consejería de Educación y Formación Profesional', 300, 48, { width: 235, align: 'right', lineBreak: false });
    doc.moveTo(X, 100).lineTo(X + ANCHO, 100).lineWidth(0.6).strokeColor('#d9c6e6').stroke();

    const est = s.estado;
    const titulo = est === 'concedida' ? 'RESOLUCIÓN DE CONCESIÓN' : est === 'revocada' ? 'RESOLUCIÓN DE REVOCACIÓN' : 'RESOLUCIÓN DE DENEGACIÓN';
    doc.fillColor(TINTA).font('Helvetica-Bold').fontSize(13).text(titulo, X, 122, { width: ANCHO, align: 'center' });
    doc.fontSize(10.5).text('PERMISO POR ASUNTOS PARTICULARES (DAP)', X, doc.y + 3, { width: ANCHO, align: 'center' });
    doc.font('Helvetica').fontSize(8.5).fillColor(GRIS).text(`Registro DAP-${String(s.id).padStart(4, '0')} · solicitud presentada en la App el ${fecha(s.creado)} a las ${String(s.creado).slice(11, 16)}`, X, doc.y + 6, { width: ANCHO, align: 'center' });

    /* datos */
    let y = doc.y + 22;
    const fila = (k, v) => {
      doc.font('Helvetica').fontSize(9.5).fillColor('#5b4568').text(k, X + 14, y, { width: 150 });
      doc.font('Helvetica-Bold').fontSize(10.5).fillColor(TINTA).text(v, X + 170, y - 1, { width: ANCHO - 184 });
      y = Math.max(doc.y, y + 14) + 7;
    };
    doc.roundedRect(X, y - 10, ANCHO, 112, 8).fill('#f7f2fa');
    fila('Profesor/a', natural(s.profesor));
    fila('Día solicitado', largo(s.fecha));
    fila('Turno', s.turnos.map(t => t === 'vespertino' ? 'Vespertino' : 'Diurno').join(' y '));
    fila('Fecha de la resolución', s.resuelto ? fecha(s.resuelto) + ' · ' + String(s.resuelto).slice(11, 16) : '—');
    y += 14;

    /* cuerpo */
    const p = (t, o = {}) => { doc.font(o.b ? 'Helvetica-Bold' : 'Helvetica').fontSize(10.5).fillColor(TINTA).text(t, X, y, { width: ANCHO, align: 'justify', lineGap: 2.5 }); y = doc.y + 10; };
    p(`Vista la solicitud presentada por D./Dña. ${natural(s.profesor)}, profesor/a de este centro, para disfrutar de un día de permiso por asuntos particulares el ${largo(s.fecha)}, y de acuerdo con la normativa vigente sobre permisos del personal docente y con los criterios de organización del centro (un máximo, con carácter general, de dos permisos por día en cada turno, atendidos por orden de entrada de las solicitudes y garantizando el normal funcionamiento de las actividades lectivas),`);
    y += 2;
    doc.font('Helvetica-Bold').fontSize(11.5).fillColor(MORADO).text('RESUELVO', X, y, { width: ANCHO, align: 'center', characterSpacing: 2 }); y = doc.y + 10;
    if (est === 'concedida') {
      p(`CONCEDER el día de permiso por asuntos particulares solicitado para el ${largo(s.fecha)}.`, { b: true });
      if (s.fuerzaMayor) p(`La concesión se realiza por causa de fuerza mayor, por encima del número general de permisos de ese día${s.nota ? ': ' + s.nota : '.'}`);
      p('El día concedido queda registrado como ausencia por asuntos propios (DAP) en la aplicación del centro. Esta concesión podrá ser revocada en cualquier momento si las necesidades del centro así lo exigen, lo que se le comunicará por el mismo medio.');
    } else if (est === 'revocada') {
      p(`REVOCAR la concesión del día de permiso por asuntos particulares del ${largo(s.fecha)}${s.concedido ? ', concedido el ' + fecha(s.concedido) : ''}, por las necesidades del centro${s.nota ? ': ' + s.nota : '.'}`, { b: true });
      p('El día deja de figurar como ausencia en la aplicación del centro y no se descuenta de los días de asuntos particulares que le corresponden.');
    } else {
      p(`DENEGAR el día de permiso por asuntos particulares solicitado para el ${largo(s.fecha)}${s.nota ? ', por el siguiente motivo: ' + s.nota : '.'}`, { b: true });
      p('Puede solicitar otra fecha desde el módulo DAP de la aplicación.');
    }

    /* firma */
    y += 16;
    doc.font('Helvetica').fontSize(10.5).fillColor(TINTA).text(`En Plasencia, a ${fecha(s.resuelto || s.creado)}`, X, y, { width: ANCHO, align: 'right' });
    y = doc.y + 16;
    doc.font('Helvetica-Bold').fontSize(10.5).text('LA DIRECTORA', X + 250, y, { width: ANCHO - 250, align: 'center' });
    y = doc.y + 8;
    doc.roundedRect(X + 270, y, ANCHO - 290, 46, 6).lineWidth(0.8).strokeColor(MORADO).stroke();
    doc.font('Helvetica').fontSize(7.2).fillColor(MORADO).text('Firmado electrónicamente', X + 270, y + 7, { width: ANCHO - 290, align: 'center' });
    doc.font('Helvetica-Bold').fontSize(9.5).fillColor(TINTA).text(natural(s.directora), X + 270, y + 18, { width: ANCHO - 290, align: 'center' });
    doc.font('Helvetica').fontSize(7).fillColor(GRIS).text(s.resuelto ? String(s.resuelto).replace(/^(\d{4})-(\d\d)-(\d\d)/, '$3/$2/$1') : '', X + 270, y + 32, { width: ANCHO - 290, align: 'center' });

    /* pie: verificación */
    doc.moveTo(X, 772).lineTo(X + ANCHO, 772).lineWidth(0.5).strokeColor('#d9c6e6').stroke();
    doc.font('Helvetica').fontSize(7.2).fillColor(GRIS)
      .text(`Documento firmado electrónicamente por la Dirección del IES Valle del Jerte mediante la aplicación del centro. Código seguro de verificación: `, X, 780, { width: ANCHO, continued: true })
      .font('Helvetica-Bold').fillColor(MORADO).text(csv, { continued: true })
      .font('Helvetica').fillColor(GRIS).text(` (comprobable en la App, módulo DAP · registro DAP-${String(s.id).padStart(4, '0')}).`);
    doc.end();
  });
}
