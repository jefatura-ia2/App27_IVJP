/**
 * Impreso oficial «PERMISO POR ASUNTOS PARTICULARES (Art. 12)» con los datos de una solicitud de DAP ya resuelta por
 * la Directora. Lo imprimen Administración 1 y 2 (y Dirección/Jefatura): dos páginas, «Ejemplar para registro» y
 * «Ejemplar para el interesado».
 * Protección de datos: la app no guarda DNI ni domicilio; esos campos salen en blanco para rellenarlos a mano.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import PDFDocument from 'pdfkit';
import { codigoVerificacion } from './firma.js';
import { textoVerificable } from './pdfDap.js';

const LOGO = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..', 'assets', 'logo-ivj.png');
const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
const DIAS = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
const NAVY = '#1f2d4d', TINTA = '#111827', GRIS = '#6b7280', PUNTOS = '#9aa3b2', FONDO = '#eef2f8', BORDE = '#c9d2e3';
const X = 48, ANCHO = 499;
export const DIRECTORA = process.env.DIRECTORA_NOMBRE || 'Claudia Ortega Ávila';
export const CONSEJERIA = process.env.CONSEJERIA_NOMBRE || 'Educación y Formación Profesional';

const separar = n => { const [a, b] = String(n || '').split(',').map(s => (s || '').trim()); return { apellidos: a || '', nombre: b || '' }; };
const largo = iso => { const d = new Date(iso + 'T12:00:00Z'); return `${DIAS[d.getUTCDay()]}, ${d.getUTCDate()} de ${MESES[d.getUTCMonth()]} de ${d.getUTCFullYear()}`; };
const corta = iso => { const [a, m, d] = String(iso).slice(0, 10).split('-'); return `${d}/${m}/${a}`; };

export async function generarImpresoDap(s, { telefono = '' } = {}) {
  const csv = await codigoVerificacion(textoVerificable(s));
  const reg = 'DAP-' + String(s.id).padStart(4, '0');
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A4', margin: 0, autoFirstPage: false,
      info: { Title: `Permiso por asuntos particulares · ${reg}`, Author: 'IES Valle del Jerte · Dirección' } });
    const trozos = [];
    doc.on('data', b => trozos.push(b)); doc.on('end', () => resolve(Buffer.concat(trozos))); doc.on('error', reject);
    pagina(doc, s, { telefono, csv, reg, ejemplar: 'registro' });
    pagina(doc, s, { telefono, csv, reg, ejemplar: 'interesado' });
    doc.end();
  });
}

function pagina(doc, s, { telefono, csv, reg, ejemplar }) {
  doc.addPage();
  const { apellidos, nombre } = separar(s.profesor);

  /* ---------- cabecera: logo del centro y Junta de Extremadura ---------- */
  doc.roundedRect(X, 40, 150, 76, 4).lineWidth(0.7).strokeColor(BORDE).stroke();
  if (fs.existsSync(LOGO)) doc.image(LOGO, X + 10, 50, { fit: [52, 56] });
  doc.font('Helvetica-Bold').fontSize(9).fillColor('#6B2D8B').text('I.E.S.', X + 68, 58, { width: 78 })
    .text('«Valle del Jerte»', X + 68, doc.y, { width: 78 });
  doc.font('Helvetica').fontSize(6.6).fillColor(GRIS).text('C/ Pedro y Francisco González, s/n · 10600 Plasencia (Cáceres)', X + 68, doc.y + 3, { width: 78 });

  const JX = 335, JW = X + ANCHO - JX;
  doc.roundedRect(JX, 40, JW, 76, 4).lineWidth(0.9).strokeColor(NAVY).stroke();
  doc.font('Helvetica-Bold').fontSize(13).fillColor(NAVY).text('Junta de Extremadura', JX + 14, 56, { width: JW - 24 });
  doc.font('Helvetica').fontSize(8.6).fillColor(TINTA).text('Consejería de ' + CONSEJERIA, JX + 14, 78, { width: JW - 24 });

  /* ---------- título ---------- */
  doc.font('Helvetica-Bold').fontSize(15.5).fillColor(NAVY).text('PERMISO POR ASUNTOS PARTICULARES', X, 134, { width: ANCHO, align: 'center' });
  doc.font('Helvetica').fontSize(8.5).fillColor(GRIS).text('(Art. 12)', X, doc.y + 2, { width: ANCHO, align: 'center' });
  doc.font('Helvetica').fontSize(7.4).fillColor(GRIS).text(`Registro ${reg} · solicitud presentada en la aplicación del centro`, X, doc.y + 1, { width: ANCHO, align: 'center' });
  doc.moveTo(X, 182).lineTo(X + ANCHO, 182).lineWidth(0.8).strokeColor(NAVY).stroke();

  /* utilidades */
  const seccion = (titulo, y, alto) => {
    doc.rect(X, y, ANCHO, 18).fill(NAVY);
    doc.font('Helvetica-Bold').fontSize(8.6).fillColor('#fff').text(titulo, X + 10, y + 5, { lineBreak: false });
    doc.rect(X, y + 18, ANCHO, alto).fillAndStroke(FONDO, NAVY);
    return y + 18;
  };
  /* etiqueta + valor sobre línea de puntos */
  const campo = (etq, valor, x, y, w, { negrita = true } = {}) => {
    doc.font('Helvetica-Bold').fontSize(8.6).fillColor(NAVY);
    const we = doc.widthOfString(etq) + 6;
    doc.text(etq, x, y, { lineBreak: false });
    doc.moveTo(x + we, y + 10).lineTo(x + w, y + 10).dash(1, { space: 1.6 }).lineWidth(0.6).strokeColor(PUNTOS).stroke().undash();
    if (valor) doc.font(negrita ? 'Helvetica-Bold' : 'Helvetica').fontSize(9.4).fillColor(TINTA).text(valor, x + we + 2, y - 1, { width: w - we - 4, lineBreak: false, ellipsis: true });
  };
  const casilla = (x, y, marcada) => {
    doc.rect(x, y, 10, 10).lineWidth(0.8).strokeColor(TINTA).stroke();
    if (marcada) doc.moveTo(x + 2, y + 2).lineTo(x + 8, y + 8).moveTo(x + 8, y + 2).lineTo(x + 2, y + 8).lineWidth(1.4).strokeColor(TINTA).stroke();
  };

  /* ---------- datos del interesado ---------- */
  let y = seccion('DATOS DEL INTERESADO', 196, 82) + 12;
  const I = X + 12, F = X + ANCHO - 12;
  campo('Apellidos:', apellidos, I, y, I + 285 - I);
  campo('Nombre:', nombre, I + 298, y, F - (I + 298));
  y += 22;
  campo('Tipo de vía (C/, Avda., ...):', '', I, y, 280);
  campo('Nº:', '', I + 298, y, 52);
  campo('Puerta:', '', I + 362, y, F - (I + 362));
  y += 22;
  campo('DNI:', '', I, y, 200);
  campo('Teléfono:', telefono, I + 222, y, F - (I + 222));

  /* ---------- fechas ---------- */
  y = seccion('FECHAS DEL PERMISO', 302, 66) + 12;
  campo('Inicio:', largo(s.fecha), I, y, 230);
  campo('Fin:', largo(s.fecha), I + 248, y, F - (I + 248));
  y += 22;
  const turno = (s.turnos || []).map(t => t === 'vespertino' ? 'vespertino' : 'diurno').join(' y ') || 'diurno';
  const info = `Un día, turno ${turno}.` + (s.observaciones ? ' ' + String(s.observaciones).replace(/\s+/g, ' ') : '') + (s.fuerzaMayor ? ' Concedido por fuerza mayor.' : '');
  doc.font('Helvetica-Bold').fontSize(8.6).fillColor(NAVY).text('Información adicional:', I, y, { lineBreak: false });
  doc.font('Helvetica').fontSize(9).fillColor(TINTA).text(info, I + 108, y - 0.5, { width: F - I - 108, height: 24, ellipsis: true });
  doc.moveTo(I + 106, y + 10).lineTo(F, y + 10).dash(1, { space: 1.6 }).lineWidth(0.6).strokeColor(PUNTOS).stroke().undash();
  doc.moveTo(I, y + 24).lineTo(F, y + 24).dash(1, { space: 1.6 }).lineWidth(0.6).strokeColor(PUNTOS).stroke().undash();

  /* ---------- declaración y firma del interesado ---------- */
  y = 398;
  doc.font('Helvetica').fontSize(8.8).fillColor(TINTA).text('El presentador declara que son ciertos los datos consignados y que reúne los requisitos establecidos en el procedimiento correspondiente.', I, y, { width: ANCHO - 24, align: 'justify' });
  y = doc.y + 14;
  campo('Firma del interesado:', 'Presentada con su usuario en la App', I, y, 300, { negrita: false });
  campo('Fecha:', s.creado ? corta(s.creado) + ' · ' + String(s.creado).slice(11, 16) : '', I + 318, y, F - (I + 318));

  /* ---------- resolución ---------- */
  const est = s.estado, procede = est === 'concedida';
  y = seccion('RESOLUCIÓN DE LA DIRECCIÓN DEL CENTRO', 458, 250) + 16;
  const R = X + 18;
  doc.font('Helvetica').fontSize(9.6).fillColor(TINTA).text('La directora del Centro considera que:', R, y);
  y += 22;
  casilla(R + 12, y, procede); doc.font('Helvetica-Bold').fontSize(9.6).text('PROCEDE', R + 28, y + 1, { lineBreak: false });
  casilla(R + 150, y, !procede); doc.text('NO PROCEDE', R + 166, y + 1, { lineBreak: false });
  doc.font('Helvetica').text('su concesión', R + 316, y + 1, { lineBreak: false });
  y += 16;
  doc.text('atendiendo a las necesidades del servicio.', R + 12, y);
  y += 24;
  doc.font('Helvetica-Bold').fontSize(9.6).text('En caso de denegación:', R, y);
  y += 18;
  const motivo = procede ? '' : est === 'revocada'
    ? `Revocación de la concesión${s.concedido ? ' del ' + corta(s.concedido) : ''} por necesidades del servicio${s.nota ? ': ' + s.nota : '.'}`
    : (s.nota || 'Necesidades del servicio.');
  doc.font('Helvetica-Bold').fontSize(8.6).fillColor(NAVY).text('MOTIVACIÓN:', R + 12, y, { lineBreak: false });
  doc.moveTo(R + 82, y + 10).lineTo(X + ANCHO - 16, y + 10).dash(1, { space: 1.6 }).lineWidth(0.6).strokeColor(PUNTOS).stroke().undash();
  doc.moveTo(R + 12, y + 26).lineTo(X + ANCHO - 16, y + 26).dash(1, { space: 1.6 }).lineWidth(0.6).strokeColor(PUNTOS).stroke().undash();
  if (motivo) doc.font('Helvetica').fontSize(9).fillColor(TINTA).text(motivo, R + 84, y - 0.5, { width: X + ANCHO - 16 - R - 84, height: 30, lineGap: 5.5, ellipsis: true });
  y += 42;
  doc.font('Helvetica').fontSize(9.6).fillColor(TINTA).text('Se notifica al interesado/a.', R, y);
  y += 22;
  const f = String(s.resuelto || s.creado).slice(0, 10).split('-');
  const linea = (x, w, t) => { doc.moveTo(x, y + 11).lineTo(x + w, y + 11).undash().lineWidth(0.7).strokeColor(TINTA).stroke(); doc.font('Helvetica-Bold').fontSize(9.6).text(t, x, y, { width: w, align: 'center', lineBreak: false }); };
  doc.font('Helvetica').fontSize(9.6).fillColor(TINTA).text('En Plasencia, a', R, y, { lineBreak: false });
  linea(R + 76, 34, String(+f[2]));
  doc.font('Helvetica').text('de', R + 120, y, { lineBreak: false });
  linea(R + 138, 90, MESES[+f[1] - 1]);
  doc.font('Helvetica').text('de 20', R + 236, y, { lineBreak: false });
  linea(R + 264, 26, f[0].slice(2));
  y += 28;
  doc.font('Helvetica').fontSize(9.6).text('Fdo.: La Directora', X, y, { width: ANCHO, align: 'center' });
  doc.font('Helvetica').fontSize(6.8).fillColor(GRIS).text(`Firmado electrónicamente en la aplicación del centro${s.resuelto ? ' el ' + corta(s.resuelto) + ' a las ' + String(s.resuelto).slice(11, 16) : ''}`, X, doc.y + 3, { width: ANCHO, align: 'center' });
  doc.font('Helvetica-Bold').fontSize(10.4).fillColor(TINTA).text('Dña. ' + DIRECTORA, X, doc.y + 5, { width: ANCHO, align: 'center' });

  /* ---------- ejemplar ---------- */
  y = 738;
  casilla(X + 4, y, ejemplar === 'registro'); doc.font('Helvetica').fontSize(8.6).fillColor(TINTA).text('Ejemplar para registro', X + 20, y + 1, { lineBreak: false });
  casilla(X + 4, y + 16, ejemplar === 'interesado'); doc.text('Ejemplar para el interesado', X + 20, y + 17, { lineBreak: false });

  /* ---------- pie: verificación ---------- */
  doc.moveTo(X, 778).lineTo(X + ANCHO, 778).lineWidth(0.5).strokeColor(BORDE).stroke();
  doc.font('Helvetica').fontSize(7).fillColor(GRIS)
    .text('Resolución firmada electrónicamente por la Dirección del IES Valle del Jerte en la aplicación del centro. Código seguro de verificación: ', X, 785, { width: ANCHO, continued: true })
    .font('Helvetica-Bold').fillColor(NAVY).text(csv, { continued: true })
    .font('Helvetica').fillColor(GRIS).text(` (registro ${reg}). Los datos personales se tratan para la gestión de este permiso; más información en «Protección de datos» de la App.`);
}
