/**
 * Mapa de perfiles y permisos (lo gestiona solo la cuenta de administración).
 * Para cada perfil, qué mosaicos (iconos) de la portada ve y qué notificaciones (avisos de la portada) recibe.
 * Un usuario ve/recibe la unión de lo que permiten sus perfiles. Las cuentas sin perfil «principal»
 * (profesor, no docente, conserjería, administración, dirección) cuentan además como «profesor».
 * La cuenta de administración lo ve todo. Lo que no se haya configurado usa los valores por defecto (el comportamiento actual).
 */
import { query } from '../db.js';
import { Ajuste } from '../models/index.js';
import { PERFILES, perfilesExtra } from './authService.js';

const CLAVE = 'mapa_perfiles';
export const MOSAICOS = ['profesores', 'grupos', 'aulas', 'biblioteca', 'guardias', 'ausencia', 'calendarios', 'dap', 'ccp', 'disciplina', 'cronologia', 'avisos', 'familias'];
export const NOTIFICACIONES = ['aus_grabar', 'incidencias', 'ccp', 'datos', 'disc_jefatura', 'disc_tutoria', 'dap_resol', 'dap_gestion', 'justificar'];
/* notificaciones solo para algunos perfiles por defecto */
const SOLO = { aus_grabar: ['jefe_estudios'], incidencias: ['jefe_estudios', 'conserjeria'], disc_jefatura: ['jefe_estudios'], disc_tutoria: ['tutor'] };
/* conductas contrarias (partes de disciplina): solo las reciben Jefatura de Estudios y el tutor/a del grupo.
   No se pueden cambiar en el mapa de perfiles (protección de datos de menores) */
export const FIJAS = ['disc_jefatura', 'disc_tutoria'];
const BASE = ['profesores', 'grupos', 'aulas', 'biblioteca', 'guardias', 'ausencia', 'dap', 'disciplina', 'cronologia'];
const PRINCIPALES = ['profesor', 'no_docente', 'conserjeria', 'administracion', 'direccion'];

export function porDefecto(perfil) {
  const tiles = ['profesor', 'no_docente', 'conserjeria', 'administracion', 'direccion'].includes(perfil) ? BASE.slice() : [];
  if (perfil === 'tutor') tiles.push('familias');
  if (['jefe_departamento', 'direccion', 'jefe_estudios', 'ccp', 'consejo_escolar'].includes(perfil)) tiles.push('ccp');
  return { tiles, avisos: NOTIFICACIONES.filter(n => !SOLO[n] || SOLO[n].includes(perfil)) };
}
export async function todosLosPerfiles() {
  return PERFILES.concat((await perfilesExtra()).map(p => p.k));
}
async function leerGuardado() {
  try { const c = JSON.parse((await Ajuste.leer({ query }, CLAVE)) || '{}'); return c && typeof c === 'object' ? c : {}; } catch { return {}; }
}
export async function mapa() {
  const g = await leerGuardado();
  const out = {};
  for (const p of await todosLosPerfiles()) {
    const d = porDefecto(p), c = g[p] || {};
    out[p] = { tiles: Array.isArray(c.tiles) ? c.tiles.filter(t => MOSAICOS.includes(t)) : d.tiles,
      /* las notificaciones añadidas después de guardar el mapa toman su valor por defecto */
      avisos: Array.isArray(c.avisos) ? NOTIFICACIONES.filter(a => {
        if (FIJAS.includes(a)) return d.avisos.includes(a);
        const nueva = (Array.isArray(c.conocidas) && !c.conocidas.includes(a)) || (!Array.isArray(c.conocidas) && (a === 'aus_grabar' || a === 'incidencias'));
        return nueva ? d.avisos.includes(a) : c.avisos.includes(a);
      }) : d.avisos, propio: !!g[p] };
  }
  return out;
}
export async function guardar(config = {}, restablecer = false) {
  if (restablecer) { await Ajuste.guardar({ query }, CLAVE, '{}'); return mapa(); }
  const validos = await todosLosPerfiles(), limpio = {};
  for (const [p, v] of Object.entries(config || {})) {
    if (!validos.includes(p) || !v) continue;
    limpio[p] = { tiles: [...new Set((v.tiles || []).filter(t => MOSAICOS.includes(t)))], avisos: [...new Set((v.avisos || []).filter(a => NOTIFICACIONES.includes(a)))], conocidas: NOTIFICACIONES.slice() };
  }
  await Ajuste.guardar({ query }, CLAVE, JSON.stringify(limpio));
  return mapa();
}
/** Lo que corresponde a un usuario */
export async function deUsuario(u) {
  if (!u) return { tiles: [], avisos: [] };
  if (u.rol === 'admin') return { tiles: MOSAICOS.slice(), avisos: NOTIFICACIONES.slice(), todo: true };
  const m = await mapa();
  const perfiles = (u.perfiles || []).filter(p => m[p]);
  if (!perfiles.some(p => PRINCIPALES.includes(p))) perfiles.push('profesor');
  const tiles = new Set(), avisos = new Set();
  for (const p of perfiles) { m[p].tiles.forEach(t => tiles.add(t)); m[p].avisos.forEach(a => avisos.add(a)); }
  /* partes de disciplina: Jefatura de Estudios (de su etapa) y tutor/a del grupo, aunque no tengan el perfil marcado */
  FIJAS.forEach(a => avisos.delete(a));
  const { etapasDe } = await import('./disciplinaService.js');
  if (etapasDe(u).length) avisos.add('disc_jefatura');
  let tutor = (u.perfiles || []).includes('tutor') || (u.tutorDe || []).length > 0;
  if (!tutor && u.nombre) {
    const { profesorDeCuenta } = await import('./authService.js');
    const prof = await profesorDeCuenta(u.nombre);
    tutor = !!prof && (await query('SELECT 1 FROM tutoria WHERE profesor = $1', [prof])).rowCount > 0;
  }
  if (tutor) avisos.add('disc_tutoria');
  return { tiles: MOSAICOS.filter(t => tiles.has(t)), avisos: NOTIFICACIONES.filter(a => avisos.has(a)), perfiles };
}
/** Cuántas cuentas activas tiene cada perfil (para el mapa) */
export async function recuento() {
  const { rows } = await query(`SELECT p, count(*)::int AS n FROM usuario, unnest(perfiles) AS p WHERE activo GROUP BY p`);
  return Object.fromEntries(rows.map(r => [r.p, r.n]));
}
