import fs from 'node:fs/promises';
import path from 'node:path';
import { query, transaccion } from '../db.js';
import { valido } from './modoAdmin.js';
import { usuarioActual } from './contexto.js';
import { hashClave, verificarClave, claveAleatoria, frenoComprobar, frenoFallo, frenoExito } from './authService.js';
import { config } from '../config.js';
import { firmarDoc } from './firma.js';

const norm = t => String(t == null ? '' : t).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();

/** ¿Es una de las contraseñas de administrador? */
/* Seguridad: el pase solo vale para la MISMA cuenta de administración que lo obtuvo (usuario de la sesión en curso) */
export function claveAdminOk(clave, usuario = usuarioActual()) {
  const c = String(clave || '').trim();
  if (!c || !usuario || usuario.rol !== 'admin') return false;
  const v = valido(c);
  if (v) return v.id === usuario.id;   /* pase personal del modo administrador */
  return config.claveComun && config.adminPasswords.includes(c);   /* clave común: solo si se permite en .env */
}

/** Admin, o la contraseña propia del departamento */
/* Claves de departamento: guardadas cifradas (scrypt) y con freno a los intentos fallidos (por departamento e IP) */
async function claveDepOk(depId, clave) {
  const k = 'dep#' + depId + '|' + ((usuarioActual() || {}).ip || '');
  frenoComprobar(k);
  const { rows } = await query('SELECT clave FROM departamento WHERE id=$1', [depId]);
  const guardada = rows[0] ? rows[0].clave : '';
  const c = String(clave || '').trim();
  const ok = !!guardada && !!c && (guardada.startsWith('scrypt$') ? await verificarClave(c, guardada) : false);
  if (ok) frenoExito(k); else frenoFallo(k);
  return ok;
}
/** Al arrancar: cifra las claves de departamento que aún estén en claro */
export async function protegerClavesDep() {
  const { rows } = await query("SELECT id, clave FROM departamento WHERE clave NOT LIKE 'scrypt$%'");
  for (const r of rows) await query('UPDATE departamento SET clave=$2 WHERE id=$1', [r.id, await hashClave(String(r.clave || '').trim())]);
  return rows.length;
}
async function depAutorizado(depId, clave) {
  if (claveAdminOk(clave)) return true;
  return claveDepOk(depId, clave);
}

async function exigirAutorizado(depId, clave) {
  if (!(await depAutorizado(depId, clave))) {
    const e = new Error('Contraseña incorrecta'); e.status = 401; throw e;
  }
}

async function carpeta(depId) {
  const dir = path.join(config.uploadsDir, String(depId));
  await fs.mkdir(dir, { recursive: true });
  return dir;
}

/** Lista todos los departamentos con sus documentos, más recientes primero */
export async function listar() {
  const { rows: deps } = await query(
    `SELECT id, nombre, jefe, estado, to_char(fecha,'YYYY-MM-DD') AS fecha, to_char(fecha,'HH24:MI') AS hora, obs
     FROM departamento ORDER BY nombre`);
  const { rows: docs } = await query(
    `SELECT id, departamento_id AS "depId", nombre, to_char(fecha,'YYYY-MM-DD') AS fecha, to_char(fecha,'HH24:MI') AS hora
     FROM documento ORDER BY fecha DESC`);
  for (const x of docs) x.firma = await firmarDoc(x.id);   /* enlace válido 12 h sin sesión (app de móvil) */
  return deps.map(d => ({
    ...d,
    fueraPlazo: d.estado === 'entregado' && d.fecha && d.fecha > config.fechaLimiteProg,
    docs: docs.filter(x => x.depId === d.id),
  }));
}

/** Admin: crea un departamento nuevo. Devuelve {id, clave} (clave generada si no se indicó) */
export async function crear({ nombre, jefe, claveDep, clave }) {
  if (!claveAdminOk(clave)) { const e = new Error('No autorizado'); e.status = 401; throw e; }
  nombre = String(nombre || '').trim();
  if (!nombre) { const e = new Error('Falta el nombre del departamento'); e.status = 400; throw e; }
  const { rows } = await query('SELECT nombre FROM departamento');
  if (rows.some(r => norm(r.nombre) === norm(nombre))) { const e = new Error('Ya existe un departamento con ese nombre'); e.status = 400; throw e; }
  let claveFinal = String(claveDep || '').trim();
  if (!claveFinal) claveFinal = claveAleatoria(10);   /* aleatoria (antes: 3 letras + 4 cifras, fácil de adivinar) */
  if (claveFinal.length < 8) { const e = new Error('La contraseña debe tener al menos 8 caracteres'); e.status = 400; throw e; }
  const { rows: ins } = await query(
    'INSERT INTO departamento (nombre, jefe, clave) VALUES ($1,$2,$3) RETURNING id', [nombre, String(jefe || '').trim(), await hashClave(claveFinal)]);
  return { id: ins[0].id, clave: claveFinal };
}

/** Sube uno o varios PDFs al departamento */
export async function subir(depId, clave, nombreOriginal, buffer) {
  await exigirAutorizado(depId, clave);
  if (!buffer || !buffer.length) { const e = new Error('No se ha recibido el PDF'); e.status = 400; throw e; }
  if (buffer.length > config.maxPdfMb * 1024 * 1024) { const e = new Error('El PDF supera ' + config.maxPdfMb + ' MB'); e.status = 400; throw e; }
  if (buffer.toString('ascii', 0, 4) !== '%PDF') { const e = new Error('El archivo no es un PDF'); e.status = 400; throw e; }
  const limpio = String(nombreOriginal || 'programacion.pdf').replace(/[\\/:*?"<>|]/g, '_').slice(0, 120);
  const archivoDisco = Date.now() + '_' + Math.random().toString(36).slice(2, 8) + '.pdf';
  await fs.writeFile(path.join(await carpeta(depId), archivoDisco), buffer);

  return transaccion(async c => {
    const { rows: prev } = await c.query('SELECT COUNT(*)::int AS n FROM documento WHERE departamento_id=$1', [depId]);
    const { rows: ins } = await c.query(
      'INSERT INTO documento (departamento_id, nombre, archivo) VALUES ($1,$2,$3) RETURNING id, to_char(fecha,\'YYYY-MM-DD\') AS fecha, to_char(fecha,\'HH24:MI\') AS hora',
      [depId, limpio, archivoDisco]);
    /* fecha de entrega = momento de la primera subida; las siguientes no la cambian */
    if (prev[0].n === 0) await c.query("UPDATE departamento SET estado='entregado', fecha=now() WHERE id=$1", [depId]);
    return { id: ins[0].id, nombre: limpio, fecha: ins[0].fecha, hora: ins[0].hora };
  });
}

export async function rutaArchivo(depId, docId) {
  const { rows } = await query('SELECT archivo, nombre FROM documento WHERE id=$1 AND departamento_id=$2', [docId, depId]);
  if (!rows.length) { const e = new Error('Documento no encontrado'); e.status = 404; throw e; }
  return { ruta: path.join(config.uploadsDir, String(depId), rows[0].archivo), nombre: rows[0].nombre };
}

export async function borrarDocumento(depId, docId, clave) {
  await exigirAutorizado(depId, clave);
  const { rows } = await query('SELECT archivo FROM documento WHERE id=$1 AND departamento_id=$2', [docId, depId]);
  if (!rows.length) { const e = new Error('Documento no encontrado'); e.status = 404; throw e; }
  await query('DELETE FROM documento WHERE id=$1', [docId]);
  try { await fs.unlink(path.join(config.uploadsDir, String(depId), rows[0].archivo)); } catch { /* ya no está, no pasa nada */ }
  const { rows: quedan } = await query('SELECT COUNT(*)::int AS n FROM documento WHERE departamento_id=$1', [depId]);
  if (quedan[0].n === 0) await query("UPDATE departamento SET estado='pendiente', fecha=NULL WHERE id=$1", [depId]);
}

/** Elimina la entrega completa (todos los PDF) y vuelve el departamento a pendiente */
export async function anular(depId, clave) {
  await exigirAutorizado(depId, clave);
  const { rows: docs } = await query('SELECT archivo FROM documento WHERE departamento_id=$1', [depId]);
  await query('DELETE FROM documento WHERE departamento_id=$1', [depId]);
  await query("UPDATE departamento SET estado='pendiente', fecha=NULL WHERE id=$1", [depId]);
  for (const d of docs) { try { await fs.unlink(path.join(config.uploadsDir, String(depId), d.archivo)); } catch { /* ignorar */ } }
}

export async function guardarObs(depId, obs, clave) {
  await exigirAutorizado(depId, clave);
  await query('UPDATE departamento SET obs=$1 WHERE id=$2', [String(obs || ''), depId]);
}

export async function guardarJefe(depId, jefe, clave) {
  await exigirAutorizado(depId, clave);
  await query('UPDATE departamento SET jefe=$1 WHERE id=$2', [String(jefe || '').trim(), depId]);
}

export async function cambiarClave(depId, claveDepNueva, clave) {
  await exigirAutorizado(depId, clave);
  const nueva = String(claveDepNueva || '').trim();
  if (nueva.length < 8) { const e = new Error('La contraseña debe tener al menos 8 caracteres'); e.status = 400; throw e; }
  await query('UPDATE departamento SET clave=$1 WHERE id=$2', [await hashClave(nueva), depId]);
}

/** Login de jefe/a de departamento: {ok, depId, depNombre} */
export async function loginJefe(depId, clave) {
  const { rows } = await query('SELECT id, nombre FROM departamento WHERE id=$1', [depId]);
  if (!rows.length) return { ok: false };
  if (!(await claveDepOk(depId, clave))) return { ok: false };
  return { ok: true, depId: rows[0].id, depNombre: rows[0].nombre };
}

/** Admin: marcar a mano un departamento como entregado o pendiente (sin tocar sus documentos) */
export async function cambiarEstado(depId, estado, clave) {
  if (!claveAdminOk(clave)) { const e = new Error('No autorizado'); e.status = 401; throw e; }
  if (!['pendiente', 'entregado'].includes(estado)) { const e = new Error('Estado no válido'); e.status = 400; throw e; }
  if (estado === 'entregado') await query("UPDATE departamento SET estado='entregado', fecha=COALESCE(fecha, now()) WHERE id=$1", [depId]);
  else await query("UPDATE departamento SET estado='pendiente', fecha=NULL WHERE id=$1", [depId]);
}
