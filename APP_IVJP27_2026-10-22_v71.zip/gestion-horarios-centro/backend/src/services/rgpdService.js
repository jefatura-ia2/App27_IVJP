/**
 * Protección de datos: datos de la información de privacidad (responsable, DPD, contacto) y plazos de
 * conservación con el «cierre de curso», que borra lo que ha vencido (RGPD art. 5.1.e).
 * Los plazos se expresan en cursos completos que se conservan ADEMÁS del curso actual.
 */
import fs from 'node:fs';
import path from 'node:path';
import { query, transaccion } from '../db.js';
import { Ajuste } from '../models/index.js';
import { config } from '../config.js';
import { ahora } from './tiempo.js';
import { carpetaDe } from './disciplinaService.js';

const err = (m, s = 400) => Object.assign(new Error(m), { status: s });
export const esAdmin = u => !!u && u.rol === 'admin';

/* ---------- información de privacidad ---------- */
export const PRIVACIDAD_DEFECTO = {
  responsable: 'Consejería con competencias en materia de educación de la Junta de Extremadura. Centro: IES Valle del Jerte (Plasencia).',
  dpd: 'Delegado/a de Protección de Datos de la Consejería con competencias en educación (el contacto figura en la sede electrónica de la Junta de Extremadura).',
  contacto: 'Jefatura de Estudios del IES Valle del Jerte (también a través de la secretaría del centro).',
  validado: false,
  validadoFecha: '',
};
const limpio = (v, n = 600) => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, n);
export async function privacidad() {
  const v = await Ajuste.leer({ query }, 'privacidad');
  const p = { ...PRIVACIDAD_DEFECTO, ...(v ? JSON.parse(v) : {}) };
  return { ...p, plazos: await plazos(), categorias: CATEGORIAS.map(({ k, l, d }) => ({ k, l, d })) };
}
export async function guardarPrivacidad(usuario, b = {}) {
  if (!esAdmin(usuario)) throw err('Solo administración', 404);
  const actual = await privacidad();
  const nuevo = {
    responsable: limpio(b.responsable ?? actual.responsable) || PRIVACIDAD_DEFECTO.responsable,
    dpd: limpio(b.dpd ?? actual.dpd) || PRIVACIDAD_DEFECTO.dpd,
    contacto: limpio(b.contacto ?? actual.contacto) || PRIVACIDAD_DEFECTO.contacto,
    validado: !!(b.validado ?? actual.validado),
    validadoFecha: (b.validado ?? actual.validado) ? (actual.validado ? actual.validadoFecha : ahora().fecha) : '',
  };
  await Ajuste.guardar({ query }, 'privacidad', JSON.stringify(nuevo));
  return privacidad();
}

/* ---------- plazos de conservación ---------- */
export const CATEGORIAS = [
  { k: 'ausencias', l: 'Ausencias, motivos, justificaciones y sus PDF', d: 1 },
  { k: 'partes', l: 'Partes de disciplina', d: 1 },
  { k: 'firmas', l: 'Firmas de las guardias', d: 1 },
  { k: 'dap', l: 'Solicitudes de días de asuntos particulares (DAP)', d: 1 },
  { k: 'reservas', l: 'Reservas de espacios', d: 0 },
  { k: 'incidencias', l: 'Incidencias de las aulas ya resueltas', d: 0 },
  { k: 'accesos', l: 'Registro de accesos a datos sensibles', d: 2 },
];
export async function plazos() {
  const v = await Ajuste.leer({ query }, 'conservacion');
  const g = v ? JSON.parse(v) : {};
  return Object.fromEntries(CATEGORIAS.map(c => [c.k, Number.isInteger(g[c.k]) ? g[c.k] : c.d]));
}
export async function guardarPlazos(usuario, valores = {}) {
  if (!esAdmin(usuario)) throw err('Solo administración', 404);
  const p = await plazos();
  for (const c of CATEGORIAS) if (valores[c.k] !== undefined) {
    const n = Number(valores[c.k]);
    if (!Number.isInteger(n) || n < 0 || n > 10) throw err('Plazo no válido: ' + c.l);
    p[c.k] = n;
  }
  await Ajuste.guardar({ query }, 'conservacion', JSON.stringify(p));
  return p;
}
/** Primer día del curso que ya no se conserva: 1 de septiembre de (curso actual − n) */
export function corte(n, hoy = ahora().fecha) {
  const [y, m] = hoy.split('-').map(Number);
  const inicio = m >= 9 ? y : y - 1;
  return `${inicio - n}-09-01`;
}

/* qué se borraría de cada categoría (fecha de corte = $1) */
const SQL = {
  ausencias: { cuenta: `SELECT count(*)::int AS n FROM ausencia WHERE COALESCE(hasta, fecha) < $1::date` },
  partes: { cuenta: `SELECT count(*)::int AS n FROM parte_disciplina WHERE fecha < $1::date` },
  firmas: { cuenta: `SELECT count(*)::int AS n FROM guardia_firma WHERE fecha < $1::date` },
  dap: { cuenta: `SELECT count(*)::int AS n FROM dap_solicitud WHERE fecha < $1::date` },
  reservas: { cuenta: `SELECT count(*)::int AS n FROM reserva WHERE fecha < $1::date` },
  incidencias: { cuenta: `SELECT count(*)::int AS n FROM aula_incidencia WHERE resuelta AND creado < $1::date` },
  accesos: { cuenta: `SELECT count(*)::int AS n FROM registro_acceso WHERE cuando < $1::date` },
};
export async function previsualizar(usuario, hoy) {
  if (!esAdmin(usuario)) throw err('Solo administración', 404);
  const p = await plazos();
  const out = [];
  for (const c of CATEGORIAS) {
    const f = corte(p[c.k], hoy);
    const { rows: [r] } = await query(SQL[c.k].cuenta, [f]);
    out.push({ k: c.k, l: c.l, cursos: p[c.k], antesDe: f, n: r.n });
  }
  return { categorias: out, total: out.reduce((s, x) => s + x.n, 0) };
}
/** Borra lo vencido. Devuelve lo borrado por categoría */
export async function cierreDeCurso(usuario, hoy) {
  const prev = await previsualizar(usuario, hoy);
  const f = Object.fromEntries(prev.categorias.map(c => [c.k, c.antesDe]));
  const borrado = {};
  const dirsJustif = [], pdfsPartes = [];
  await transaccion(async db => {
    /* ausencias y las justificaciones que solo cubren ausencias vencidas */
    const { rows: js } = await db.query(`SELECT DISTINCT justificacion_id AS id FROM ausencia a WHERE justificacion_id IS NOT NULL
        AND COALESCE(hasta, fecha) < $1::date
        AND NOT EXISTS (SELECT 1 FROM ausencia b WHERE b.justificacion_id = a.justificacion_id AND COALESCE(b.hasta, b.fecha) >= $1::date)`, [f.ausencias]);
    borrado.ausencias = (await db.query('DELETE FROM ausencia WHERE COALESCE(hasta, fecha) < $1::date', [f.ausencias])).rowCount;
    const huerfanas = (await db.query(`SELECT id FROM justificacion j WHERE creado < $1::date AND NOT EXISTS (SELECT 1 FROM ausencia a WHERE a.justificacion_id = j.id)`, [f.ausencias])).rows;
    const ids = [...new Set(js.concat(huerfanas).map(r => r.id))];
    if (ids.length) { await db.query('DELETE FROM justificacion WHERE id = ANY($1::int[])', [ids]); dirsJustif.push(...ids); }
    borrado.justificaciones = ids.length;
    const { rows: pts } = await db.query(`DELETE FROM parte_disciplina WHERE fecha < $1::date RETURNING etapa, archivo`, [f.partes]);
    pdfsPartes.push(...pts.filter(p => p.archivo));
    borrado.partes = pts.length;
    borrado.firmas = (await db.query('DELETE FROM guardia_firma WHERE fecha < $1::date', [f.firmas])).rowCount;
    await db.query('DELETE FROM dap_evento WHERE solicitud_id IN (SELECT id FROM dap_solicitud WHERE fecha < $1::date)', [f.dap]);
    borrado.dap = (await db.query('DELETE FROM dap_solicitud WHERE fecha < $1::date', [f.dap])).rowCount;
    borrado.reservas = (await db.query('DELETE FROM reserva WHERE fecha < $1::date', [f.reservas])).rowCount;
    borrado.incidencias = (await db.query('DELETE FROM aula_incidencia WHERE resuelta AND creado < $1::date', [f.incidencias])).rowCount;
    borrado.accesos = (await db.query('DELETE FROM registro_acceso WHERE cuando < $1::date', [f.accesos])).rowCount;
  });
  for (const id of dirsJustif) fs.rmSync(path.join(config.justificantesDir, String(id)), { recursive: true, force: true });
  for (const p of pdfsPartes) { try { fs.rmSync(path.join(carpetaDe(p.etapa), path.basename(p.archivo)), { force: true }); } catch { /* nada */ } }
  return { borrado, previo: prev };
}
