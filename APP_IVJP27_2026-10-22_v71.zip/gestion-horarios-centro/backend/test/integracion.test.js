/* Requiere PostgreSQL (DATABASE_URL). Usa un esquema temporal para no tocar los datos reales. */
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { pool, query } from '../src/db.js';
import { migrar } from '../src/models/index.js';
import { csvHorarios } from '../src/ingestors/index.js';
import * as S from '../src/services/servicioService.js';
import { datosInforme } from '../src/services/informeAusencias.js';
import { generarPDF } from '../src/services/pdfInforme.js';
import * as J from '../src/services/justificacionService.js';
import { generarDossier } from '../src/services/dossier.js';
import { PDFDocument } from 'pdf-lib';
import fs from 'node:fs/promises';
import { estadoDelDia } from '../src/services/guardiasService.js';
import { buscar, sesionesDe, aulasLibres } from '../src/services/horarioService.js';
import * as B from '../src/services/bibliotecaService.js';
import * as Auth from '../src/services/authService.js';

const ESQUEMA = 'prueba_' + process.pid;
const CSV = [
  '"Pérez Gil, Ana",2,3,,,,Guardia de Aula',
  '"López Sanz, Luis",2,3,Matemáticas,E1A,101,Docencia',
  '"López Sanz, Luis",2,4,Matemáticas,E1B,102,Docencia',
  '"Pérez Gil, Ana",2,R1,,,,Guardia de Recreo',
].join('\n');

before(async () => {
  pool.on('connect', c => c.query(`SET search_path TO ${ESQUEMA}`));
  await pool.query(`CREATE SCHEMA ${ESQUEMA}`);
  await migrar(pool);
  await csvHorarios.ingerirTexto(CSV);
});
after(async () => { await pool.query(`DROP SCHEMA ${ESQUEMA} CASCADE`); await pool.end(); });

test('horario cargado y buscador sin tildes', async () => {
  const r = await buscar('lopez');
  assert.equal(r[0].nombre, 'López Sanz, Luis');
  assert.equal((await sesionesDe('profesor', r[0].id)).length, 2);
  const libres = await aulasLibres(2, '3');
  assert.deepEqual(libres.map(a => a.codigo), ['102']);
});

test('ausencia grabada por Jefatura: guardias y grupos sin cubrir', async () => {
  await S.guardarAusencia({ id: 'a1', prof: 'lopez sanz, luis', fecha: '2026-10-06', modo: 'horas', horas: ['3'], obs: 'Ejercicios pág. 20', motivo: 'Cita médica' }, 'jefatura');
  const e = await estadoDelDia('2026-10-06');   // martes
  const t3 = e.tramos.find(t => t.tramo === '3');
  assert.deepEqual(t3.guardias.map(g => g.nombre), ['Pérez Gil, Ana']);
  assert.equal(t3.sinCubrir[0].grupo, 'E1A');   // casa el nombre aunque esté sin tildes
  assert.equal(t3.sinCubrir[0].tarea, 'Ejercicios pág. 20');
  assert.equal(e.tramos.find(t => t.tramo === '4').sinCubrir.length, 0);
});

test('notificada por un docente: pendiente hasta que Jefatura la graba; el público no ve el motivo', async () => {
  const hoy = (await query(`SELECT to_char(CURRENT_DATE,'YYYY-MM-DD') AS d`)).rows[0].d;
  const id = await S.notificar({ prof: 'Pérez Gil, Ana', fecha: hoy, modo: 'dia', motivo: 'Asuntos propios' }, 'aperez');
  let pub = await S.datosPublicos();
  assert.equal(pub.pendientes, 1);
  assert.ok(!pub.ausencias.some(a => a.id === id));
  await S.grabarAusencias([id]);
  pub = await S.datosPublicos();
  const a = pub.ausencias.find(x => x.id === id);
  assert.equal(pub.pendientes, 0);
  assert.equal(a.prof, 'Pérez Gil, Ana');
  assert.equal(a.motivo, undefined);
  assert.equal((await S.ausenciasAdmin()).find(x => x.id === id).motivo, 'Asuntos propios');
  await S.borrarAusencias([id]);
  assert.ok(!(await S.ausenciasAdmin()).some(x => x.id === id));
});

test('avisos y calendarios en la base de datos', async () => {
  await S.guardarAviso({ titulo: 'Claustro', texto: 'El jueves a las 17:00', nivel: 'importante' });
  await S.guardarCalendario('extra', { nombre: 'Actividades extraescolares', url: 'https://calendar.google.com/x' });
  const d = await S.datosPublicos();
  assert.equal(d.avisos[0].titulo, 'Claustro');
  assert.equal(d.calendarios.extra.url, 'https://calendar.google.com/x');
  await S.borrarAviso(d.avisos[0].id);
  assert.equal((await S.datosPublicos()).avisos.length, 0);
});

test('importación única desde la hoja de Google (no borra lo que ya hay)', async () => {
  const falso = async (url, opc) => ({ json: async () => (opc && opc.method === 'POST')
    ? { ok: true, ausencias: [{ id: 'h1', prof: 'López Sanz, Luis', fecha: '2026-09-21', modo: 'dia', motivo: 'Enfermedad', estado: 'Grabada', creado: '2026-09-20' },
                              { id: 'h2', prof: 'Pérez Gil, Ana', fecha: '2026-09-22', modo: 'horas', horas: ['R1'], estado: 'Pendiente' }] }
    : { avisos: [{ id: 'v1', titulo: 'Bienvenida', texto: 'Hola', nivel: 'info' }], calendarios: { dap: { nombre: 'DAP', url: 'https://c/x' } } } });
  const r = await S.importarDeHoja('http://hoja.local/exec', 'rafael2025', falso);
  assert.deepEqual(r, { ausencias: 2, avisos: 1, calendarios: 1 });
  const adm = await S.ausenciasAdmin();
  assert.equal(adm.find(a => a.id === 'h2').estado, 'Pendiente');
  assert.equal(adm.find(a => a.id === 'h1').creado, '2026-09-20');
  assert.ok(adm.some(a => a.id === 'a1'));   // la que ya estaba sigue
});

test('informe mensual: días, sesiones afectadas y PDF', async () => {
  /* Luis: martes 6 (3ª hora, ya grabada) + del 12 al 14 de octubre todo el día (lunes a miércoles) */
  await S.guardarAusencia({ id: 'm1', prof: 'López Sanz, Luis', fecha: '2026-10-12', hasta: '2026-10-14', modo: 'dia', motivo: 'Enfermedad' }, 'jefatura');
  await S.guardarAusencia({ id: 'm2', prof: 'Pérez Gil, Ana', fecha: '2026-09-30', hasta: '2026-10-01', modo: 'dia', motivo: 'Formación' }, 'jefatura');
  const inf = await datosInforme('2026-10');
  const luis = inf.porProfesor.find(p => p.profesor === 'López Sanz, Luis');
  assert.equal(luis.ausencias, 2);
  assert.equal(luis.dias, 4);              // 1 (día 6) + 3 (12-14)
  assert.equal(luis.clases, 1 + 2);        // 3ª del martes 6 + sus 2 clases del martes 13
  const ana = inf.porProfesor.find(p => p.profesor === 'Pérez Gil, Ana');
  assert.equal(ana.dias, 1);               // solo el 1 de octubre cae en el mes
  assert.equal(inf.totales.ausencias, 3);
  const pdf = await generarPDF(inf);
  assert.equal(pdf.subarray(0, 5).toString(), '%PDF-');
  assert.ok(pdf.length > 2000);
});

test('justificación: cuadrante, cómputo de horas, artículo, PDF y dossier', async () => {
  /* Luis: martes 13/10 (dentro de la ausencia m1), marca 3ª y 4ª (dos clases: lectivas) */
  const pdf = await PDFDocument.create(); pdf.addPage([300, 300]);
  const fichero = { originalname: 'parte_de_baja.pdf', buffer: Buffer.from(await pdf.save()) };
  await assert.rejects(J.crear('López Sanz, Luis', { ausencias: ['m1'], articulo: 3, detalle: [{ fecha: '2026-10-13', tramos: ['3'] }] },
    [{ originalname: 'foto.jpg', buffer: Buffer.from('JFIF') }], 'luis'), /PDF/);
  await assert.rejects(J.crear('Pérez Gil, Ana', { ausencias: ['m1'], articulo: 3, detalle: [{ fecha: '2026-10-13', tramos: ['3'] }] }, [fichero], 'ana'), /propias/);
  await assert.rejects(J.crear('López Sanz, Luis', { ausencias: ['m1'], articulo: 19, detalle: [{ fecha: '2026-10-13', tramos: ['3'] }] }, [fichero], 'luis'), /artículo/);
  const jid = await J.crear('López Sanz, Luis', { ausencias: ['m1'], articulo: 3,
    detalle: [{ fecha: '2026-10-13', tramos: ['3', '4'] }, { fecha: '2026-10-12', tramos: ['1', '2'] }] }, [fichero], 'luis');
  const m = await J.mias('López Sanz, Luis', '2026-10-20');
  const j = m.justificaciones.find(x => x.id === jid);
  assert.equal(j.lectivas, 2);              // martes 3ª y 4ª: docencia
  assert.equal(j.complementarias, 0);       // lunes 1ª y 2ª: sin actividad en su horario
  assert.equal(j.documentos.length, 1);
  assert.equal(m.ausencias.find(a => a.id === 'm1').justificacion_id, jid);
  await assert.rejects(J.crear('López Sanz, Luis', { ausencias: ['m1'], articulo: 3, detalle: [{ fecha: '2026-10-13', tramos: ['3'] }] }, [fichero], 'luis'), /ya está justificada/);
  await assert.rejects(J.borrarDoc(jid, j.documentos[0].id, 'López Sanz, Luis', false), /al menos un PDF/);

  const inf = await datosInforme('2026-10');
  assert.equal(inf.detalle.find(a => a.id === 'm1').articulo, 3);
  assert.ok(inf.porMotivo.some(x => x.motivo.startsWith('Art. 3.')));
  const d = await generarDossier('2026-10');
  const leido = await PDFDocument.load(d.pdf);
  assert.equal(d.justificaciones, 1);
  assert.ok(leido.getPageCount() >= 3);     // informe + hoja + justificante
  await J.borrar(jid, 'López Sanz, Luis', false);
  assert.equal((await J.mias('López Sanz, Luis', '2026-10-20')).ausencias.find(a => a.id === 'm1').justificacion_id, null);
});

test('alerta del 1 al 5: ausencias de meses anteriores sin justificar', () => {
  const aus = [{ id: 'x', fecha: '2026-09-28', justificacion_id: null }, { id: 'y', fecha: '2026-10-02', justificacion_id: null }, { id: 'z', fecha: '2026-09-10', justificacion_id: 4 }];
  const a = J.alertaDe(aus, '2026-10-01');
  assert.deepEqual([a.n, a.limite, a.enPlazo], [1, '2026-10-05', true]);
  assert.equal(J.alertaDe(aus, '2026-10-07').enPlazo, false);
  assert.equal(J.alertaDe(aus.slice(1), '2026-10-03'), null);
  assert.equal(J.tipoHora({ categoria: 'tutoria', materia: 'Tutoría con alumnos (ESO)' }), 'lectiva');
  assert.equal(J.tipoHora({ categoria: 'tutoria', materia: 'Tutoría de Atención a Padres y Madres' }), 'complementaria');
  assert.equal(J.tipoHora({ categoria: 'guardia', materia: '' }), 'complementaria');
});

test('biblioteca en el servidor: perfil, clave propia, guardado y paso desde la hoja', async () => {
  const hoja = { records: [{ name: 'Pérez Gil, Ana', dept: 'Lengua', act: 'GB', day: 1, slot: '3ª Diurno' }, { name: 'X', act: 'ZZ', day: 9, slot: 'mal' }] };
  assert.equal(await B.importarDeHoja('http://hoja', async () => ({ json: async () => hoja })), 1);
  assert.deepEqual((await B.listar()).map(r => [r.name, r.act, r.day, r.slot]), [['Pérez Gil, Ana', 'GB', 1, '3ª Diurno']]);

  const prof = await Auth.crear({ nombre: 'Pérez Gil, Ana', rol: 'profesor' });
  const sinPerfil = { id: prof.id, rol: 'profesor', perfiles: [] };
  await assert.rejects(B.comprobar(sinPerfil, 'loquesea'), /perfil de Biblioteca/);
  await Auth.actualizar(prof.id, { perfiles: ['biblioteca', 'inventado'] }, { id: -1 });
  const u = (await Auth.listar()).find(x => x.id === prof.id);
  assert.deepEqual(u.perfiles, ['biblioteca']);
  const conPerfil = { id: prof.id, rol: 'profesor', perfiles: u.perfiles };
  await assert.rejects(B.comprobar(conPerfil, 'Biblio2026'), /aún no ha fijado/);
  await assert.rejects(B.fijarClave('abc'), /al menos 8 caracteres/);
  await assert.rejects(B.fijarClave('raton'), /8 caracteres/); await B.fijarClave('ratonera1'); await B.comprobar(conPerfil, 'ratonera1');
  await B.fijarClave('Biblio2026');
  assert.equal(await B.claveDefinida(), true);
  assert.equal(await B.claveDebil(), false);
  await assert.rejects(B.comprobar(conPerfil, 'otra'), /incorrecta/);
  await B.comprobar(conPerfil, 'Biblio2026');
  const { emitir } = await import('../src/services/modoAdmin.js');
  await B.comprobar({ id: 999, rol: 'admin', perfiles: [] }, emitir({ id: 999, usuario: 'jefatura', nombre: 'Jefatura' }));   /* Jefatura entra con su pase del modo administrador */
  await assert.rejects(B.comprobar({ id: 999, rol: 'admin', perfiles: [] }, 'rafael2025'));   /* la clave común ya no vale */
  assert.deepEqual((await B.gestores()).map(g => g.nombre), ['Pérez Gil, Ana']);

  const recs = await B.guardarTodo([...await B.listar(), { name: 'López Sanz, Luis', dept: 'Matemáticas', act: 'MAY', day: 4, slot: '1º Recreo' }], { deUsuario: true });
  assert.equal(recs.length, 2);
  await B.iniciar();   /* ya hay datos editados: no vuelve a traer nada */
  assert.equal((await B.listar()).length, 2);
});

test('panel de la sala de profesores: enlace secreto, configuración y datos sin motivos', async () => {
  const P = await import('../src/services/panelService.js');
  assert.equal(P.siguienteLectivo('2026-10-16'), '2026-10-19');   /* viernes → lunes */
  assert.equal(P.siguienteLectivo('2026-10-19'), '2026-10-20');
  const t = await P.token();
  assert.equal(await P.tokenValido(t), true);
  assert.equal(await P.tokenValido('otro'), false);
  const r = await P.guardarConfig({ mensaje: 'Hola', enlaces: [{ titulo: 'Planos', url: 'https://x.es/p' }, { titulo: 'Mal', url: 'javascript:alert(1)' }] }, { regenerar: true });
  assert.notEqual(r.token, t);
  assert.equal(await P.tokenValido(t), false);
  assert.deepEqual(r.config.enlaces, [{ titulo: 'Planos', url: 'https://x.es/p' }]);
  const d = await P.datos(new Date('2026-10-16T09:00:00Z'));
  assert.equal(d.ok, true); assert.equal(d.mensaje, 'Hola');
  assert.ok(Array.isArray(d.tramos) && Array.isArray(d.ausentes));
  assert.ok(!JSON.stringify(d).includes('"motivo"'));
  /* tipo de ausencia (sin el motivo): DAP, extraescolar/complementaria u otros */
  const { tipoAusencia } = await import('../src/services/guardiasService.js');
  assert.deepEqual(['Asuntos propios (DAP)', 'Actividad extraescolar', 'Actividad complementaria', 'Cita médica', 'Formación'].map(tipoAusencia),
    ['dap', 'extraescolar', 'complementaria', 'otros', 'otros']);
  const dia = '2026-10-19';
  await S.guardarAusencia({ id: 'pt1', prof: 'Pérez Gil, Ana', fecha: dia, modo: 'dia', motivo: 'Asuntos propios (DAP)' }, 'jefatura');
  await S.guardarAusencia({ id: 'pt2', prof: 'López Sanz, Luis', fecha: dia, modo: 'dia', motivo: 'Cita médica' }, 'jefatura');
  const d2 = await P.datos(new Date('2026-10-16T09:00:00Z'));   /* viernes: «mañana» es el lunes 19 */
  assert.deepEqual(d2.proximo.ausentes.map(a => [a.profesor, a.tipo]).sort(), [['López Sanz, Luis', 'otros'], ['Pérez Gil, Ana', 'dap']]);
  assert.ok(!JSON.stringify(d2).includes('Cita médica'));
  await S.borrarAusencias(['pt1', 'pt2']);
});


test('cronología: el cronograma se guarda en el servidor y se limpia lo que no es válido', async () => {
  const C = await import('../src/services/cronologiaService.js');
  assert.equal(await C.leer(), null);
  const v = await C.guardar([
    { id: 1, titulo: 'Evaluación inicial', inicio: '2026-10-14', fin: '2026-10-15', trim: 1, subtipo: 'evaluacion',
      grupos: [{ code: 'E1A', lugar: 'Aula 101', fechaHora: '16:30', fecha: '2026-10-14', alumnos: 29, tutor: 'Antonia' }], enlace: '', extra: 'x' },
    { id: 1, titulo: 'Reunión con familias', inicio: '2026-10-20', subtipo: 'reunion' },
  ], 'jefatura');
  assert.deepEqual(v.eventos.map(e => [e.id, e.titulo, e.fin, e.grupos.length]), [[1, 'Evaluación inicial', '2026-10-15', 1], [2, 'Reunión con familias', '2026-10-20', 0]]);
  assert.equal('extra' in v.eventos[0], false);
  assert.equal((await C.leer()).eventos.length, 2);
  await assert.rejects(C.guardar([{ titulo: 'Sin fecha' }]), /fechas válidas/);
  const P = await import('../src/services/panelService.js');
  assert.equal((await P.datos(new Date('2026-10-16T09:00:00Z'))).cronologia.length, 2);
});

test('calendario de asuntos propios (DAP): crea, actualiza y quita ausencias; títulos no reconocidos', async () => {
  const D = await import('../src/services/dapService.js');
  const X = await import('../src/services/extraescolaresService.js');
  const profs = [{ id: 1, nombre: 'López Sanz, Luis' }, { id: 2, nombre: 'Pérez Gil, Ana' }, { id: 3, nombre: 'Pérez Ruiz, Juan' }];
  assert.equal(D.reconocer('DAP - Luis López', profs).nombre, 'López Sanz, Luis');
  assert.equal(D.reconocer('Asuntos propios: PEREZ GIL', profs).nombre, 'Pérez Gil, Ana');
  assert.equal(D.reconocer('DAP Pérez', profs), null);                       /* dos Pérez: no se adivina */
  assert.equal(D.reconocer('DAP Juan Pérez (2ª-3ª)', profs).nombre, 'Pérez Ruiz, Juan');
  const tramos = [{ codigo: '1', inicio: '08:25', fin: '09:20', tipo: 'lectivo' }, { codigo: '2', inicio: '09:20', fin: '10:15', tipo: 'lectivo' },
    { codigo: 'R1', inicio: '10:15', fin: '10:30', tipo: 'recreo' }, { codigo: '3', inicio: '10:30', fin: '11:25', tipo: 'lectivo' }];
  assert.deepEqual(D.tramosEntre('09:30', '11:00', tramos), ['2', '3']);

  const ics = cuerpo => async () => ({ ok: true, status: 200, text: async () => 'BEGIN:VCALENDAR\n' + cuerpo + 'END:VCALENDAR\n' });
  const ev = (uid, titulo, ini, fin) => `BEGIN:VEVENT\nUID:${uid}\nSUMMARY:${titulo}\nDTSTART${ini.length === 8 ? ';VALUE=DATE' : ''}:${ini}\nDTEND${fin.length === 8 ? ';VALUE=DATE' : ''}:${fin}\nEND:VEVENT\n`;
  await S.guardarCalendario('dap', { nombre: 'Asuntos propios (DAP)', url: 'https://calendar.google.com/calendar/embed?src=dap%40x.es' });
  X._vaciarCache();
  let e = await D.sincronizar({ hoyIso: '2026-10-19', forzar: true, fetchImpl: ics(
    ev('u1', 'DAP - Luis López', '20261021', '20261022') + ev('u2', 'DAP Ana Pérez Gil', '20261022T083000', '20261022T101500') + ev('u3', 'DAP Fulanito', '20261023', '20261024')) });
  assert.equal(e.creadas, 2);
  assert.deepEqual(e.sinReconocer.map(x => x.titulo), ['DAP Fulanito']);
  let dap = (await S.ausenciasAdmin()).filter(a => a.id.startsWith('dap-'));
  assert.deepEqual(dap.map(a => [a.prof, a.fecha, a.modo, a.horas.join(','), a.motivo, a.estado]),
    [['López Sanz, Luis', '2026-10-21', 'dia', '', D.MOTIVO_DAP, 'Grabada'], ['Pérez Gil, Ana', '2026-10-22', 'horas', '1,2', D.MOTIVO_DAP, 'Grabada']]);
  /* Jefatura asigna el título desconocido; se recuerda */
  await S.guardarCalendario('dap', { nombre: 'Asuntos propios (DAP)', url: 'https://calendar.google.com/calendar/embed?src=dap%40x.es' });
  X._vaciarCache();
  const f2 = ics(ev('u1', 'DAP - Luis López', '20261021', '20261022') + ev('u3', 'DAP Fulanito', '20261023', '20261024'));
  await D.sincronizar({ hoyIso: '2026-10-19', forzar: true, fetchImpl: f2 });
  const A = await import('../src/models/index.js');
  await A.Ajuste.guardar({ query }, 'dap_alias', JSON.stringify({ [D.claveTitulo('DAP Fulanito')]: 'Pérez Gil, Ana' }));
  e = await D.sincronizar({ hoyIso: '2026-10-19', forzar: true, fetchImpl: f2 });
  dap = (await S.ausenciasAdmin()).filter(a => a.id.startsWith('dap-'));
  assert.deepEqual(dap.map(a => [a.prof, a.fecha]), [['López Sanz, Luis', '2026-10-21'], ['Pérez Gil, Ana', '2026-10-23']]);   /* la del 22 se borró del calendario */
  assert.equal(e.sinReconocer.length, 0);
  /* si Jefatura ya la había grabado a mano, no se duplica */
  await S.guardarAusencia({ id: 'm1', prof: 'López Sanz, Luis', fecha: '2026-10-21', modo: 'dia', motivo: 'Asuntos propios (DAP)' }, 'jefatura');
  e = await D.sincronizar({ hoyIso: '2026-10-19', forzar: true, fetchImpl: f2 });
  assert.equal(e.duplicadas, 1);
  assert.equal((await S.ausenciasAdmin()).filter(a => a.fecha === '2026-10-21' && a.prof === 'López Sanz, Luis').length, 1);
  /* los asuntos propios no necesitan justificante: en el informe cuentan como justificados, con motivo DAP */
  const inf = await datosInforme('2026-10');
  const dapInf = inf.detalle.filter(a => /DAP/.test(a.motivo));
  assert.ok(dapInf.length >= 2 && dapInf.every(a => a.dap));
  assert.ok(inf.porMotivo.some(m => m.motivo === 'Asuntos propios (DAP) (justificada)'));
  assert.ok(inf.totales.justificadas >= dapInf.length);
  const m = await J.mias('Pérez Gil, Ana', '2026-11-03');
  assert.ok(m.ausencias.filter(a => a.dap).every(a => !a.justificable));
  assert.equal(m.alerta && m.alerta.ids.some(id => id.startsWith('dap-')), false);
  const pdf = await generarPDF(inf, { conMotivo: true });
  assert.ok(pdf.length > 1000);
});

test('datos del docente: correo de Educarex, móvil y años trabajados', async () => {
  assert.throws(() => Auth.limpiarDatos({ email: 'a@gmail.com', movil: '612345678', anios: 3 }), /Educarex/);
  assert.throws(() => Auth.limpiarDatos({ email: 'a@educarex.es', movil: '912345678', anios: 3 }), /móvil/);
  assert.throws(() => Auth.limpiarDatos({ email: 'a@educarex.es', movil: '612345678', anios: '' }), /años/);
  assert.deepEqual(Auth.limpiarDatos({ email: ' Ana@EDUCAREX.es ', movil: '+34 612-34-56-78', anios: '12' }), { email: 'ana@educarex.es', movil: '612 345 678', anios: 12 });
  /* «parcial»: se puede guardar solo lo que se tiene; lo escrito se valida igual */
  assert.deepEqual(Auth.limpiarDatos({ email: '', movil: '612345678', anios: '' }, { parcial: true }), { email: '', movil: '612 345 678', anios: null });
  assert.throws(() => Auth.limpiarDatos({ email: 'x@gmail.com' }, { parcial: true }), /Educarex/);
  assert.throws(() => Auth.limpiarDatos({}, { parcial: true }), /al menos uno/);
  assert.deepEqual(Auth.datosFaltan({ rol: 'profesor', perfiles: [], email: 'a@educarex.es', movil: '', anios_servicio: null }), ['años trabajados']);   /* el móvil es voluntario */
  assert.deepEqual(Auth.datosFaltan({ rol: 'profesor', perfiles: ['conserjeria'], email: '' }), []);
});

test('contador de DAP: días según años trabajados y días usados en el curso', async () => {
  const C = await import('../src/services/contadorDap.js');
  assert.deepEqual([0, 17, 18, 22, 23, 35].map(C.diasDerecho), [4, 4, 5, 5, 6, 6]);
  assert.equal(C.diasDerecho(null), null);
  assert.deepEqual(C.cursoDe('2026-10-18'), { desde: '2026-09-01', hasta: '2027-08-31', nombre: '2026-27' });
  assert.equal(C.aniosActuales(17, '2025-10-01', '2026-10-18'), 18);
  assert.deepEqual(C.diasDe({ fecha: '2026-10-23', hasta: '2026-10-27' }, C.cursoDe('2026-10-18')), ['2026-10-23', '2026-10-26', '2026-10-27']);
  /* solo el propio docente o administración */
  assert.equal(await C.ficha('López Sanz, Luis', { rol: 'profesor', nombre: 'Pérez Gil, Ana' }, '2026-10-30'), null);
  const f = await C.ficha('López Sanz, Luis', { rol: 'admin', nombre: 'Jefatura' }, '2026-10-30');
  assert.ok(f.usados >= 1 && f.dias.includes('2026-10-21'));
});

test('departamento del docente: por materias, jefatura o a mano', async () => {
  const D = await import('../src/services/departamentoProfesor.js');
  assert.equal(D.departamentoDeMateria('Historia de la Filosofía'), 'Filosofía');
  assert.equal(D.departamentoDeMateria('Lengua Extranjera Inglés'), 'Inglés');
  assert.equal(D.departamentoDeMateria('Redes locales'), 'Fam. Prof. Informática y Comunicaciones');
  assert.equal((await D.departamentoDe('López Sanz, Luis')).departamento, 'Matemáticas');
  await D.asignar('López Sanz, Luis', 'Física y Química');
  assert.deepEqual(await D.departamentoDe('lopez sanz, luis'), { departamento: 'Física y Química', origen: 'manual' });
  await D.asignar('López Sanz, Luis', '');
  assert.equal((await D.departamentoDe('López Sanz, Luis')).origen, 'materias');
  await assert.rejects(D.asignar('López Sanz, Luis', 'Astrología'), /no válido/);
});

test('disciplina: etapa del grupo, registro con código, PDF en la carpeta del Jefe/a adjunto y recibido', async () => {
  const { config } = await import('../src/config.js');
  config.disciplinaDir = '/tmp/disciplina_prueba_' + process.pid;
  const D = await import('../src/services/disciplinaService.js');
  assert.equal(D.describirGrupo('E3B').etapa, 'eso');
  assert.equal(D.describirGrupo('2ºPDC').etapa, 'eso');
  assert.deepEqual(D.describirGrupo('B1B_GEN'), { etapa: 'bach', curso: '1º Bachillerato', letra: 'B (General)' });
  assert.equal(D.describirGrupo('1º SMRD', ['mañana']).etapa, 'fpd');
  assert.equal(D.describirGrupo('1º DAM', ['tarde']).etapa, 'fp');
  assert.equal(D.describirGrupo('CETI_ONLIN', ['mañana']).etapa, 'fp');
  const luis = { usuario: 'lsanz', nombre: 'López Sanz, Luis', rol: 'profesor' };
  await assert.rejects(D.crear(luis, { alumno: 'Ana Ruiz', grupo: 'E1A', fecha: '2026-10-01' }), /al menos una conducta/);
  const p = await D.crear(luis, { alumno: 'Ana Ruiz Gil', grupo: 'E1A', fecha: '2026-10-01', hora: '2ª hora', contrarias: ['c1', 'xx'], graves: ['g9'] });
  assert.match(p.codigo, /^DIS-2627-\d{4}$/);
  assert.deepEqual([p.etapa, p.responsable, p.curso, p.grupoLetra, p.contrarias], ['eso', 'Páramo Vicente, Delia Esther', '1º ESO', 'A', ['c1']]);
  const fichero = `${config.disciplinaDir}/Delia Esther Páramo Vicente/${p.archivo}`;
  assert.equal((await fs.readFile(fichero)).subarray(0, 4).toString(), '%PDF');
  /* solo la Jefa adjunta de ESO (o Jefatura) lo recibe */
  await assert.rejects(D.marcarRecibido(p.id, { nombre: 'Calderón de Arriba, Fernando', rol: 'profesor' }), /lo recibe/);
  const delia = { usuario: 'dparamo', nombre: 'Páramo Vicente, Delia Esther', rol: 'profesor' };
  assert.equal((await D.resumen(delia)).pendientes, 1);
  /* avisos solo para Jefatura de Estudios: la Directora (cuenta de administración) no los recibe; la cuenta «jefatura» sí */
  assert.equal((await D.resumen({ usuario: 'cortega', nombre: 'Ortega Ávila, Claudia', rol: 'admin', perfiles: ['direccion'] })).pendientes, 0);
  assert.equal((await D.resumen({ usuario: 'jefatura', nombre: 'Jefatura de Estudios', rol: 'admin', perfiles: [] })).pendientes, 1);
  await D.marcarRecibido(p.id, delia);
  /* recibido: el PDF sale de la carpeta (los datos quedan en la base de datos) */
  await assert.rejects(fs.access(fichero));
  assert.equal((await D.carpeta(delia))[0].archivos.length, 0);
  assert.equal((await D.pdf(p.id, delia, 'jefatura')).tipo, 'jefatura');
  assert.deepEqual(await D.resumen(luis), { pendientes: 0, recibidos: 1, tutoria: 0, responsable: false, tutor: false });
  await D.marcarVisto(p.id, luis);
  assert.equal((await D.resumen(luis)).recibidos, 0);
  await assert.rejects(D.pdf(p.id, { usuario: 'otro', nombre: 'Pérez Gil, Ana', rol: 'profesor' }, 'profesor'), /No puedes/);
  /* copia al tutor/a del grupo */
  assert.equal(p.tutor, 'Muriel Criado, M. Antonia');
  const tutora = { usuario: 'mmuriel', nombre: 'Muriel Criado, M. Antonia', rol: 'profesor' };
  assert.equal((await D.resumen(tutora)).tutoria, 1);
  const avisoT = (await D.deMiTutoria(tutora)).partes[0];
  assert.deepEqual(Object.keys(avisoT).sort(), ['codigo', 'creado', 'fecha', 'grupo', 'id', 'tutorVisto']);   /* sin datos del alumno/a */
  await assert.rejects(D.pdf(p.id, tutora, 'tutor'), /No puedes/);
  await assert.rejects(D.marcarLeidoTutor(p.id, delia), /No eres tutor/);
  await D.marcarLeidoTutor(p.id, tutora);
  assert.equal((await D.resumen(tutora)).tutoria, 0);
  /* si se deshace el recibido, el PDF vuelve a la carpeta */
  await D.marcarRecibido(p.id, delia, false);
  const carp = await D.carpeta(delia);
  assert.deepEqual([carp.length, carp[0].nombre, carp[0].archivos.length, carp[0].archivos[0].codigo], [1, 'Delia Esther Páramo Vicente', 1, p.codigo]);
  const p2 = (await D.bandeja(delia)).find(x => x.id === p.id);
  assert.equal((await D.carpeta({ nombre: 'Jefatura', rol: 'admin' })).length, 4);
  await assert.rejects(D.carpeta(luis), /solo para Jefatura/);
  assert.throws(() => D.archivoCarpeta(delia, 'eso', '../x.pdf'), /no válido/);
  assert.throws(() => D.archivoCarpeta(delia, 'bach', p2.archivo), /No tienes acceso/);
  assert.ok(D.archivoCarpeta(delia, 'eso', p2.archivo).ruta.endsWith(p2.archivo));
  await D.marcarRecibido(p.id, delia);
  assert.equal(await D.purgarRecibidos(), 0);
  await fs.rm(config.disciplinaDir, { recursive: true, force: true });
});

test('ausencias por actividad complementaria o extraescolar: no necesitan justificación', async () => {
  const M = await import('../src/services/motivos.js');
  assert.ok(M.sinJustificante('Actividad extraescolar') && M.sinJustificante('Actividad complementaria') && M.sinJustificante('Asuntos propios (DAP)'));
  assert.ok(!M.sinJustificante('Cita médica') && !M.sinJustificante('Formación'));
  assert.equal(M.motivoExento('Actividad complementaria'), 'Actividad complementaria o extraescolar');
  await S.guardarAusencia({ id: 'act1', prof: 'Pérez Gil, Ana', fecha: '2026-10-28', modo: 'dia', motivo: 'Actividad extraescolar' }, 'jefatura');
  await S.guardarAusencia({ id: 'act2', prof: 'Pérez Gil, Ana', fecha: '2026-10-29', modo: 'dia', motivo: 'Cita médica' }, 'jefatura');
  const m = await J.mias('Pérez Gil, Ana', '2026-11-03');
  const a1 = m.ausencias.find(a => a.id === 'act1'), a2 = m.ausencias.find(a => a.id === 'act2');
  assert.deepEqual([a1.exenta, a1.justificable, a1.exentaMotivo], [true, false, 'Actividad complementaria o extraescolar']);
  assert.deepEqual([a2.exenta, a2.justificable], [false, true]);
  assert.ok(!m.alerta.ids.includes('act1') && m.alerta.ids.includes('act2'));
  const doc = await PDFDocument.create(); doc.addPage();
  const fichero = { originalname: 'x.pdf', buffer: Buffer.from(await doc.save()) };
  await assert.rejects(J.crear('Pérez Gil, Ana', { ausencias: ['act1'], articulo: 3, detalle: [{ fecha: '2026-10-28', tramos: ['3'] }] }, [fichero], 'apg'), /no necesitan justificación/);
  const inf = await datosInforme('2026-10');
  const d = inf.detalle.find(x => x.id === 'act1');
  assert.deepEqual([d.exenta, d.actividad, d.dap], [true, true, false]);
  assert.ok(inf.porMotivo.some(x => x.motivo === 'Actividad complementaria o extraescolar (justificada)'));
  assert.ok(inf.totales.actividad >= 1);
  await S.borrarAusencias(['act1', 'act2']);
});

test('ausencias: tareas por día que deja el profesor/a y aparecen en las guardias', async () => {
  const { limpiarDetalle } = S;
  assert.deepEqual(limpiarDetalle({ '2026-10-22|3': { obs: ' Ficha 4 ' }, '3': { aula: '209' }, 'x|3': { obs: 'no' }, '2026-10-22|99': { obs: 'no' } }, ['3']),
    { '2026-10-22|3': { obs: 'Ficha 4' }, '3': { aula: '209' } });
  await S.notificar({ id: 'tt1', prof: 'López Sanz, Luis', fecha: '2026-11-03', hasta: '2026-11-04', modo: 'dia', motivo: 'Formación', obs: 'General' }, 'luis');
  await S.guardarTareas('tt1', 'López Sanz, Luis', { detalle: { '2026-11-03|3': { obs: 'E1A: ejercicios 4-7' }, '2026-11-04|3': { obs: 'Otra tarea' } }, obs: 'Libro en la mesa' });
  await assert.rejects(S.guardarTareas('tt1', 'Pérez Gil, Ana', { detalle: {} }), /propias/);
  await S.grabarAusencias(['tt1']);
  /* Jefatura la edita (sin las tareas por día) y se conservan */
  await S.guardarAusencia({ id: 'tt1', prof: 'López Sanz, Luis', fecha: '2026-11-03', hasta: '2026-11-04', modo: 'dia', motivo: 'Formación', obs: 'Libro en la mesa', detalle: { '3': { aula: '105' } } }, 'jefatura');
  const e = await estadoDelDia('2026-11-03');   /* martes: Luis tiene E1A a 3ª */
  const t3 = e.tramos.find(t => t.tramo === '3');
  const sc = t3.sinCubrir.find(x => x.profesor === 'López Sanz, Luis');
  assert.deepEqual([sc.tarea, sc.aula], ['E1A: ejercicios 4-7', '105']);
  await S.borrarAusencias(['tt1']);
});

test('DAP: solicitud, cupo por turno, fuerza mayor, revocación y bloqueos de la Dirección', async () => {
  const D = await import('../src/services/dapSolicitudes.js');
  const { config } = await import('../src/config.js');
  const url0 = config.sheetsServiceUrl; config.sheetsServiceUrl = '';   /* sin llamadas reales a Google en las pruebas */
  const { hashClave } = Auth;
  const h = new Date().toISOString().slice(0, 10);
  const mas = n => { const d = new Date(h + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
  const laborable = n => { let f = mas(n); while ([0, 6].includes(new Date(f + 'T12:00:00Z').getUTCDay())) f = mas(n += 1); return f; };
  const dia = laborable(10), otro = laborable(17);
  for (const [u, n] of [['ana', 'Pérez Gil, Ana'], ['luis', 'López Sanz, Luis'], ['eva', 'Ruiz Mora, Eva']]) {
    await query(`INSERT INTO usuario (usuario, nombre, rol, clave_hash, anios_servicio, datos_fecha) VALUES ($1,$2,'profesor','x',$3,$4)
      ON CONFLICT (usuario) DO UPDATE SET anios_servicio = EXCLUDED.anios_servicio, datos_fecha = EXCLUDED.datos_fecha`, ['dap_' + u, n, 10, h]);
  }
  await query(`UPDATE usuario SET anios_servicio = 10, datos_fecha = $1 WHERE nombre IN ('Pérez Gil, Ana','López Sanz, Luis')`, [h]);
  const ana = { usuario: 'dap_ana', nombre: 'Pérez Gil, Ana', rol: 'profesor', perfiles: [] };
  const luis = { usuario: 'dap_luis', nombre: 'López Sanz, Luis', rol: 'profesor', perfiles: [] };
  const dir = { usuario: 'direccion', nombre: 'Directora del centro', rol: 'profesor', perfiles: ['direccion'] };
  const adm = { usuario: 'administracion1', nombre: 'Administración 1', rol: 'profesor', perfiles: ['administracion'] };
  void hashClave;

  /* reglas de la solicitud */
  await assert.rejects(D.solicitar(ana, { fecha: h }), /posteriores/);
  await assert.rejects(D.solicitar(ana, { fecha: mas(120) }), /3 meses/);
  const s1 = await D.solicitar(ana, { fecha: dia, observaciones: 'Notaría' });
  await assert.rejects(D.solicitar(ana, { fecha: dia }), /Ya tienes/);
  const s2 = await D.solicitar(luis, { fecha: dia });
  assert.equal((await D.mio(ana)).saldo.pendientes, 1);
  const sa = (await D.mio(ana)).saldo; const usados0 = sa.usados;
  assert.equal(sa.derecho, 4); assert.equal(sa.disponibles, 4 - usados0 - 1);

  /* solo la Directora resuelve; administración ve y recibe novedades */
  await assert.rejects(D.resolver(ana, s1.id, 'conceder'), /Directora/);
  await assert.rejects(D.resolver(adm, s1.id, 'conceder'), /Directora/);
  const l = await D.lista(adm, { estado: 'solicitada' });
  assert.deepEqual(l.filter(x => x.fecha === dia).map(x => x.posicion), [1, 2]);
  assert.ok((await D.avisos(adm)).novedades >= 2);

  /* concesión: crea la ausencia DAP; cupo de 2 por turno; el tercero solo por fuerza mayor */
  await D.resolver(dir, s1.id, 'conceder');
  await D.resolver(dir, s2.id, 'conceder');
  assert.equal((await D.mio(ana)).saldo.usados, usados0 + 1);
  const eva = { usuario: 'dap_eva', nombre: 'Ruiz Mora, Eva', rol: 'profesor', perfiles: [] };
  const { rows: [pe] } = await query(`SELECT id FROM profesor LIMIT 1`); void pe;
  await query(`INSERT INTO profesor (nombre, nombre_norm) VALUES ('Ruiz Mora, Eva', 'ruiz mora, eva') ON CONFLICT DO NOTHING`).catch(() => {});
  const s3 = await D.solicitar(eva, { fecha: dia }).catch(e => e);
  if (!(s3 instanceof Error)) {
    await assert.rejects(D.resolver(dir, s3.id, 'conceder'), /fuerza mayor/i);
    await assert.rejects(D.resolver(dir, s3.id, 'conceder', { fuerzaMayor: true }), /motivo/);
    await D.resolver(dir, s3.id, 'conceder', { fuerzaMayor: true, nota: 'Juicio' });
  }

  /* avisos al profesor/a y PDF de la resolución */
  assert.equal((await D.avisos(ana)).resoluciones.length, 1);
  const { generarPdfDap } = await import('../src/services/pdfDap.js');
  const pdf = await generarPdfDap(await D.paraPdf(ana, s1.id));
  assert.equal(pdf.subarray(0, 4).toString(), '%PDF');
  await assert.rejects(D.paraPdf(luis, s1.id), /No puedes/);

  /* revocación: motivo obligatorio; quita la ausencia y devuelve el día */
  await assert.rejects(D.resolver(dir, s1.id, 'revocar'), /motivo/);
  await D.resolver(dir, s1.id, 'revocar', { nota: 'Necesidades del centro' });
  assert.equal((await D.mio(ana)).saldo.usados, usados0);

  /* bloqueos de la Dirección */
  await assert.rejects(D.bloquear(adm, otro, 'Claustro'), /Dirección/);
  await D.bloquear(dir, otro, 'Claustro extraordinario');
  await assert.rejects(D.solicitar(ana, { fecha: otro }), /Claustro extraordinario/);
  await D.bloquear(dir, otro, '', true);
  const s4 = await D.solicitar(ana, { fecha: otro });
  await D.anular(ana, s4.id);
  await assert.rejects(D.anular(luis, s2.id), /no es tuya|pendientes/);

  /* --- sincronización con el calendario de Google «Asuntos propios (DAP)» --- */
  const G = await import('../src/services/dapGoogle.js');
  assert.equal(G.calIdDe('https://calendar.google.com/calendar/embed?src=dap%40x.es'), 'dap@x.es');
  assert.equal(G.calIdDe('https://calendar.google.com/calendar/ical/abc%40group.calendar.google.com/private-123/basic.ics'), 'abc@group.calendar.google.com');
  /* app → calendario: crear al conceder y borrar al revocar (el script de Google responde) */
  const llamadas = [];
  const falso = async (u, o) => { const b = JSON.parse(o.body); llamadas.push(b); return { json: async () => ({ ok: true, eventId: 'ev-' + b.ref }) }; };
  config.sheetsServiceUrl = 'https://script.falso/exec';
  const espera = () => new Promise(r => setTimeout(r, 80));
  G._usarFetch(async () => ({ json: async () => ({ ok: true, eventId: 'x' }) }));   /* lo que se lanza en segundo plano */
  await S.guardarCalendario('dap', { nombre: 'Asuntos propios (DAP)', url: 'https://calendar.google.com/calendar/embed?src=dap%40x.es' });
  assert.equal((await G.publicar(s2.id, falso)).ok, true);
  assert.deepEqual([llamadas[0].accion, llamadas[0].op, llamadas[0].calId, llamadas[0].fecha, llamadas[0].titulo], ['dap_calendario', 'crear', 'dap@x.es', dia, 'DAP · Luis López Sanz']);
  assert.match(llamadas[0].descripcion, /\[app-dap:\d+\]/);
  assert.equal((await D.lista(dir, { estado: 'concedida' })).find(x => x.id === s2.id).enCalendario, true);
  await D.resolver(dir, s2.id, 'revocar', { nota: 'Necesidades del centro' }); await espera();
  await query(`UPDATE dap_solicitud SET gcal_id = 'ev-DAP-' || lpad(id::text, 4, '0') WHERE id = $1`, [s2.id]);
  await G.publicar(s2.id, falso);
  assert.deepEqual([llamadas.at(-1).op, llamadas.at(-1).eventId], ['borrar', 'ev-DAP-' + String(s2.id).padStart(4, '0')]);
  /* si Google falla, queda anotado y se reintenta */
  G._usarFetch(async () => ({ json: async () => ({ error: 'Acción no válida' }) }));
  await D.resolver(dir, s2.id, 'conceder'); await espera();
  assert.match((await D.lista(dir, { estado: 'concedida' })).find(x => x.id === s2.id).errorCalendario, /versión 10/);
  assert.equal((await G.reintentar(falso)).ok >= 1, true);
  /* calendario → app: lo apuntado por Jefatura en el calendario cuenta como concedido en el módulo */
  const DS = await import('../src/services/dapService.js');
  const X = await import('../src/services/extraescolaresService.js'); X._vaciarCache();
  const ymd = f => f.replace(/-/g, ''), sig = f => ymd(mas(Math.round((new Date(f) - new Date(h)) / 864e5) + 1));
  const ics = 'BEGIN:VCALENDAR\nBEGIN:VEVENT\nUID:g1\nSUMMARY:DAP Ana Pérez Gil\nDTSTART;VALUE=DATE:' + ymd(otro) + '\nDTEND;VALUE=DATE:' + sig(otro) + '\nEND:VEVENT\n'
    + 'BEGIN:VEVENT\nUID:g2\nSUMMARY:DAP · Luis López Sanz\nDESCRIPTION:' + G.marca(s2.id) + ' concedido en la App\nDTSTART;VALUE=DATE:' + ymd(dia) + '\nDTEND;VALUE=DATE:' + sig(dia) + '\nEND:VEVENT\nEND:VCALENDAR\n';
  const e = await DS.sincronizar({ forzar: true, fetchImpl: async () => ({ ok: true, status: 200, text: async () => ics }) });
  assert.equal(e.delModulo, 1);                       /* el evento del módulo no se graba otra vez */
  assert.equal(e.creadas, 1);
  const cal = await D.calendario(dir, otro, otro);
  assert.deepEqual(cal.dias[otro].solicitudes.map(x => [x.profesor, x.estado, x.origen]), [['Pérez Gil, Ana', 'concedida', 'calendario']]);
  assert.equal(cal.dias[otro].concedidas.diurno, 1);
  const mia = (await D.mio(ana)).solicitudes.find(x => x.fecha === otro && x.origen);
  assert.equal(mia.estado, 'concedida');
  await assert.rejects(D.solicitar(ana, { fecha: otro }), /Ya tienes|ya figura/);
  /* calendario privado: el .ics no se puede leer y los días se leen a través del script de Google (dap_leer) */
  const tercero = laborable(24);
  X._vaciarCache(); G._vaciarCache();
  G._usarFetch(async (u, o) => {
    if (String(u).includes('calendar.google.com')) return { ok: false, status: 404, text: async () => 'Not found' };
    const b = JSON.parse(o.body);
    if (b.accion === 'dap_leer') return { json: async () => ({ ok: true, eventos: [
      { uid: 'p1', titulo: 'DAP Luis López', desc: '', inicio: tercero, fin: tercero, todoElDia: true },
      { uid: 'p2', titulo: 'DAP Fulanito de Tal', desc: '', inicio: tercero, fin: tercero, todoElDia: true }] }) };
    return { json: async () => ({ ok: true, eventId: 'x' }) };
  });
  const c3 = await D.calendario(dir, tercero, tercero);
  assert.equal(c3.calendarioGoogle.fuente, 'script');
  assert.deepEqual(c3.dias[tercero].solicitudes.map(x => [x.profesor, !!x.sinReconocer]).sort(), [['DAP Fulanito de Tal', true], ['López Sanz, Luis', false]]);
  assert.equal(c3.dias[tercero].concedidas.diurno, 2);
  assert.equal((await D.calendario(luis, tercero, tercero)).dias[tercero].solicitudes.length, 2);   /* el profesorado ve también a sus compañeros/as */
  config.sheetsServiceUrl = url0; G._usarFetch(null); G._vaciarCache(); X._vaciarCache();
});


test('perfiles: conserjería y administración sin datos de docente; jefe/a de departamento y coordinador/a de proyectos', async () => {
  assert.equal(Auth.sinDatosDocente({ perfiles: ['conserjeria'] }), true);
  assert.equal(Auth.sinDatosDocente({ perfiles: ['administracion'] }), true);
  assert.equal(Auth.sinDatosDocente({ perfiles: ['jefe_departamento'] }), false);
  const { listaDepartamentos } = await import('../src/services/departamentoProfesor.js');
  const dep = (await listaDepartamentos()).find(d => d !== 'Religión');
  const c = await Auth.crear({ nombre: 'Ruiz Mora, Eva', usuario: 'eruizp', rol: 'profesor' });
  await assert.rejects(Auth.actualizar(c.id, { perfiles: ['jefe_departamento'], departamentoJefe: 'Inventado' }, { id: -1 }), /no existe/);
  await Auth.actualizar(c.id, { perfiles: ['jefe_departamento', 'coordinador_proyectos'], departamentoJefe: dep, proyectos: 'Erasmus+' }, { id: -1 });
  let u = (await Auth.listar()).find(x => x.id === c.id);
  assert.deepEqual([u.perfiles, u.departamentoJefe, u.proyectos], [['jefe_departamento', 'coordinador_proyectos'], dep, 'Erasmus+']);
  assert.equal((await query('SELECT jefe FROM departamento WHERE nombre = $1', [dep])).rows[0].jefe, 'Ruiz Mora, Eva');
  await Auth.actualizar(c.id, { perfiles: [] }, { id: -1 });
  u = (await Auth.listar()).find(x => x.id === c.id);
  assert.deepEqual([u.perfiles, u.departamentoJefe, u.proyectos], [[], '', '']);
});

test('perfiles: tutor/a (tabla de tutorías), jefe/a de estudios (etapa de disciplina) y perfiles creados por el administrador', async () => {
  const c = await Auth.crear({ nombre: 'López Sanz, Luis', usuario: 'llopezt', rol: 'profesor' });
  await assert.rejects(Auth.actualizar(c.id, { perfiles: ['tutor'], tutorGrupos: [] }, { id: -1 }), /al menos un grupo/);
  await assert.rejects(Auth.actualizar(c.id, { perfiles: ['tutor'], tutorGrupos: ['ZZ9'] }, { id: -1 }), /no encontrado/);
  await Auth.actualizar(c.id, { perfiles: ['tutor'], tutorGrupos: ['E1A'] }, { id: -1 });
  assert.equal((await query(`SELECT profesor FROM tutoria WHERE grupo = 'E1A'`)).rows[0].profesor, 'López Sanz, Luis');
  let u = (await Auth.listar()).find(x => x.id === c.id);
  assert.deepEqual([u.perfiles.includes('tutor'), u.tutorDe], [true, ['E1A']]);
  await Auth.actualizar(c.id, { perfiles: [] }, { id: -1 });
  assert.equal((await query(`SELECT 1 FROM tutoria WHERE grupo = 'E1A'`)).rowCount, 0);

  await assert.rejects(Auth.actualizar(c.id, { perfiles: ['jefe_estudios'], jefeEstudios: '' }, { id: -1 }), /etapa/);
  await Auth.actualizar(c.id, { perfiles: ['jefe_estudios'], jefeEstudios: 'bach' }, { id: -1 });
  const Di = await import('../src/services/disciplinaService.js');
  assert.deepEqual(Di.etapasDe({ nombre: 'López Sanz, Luis', perfiles: ['jefe_estudios'], jefeEstudios: 'bach' }), ['bach']);
  assert.deepEqual(Di.etapasDe({ nombre: 'X', perfiles: ['jefe_estudios'], jefeEstudios: 'todas' }).length, 4);

  await assert.rejects(Auth.guardarPerfil({ nombre: 'TI' }), /al menos 3/);
  let l = await Auth.guardarPerfil({ nombre: 'Coordinador/a TIC', descripcion: 'Equipos y redes', color: '#1d4ed8' });
  assert.deepEqual(l.map(p => [p.k, p.l]), [['p_coordinador_a_tic', 'Coordinador/a TIC']]);
  await assert.rejects(Auth.guardarPerfil({ nombre: 'coordinador/a tic' }), /Ya hay/);
  await Auth.actualizar(c.id, { perfiles: ['jefe_estudios', 'p_coordinador_a_tic', 'inventado'], jefeEstudios: 'bach' }, { id: -1 });
  u = (await Auth.listar()).find(x => x.id === c.id);
  assert.deepEqual(u.perfiles, ['jefe_estudios', 'p_coordinador_a_tic']);
  l = await Auth.borrarPerfil('p_coordinador_a_tic');
  assert.equal(l.length, 0);
  assert.deepEqual((await Auth.listar()).find(x => x.id === c.id).perfiles, ['jefe_estudios']);
});

test('Consejo Escolar: profesorado con ese perfil', async () => {
  const c = await Auth.crear({ nombre: 'Pérez Gil, Ana', usuario: 'aperezce', rol: 'profesor' });
  await Auth.actualizar(c.id, { perfiles: ['consejo_escolar'] }, { id: -1 });
  assert.ok((await Auth.consejoEscolar()).includes('Pérez Gil, Ana'));
  await Auth.actualizar(c.id, { perfiles: [] }, { id: -1 });
  assert.ok(!(await Auth.consejoEscolar()).includes('Pérez Gil, Ana') || (await query(`SELECT 1 FROM usuario WHERE nombre = 'Pérez Gil, Ana' AND 'consejo_escolar' = ANY(perfiles)`)).rowCount > 0);
});

test('perfiles Profesor/a y Personal no docente', async () => {
  assert.equal(Auth.sinDatosDocente({ perfiles: ['no_docente'] }), true);
  assert.equal(Auth.sinDatosDocente({ perfiles: ['profesor'] }), false);
  const c = await Auth.crear({ nombre: 'Pérez Gil, Ana', usuario: 'aperezpd', rol: 'profesor' });
  assert.ok((await Auth.listar()).find(x => x.id === c.id).perfiles.includes('profesor'));   /* está en el horario */
  const nd = await Auth.crear({ nombre: 'Gómez Ruiz, Pilar', usuario: 'pgomeznd', rol: 'profesor' });
  assert.deepEqual((await Auth.listar()).find(x => x.id === nd.id).perfiles, []);
  await assert.rejects(Auth.actualizar(nd.id, { perfiles: ['profesor', 'no_docente'] }, { id: -1 }), /a la vez/);
  await Auth.actualizar(nd.id, { perfiles: ['no_docente'] }, { id: -1 });
  assert.deepEqual(Auth.datosFaltan({ rol: 'profesor', perfiles: ['no_docente'], email: '' }), []);
});

test('firma de guardias: previstas del día, registro para Jefatura y CSV', async () => {
  const F = await import('../src/services/firmasGuardia.js');
  const g = await F.guardiasDelDia('2026-10-13');   /* martes */
  assert.ok(g.some(x => x.profesor === 'Pérez Gil, Ana' && x.tramo === '3' && x.tipo === 'aula'));
  assert.ok(g.some(x => x.profesor === 'Pérez Gil, Ana' && x.tramo === 'R1' && x.tipo === 'recreo'));
  await query(`INSERT INTO guardia_firma (fecha, tramo, tipo, profesor) VALUES ('2026-10-13','3','aula','Pérez Gil, Ana')`);
  await assert.rejects(F.registro({ rol: 'profesor', perfiles: [] }, {}), /Jefatura/);
  const r = await F.registro({ rol: 'profesor', perfiles: ['jefe_estudios'] }, { desde: '2026-10-13', hasta: '2026-10-13' });
  const fila = r.dias[0].filas.find(x => x.tramo === '3' && x.profesor === 'Pérez Gil, Ana');
  assert.ok(fila.firmado);
  assert.equal(r.dias[0].filas.find(x => x.tramo === 'R1').firmado, null);
  assert.match(F.csv(r), /Pérez Gil, Ana.*"Sí"/);
});

test('CCP: miembros, convocatoria, enterado y avisos', async () => {
  const C = await import('../src/services/ccpService.js');
  const jd = await Auth.crear({ nombre: 'Jefa Dpto, Marta', usuario: 'ccpjd', rol: 'profesor' });
  const { listaDepartamentos } = await import('../src/services/departamentoProfesor.js');
  await Auth.actualizar(jd.id, { perfiles: ['jefe_departamento'], departamentoJefe: (await listaDepartamentos())[1] }, { id: -1 });
  const u = { usuario: 'ccpjd', nombre: 'Jefa Dpto, Marta', rol: 'profesor', perfiles: ['jefe_departamento'] };
  const dir = { usuario: 'ccpdir', nombre: 'Directora', rol: 'profesor', perfiles: ['direccion'] };
  const otro = { usuario: 'x', nombre: 'X', rol: 'profesor', perfiles: [] };
  assert.equal(C.esMiembro(u), true); assert.equal(C.esMiembro(otro), false);
  assert.equal(C.esMiembro({ perfiles: ['jefe_estudios'], jefeEstudios: 'eso' }), false);
  assert.equal(C.esMiembro({ perfiles: ['jefe_estudios'], jefeEstudios: 'todas' }), true);
  assert.ok((await C.miembros()).some(m => m.usuario === 'ccpjd' && /departamento/.test(m.cargo)));
  await assert.rejects(C.guardar(u, { fecha: '2099-01-10', hora: '16:30' }), /convocar/);
  await assert.rejects(C.guardar({ usuario: 'jefatura', nombre: 'Jefatura', rol: 'admin', perfiles: [] }, { fecha: '2099-01-10', hora: '16:30' }), /convocar/);
  assert.equal(C.puedeConvocar({ perfiles: ['jefe_estudios'], jefeEstudios: 'bach' }), true);
  assert.ok((await C.datos({ usuario: 'jefatura', nombre: 'Jefatura', rol: 'admin', perfiles: [] })).convoca === false);
  await assert.rejects(C.datos(otro), /miembros/);
  const d = await C.guardar(dir, { fecha: '2099-01-10', hora: '16:30', lugar: 'Sala', orden: '1. Acta' });
  const r = d.reuniones.find(x => x.fecha === '2099-01-10');
  assert.equal((await C.avisos(u)).pendientes.length, 1);
  await C.enterado(u, r.id);
  assert.equal((await C.avisos(u)).pendientes.length, 0);
  assert.ok((await C.datos(dir)).reuniones.find(x => x.id === r.id).enterados.some(e => e.usuario === 'ccpjd'));
  await C.guardar(dir, { id: r.id, fecha: '2099-01-11', hora: '17:00' });   /* modificada: hay que confirmar de nuevo */
  assert.equal((await C.avisos(u)).pendientes.length, 1);
});

test('Consejo Escolar: convocatoria, miembros y aviso en el panel de la sala', async () => {
  const C = await import('../src/services/ccpService.js');
  const dir = { usuario: 'cedir', nombre: 'Directora', rol: 'profesor', perfiles: ['direccion'] };
  const rep = { usuario: 'cerep', nombre: 'Rep', rol: 'profesor', perfiles: ['consejo_escolar'] };
  assert.equal(C.esMiembro(rep, 'consejo'), true); assert.equal(C.esMiembro(rep, 'ccp'), false);
  await assert.rejects(C.datos(rep, 'ccp'), /CCP/);
  const hoy = new Date().toISOString().slice(0, 10);
  const f = new Date(Date.now() + 3 * 864e5).toISOString().slice(0, 10);
  const d = await C.guardar(dir, { organo: 'consejo', fecha: f, hora: '17:00', lugar: 'Biblioteca' });
  assert.equal(d.organo, 'consejo');
  assert.ok((await C.avisos(rep)).pendientes.some(r => r.organo === 'consejo' && r.nombreOrgano === 'Consejo Escolar'));
  const p = await C.proximasParaPanel(hoy);
  assert.ok(p.some(r => r.organo === 'consejo' && r.fecha === f && r.lugar === 'Biblioteca'));
  assert.ok(!p.some(r => r.fecha > new Date(Date.now() + 15 * 864e5).toISOString().slice(0, 10)));
});

test('administrador: datos de cualquier cuenta, vincular horario y restaurar acceso', async () => {
  const c = await Auth.crear({ nombre: 'Nuevo Sustituto, Juan', usuario: 'jnuevo', rol: 'admin' });
  assert.equal(await Auth.profesorDeCuenta('Nuevo Sustituto, Juan'), null);
  await Auth.actualizar(c.id, { profesorHorario: 'López Sanz, Luis' }, { id: -1 });
  assert.equal(await Auth.profesorDeCuenta('Nuevo Sustituto, Juan'), 'López Sanz, Luis');
  const u = (await Auth.listar()).find(x => x.id === c.id);
  assert.deepEqual([u.profesor, u.profesorHorario, u.perfiles.includes('profesor')], ['López Sanz, Luis', 'López Sanz, Luis', true]);
  await assert.rejects(Auth.actualizar(c.id, { profesorHorario: 'No Existe, X' }, { id: -1 }), /no existe/);
  const d = await Auth.guardarDatos(c.id, { email: 'juan@educarex.es', movil: '', anios: '7', parcial: true });
  assert.deepEqual([d.email, d.aniosServicio], ['juan@educarex.es', 7]);
  const { ficha } = await import('../src/services/contadorDap.js');
  assert.equal((await ficha('López Sanz, Luis', { rol: 'admin' })).anios != null, true);   /* DAP con los años del sustituto */
  await Auth.actualizar(c.id, { activo: false }, { id: -1 });
  await Auth.restablecer(c.id);
  assert.equal((await Auth.listar()).find(x => x.id === c.id).activo, true);
  await Auth.actualizar(c.id, { profesorHorario: '' }, { id: -1 });
  assert.equal(await Auth.profesorDeCuenta('Nuevo Sustituto, Juan'), null);
});

test('mapa de perfiles: iconos y notificaciones por perfil (unión de perfiles)', async () => {
  const P = await import('../src/services/permisosService.js');
  let r = await P.deUsuario({ rol: 'profesor', perfiles: ['tutor'] });          /* sin perfil principal: cuenta como profesor */
  assert.ok(r.tiles.includes('profesores') && r.tiles.includes('familias') && !r.tiles.includes('calendarios'));
  assert.equal(r.avisos.length, P.NOTIFICACIONES.length - 3);   /* todas salvo «ausencias por grabar», «incidencias» y partes de Jefatura */
  /* conductas contrarias: solo Jefatura de Estudios (de su etapa) y el tutor/a; no se pueden dar a otros perfiles */
  assert.ok(r.avisos.includes('disc_tutoria') && !r.avisos.includes('disc_jefatura'));
  const prof = await P.deUsuario({ rol: 'profesor', perfiles: ['profesor'], nombre: 'Nadie, Nadie' });
  assert.ok(!prof.avisos.includes('disc_tutoria') && !prof.avisos.includes('disc_jefatura'));
  const je = await P.deUsuario({ rol: 'profesor', perfiles: ['profesor', 'jefe_estudios'], jefeEstudios: 'eso', nombre: 'X, Y' });
  assert.ok(je.avisos.includes('disc_jefatura'));
  await P.guardar({ profesor: { tiles: ['disciplina'], avisos: ['disc_jefatura', 'disc_tutoria'] } });
  const prof2 = await P.deUsuario({ rol: 'profesor', perfiles: ['profesor'], nombre: 'Nadie, Nadie' });
  assert.ok(!prof2.avisos.includes('disc_tutoria') && !prof2.avisos.includes('disc_jefatura'));
  await P.guardar({}, true);
  await P.guardar({ conserjeria: { tiles: ['guardias', 'inventado'], avisos: [] }, tutor: { tiles: ['familias', 'calendarios'], avisos: ['disc_tutoria'] } });
  r = await P.deUsuario({ rol: 'profesor', perfiles: ['conserjeria'] });
  assert.deepEqual([r.tiles, r.avisos], [['guardias'], []]);
  r = await P.deUsuario({ rol: 'profesor', perfiles: ['profesor', 'tutor'] });
  assert.ok(r.tiles.includes('calendarios') && r.tiles.includes('dap'));
  assert.equal((await P.deUsuario({ rol: 'admin', perfiles: [] })).todo, true);
  const m = await P.mapa();
  assert.equal(m.conserjeria.propio, true); assert.equal(m.profesor.propio, false);
  await P.guardar({}, true);
  assert.equal((await P.mapa()).conserjeria.tiles.includes('profesores'), true);
});

test('mapa de perfiles: «ausencias por grabar» solo para Jefatura por defecto', async () => {
  const P = await import('../src/services/permisosService.js');
  assert.ok((await P.deUsuario({ rol: 'profesor', perfiles: ['profesor', 'jefe_estudios'] })).avisos.includes('aus_grabar'));
  assert.ok(!(await P.deUsuario({ rol: 'profesor', perfiles: ['profesor'] })).avisos.includes('aus_grabar'));
  assert.ok((await P.deUsuario({ rol: 'admin', perfiles: [] })).avisos.includes('aus_grabar'));
  /* un mapa guardado antes de existir esta notificación: toma su valor por defecto */
  const { Ajuste } = await import('../src/models/index.js');
  await Ajuste.guardar({ query }, 'mapa_perfiles', JSON.stringify({ jefe_estudios: { tiles: ['ccp'], avisos: ['ccp'] } }));
  assert.ok((await P.mapa()).jefe_estudios.avisos.includes('aus_grabar'));
  await P.guardar({ jefe_estudios: { tiles: ['ccp'], avisos: ['ccp'] } });
  assert.ok(!(await P.mapa()).jefe_estudios.avisos.includes('aus_grabar'));
  await P.guardar({}, true);
});

test('Mis ausencias: notificadas, grabadas y justificadas del curso', async () => {
  const C = await import('../src/controllers/ausenciasController.js');
  const h = new Date().toISOString().slice(0, 10);
  await S.notificar({ id: 'mh1', prof: 'Pérez Gil, Ana', fecha: h, modo: 'dia', motivo: 'Cita médica' }, 'ana');
  await S.guardarAusencia({ id: 'mh2', prof: 'Pérez Gil, Ana', fecha: h, modo: 'dia', motivo: 'Formación' }, 'jefatura');
  await S.guardarAusencia({ id: 'mh3', prof: 'Pérez Gil, Ana', fecha: h, modo: 'dia', motivo: 'Asuntos propios (DAP)' }, 'jefatura');
  let out; await C.historial({ usuario: { nombre: 'Pérez Gil, Ana' } }, { json: x => { out = x; } });
  const sit = id => out.ausencias.find(a => a.id === id).situacion;
  assert.deepEqual([sit('mh1'), sit('mh2'), sit('mh3')], ['notificada', 'grabada', 'justificada']);
  await S.borrarAusencias(['mh1', 'mh2', 'mh3']);
});

test('justificar por adelantado: ausencias futuras ya grabadas por Jefatura', async () => {
  const futuro = new Date(Date.now() + 2 * 864e5).toISOString().slice(0, 10);
  await S.guardarAusencia({ id: 'fut1', prof: 'Pérez Gil, Ana', fecha: futuro, modo: 'dia', motivo: 'Cita médica' }, 'jefatura');
  await S.notificar({ id: 'fut2', prof: 'Pérez Gil, Ana', fecha: futuro, modo: 'horas', horas: ['3'], motivo: 'Cita médica' }, 'ana');
  const m = await J.mias('Pérez Gil, Ana');
  const f1 = m.ausencias.find(a => a.id === 'fut1'), f2 = m.ausencias.find(a => a.id === 'fut2');
  assert.deepEqual([f1.justificable, f1.anticipada, f2.justificable], [true, true, false]);
  await S.borrarAusencias(['fut1', 'fut2']);
});

test('incidencias en las aulas: cualquiera marca, Jefatura y Conserjería reciben y resuelven', async () => {
  const I = await import('../src/services/incidenciasService.js');
  const P = await import('../src/services/permisosService.js');
  const prof = { usuario: 'ana', nombre: 'Pérez Gil, Ana', rol: 'profesor', perfiles: ['profesor'] };
  const cons = { usuario: 'conserjeria', nombre: 'Conserjería', rol: 'profesor', perfiles: ['conserjeria'] };
  await assert.rejects(I.crear(prof, { aula: '101', descripcion: 'x' }), /Describe/);
  let r = await I.crear(prof, { aula: '101', descripcion: 'El proyector no enciende' });
  assert.deepEqual([r.incidencias.length, r.gestiona], [1, false]);
  const res = await I.resumen(cons);
  assert.deepEqual([res.total, res.aulas[0].aula, res.gestiona], [1, '101', true]);
  assert.ok((await P.deUsuario(cons)).avisos.includes('incidencias'));
  assert.ok((await P.deUsuario({ rol: 'profesor', perfiles: ['jefe_estudios'] })).avisos.includes('incidencias'));
  assert.ok(!(await P.deUsuario(prof)).avisos.includes('incidencias'));
  const otro = { usuario: 'luis', nombre: 'López Sanz, Luis', rol: 'profesor', perfiles: ['profesor'] };
  await assert.rejects(I.resolver(otro, r.incidencias[0].id), /Solo Jefatura/);
  r = await I.resolver(cons, r.incidencias[0].id, 'Cambiada la lámpara');
  assert.equal(r.incidencias.length, 0);
  assert.equal((await I.resumen(cons)).total, 0);
  assert.equal((await I.lista(cons, { aula: '101', todas: true })).incidencias[0].nota, 'Cambiada la lámpara');
});

test('reservas de aulas: el profesorado puede reservar hasta un mes', async () => {
  const R = await import('../src/services/reservaService.js');
  assert.equal(R.MAX_DIAS, 31);
});

test('nº de alumnos por grupo: lo escribe Jefatura de Estudios y lo ve todo el claustro', async () => {
  const GA = await import('../src/services/grupoAlumnosService.js');
  const prof = { usuario: 'ana', nombre: 'Pérez Gil, Ana', rol: 'profesor', perfiles: ['profesor'] };
  const je = { usuario: 'je', nombre: 'Jefa, Estudios', rol: 'profesor', perfiles: ['jefe_estudios'] };
  await assert.rejects(GA.guardar(prof, { E1A: 25 }), /Solo Jefatura/);
  await assert.rejects(GA.guardar(je, { XX9: 25 }), /no está en el horario/);
  await assert.rejects(GA.guardar(je, { E1A: -3 }), /no válido/);
  let r = await GA.guardar(je, { E1A: '25', E1B: 27 });
  assert.deepEqual([r.grupos.E1A, r.grupos.E1B, r.total, r.puedeEditar], [25, 27, 52, true]);
  r = await GA.guardar(je, { E1B: '' });
  assert.deepEqual([r.grupos.E1B, await GA.uno('E1A'), (await GA.todos(prof)).puedeEditar], [undefined, 25, false]);
});

test('protección de datos: candado personal, sesión compartida, contraseñas, registro de accesos y cierre de curso', async () => {
  const MA = await import('../src/services/modoAdmin.js');
  const { claveAdminOk } = await import('../src/services/programacionesService.js');
  const pase = MA.emitir({ id: 1, usuario: 'jefatura', nombre: 'Jefatura' });
  const jef = { id: 1, rol: 'admin' };
  assert.equal(claveAdminOk(pase, jef), true);
  assert.equal(claveAdminOk(pase, { id: 2, rol: 'admin' }), false);    /* el pase es de otra cuenta */
  assert.equal(claveAdminOk(pase, { id: 1, rol: 'profesor' }), false); /* una cuenta que no es de administración */
  assert.equal(claveAdminOk(pase), false);                             /* sin sesión */
  assert.equal(claveAdminOk('rafael2025', jef), false);
  MA.revocar(pase); assert.equal(claveAdminOk(pase, jef), false);
  /* contraseñas: 12 caracteres en cuentas con datos sensibles */
  assert.throws(() => Auth.validarClaveNueva('Corta12345', { rol: 'admin' }), /12 caracteres/);
  Auth.validarClaveNueva('Corta12345', { rol: 'profesor', perfiles: ['profesor'] });
  /* cuenta nueva: la contraseña provisional caduca a las 72 h; sesión de equipo compartido */
  const c = await Auth.crear({ nombre: 'Prueba, RGPD', usuario: 'prgpd' });
  await assert.rejects(Auth.login('prgpd', c.clave + 'x', '1.1.1.1'), /incorrectos/);
  const l = await Auth.login('prgpd', c.clave, '1.1.1.2', { compartido: true });
  assert.equal(l.usuario.compartido, true);
  assert.equal((await Auth.deSesion(l.token)).compartido, true);
  await query("UPDATE usuario SET provisional_hasta = now() - interval '1 hour' WHERE id = $1", [c.id]);
  await assert.rejects(Auth.login('prgpd', c.clave, '1.1.1.3'), /caducado/);
  await Auth.restablecer(c.id);
  /* registro de accesos */
  const Reg = await import('../src/services/registroAccesos.js');
  await Reg.registrar({ usuario: { usuario: 'jefatura', nombre: 'Jefatura' }, ip: '10.0.0.1' }, 'parte_pdf', 'parte 1');
  await assert.rejects(Reg.listar({ rol: 'profesor', perfiles: ['profesor'] }), /solo para Dirección/);
  const lr = await Reg.listar({ rol: 'profesor', perfiles: ['direccion'] }, { texto: 'parte' });
  assert.equal(lr.registros[0].accionTexto, 'Abre el PDF de un parte de disciplina');
  /* plazos y cierre de curso */
  const R = await import('../src/services/rgpdService.js');
  assert.equal(R.corte(1, '2026-10-22'), '2025-09-01');
  assert.equal(R.corte(0, '2027-03-01'), '2026-09-01');
  await assert.rejects(R.guardarPlazos({ rol: 'profesor' }, { partes: 0 }), /Solo administración/);
  await R.guardarPlazos({ rol: 'admin' }, { ausencias: 0 });
  await S.guardarAusencia({ id: 'vieja1', prof: 'Pérez Gil, Ana', fecha: '2024-02-05', modo: 'dia', motivo: 'Cita médica' }, 'jefatura');
  const prev = await R.previsualizar({ rol: 'admin' }, '2026-10-22');
  assert.ok(prev.categorias.find(x => x.k === 'ausencias').n >= 1);
  const hecho = await R.cierreDeCurso({ rol: 'admin' }, '2026-10-22');
  assert.ok(hecho.borrado.ausencias >= 1);
  assert.equal((await query("SELECT 1 FROM ausencia WHERE id = 'vieja1'")).rowCount, 0);
  const pv = await R.privacidad();
  assert.equal(pv.validado, false); assert.equal(pv.plazos.ausencias, 0);
  await R.guardarPlazos({ rol: 'admin' }, { ausencias: 1 });
});

test('DAP: impreso oficial «Permiso por asuntos particulares» con ejemplar para registro y para el interesado', async () => {
  const { generarImpresoDap } = await import('../src/services/pdfDapImpreso.js');
  const base = { id: 7, profesor: 'Muriel Criado, M. Antonia', usuario: 'mmuriel', fecha: '2026-11-06', turnos: ['diurno'], creado: '2026-10-19 18:45:00', resuelto: '2026-10-20 09:10', observaciones: '', nota: '' };
  for (const estado of ['concedida', 'denegada', 'revocada']) {
    const buf = await generarImpresoDap({ ...base, estado, nota: estado === 'concedida' ? '' : 'Necesidades del servicio' }, { telefono: '611 222 333' });
    assert.equal(buf.subarray(0, 4).toString(), '%PDF');
    assert.equal((await PDFDocument.load(buf)).getPageCount(), 2);
  }
  const C = await import('../src/controllers/dapController.js');
  await assert.rejects(C.impreso({ usuario: { rol: 'profesor', perfiles: ['profesor'], nombre: 'X' }, params: { id: '7' }, query: {} }, {}), /Administración/);
});

test('perfil de administración restaurado a Jefatura de Estudios y Dirección (una sola vez)', async () => {
  const c = await Auth.crear({ nombre: 'Calderón de Arriba, Fernando', usuario: 'fcalderon_t' });
  assert.equal((await Auth.listar()).find(x => x.id === c.id).rol, 'profesor');
  assert.deepEqual(await Auth.restaurarAdministradores({ marca: 'prueba_admins' }), ['fcalderon_t']);
  assert.equal((await Auth.listar()).find(x => x.id === c.id).rol, 'admin');
  await Auth.actualizar(c.id, { rol: 'profesor' }, { id: -1 });
  assert.deepEqual(await Auth.restaurarAdministradores({ marca: 'prueba_admins' }), []);   /* ya hecho: no se vuelve a poner */
});

test('DAP: diagnóstico paso a paso de la escritura en el calendario de Google', async () => {
  const G = await import('../src/services/dapGoogle.js');
  const { config } = await import('../src/config.js');
  const [u0, c0] = [config.sheetsServiceUrl, config.googleClave];
  config.sheetsServiceUrl = 'https://script.google.com/macros/s/X/exec'; config.googleClave = 'clave';
  await S.guardarCalendario('dap', { nombre: 'Asuntos propios (DAP)', url: 'https://calendar.google.com/calendar/ical/dap%40x.es/public/basic.ics' });
  const bien = async (u, o) => {
    if (!o || !o.body) return { text: async () => JSON.stringify({ ok: true, version: '2026-10-22 v10' }) };
    const b = JSON.parse(o.body);
    return { json: async () => (b.accion === 'login' ? { ok: true } : b.accion === 'dap_leer' ? { ok: true, eventos: [] } : { ok: true, eventId: 'e1' }) };
  };
  let d = await G.diagnostico(bien);
  assert.ok(d.pasos.every(p => p.ok), JSON.stringify(d.pasos));
  assert.equal(d.pasos.length, 7);
  /* sin permiso de escritura en el calendario */
  d = await G.diagnostico(async (u, o) => o && o.body && JSON.parse(o.body).op === 'crear' ? { json: async () => ({ ok: false, error: 'Calendario DAP: falta autorizar Google Calendar' }) } : bien(u, o));
  assert.equal(d.pasos.at(-1).ok, false); assert.match(d.pasos.at(-1).detalle, /autorizar/);
  /* la implementación pide iniciar sesión (acceso mal configurado) */
  d = await G.diagnostico(async () => ({ text: async () => '<html>login</html>' }));
  assert.equal(d.pasos[1].ok, false); assert.match(d.pasos[1].ayuda, /Cualquier usuario/);
  /* versión antigua publicada */
  d = await G.diagnostico(async (u, o) => !o || !o.body ? { text: async () => JSON.stringify({ ok: true, version: '2026-10-19 v9' }) } : bien(u, o));
  assert.equal(d.pasos[2].ok, false);
  config.sheetsServiceUrl = u0; config.googleClave = c0;
});

test('seguridad: motivos nunca en guardias (también fines de semana), enlaces seguros y claves de departamento cifradas', async () => {
  const G = await import('../src/services/guardiasService.js');
  await S.guardarAusencia({ id: 'fs1', prof: 'Pérez Gil, Ana', fecha: '2026-10-23', hasta: '2026-10-26', modo: 'dia', motivo: 'Incapacidad temporal' }, 'jefatura');
  const sab = await G.estadoDelDia('2026-10-24');
  assert.equal(sab.lectivo, false); assert.equal(sab.ausencias.length, 1);
  assert.ok(!JSON.stringify(sab).includes('Incapacidad'));
  await S.borrarAusencias(['fs1']);
  const { enlaceSeguro, igualSeguro } = await import('../src/services/contexto.js');
  assert.deepEqual(['javascript:alert(1)', 'data:text/html,x', 'https://x.es/a', 'reunion-familias.html?id=3', '//malo.es', '../x'].map(u => enlaceSeguro(u)),
    ['', '', 'https://x.es/a', 'reunion-familias.html?id=3', '', '']);
  assert.equal(igualSeguro('abc', 'abc'), true); assert.equal(igualSeguro('abc', 'abd'), false); assert.equal(igualSeguro('', ''), false);
  await S.guardarAviso({ id: 'xss1', titulo: 't', texto: 'x', enlace: 'javascript:alert(1)' });
  const { rows: [av] } = await query("SELECT enlace FROM aviso WHERE id = 'xss1'"); assert.equal(av.enlace, '');
  await S.borrarAviso('xss1');
  /* claves de departamento: cifradas al arrancar y con freno a los intentos */
  const P = await import('../src/services/programacionesService.js');
  const { rows: [dep] } = await query("INSERT INTO departamento (nombre, jefe, clave) VALUES ('Dep Prueba Seg', '', 'ABC1234') RETURNING id");
  assert.ok(await P.protegerClavesDep() >= 1);
  const { rows: [d2] } = await query('SELECT clave FROM departamento WHERE id = $1', [dep.id]);
  assert.match(d2.clave, /^scrypt\$/);
  assert.equal((await P.loginJefe(dep.id, 'ABC1234')).ok, true);
  for (let i = 0; i < 5; i++) assert.equal((await P.loginJefe(dep.id, 'MAL' + i)).ok, false);
  await assert.rejects(P.loginJefe(dep.id, 'ABC1234'), /Demasiados intentos/);
  await query('DELETE FROM departamento WHERE id = $1', [dep.id]);
});

test('servicio de Google: la URL del script se cambia desde la app (sin entrar en el servidor)', async () => {
  const G = await import('../src/services/googleServicio.js');
  const { config } = await import('../src/config.js');
  const antes = config.sheetsServiceUrl;
  const admin = { rol: 'admin', usuario: 'jefatura' };
  await assert.rejects(G.guardar({ rol: 'profesor' }, 'https://script.google.com/macros/s/AKfycbxNUEVA1234567890abcdef/exec'), /administración/);
  await assert.rejects(G.guardar(admin, 'https://malo.example/exec'), /script\.google\.com/);
  const nueva = 'https://script.google.com/macros/s/AKfycbxNUEVA1234567890abcdef/exec';
  let r = await G.guardar(admin, nueva);
  assert.deepEqual([r.url, r.origen, config.sheetsServiceUrl], [nueva, 'app', nueva]);
  config.sheetsServiceUrl = 'x'; await G.cargar(); assert.equal(config.sheetsServiceUrl, nueva);   /* al reiniciar se mantiene */
  r = await G.guardar(admin, '');
  assert.equal(r.origen, 'servidor'); assert.equal(config.sheetsServiceUrl, antes);
});
