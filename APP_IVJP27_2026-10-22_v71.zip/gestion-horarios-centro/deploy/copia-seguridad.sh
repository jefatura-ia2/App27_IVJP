#!/usr/bin/env bash
# Copia de seguridad CIFRADA (protección de datos: RGPD art. 32 · ENS mp.info.6):
# base de datos + PDF subidos (justificantes, partes, programaciones) + horario (CSV).
# El fichero de configuración (.env, con contraseñas) NO se copia: guárdalo aparte en un lugar seguro.
# Uso: sudo /var/www/App/deploy/copia-seguridad.sh   (cada noche lo hace solo a las 2:30)
#
# Las copias se cifran con AES-256 y la clave del fichero $CLAVE (se crea sola la primera vez).
# ¡GUARDA ESA CLAVE FUERA DEL SERVIDOR (p. ej. impresa en Jefatura o en un gestor de contraseñas)!
# Sin ella las copias no se pueden restaurar.
set -euo pipefail
DIR="${DIR:-/opt/gestion-horarios-centro}"
DEST="${DEST:-/var/backups/horarios}"
DIAS="${DIAS:-30}"
CLAVE="${CLAVE_COPIAS:-/etc/gestion-horarios/clave-copias}"
F="$(date +%Y-%m-%d_%H%M%S)"
umask 077
mkdir -p "$DEST" "$(dirname "$CLAVE")"
if [ ! -s "$CLAVE" ]; then
  head -c 48 /dev/urandom | base64 | tr -d '\n' > "$CLAVE"; chmod 600 "$CLAVE"
  echo "*** Creada la clave de cifrado de las copias en $CLAVE. Cópiala y guárdala FUERA del servidor:"
  echo "    sudo cat $CLAVE"
fi
cifrar() { openssl enc -aes-256-cbc -pbkdf2 -iter 200000 -salt -pass "file:$CLAVE"; }

runuser -u postgres -- pg_dump -Fc horarios | cifrar > "$DEST/bd_$F.dump.enc"
CARPETAS=()
for c in uploads data; do [ -e "$DIR/backend/$c" ] && CARPETAS+=("$c"); done
if [ ${#CARPETAS[@]} -gt 0 ]; then tar -cz -C "$DIR/backend" "${CARPETAS[@]}" | cifrar > "$DEST/ficheros_$F.tar.gz.enc"; fi

# las copias antiguas SIN cifrar (versiones anteriores a la v63) se borran: contenían datos de salud y de menores
find "$DEST" -maxdepth 1 -type f \( -name 'bd_*.dump' -o -name 'ficheros_*.tar.gz' \) -print -delete | sed 's/^/  borrada copia sin cifrar: /' || true
find "$DEST" -maxdepth 1 -type f \( -name 'bd_*.dump.enc' -o -name 'ficheros_*.tar.gz.enc' \) -mtime +"$DIAS" -delete
echo "$(date '+%F %T') copia cifrada $F en $DEST ($(du -sh "$DEST" | cut -f1) en total)"
# Recomendado: llevar también una copia fuera del servidor (NAS del centro, disco externo…). Las copias van cifradas:
#   rsync -a "$DEST"/ usuario@nas:/copias/horarios/
# Prueba la restauración al menos una vez por trimestre (deploy/restaurar.sh en un equipo de pruebas).
