/* =====================================================================
   SERVICIO DE DATOS · App de horarios IES Valle del Jerte · Curso 2026-27
   Vive en la hoja "Ausencias 2026-27" (Extensiones → Apps Script).

   Pestañas que usa (con la fila 1 de cabeceras tal cual):
     Avisos      → ID | Título | Texto | Nivel | Caduca | Enlace | Publicado
     Calendarios → Clave | Nombre | URL
     Ausencias   → Registrado | ID | Profesor/a | Fecha | Hasta | Modo | Horas | Motivo | Observaciones | Estado

   La pestaña Ausencias es la FUENTE de la hoja de guardias de aula:
   cualquier fila que se añada, cambie o borre aquí (a mano o desde la app
   en modo administrador) se refleja en "Guardias de aula" en la siguiente
   consulta.

   Estado de cada ausencia (columna J):
     Pendiente → la ha notificado un docente desde la app y espera a que
                 Jefatura la grabe. NO aparece todavía en la hoja de guardias.
     Grabada   → validada por Jefatura: aparece en la hoja de guardias.
   El administrador graba o elimina las notificadas desde la app (Guardias
   de aula → modo administrador) o escribiendo "Grabada" en la columna J.
   Una fila escrita a mano con Estado vacío cuenta como Grabada.

   Cómo rellenar una fila a mano en "Ausencias":
     Profesor/a     → igual que en el horario: "Apellidos, Nombre"
     Fecha / Hasta  → fecha (Hasta vacío si es un solo día)
     Modo           → "dia" (todo el día) o "horas"
     Horas          → solo si Modo = horas: 1, 2, R1, 3… separadas por comas
     ID, Registrado, Estado → se pueden dejar vacíos: el servicio los completa

   v10 (22/10/2026): función autorizarPermisos() para conceder el permiso de Google Calendar (y Drive/Hojas) a la
   cuenta del script, diagnóstico del calendario DAP y mensajes de error claros si falta un permiso.
   DESPUÉS DE PEGAR ESTE CÓDIGO: ejecuta autorizarPermisos() desde el editor (▶), acepta los permisos y
   publica una NUEVA VERSIÓN de la implementación existente (Implementar → Gestionar implementaciones).

   CALENDARIO «ASUNTOS PROPIOS (DAP)» (v9): la app lee sus días a través de este script (acción dap_leer)
   aunque el calendario no sea público. Además, cuando la Directora concede un DAP en la app, el servidor pide a
   este script que cree el evento «DAP · Nombre Apellidos» (día completo) en ese calendario, y que lo borre si
   se revoca. Requisitos: la cuenta propietaria de este script debe tener el calendario con permiso «Hacer
   cambios en eventos», y al publicar esta versión hay que aceptar el permiso de Google Calendar.

   Contraseña de administración: lista CLAVES_ADMIN (más abajo). Opcional:
   propiedad del script CLAVE_ADMIN (también se acepta).

   PROGRAMACIONES DIDÁCTICAS (pestaña "Programaciones", se crea sola):
     ID | Departamento | Jefe/a | Clave | Carpeta Drive | Estado | Fecha | Archivo | Enlace archivo | Observaciones
     · Fecha: fecha y hora de la PRIMERA subida = fecha de entrega (la pone el servicio).
   DOCUMENTOS (pestaña "Documentos"): un registro por cada PDF subido; un
   departamento puede tener varios. Borrar una fila aquí lo quita de la app.
     · Clave: contraseña de cada jefe/a de departamento (solo vive aquí).
     · Carpeta Drive: URL de la carpeta donde se guarda el PDF. Si está vacía,
       el servicio crea "Programaciones didácticas 2026-27/<Departamento>" en
       el Drive de quien implementa el script y anota aquí la URL.
     Ejecuta una vez inicializarProgramaciones() desde el editor para crear la
     pestaña y autorizar el acceso a Drive.

   Comprobar que la app usa ESTA versión: abre en el navegador
   <URL de la implementación>?accion=ping  → debe mostrar la versión.
   ===================================================================== */

const HOJA_AVISOS = 'Avisos';
const HOJA_CALENDARIOS = 'Calendarios';
const HOJA_AUSENCIAS = 'Ausencias';
const CAB_AUSENCIAS = ['Registrado', 'ID', 'Profesor/a', 'Fecha', 'Hasta', 'Modo', 'Horas', 'Motivo', 'Observaciones', 'Estado'];
const PENDIENTE = 'Pendiente', GRABADA = 'Grabada';
const CAB_AVISOS = ['ID', 'Título', 'Texto', 'Nivel', 'Caduca', 'Enlace', 'Publicado'];
const CAB_CALENDARIOS = ['Clave', 'Nombre', 'URL'];
const HORAS_VALIDAS = ['1', '2', 'R1', '3', '4', 'R2', '5', '6', '7', '8', '9', '10', '11', '12', '13'];
const TZ = 'Europe/Madrid';
/* Contraseñas de administración válidas. Viven solo en el servidor (no llegan
   al navegador). Si además existe la propiedad del script CLAVE_ADMIN, también
   vale: se acepta cualquiera de ellas, así una propiedad antigua no bloquea el acceso. */
const CLAVES_ADMIN = ['rafael2025'];   // ⚠ la MISMA que ya tenía vuestro script (y que GOOGLE_CLAVE / ADMIN_PASSWORD del servidor)
const VERSION_SERVICIO = '2026-10-22 v10';
const HOJA_DOCS = 'Documentos';
const CAB_DOCS = ['ID', 'Dep ID', 'Departamento', 'Fecha', 'Nombre', 'Enlace', 'ID archivo'];

const HOJA_PROG = 'Programaciones';
const CAB_PROG = ['ID', 'Departamento', 'Jefe/a', 'Clave', 'Carpeta Drive', 'Estado', 'Fecha', 'Archivo', 'Enlace archivo', 'Observaciones'];
const FECHA_LIMITE_PROG = '2026-10-14';   /* fecha límite de entrega de programaciones */
const CARPETA_RAIZ_PROG = 'Programaciones didácticas 2026-27';
const MAX_PDF_MB = 15;
/* [id, departamento, jefe/a, clave, carpeta, estado, fecha, observaciones] — solo para crear la pestaña la primera vez */
const DEPARTAMENTOS_INICIALES = [
  [1, "Actividades Complementarias y Extraescolares", "Castillo Trenado, Jorge", "ACE2627", "", "entregado", "2026-10-08", "Plan anual aprobado en claustro. Incluye salidas a Cáceres y Madrid."],
  [2, "Artes Plásticas", "Pérez Martín, Máxima", "APL2627", "", "entregado", "2026-10-11", "Incluye materiales específicos por nivel y proyecto de murales."],
  [3, "Ciencias Naturales", "Cosano León, Francisco J.", "CNT2627", "", "pendiente", "", "En revisión final. Pendiente de incorporar criterios LOMLOE en 1º ESO."],
  [4, "Economía", "Pérez Borrego, Narbella", "ECO2627", "", "entregado", "2026-10-10", "Adaptada a LOMLOE en 1º y 2º Bachillerato."],
  [5, "Educación Física", "Ramos Calle, Marco Antonio", "EFI2627", "", "entregado", "2026-10-12", "Incluye actividades al aire libre y pruebas de condición física."],
  [6, "Filosofía", "Sánchez Bravo, Eugenio", "FIL2627", "", "pendiente", "", "Coordinando con Griego y Latín para proyecto interdisciplinar."],
  [7, "Física y Química", "Ramos Sánchez, Ángel Custodio", "FQU2627", "", "entregado", "2026-10-09", "Prácticas de laboratorio calendarizadas por trimestre."],
  [8, "Formación y orientación laboral", "Pérez Visus, Marta", "FOL2627", "", "entregado", "2026-10-13", "Convenios con empresas locales actualizados."],
  [9, "Francés", "Chendea Boroica, Adriana Daniela", "FRA2627", "", "pendiente", "", "Pendiente de revisión de criterios de evaluación oral."],
  [10, "Geografía e Historia", "Álvarez Salcedo, Gema", "GHI2627", "", "entregado", "2026-10-11", "Incluye proyecto de patrimonio local con el museo de Plasencia."],
  [11, "Griego", "", "GRI2627", "", "retrasado", "", "Falta incorporar la nueva normativa de la EBAU."],
  [12, "Inglés", "Amor Rodríguez, María del Carmen", "ING2627", "", "entregado", "2026-10-10", "Programación bilingüe completa. Certificación Cambridge integrada."],
  [13, "Latín", "Fernández Carmona, Pedro Manuel", "LAT2627", "", "pendiente", "", "Revisando textos clásicos para 2º Bachillerato."],
  [14, "Lengua Castellana y Literatura", "Moreno Rama, Francisco Javier", "LCL2627", "", "entregado", "2026-10-09", "Incluye plan lector y club de lectura interdepartamental."],
  [15, "Matemáticas", "García-Miguel Gago, Ana María", "MAT2627", "", "entregado", "2026-10-12", "Pendiente de revisión de criterios de calificación en ESO."],
  [16, "Música", "García Aranzabal, Miriam", "MUS2627", "", "entregado", "2026-10-13", "Concierto de Navidad y audiciones trimestrales programadas."],
  [17, "Orientación", "Mordillo Serrano, María Luz", "ORI2627", "", "entregado", "2026-10-07", "Plan de acción tutorial y orientación académica actualizado."],
  [18, "Tecnología", "Orantos Míguez, M.Puerto", "TEC2627", "", "pendiente", "", "Adaptando proyectos a los nuevos talleres del centro."],
  [19, "Fam. Prof. Informática y Comunicaciones", "Laguna García, Óscar", "INF2627", "", "entregado", "2026-10-11", "Módulos de FCT coordinados con empresas de la comarca."]
];

/* ---------------- entrada HTTP ---------------- */
function doGet(e) {
  const accion = (e && e.parameter && e.parameter.accion) || 'datos';
  if (accion === 'datos') return json_(datosPublicos_());
  if (accion === 'programaciones') return json_({ ok: true, programaciones: leerProgramaciones_() });
  if (accion === 'ping') return json_({ ok: true, version: VERSION_SERVICIO, claves: clavesValidas_().length, tokenNotif: !!PropertiesService.getScriptProperties().getProperty('TOKEN_NOTIF') });
  return json_({ error: 'Acción no válida' });
}

function doPost(e) {
  let p;
  try { p = JSON.parse((e && e.postData && e.postData.contents) || '{}'); } catch (err) { return json_({ error: 'Petición no válida' }); }
  const accion = p.accion;

  /* Pública: cualquier docente puede notificar su ausencia */
  if (accion === 'ausencia') {
    /* v7: si existe la propiedad TOKEN_NOTIF, solo se aceptan notificaciones que llegan a través del
       servidor de la app (que comprueba que cada profesor/a notifica solo sus propias ausencias) */
    const tokenNotif = PropertiesService.getScriptProperties().getProperty('TOKEN_NOTIF');
    if (tokenNotif && String(p.token || '') !== tokenNotif) return json_({ ok: false, error: 'Notificación no autorizada' });
    const a = limpiarAusencia_(p.ausencia || {});
    if (!a.prof || !a.fecha) return json_({ ok: false, error: 'Faltan datos' });
    a.estado = PENDIENTE;   /* queda a la espera de que Jefatura la grabe */
    conBloqueo_(() => insertarAusencia_(a));
    return json_({ ok: true });
  }

  if (accion === 'login') return json_({ ok: claveOk_(p.clave) });

  /* v9: módulo DAP de la app → calendario de Google «Asuntos propios (DAP)».
     El servidor de la app (con la contraseña de administración) crea el evento al conceder un DAP y lo borra al
     revocarlo. La cuenta propietaria de este script debe poder «Hacer cambios en eventos» de ese calendario. */
  if (accion === 'dap_calendario') {
    if (!claveOk_(p.clave)) return json_({ ok: false, error: 'No autorizado' });
    try { return json_(conBloqueo_(() => dapCalendario_(p))); }
    catch (err) { return json_({ ok: false, error: 'Calendario DAP: ' + errorCalendario_(err) }); }
  }
  /* v9: la app lee el calendario «Asuntos propios (DAP)» aunque no sea público (lo ve la cuenta del script) */
  if (accion === 'dap_leer') {
    if (!claveOk_(p.clave)) return json_({ ok: false, error: 'No autorizado' });
    try { return json_(dapLeer_(p)); }
    catch (err) { return json_({ ok: false, error: 'Calendario DAP: ' + errorCalendario_(err) }); }
  }

  /* v8: el servidor de la app registra solo su token de notificación (con la contraseña de administración).
     Así no hay que tocar las propiedades del script a mano. */
  if (accion === 'token_notif') {
    if (!claveOk_(p.clave)) return json_({ ok: false, error: 'No autorizado' });
    const t = String(p.token || '');
    if (t.length < 20) return json_({ ok: false, error: 'Token no válido' });
    PropertiesService.getScriptProperties().setProperty('TOKEN_NOTIF', t);
    return json_({ ok: true });
  }

  /* Programaciones: acceso de cada jefe/a con la clave de su departamento (o la de administración) */
  if (accion === 'prog_login') {
    const d = depAutorizado_(p.depId, p.clave);
    return json_(d ? { ok: true, depId: d.id, nombre: d.nombre, jefe: d.jefe } : { ok: false, error: 'Contraseña incorrecta' });
  }
  if (accion === 'prog_obs') {
    const d = depAutorizado_(p.depId, p.clave);
    if (!d) return json_({ ok: false, error: 'Contraseña incorrecta' });
    conBloqueo_(() => hojaProg_().getRange(d.fila, CAB_PROG.indexOf('Observaciones') + 1).setValue(String(p.obs || '').slice(0, 2000)));
    return json_({ ok: true, programaciones: leerProgramaciones_() });
  }
  if (accion === 'prog_borrar_doc') {
    const d = depAutorizado_(p.depId, p.clave);
    if (!d) return json_({ ok: false, error: 'Contraseña incorrecta' });
    try { conBloqueo_(() => borrarDocumento_(d, p.docId)); }
    catch (err) { return json_({ ok: false, error: err.message }); }
    return json_({ ok: true, programaciones: leerProgramaciones_() });
  }
  if (accion === 'prog_subir') {
    const d = depAutorizado_(p.depId, p.clave);
    if (!d) return json_({ ok: false, error: 'Contraseña incorrecta' });
    try {
      const r = conBloqueo_(() => subirProgramacion_(d, p.nombre, p.pdf));
      return json_({ ok: true, archivo: r, programaciones: leerProgramaciones_() });
    } catch (err) { return json_({ ok: false, error: 'No se pudo guardar en Drive: ' + err.message }); }
  }

  /* A partir de aquí, solo administración */
  if (!claveOk_(p.clave)) return json_({ error: 'Contraseña incorrecta' });

  switch (accion) {
    case 'ausencias_admin':
      return json_({ ok: true, ausencias: leerAusencias_(true) });

    case 'ausencia_guardar': {
      const a = limpiarAusencia_(p.ausencia || {});
      if (!a.prof || !a.fecha) return json_({ error: 'Indica profesor/a y fecha' });
      a.estado = GRABADA;     /* lo que guarda el administrador queda grabado */
      conBloqueo_(() => { if (!a.id || !actualizarAusencia_(a)) insertarAusencia_(a); });
      return json_({ ok: true, datos: datosPublicos_(), ausencias: leerAusencias_(true) });
    }

    case 'ausencia_grabar':
      conBloqueo_(() => (p.ids || [p.id]).forEach(id => cambiarEstado_(id, GRABADA)));
      return json_({ ok: true, datos: datosPublicos_(), ausencias: leerAusencias_(true) });

    case 'ausencia_borrar':
      conBloqueo_(() => (p.ids || [p.id]).forEach(id => borrarFilaPorId_(HOJA_AUSENCIAS, CAB_AUSENCIAS, 2, id)));
      return json_({ ok: true, datos: datosPublicos_(), ausencias: leerAusencias_(true) });

    /* ---- programaciones: gestión del administrador ---- */
    case 'prog_crear': {
      const nombre = String(p.nombre || '').trim().slice(0, 120);
      if (!nombre) return json_({ error: 'Indica el nombre del departamento' });
      let res;
      try { res = conBloqueo_(() => crearDepartamento_(nombre, String(p.jefe || '').trim(), normClave_(p.claveDep))); }
      catch (err) { return json_({ error: err.message }); }
      return json_({ ok: true, depId: res.id, claveDep: res.clave, programaciones: leerProgramaciones_() });
    }

    case 'prog_anular':
      try { conBloqueo_(() => anularEntrega_(Number(p.depId))); }
      catch (err) { return json_({ error: err.message }); }
      return json_({ ok: true, programaciones: leerProgramaciones_() });

    case 'prog_jefe':
      conBloqueo_(() => {
        const h = hojaProg_(), n = filaPorId_(h, 1, p.depId);
        if (n) h.getRange(n, 3).setValue(String(p.jefe || '').trim().slice(0, 120));
      });
      return json_({ ok: true, programaciones: leerProgramaciones_() });

    case 'prog_clave': {
      const nueva = normClave_(p.claveDep);
      if (nueva.length < 4) return json_({ error: 'La contraseña debe tener al menos 4 caracteres' });
      conBloqueo_(() => {
        const h = hojaProg_(), n = filaPorId_(h, 1, p.depId);
        if (n) h.getRange(n, 4).setNumberFormat('@').setValue(nueva);
      });
      return json_({ ok: true });
    }

    case 'prog_estado':
      conBloqueo_(() => {
        const h = hojaProg_(), n = filaPorId_(h, 1, p.depId);
        if (n) h.getRange(n, 6, 1, 2).setValues([[p.estado === 'entregado' ? 'entregado' : (p.estado === 'retrasado' ? 'retrasado' : 'pendiente'),
          p.estado === 'entregado' ? new Date() : '']]);
        if (n) h.getRange(n, 7).setNumberFormat('dd/mm/yyyy HH:mm');
      });
      return json_({ ok: true, programaciones: leerProgramaciones_() });

    case 'aviso_guardar': {
      const a = p.aviso || {};
      conBloqueo_(() => {
        const h = hoja_(HOJA_AVISOS, CAB_AVISOS);
        const fila = [a.id || nuevoId_(), a.titulo || '', a.texto || '', a.nivel || 'info', a.caduca || '', a.enlace || ''];
        const n = filaPorId_(h, 1, a.id);
        if (n) h.getRange(n, 1, 1, 6).setValues([fila]);
        else h.appendRow(fila.concat([hoy_()]));
      });
      return json_({ ok: true, datos: datosPublicos_() });
    }

    case 'aviso_borrar':
      conBloqueo_(() => borrarFilaPorId_(HOJA_AVISOS, CAB_AVISOS, 1, p.id));
      return json_({ ok: true, datos: datosPublicos_() });

    case 'calendario_guardar': {
      const k = p.clave_cal, c = p.calendario || {};
      conBloqueo_(() => {
        const h = hoja_(HOJA_CALENDARIOS, CAB_CALENDARIOS);
        const n = filaPorId_(h, 1, k);
        if (n) h.getRange(n, 2, 1, 2).setValues([[c.nombre || '', c.url || '']]);
        else h.appendRow([k, c.nombre || '', c.url || '']);
      });
      return json_({ ok: true, datos: datosPublicos_() });
    }
  }
  return json_({ error: 'Acción no válida' });
}

/* ---------------- datos que ve todo el claustro ---------------- */
function datosPublicos_() {
  const todas = leerAusencias_(true);
  return {
    avisos: leerAvisos_(), calendarios: leerCalendarios_(),
    ausencias: leerAusencias_(false),
    pendientes: todas.filter(a => a.estado === PENDIENTE).length   /* solo el número, sin nombres */
  };
}

function leerAvisos_() {
  return filas_(hoja_(HOJA_AVISOS, CAB_AVISOS)).filter(r => r[0] || r[1]).map(r => ({
    id: String(r[0]), titulo: String(r[1]), texto: String(r[2]), nivel: String(r[3] || 'info'),
    caduca: iso_(r[4]), enlace: String(r[5] || ''), fecha: iso_(r[6])
  }));
}

function leerCalendarios_() {
  const out = {};
  filas_(hoja_(HOJA_CALENDARIOS, CAB_CALENDARIOS)).forEach(r => {
    if (r[0]) out[String(r[0]).trim()] = { nombre: String(r[1] || ''), url: String(r[2] || '') };
  });
  return out;
}

/* conMotivo=false para el público: solo las grabadas y sin motivo.
   conMotivo=true para Jefatura: todas, con motivo y estado. */
function leerAusencias_(conMotivo) {
  const h = hoja_(HOJA_AUSENCIAS, CAB_AUSENCIAS);
  completarIds_(h);
  /* al público: desde hace una semana en adelante (cubre la semana en curso) */
  const limite = conMotivo ? '' : Utilities.formatDate(new Date(Date.now() - 7 * 864e5), TZ, 'yyyy-MM-dd');
  return filas_(h).map(r => {
    const fecha = iso_(r[3]);
    if (!r[2] || !fecha) return null;
    const horas = normalizarHoras_(r[6]);
    let modo = String(r[5] || '').toLowerCase();
    modo = (modo.indexOf('hora') === 0 || (!modo && horas.length)) ? 'horas' : 'dia';
    const hasta = iso_(r[4]);
    if (limite && (hasta || fecha) < limite) return null;
    const estado = String(r[9] || '').trim().toLowerCase().indexOf('pend') === 0 ? PENDIENTE : GRABADA;
    if (!conMotivo && estado !== GRABADA) return null;
    const a = { id: String(r[1]), prof: String(r[2]).trim(), fecha: fecha, hasta: hasta && hasta !== fecha ? hasta : '',
      modo: modo, horas: modo === 'horas' ? horas : [], obs: String(r[8] || ''), creado: iso_(r[0]) };
    if (conMotivo) { a.motivo = String(r[7] || ''); a.estado = estado; }
    return a;
  }).filter(Boolean);
}

/* ---------------- escritura de ausencias ---------------- */
function limpiarAusencia_(a) {
  const horas = normalizarHoras_(a.horas);
  const modo = a.modo === 'horas' && horas.length ? 'horas' : 'dia';
  const fecha = iso_(a.fecha);
  const hasta = iso_(a.hasta);
  return { id: String(a.id || ''), prof: String(a.prof || '').trim(), fecha: fecha,
    hasta: hasta && hasta > fecha ? hasta : '', modo: modo, horas: modo === 'horas' ? horas : [],
    motivo: String(a.motivo || '').slice(0, 200), obs: String(a.obs || '').slice(0, 1000) };
}

function filaAusencia_(a) {
  return [new Date(), a.id || nuevoId_(), a.prof, fechaCelda_(a.fecha), a.hasta ? fechaCelda_(a.hasta) : '',
    a.modo, a.horas.join(', '), a.motivo, a.obs, a.estado || GRABADA];
}

function insertarAusencia_(a) {
  const h = hoja_(HOJA_AUSENCIAS, CAB_AUSENCIAS);
  if (a.id && filaPorId_(h, 2, a.id)) return; /* ya registrada: evita duplicados por reenvío */
  h.appendRow(filaAusencia_(a));
  ordenarAusencias_(h);
}

function actualizarAusencia_(a) {
  const h = hoja_(HOJA_AUSENCIAS, CAB_AUSENCIAS);
  const n = filaPorId_(h, 2, a.id);
  if (!n) return false;
  const fila = filaAusencia_(a);
  fila[0] = h.getRange(n, 1).getValue() || new Date(); /* conserva la fecha de registro */
  h.getRange(n, 1, 1, fila.length).setValues([fila]);
  ordenarAusencias_(h);
  return true;
}

function cambiarEstado_(id, estado) {
  const h = hoja_(HOJA_AUSENCIAS, CAB_AUSENCIAS);
  const n = filaPorId_(h, 2, id);
  if (n) h.getRange(n, CAB_AUSENCIAS.indexOf('Estado') + 1).setValue(estado);
}

function ordenarAusencias_(h) {
  const n = h.getLastRow();
  if (n > 2) h.getRange(2, 1, n - 1, CAB_AUSENCIAS.length).sort([{ column: 4, ascending: true }, { column: 3, ascending: true }]);
}

/* Filas añadidas a mano sin ID: se les asigna uno para poder borrarlas desde la app */
function completarIds_(h) {
  const n = h.getLastRow();
  if (n < 2) return;
  const r = h.getRange(2, 1, n - 1, 3).getValues();
  let cambia = false;
  r.forEach(f => {
    if (f[2] && !f[1]) { f[1] = nuevoId_(); cambia = true; }
    if (f[2] && !f[0]) { f[0] = new Date(); cambia = true; }
  });
  if (cambia) h.getRange(2, 1, n - 1, 2).setValues(r.map(f => [f[0], f[1]]));
}

/* ---------------- utilidades ---------------- */
function normClave_(c) { return String(c == null ? '' : c).normalize('NFC').trim(); }

function clavesValidas_() {
  const lista = CLAVES_ADMIN.map(normClave_);
  const prop = normClave_(PropertiesService.getScriptProperties().getProperty('CLAVE_ADMIN'));
  if (prop) lista.push(prop);
  return lista.filter(Boolean);
}

function claveOk_(c) {
  const k = normClave_(c);
  return !!k && clavesValidas_().indexOf(k) >= 0;
}

/* Ejecútala desde el editor (▶) y mira el registro de ejecución */
function probarClave() {
  Logger.log('Versión: ' + VERSION_SERVICIO);
  Logger.log('Contraseñas válidas configuradas: ' + clavesValidas_().length);
  Logger.log('¿La clave configurada es válida? ' + claveOk_(CLAVES_ADMIN[0]));
  Logger.log('Hoja: ' + SpreadsheetApp.getActiveSpreadsheet().getName());
}

function hoja_(nombre, cabeceras) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let h = ss.getSheetByName(nombre);
  if (!h) { h = ss.insertSheet(nombre); h.appendRow(cabeceras); h.setFrozenRows(1); return h; }
  /* añade las cabeceras que falten (p. ej. la columna Estado en una hoja ya existente) */
  const actual = h.getRange(1, 1, 1, cabeceras.length).getValues()[0];
  cabeceras.forEach((c, i) => { if (!actual[i]) h.getRange(1, i + 1).setValue(c); });
  return h;
}

function filas_(h) {
  const n = h.getLastRow();
  return n < 2 ? [] : h.getRange(2, 1, n - 1, h.getLastColumn()).getValues();
}

function filaPorId_(h, col, id) {
  if (!id) return 0;
  const n = h.getLastRow();
  if (n < 2) return 0;
  const v = h.getRange(2, col, n - 1, 1).getValues();
  for (let i = 0; i < v.length; i++) if (String(v[i][0]) === String(id)) return i + 2;
  return 0;
}

function borrarFilaPorId_(nombre, cab, col, id) {
  const h = hoja_(nombre, cab);
  const n = filaPorId_(h, col, id);
  if (n) h.deleteRow(n);
}

/* Acepta Date, "2026-10-05", "5/10/2026" o "05-10-26" y devuelve "AAAA-MM-DD" */
function iso_(v) {
  if (!v) return '';
  if (Object.prototype.toString.call(v) === '[object Date]') return isNaN(v) ? '' : Utilities.formatDate(v, TZ, 'yyyy-MM-dd');
  const s = String(v).trim();
  let m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (m) return m[1] + '-' + pad_(m[2]) + '-' + pad_(m[3]);
  m = s.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})$/);
  if (m) return (m[3].length === 2 ? '20' + m[3] : m[3]) + '-' + pad_(m[2]) + '-' + pad_(m[1]);
  return '';
}

/* "1ª, 3, recreo 1, R2" → ["1","3","R1","R2"] en orden de la jornada */
function normalizarHoras_(v) {
  const lista = Array.isArray(v) ? v : String(v || '').split(/[,;\s]+/);
  const out = [];
  lista.forEach(x => {
    let t = String(x).toUpperCase().replace(/[ªº°]/g, '').replace('RECREO', 'R').trim();
    if (/^R?\d{1,2}$/.test(t) && HORAS_VALIDAS.indexOf(t) >= 0 && out.indexOf(t) < 0) out.push(t);
  });
  return out.sort((a, b) => HORAS_VALIDAS.indexOf(a) - HORAS_VALIDAS.indexOf(b));
}

function fechaCelda_(iso) { const p = iso.split('-'); return new Date(+p[0], +p[1] - 1, +p[2], 12); }
function pad_(n) { return ('0' + n).slice(-2); }
function hoy_() { return Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd'); }
function nuevoId_() { return Utilities.getUuid().slice(0, 8); }
/* ---------------- v9 · calendario «Asuntos propios (DAP)» ---------------- */
function dapCalendario_(p) {
  const cal = CalendarApp.getCalendarById(String(p.calId || ''));
  if (!cal) return { ok: false, error: 'el script no puede abrir el calendario «Asuntos propios (DAP)»: compártelo con la cuenta del script con permiso para hacer cambios' };
  const f = String(p.fecha || ''), ref = String(p.ref || '');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(f) || !ref) return { ok: false, error: 'Faltan datos' };
  const n = f.split('-').map(Number), dia = new Date(n[0], n[1] - 1, n[2]);
  const deLaApp = cal.getEventsForDay(dia).filter(ev => ev.getTag('app_dap') === ref);
  if (p.op === 'crear') {
    if (deLaApp.length) return { ok: true, eventId: deLaApp[0].getId(), yaExistia: true };
    const ev = cal.createAllDayEvent(String(p.titulo || 'DAP'), dia, { description: String(p.descripcion || '') });
    ev.setTag('app_dap', ref);
    return { ok: true, eventId: ev.getId() };
  }
  if (p.op === 'borrar') {
    let lista = deLaApp;
    if (!lista.length && p.eventId) { const ev = cal.getEventById(String(p.eventId)); if (ev) lista = [ev]; }
    lista.forEach(ev => ev.deleteEvent());
    return { ok: true, borrados: lista.length };
  }
  return { ok: false, error: 'Operación no válida' };
}

function dapLeer_(p) {
  const cal = CalendarApp.getCalendarById(String(p.calId || ''));
  if (!cal) return { ok: false, error: 'el script no puede abrir el calendario «Asuntos propios (DAP)»: compártelo con la cuenta del script' };
  const f = s => { const n = String(s || '').split('-').map(Number); return new Date(n[0], n[1] - 1, n[2]); };
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(p.desde)) || !/^\d{4}-\d{2}-\d{2}$/.test(String(p.hasta))) return { ok: false, error: 'Fechas no válidas' };
  const d0 = f(p.desde), d1 = f(p.hasta); d1.setDate(d1.getDate() + 1);
  const tz = Session.getScriptTimeZone(), fmt = (d, x) => Utilities.formatDate(d, tz, x);
  const eventos = cal.getEvents(d0, d1).map(ev => {
    const todo = ev.isAllDayEvent();
    const ini = todo ? ev.getAllDayStartDate() : ev.getStartTime();
    const fin = todo ? new Date(ev.getAllDayEndDate().getTime() - 86400000) : ev.getEndTime();
    return { uid: ev.getId(), titulo: ev.getTitle(), desc: String(ev.getDescription() || '').replace(/<[^>]+>/g, ' ').slice(0, 300),
      inicio: fmt(ini, 'yyyy-MM-dd'), fin: fmt(fin < ini ? ini : fin, 'yyyy-MM-dd'), todoElDia: todo,
      hora: todo ? '' : fmt(ini, 'HH:mm'), horaFin: todo ? '' : fmt(fin, 'HH:mm') };
  });
  return { ok: true, eventos: eventos };
}

function conBloqueo_(fn) { const l = LockService.getScriptLock(); l.waitLock(30000); try { return fn(); } finally { l.releaseLock(); } }
function json_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }

/* ---------------- programaciones didácticas ---------------- */
function hojaProg_() {
  const h = hoja_(HOJA_PROG, CAB_PROG);
  if (h.getLastRow() < 2 && DEPARTAMENTOS_INICIALES.length) {
    h.getRange(2, 1, DEPARTAMENTOS_INICIALES.length, CAB_PROG.length).setValues(
      DEPARTAMENTOS_INICIALES.map(r => [r[0], r[1], r[2], r[3], r[4], r[5] || 'pendiente', r[6] ? fechaCelda_(r[6]) : '', '', '', r[7] || '']));
    h.getRange(2, 4, DEPARTAMENTOS_INICIALES.length, 1).setNumberFormat('@'); /* claves como texto */
  }
  /* hojas creadas con la v4 (sin columna Observaciones): se rellenan con las iniciales */
  const n = h.getLastRow();
  const props = PropertiesService.getScriptProperties();
  if (n >= 2 && !props.getProperty('PROG_OBS_INI')) {
    props.setProperty('PROG_OBS_INI', '1');
    const col = CAB_PROG.length, ids = h.getRange(2, 1, n - 1, 1).getValues();
    const actual = h.getRange(2, col, n - 1, 1).getValues();
    if (actual.every(v => v[0] === '')) {
      h.getRange(2, col, n - 1, 1).setValues(ids.map(v => {
        const ini = DEPARTAMENTOS_INICIALES.filter(r => String(r[0]) === String(v[0]))[0];
        return [ini ? (ini[7] || '') : ''];
      }));
    }
  }
  return h;
}

/* Fecha y hora "dd/mm/aaaa HH:mm" si la celda la tiene */
function hora_(v) {
  return Object.prototype.toString.call(v) === '[object Date]' && !isNaN(v) ? Utilities.formatDate(v, TZ, 'HH:mm') : '';
}

/* Lo que ve todo el mundo: sin claves */
function leerDocs_() {
  const h = hoja_(HOJA_DOCS, CAB_DOCS);
  migrarDocs_(h);
  return filas_(h).map((r, i) => ({ r, i })).filter(o => o.r[0] && o.r[5]).map(({ r, i }) => ({
    id: String(r[0]), depId: Number(r[1]), nombre: String(r[4] || 'programacion.pdf'),
    url: String(r[5]), fecha: iso_(r[3]), hora: hora_(r[3]), orden: i
  }));
}

/* Subidas hechas con la v4 (solo en Programaciones) pasan una vez a Documentos */
function migrarDocs_(hd) {
  const props = PropertiesService.getScriptProperties();
  if (props.getProperty('DOCS_MIGRADOS')) return;
  props.setProperty('DOCS_MIGRADOS', '1');
  if (hd.getLastRow() > 1) return;
  filas_(hojaProg_()).forEach(r => {
    if (r[0] !== '' && r[8]) hd.appendRow([nuevoId_(), r[0], r[1], r[6] || new Date(), r[7] || 'programacion.pdf', r[8], idDeUrl_(String(r[8]))]);
  });
}

function idDeUrl_(u) { const m = String(u).match(/\/d\/([\w-]+)/) || String(u).match(/[?&]id=([\w-]+)/); return m ? m[1] : ''; }

function leerProgramaciones_() {
  const docs = leerDocs_();
  return filas_(hojaProg_()).filter(r => r[0] !== '' && r[1]).map(r => ({
    docs: docs.filter(x => x.depId === Number(r[0])).sort((a, b) => (b.fecha + b.hora).localeCompare(a.fecha + a.hora) || b.orden - a.orden),
    id: Number(r[0]), nombre: String(r[1]), jefe: String(r[2] || ''),
    estado: String(r[5] || 'pendiente').toLowerCase(), fecha: iso_(r[6]), hora: hora_(r[6]),
    fueraPlazo: !!iso_(r[6]) && String(r[5]).toLowerCase() === 'entregado' && iso_(r[6]) > FECHA_LIMITE_PROG,
    obs: String(r[9] || ''),
    archivo: String(r[7] || ''), url: String(r[8] || ''), carpeta: String(r[4] || '')
  }));
}

function depAutorizado_(depId, clave) {
  const k = normClave_(clave);
  if (!k) return null;
  const h = hojaProg_(), n = filaPorId_(h, 1, depId);
  if (!n) return null;
  const r = h.getRange(n, 1, 1, CAB_PROG.length).getValues()[0];
  if (normClave_(r[3]) !== k && !claveOk_(k)) return null;
  return { fila: n, id: Number(r[0]), nombre: String(r[1]), jefe: String(r[2] || ''), carpeta: String(r[4] || '') };
}

function carpetaDep_(d, h) {
  const m = d.carpeta.match(/folders\/([\w-]+)/) || d.carpeta.match(/^([\w-]{20,})$/);
  if (m) return DriveApp.getFolderById(m[1]);
  /* sin carpeta: se crea dentro de la carpeta raíz y se anota en la hoja */
  const props = PropertiesService.getScriptProperties();
  let raiz = null;
  const idRaiz = props.getProperty('PROG_RAIZ');
  if (idRaiz) { try { raiz = DriveApp.getFolderById(idRaiz); } catch (e) { raiz = null; } }
  if (!raiz) {
    const it = DriveApp.getFoldersByName(CARPETA_RAIZ_PROG);
    raiz = it.hasNext() ? it.next() : DriveApp.createFolder(CARPETA_RAIZ_PROG);
    props.setProperty('PROG_RAIZ', raiz.getId());
  }
  const it2 = raiz.getFoldersByName(d.nombre);
  const f = it2.hasNext() ? it2.next() : raiz.createFolder(d.nombre);
  h.getRange(d.fila, 5).setValue(f.getUrl());
  return f;
}

function subirProgramacion_(d, nombre, base64) {
  if (!base64) throw new Error('No se ha recibido el PDF');
  const datos = String(base64).replace(/^data:[^,]*,/, '');
  const bytes = Utilities.base64Decode(datos);
  if (bytes.length > MAX_PDF_MB * 1024 * 1024) throw new Error('El PDF supera ' + MAX_PDF_MB + ' MB');
  if (String.fromCharCode(bytes[0], bytes[1], bytes[2], bytes[3]) !== '%PDF') throw new Error('El archivo no es un PDF');
  const h = hojaProg_();
  const carpeta = carpetaDep_(d, h);
  const limpio = String(nombre || 'programacion.pdf').replace(/[\\/:*?"<>|]/g, '_').slice(0, 120);
  const titulo = 'Programación 2026-27 · ' + d.nombre + ' · ' + hoy_() + ' · ' + limpio.replace(/\.pdf$/i, '') + '.pdf';
  const file = carpeta.createFile(Utilities.newBlob(bytes, 'application/pdf', titulo));
  /* lectura con enlace: primero para cualquiera; si el dominio no lo permite, para el dominio */
  try { file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW); }
  catch (e) { try { file.setSharing(DriveApp.Access.DOMAIN_WITH_LINK, DriveApp.Permission.VIEW); } catch (e2) {} }
  const hd = hoja_(HOJA_DOCS, CAB_DOCS);
  migrarDocs_(hd);
  const previos = filas_(hd).filter(r => Number(r[1]) === d.id && r[5]).length;
  const ahora = new Date();
  hd.appendRow([nuevoId_(), d.id, d.nombre, ahora, limpio, file.getUrl(), file.getId()]);
  hd.getRange(hd.getLastRow(), 4).setNumberFormat('dd/mm/yyyy HH:mm');
  /* fecha de entrega = momento de la primera subida; las siguientes no la cambian */
  const fechaActual = h.getRange(d.fila, 7).getValue();
  const estadoActual = String(h.getRange(d.fila, 6).getValue()).toLowerCase();
  const fecha = (previos > 0 && estadoActual === 'entregado' && fechaActual) ? fechaActual : ahora;
  h.getRange(d.fila, 6, 1, 4).setValues([['entregado', fecha, limpio, file.getUrl()]]);
  h.getRange(d.fila, 7).setNumberFormat('dd/mm/yyyy HH:mm');
  return { nombre: limpio, url: file.getUrl() };
}

/* Quitar un documento: va a la papelera de Drive y sale de la lista */
function borrarDocumento_(d, docId) {
  const hd = hoja_(HOJA_DOCS, CAB_DOCS);
  const n = filaPorId_(hd, 1, docId);
  if (!n) throw new Error('Documento no encontrado');
  const r = hd.getRange(n, 1, 1, CAB_DOCS.length).getValues()[0];
  if (Number(r[1]) !== d.id) throw new Error('El documento no es de este departamento');
  const fid = String(r[6] || '') || idDeUrl_(r[5]);
  if (fid) { try { DriveApp.getFileById(fid).setTrashed(true); } catch (e) {} }
  hd.deleteRow(n);
  /* actualizar el resumen del departamento */
  const h = hojaProg_();
  const quedan = filas_(hd).filter(x => Number(x[1]) === d.id && x[5])
    .sort((a, b) => new Date(b[3]) - new Date(a[3]));
  if (quedan.length) h.getRange(d.fila, 8, 1, 2).setValues([[quedan[0][4], quedan[0][5]]]);
  else h.getRange(d.fila, 6, 1, 4).setValues([['pendiente', '', '', '']]);
}

/* Ejecútala una vez desde el editor: crea la pestaña Programaciones y pide permiso de Drive */
function inicializarProgramaciones() {
  const h = hojaProg_();
  DriveApp.getRootFolder();
  Logger.log('Pestaña Programaciones lista con ' + (h.getLastRow() - 1) + ' departamentos.');
}

/* Nuevo departamento: ID siguiente al mayor y contraseña propia (la indicada o una generada) */
function crearDepartamento_(nombre, jefe, clave) {
  const h = hojaProg_();
  const filas = filas_(h);
  const norm = t => String(t).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
  if (filas.some(r => norm(r[1]) === norm(nombre))) throw new Error('Ya existe un departamento con ese nombre');
  const id = filas.reduce((m, r) => Math.max(m, Number(r[0]) || 0), 0) + 1;
  if (!clave) {
    const letras = norm(nombre).replace(/[^a-z]/g, '').toUpperCase();
    clave = (letras.slice(0, 3) || 'DEP') + Math.floor(1000 + Math.random() * 9000);
  }
  if (clave.length < 4) throw new Error('La contraseña debe tener al menos 4 caracteres');
  h.appendRow([id, nombre, jefe, clave, '', 'pendiente', '', '', '', '']);
  h.getRange(h.getLastRow(), 4).setNumberFormat('@').setValue(clave);
  return { id: id, clave: clave };
}

/* Eliminar la entrega de un departamento: todos sus PDF a la papelera y vuelve a "pendiente" */
function anularEntrega_(depId) {
  const h = hojaProg_(), n = filaPorId_(h, 1, depId);
  if (!n) throw new Error('Departamento no encontrado');
  const hd = hoja_(HOJA_DOCS, CAB_DOCS);
  migrarDocs_(hd);
  for (let i = hd.getLastRow(); i >= 2; i--) {
    const r = hd.getRange(i, 1, 1, CAB_DOCS.length).getValues()[0];
    if (Number(r[1]) !== Number(depId)) continue;
    const fid = String(r[6] || '') || idDeUrl_(r[5]);
    if (fid) { try { DriveApp.getFileById(fid).setTrashed(true); } catch (e) {} }
    hd.deleteRow(i);
  }
  h.getRange(n, 6, 1, 4).setValues([['pendiente', '', '', '']]);
}


/* ---------------- v10 · permisos y diagnóstico ---------------- */
/* Traduce los errores de permisos de Google a un mensaje que se entienda en la app */
function errorCalendario_(err) {
  const m = String((err && err.message) || err);
  if (/permission|permiso|authoriz|autoriz/i.test(m))
    return 'falta autorizar Google Calendar en el script de la hoja. En la hoja «Ausencias 2026-27» → Extensiones → Apps Script, ' +
      'ejecuta autorizarPermisos() y acepta los permisos; después publica una nueva versión (Implementar → Gestionar implementaciones).';
  return m;
}

/* ▶ EJECÚTALA UNA VEZ DESDE EL EDITOR después de pegar el código: Google pedirá los permisos de Calendar, Drive y Hojas
   para la cuenta propietaria del script. Luego mira el «Registro de ejecución». */
function autorizarPermisos() {
  Logger.log('Versión del servicio: ' + VERSION_SERVICIO);
  Logger.log('Cuenta del script: ' + Session.getEffectiveUser().getEmail());
  Logger.log('Hoja: ' + SpreadsheetApp.getActiveSpreadsheet().getName() + '  ✔ permiso de Hojas');
  DriveApp.getRootFolder().getName();
  Logger.log('✔ permiso de Drive (programaciones)');
  const cals = CalendarApp.getAllCalendars();
  Logger.log('✔ permiso de Google Calendar · calendarios visibles: ' + cals.length);
  const dap = cals.filter(c => /asuntos\s+propios|\bDAP\b/i.test(c.getName()));
  if (!dap.length) {
    Logger.log('⚠ La cuenta del script NO ve el calendario «Asuntos propios (DAP)». Compártelo con ' +
      Session.getEffectiveUser().getEmail() + ' con el permiso «Hacer cambios en eventos».');
  }
  dap.forEach(c => Logger.log('Calendario DAP: «' + c.getName() + '» · ID: ' + c.getId() +
    ' · ' + (c.isOwnedByMe() ? 'propietario' : 'compartido') + ' → comprueba que la app usa este ID (Calendarios → «Asuntos propios (DAP)»).'));
  Logger.log('¿La clave de administración del script es válida? ' + claveOk_(CLAVES_ADMIN[0]) + ' · claves configuradas: ' + clavesValidas_().length);
  Logger.log('Listo. Ahora: Implementar → Gestionar implementaciones → ✎ → Versión: «Nueva versión» → Implementar.');
}

/* ▶ Opcional: crea y borra al momento un evento de prueba en el calendario DAP para comprobar que se puede escribir.
   Cambia el texto de CAL_ID_PRUEBA por el ID que muestra autorizarPermisos() (o déjalo vacío para buscarlo por nombre). */
const CAL_ID_PRUEBA = '';
function probarEscrituraDap() {
  let cal = CAL_ID_PRUEBA ? CalendarApp.getCalendarById(CAL_ID_PRUEBA)
    : CalendarApp.getAllCalendars().filter(c => /asuntos\s+propios|\bDAP\b/i.test(c.getName()))[0];
  if (!cal) { Logger.log('⚠ No encuentro el calendario DAP: compártelo con la cuenta del script.'); return; }
  const dia = new Date(2030, 0, 2);   /* fecha lejana, para no molestar */
  const ev = cal.createAllDayEvent('Prueba de la app (se borra sola)', dia);
  ev.deleteEvent();
  Logger.log('✔ Se puede escribir en «' + cal.getName() + '»: creado y borrado un evento de prueba.');
}
