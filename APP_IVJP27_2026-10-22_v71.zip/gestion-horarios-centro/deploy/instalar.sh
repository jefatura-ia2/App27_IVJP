#!/usr/bin/env bash
# =====================================================================
#  Instalación de gestion-horarios-centro en un servidor del centro
#  Ubuntu Server 22.04 / 24.04 LTS o Debian 12, recién instalado.
#
#  Uso (desde la carpeta del proyecto descomprimido):
#    sudo DOMINIO=horarios.iesvalledeljerte.es bash deploy/instalar.sh
#  Variables opcionales:
#    DOMINIO         nombre o IP con el que se abrirá la app (por defecto, la IP del servidor)
#    ADMIN_PASSWORD  contraseña de administración (si no se indica, se genera una aleatoria; ya no abre el candado)
#    DIR             carpeta de instalación (por defecto /opt/gestion-horarios-centro)
#    WEB             servidor web: nginx (por defecto) o apache  → con Apache úsalo vía instalar-apache.sh
#    RUTA            (solo Apache) subcarpeta de la app, por defecto /horarios → http://servidor/horarios/
#  Se puede volver a ejecutar sin perder datos: no toca .env, base de datos ni PDF existentes.
# =====================================================================
set -euo pipefail

[ "$(id -u)" = 0 ] || { echo "Ejecútalo con sudo."; exit 1; }
ORIGEN="$(cd "$(dirname "$0")/.." && pwd)"
DIR="${DIR:-/opt/gestion-horarios-centro}"
DOMINIO="${DOMINIO:-$(hostname -I | awk '{print $1}')}"
ADMIN_PASSWORD="${ADMIN_PASSWORD:-$(head -c 18 /dev/urandom | base64 | tr -dc A-Za-z0-9 | head -c 16)}"
WEB="${WEB:-nginx}"
case "$WEB" in nginx) RUTA="";; apache) RUTA="/$(echo "${RUTA:-/horarios}" | sed 's#^/*##; s#/*$##')"; [ "$RUTA" != "/" ] || { echo "Con Apache la app va en una subcarpeta (RUTA=/horarios)."; exit 1; };; *) echo "WEB debe ser nginx o apache"; exit 1;; esac
USUARIO=horarios
paso() { echo; echo "==> $*"; }

paso "1/9 Paquetes del sistema"
export DEBIAN_FRONTEND=noninteractive
timedatectl set-timezone Europe/Madrid || true      # antes de instalar PostgreSQL, que toma la zona del sistema
apt-get update -y
apt-get install -y curl ca-certificates gnupg "$([ "$WEB" = apache ] && echo apache2 || echo nginx)" postgresql postgresql-contrib ufw rsync unzip openssl
if ! command -v node >/dev/null || [ "$(node -v | sed 's/^v//;s/\..*//')" -lt 20 ]; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi
echo "Node $(node -v) · npm $(npm -v) · $(psql --version)"

paso "2/9 Usuario del servicio («$USUARIO», sin acceso por consola)"
id -u "$USUARIO" >/dev/null 2>&1 || useradd --system --home-dir "$DIR" --shell /usr/sbin/nologin "$USUARIO"

paso "3/9 Copia de la aplicación en $DIR"
mkdir -p "$DIR"
NUEVA=0; [ -f "$DIR/backend/.env" ] || NUEVA=1
EXCL=(--exclude node_modules --exclude dist --exclude '.env' --exclude 'backend/uploads')
[ "$NUEVA" = 1 ] || EXCL+=(--exclude 'backend/data')   # en reinstalaciones se conserva el horario editado
rsync -a "${EXCL[@]}" "$ORIGEN"/ "$DIR"/
mkdir -p "$DIR/backend/uploads/programaciones" /var/backups/horarios
chmod 700 /var/backups/horarios

paso "4/9 Base de datos PostgreSQL"
systemctl enable --now postgresql
if [ "$NUEVA" = 1 ]; then
  PGPASS="$(openssl rand -hex 16)"
  runuser -u postgres -- psql -v ON_ERROR_STOP=1 -q <<SQL
DO \$\$ BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'horarios') THEN CREATE ROLE horarios LOGIN; END IF;
END \$\$;
ALTER ROLE horarios WITH PASSWORD '$PGPASS';
SQL
  runuser -u postgres -- psql -tAc "SELECT 1 FROM pg_database WHERE datname='horarios'" | grep -q 1 \
    || runuser -u postgres -- createdb -O horarios horarios
  runuser -u postgres -- psql -q -c "ALTER DATABASE horarios SET timezone TO 'Europe/Madrid'"
  ORIGEN_WEB="http://$DOMINIO,https://$DOMINIO"
  sed -e "s#__PGPASS__#$PGPASS#" -e "s#__ADMTOKEN__#$(openssl rand -hex 24)#" \
      -e "s#__ORIGEN__#$ORIGEN_WEB#" -e "s#__ADMINPASS__#$ADMIN_PASSWORD#" \
      "$DIR/deploy/env.produccion.ejemplo" > "$DIR/backend/.env"
  chmod 600 "$DIR/backend/.env"
  echo "Creado $DIR/backend/.env con contraseñas aleatorias."
else
  echo "Ya existía $DIR/backend/.env: se conserva."
fi
chown -R "$USUARIO:$USUARIO" "$DIR"

paso "5/9 Servidor (backend): dependencias, tablas y carga del horario"
cd "$DIR/backend"
runuser -u "$USUARIO" -- npm ci --omit=dev --no-audit --no-fund
runuser -u "$USUARIO" -- npm run migrate
if [ "$NUEVA" = 1 ]; then runuser -u "$USUARIO" -- npm run ingest:csv; fi

paso "6/9 App (frontend): compilación"
cd "$DIR/frontend"
runuser -u "$USUARIO" -- npm ci --no-audit --no-fund
runuser -u "$USUARIO" -- npm run build

paso "7/9 Servicios del sistema (arranque automático)"
for s in horarios-api horarios-cron; do
  sed "s#__DIR__#$DIR#g" "$DIR/deploy/$s.service" > "/etc/systemd/system/$s.service"
done
systemctl daemon-reload
systemctl enable horarios-api horarios-cron
systemctl restart horarios-api horarios-cron

printf 'WEB=%s\nRUTA=%s\n' "$WEB" "$RUTA" > "$DIR/deploy/.instalacion"   # lo leen actualizar.sh y https.sh
if [ "$WEB" = apache ]; then
  paso "8/9 Servidor web Apache (app en $RUTA/)"
  a2enmod -q proxy proxy_http headers alias rewrite deflate >/dev/null
  sed -e "s#__DIR__#$DIR#g" -e "s#__RUTA__#$RUTA#g" "$DIR/deploy/apache-horarios.conf" > /etc/apache2/conf-available/horarios.conf
  a2enconf -q horarios >/dev/null
  # Apache (usuario www-data) necesita poder leer la app compilada
  chmod o+rx "$DIR" "$DIR/frontend"; chmod -R o+rX "$DIR/frontend/dist"
  apache2ctl configtest
  systemctl enable apache2 >/dev/null 2>&1 || true
  systemctl reload apache2 2>/dev/null || systemctl restart apache2
else
  paso "8/9 Servidor web nginx"
  sed -e "s#__DIR__#$DIR#g" -e "s#__DOMINIO__#$DOMINIO#g" "$DIR/deploy/nginx-horarios.conf" > /etc/nginx/sites-available/horarios
  ln -sf /etc/nginx/sites-available/horarios /etc/nginx/sites-enabled/horarios
  rm -f /etc/nginx/sites-enabled/default
  nginx -t
  systemctl reload nginx
fi

paso "9/9 Cortafuegos y copias de seguridad diarias"
ufw allow OpenSSH >/dev/null
ufw allow 80/tcp >/dev/null; ufw allow 443/tcp >/dev/null
ufw --force enable >/dev/null
cat > /etc/cron.d/horarios-copias <<CRON
# Copia de seguridad diaria de la base de datos, PDF, horario y configuración (se guardan 30 días)
30 2 * * * root DIR=$DIR $DIR/deploy/copia-seguridad.sh >> /var/log/horarios-copias.log 2>&1
CRON
chmod +x "$DIR"/deploy/*.sh

sleep 3
if curl -fsS "http://127.0.0.1$RUTA/api/salud" >/dev/null; then
  echo; echo "✔ Instalación terminada. Abre:  http://$DOMINIO$RUTA/"
  [ "$NUEVA" = 1 ] && echo "  Primera entrada: usuario «jefatura» y la contraseña de administración ($ADMIN_PASSWORD); te pedirá cambiarla."
else
  echo; echo "⚠ La API no responde todavía. Revisa:  journalctl -u horarios-api -n 50"
fi
cat <<FIN

Siguientes pasos:
  · HTTPS (necesario para instalar la app en el móvil):  sudo bash $DIR/deploy/https.sh   (ver GUIA-DESPLIEGUE.md)
  · Estado:      systemctl status horarios-api horarios-cron
  · Registros:   journalctl -u horarios-api -f
  · Copia ahora: sudo $DIR/deploy/copia-seguridad.sh
FIN
