#!/usr/bin/env bash
# Restaura una copia hecha con copia-seguridad.sh (cifrada desde la v63; también admite las antiguas sin cifrar).
# Uso: sudo bash deploy/restaurar.sh 2026-10-05_023000      (la fecha que aparece en el nombre de los ficheros)
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "Ejecútalo con sudo."; exit 1; }
F="${1:?Indica la fecha de la copia, p. ej. 2026-10-05_023000 (mira en /var/backups/horarios)}"
DIR="${DIR:-/opt/gestion-horarios-centro}"
DEST="${DEST:-/var/backups/horarios}"
CLAVE="${CLAVE_COPIAS:-/etc/gestion-horarios/clave-copias}"
descifrar() { openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 -pass "file:$CLAVE"; }
if [ -f "$DEST/bd_$F.dump.enc" ]; then CIF=1; [ -s "$CLAVE" ] || { echo "Falta la clave de las copias en $CLAVE"; exit 1; }
elif [ -f "$DEST/bd_$F.dump" ]; then CIF=0
else echo "No existe la copia $F en $DEST"; exit 1; fi
read -r -p "Se sustituirán los datos actuales por los del $F. ¿Continuar? (escribe SI) " r
[ "$r" = "SI" ] || exit 1
systemctl stop horarios-cron horarios-api 2>/dev/null || true
if [ "$CIF" = 1 ]; then
  descifrar < "$DEST/bd_$F.dump.enc" | runuser -u postgres -- pg_restore --clean --if-exists -d horarios
  [ -f "$DEST/ficheros_$F.tar.gz.enc" ] && descifrar < "$DEST/ficheros_$F.tar.gz.enc" | tar -xz -C "$DIR/backend"
else
  runuser -u postgres -- pg_restore --clean --if-exists -d horarios < "$DEST/bd_$F.dump"
  [ -f "$DEST/ficheros_$F.tar.gz" ] && tar -xzf "$DEST/ficheros_$F.tar.gz" -C "$DIR/backend"
fi
chown -R horarios:horarios "$DIR/backend" 2>/dev/null || true
systemctl start horarios-api horarios-cron 2>/dev/null || true
echo "✔ Restaurada la copia del $F."
