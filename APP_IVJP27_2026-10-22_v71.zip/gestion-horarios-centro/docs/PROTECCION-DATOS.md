# Protección de datos en APP_IVJP27 (desde la v63)

Este documento resume las medidas de la app y lo que tiene que hacer el centro. Debe validarlo el Delegado/a de
Protección de Datos (DPD) de la Consejería con competencias en educación.

## 1. Lo que hace la app

| Medida | Dónde | Norma |
|---|---|---|
| Información por capas: aviso breve en la entrada y en cada formulario; información completa en «Protección de datos» (pie de página) | Toda la app | RGPD art. 13 · LOPDGDD art. 11 |
| Candado con la contraseña **personal** de cada cuenta de administración (pase de 8 h ligado a la persona) | Candado | RGPD art. 32 · ENS op.acc |
| Registro de accesos a datos sensibles (partes, justificantes, ausencias con motivo, informes, firmas, modo administrador, cierre de curso) | Mosaico «Protección de datos» (administración y Dirección) | RGPD art. 5.2 · ENS op.exp.8 |
| Plazos de conservación configurables y «cierre de curso» que borra lo vencido | Mosaico «Protección de datos» (administración) | RGPD art. 5.1.e |
| PDF de los partes: se borran de la carpeta al recibirlos; nombre del fichero solo con el código | Disciplina | RGPD art. 5.1.c y 25 |
| Tutor/a: aviso sin datos del alumno/a | Disciplina | RGPD art. 5.1.c · LOE DA 23.ª |
| Los motivos de ausencia ya no se guardan en el navegador | Ausencias | RGPD art. 9 y 32 |
| «Equipo compartido»: sesión de 8 h como máximo y cierre a los 20 min sin uso | Pantalla de entrada | ENS op.acc |
| Contraseña de 12 caracteres para cuentas con datos sensibles; contraseñas provisionales que caducan a las 72 h | Cuentas | ENS op.acc |
| Móvil del profesorado voluntario | Mis datos | RGPD art. 5.1.c |
| CORS cerrado, cabeceras de seguridad, sin indexar en buscadores | Servidor | RGPD art. 32 · ENS mp.com |
| Copias de seguridad cifradas (AES-256); la clave de cifrado no va dentro de la copia | Servidor | ENS mp.info.6 |
| Registros del sistema: 90 días como máximo | Servidor | RGPD art. 5.1.e |

## 2. Lo que tiene que hacer el centro

1. **Una vez, como root**, volver a ejecutar `su - -c "bash /var/www/App/deploy/instalar-en-var-www.sh"` para activar las
   copias cifradas y la retención de registros. Después, **guardar la clave de las copias fuera del servidor**:
   `sudo cat /etc/gestion-horarios/clave-copias` (sin ella no se pueden restaurar).
2. Enviar al DPD el inventario de tratamientos (pantalla «Protección de datos» de la app) y el texto informativo;
   cuando lo valide, marcar «Validado por el DPD» en el mosaico «Protección de datos».
3. Fijar con el DPD los **plazos de conservación** y hacer el **cierre de curso** cada septiembre (después de una copia).
4. Confirmar que la hoja de ausencias y el calendario de DAP de Google pertenecen a cuentas institucionales de Educarex.
5. Confirmar el contrato de encargado del tratamiento si el servidor está alojado fuera del centro.
6. Revisar que el videotutorial no muestra datos reales.
7. Recordar al claustro el deber de sigilo y el uso de «Equipo compartido» en los ordenadores comunes.

## 3. Protocolo ante una brecha de seguridad (RGPD arts. 33 y 34)

Brecha = pérdida, robo, acceso o difusión no autorizada de datos personales (p. ej. un parte enviado a quien no debe,
una contraseña de administración comprometida, un ordenador con la sesión abierta y datos copiados, un servidor atacado).

1. **Quien la detecta** avisa enseguida a Jefatura de Estudios o a Dirección (no intenta arreglarla por su cuenta).
2. **Contener (primeras horas)**: cambiar contraseñas afectadas, «Restaurar acceso» o desactivar cuentas en Usuarios,
   cerrar el modo administrador, desconectar el equipo afectado si hace falta. Consultar el **registro de accesos**.
3. **Dirección comunica la brecha al DPD de la Consejería** con: qué ha pasado, cuándo, qué datos y de cuántas personas,
   medidas tomadas.
4. El DPD/la Consejería decide si se notifica a la **Agencia Española de Protección de Datos en un máximo de 72 horas**
   desde que se tuvo conocimiento, y si hay que informar a las personas afectadas (riesgo alto).
5. **Registrar** la brecha (fecha, hechos, efectos, medidas) aunque no se notifique.

## 4. Configuración del servidor (`/etc/gestion-horarios/.env`)

- `ADMIN_PASSWORD`: solo para crear la primera cuenta «jefatura». Ya **no** abre el candado.
- `ADMIN_CLAVE_COMUN=si`: solo durante una transición, vuelve a aceptar la clave común en el candado (no recomendado).
- `GOOGLE_CLAVE`: clave que el servidor envía al script de Google (`CLAVES_ADMIN` del script). Si no se indica, se usa
  `ADMIN_PASSWORD` y todo sigue funcionando como antes. Lo recomendable es poner una distinta en los dos sitios.
- `CORS_ORIGIN`: vacío = solo la propia app y la app de móvil.

## 5. Revisión de seguridad (v69)

Corregido en la app:
- **Motivos de ausencia**: ya no salen en ninguna respuesta de guardias, tampoco en fines de semana.
- **Claves de departamento (programaciones)**: guardadas cifradas (scrypt), con freno a los intentos fallidos; las nuevas
  son aleatorias de 10 caracteres y las que se cambian deben tener 8 o más. **Conviene cambiar las antiguas (tipo ING2627).**
- **Modo administrador**: el pase solo vale para la cuenta que lo obtuvo y con su sesión; se anula al cerrar sesión o
  cambiar la contraseña.
- **Sesiones**: al cambiar la contraseña se cierran las demás sesiones; tope absoluto de 90 días.
- **Fuerza bruta**: freno por usuario e IP y además por IP (30 fallos / 15 min).
- **CSRF**: las peticiones que cambian datos solo se aceptan desde la propia app o la app de móvil.
- **Subidas**: como máximo 5 PDF por envío (10 por justificación) y 15 MB cada uno.
- **XSS**: los enlaces de avisos, Cronología y calendarios solo admiten http(s) o rutas internas.
- **Comparaciones de tokens en tiempo constante**; `/api/sync` desactivado si `ADMIN_TOKEN` no se ha cambiado.
- **Sin contraseñas en el código ni en los registros** (se quita la clave fija de la Biblioteca; las cuentas nuevas reciben
  la contraseña con «Restaurar acceso»).
- **Reservas**: el profesorado reserva a su propio nombre.
- **Errores internos** no se envían al navegador.
- **Sin servicios de terceros en el navegador**: la fuente Montserrat, React, Babel, Tailwind y PptxGenJS se sirven desde el
  propio servidor (antes Google Fonts, unpkg, cdn.tailwindcss.com y jsdelivr: transferían la IP del profesorado a terceros y
  permitían que un CDN comprometido ejecutara código en la app). Política de contenido (CSP) que solo permite código propio.
- **Pantalla de la sala**: opcional `PANEL_IPS` en `.env` para que solo la vean los equipos indicados.

A cargo del centro (servidor propio):
- Mantener el sistema actualizado (actualizaciones automáticas de seguridad), cortafuegos con solo los puertos 80/443
  (y SSH limitado a la red del centro), HTTPS activo (`deploy/https.sh`).
- Servidor en un lugar cerrado; copias cifradas también fuera del servidor; probar la restauración cada trimestre.
- Cambiar la clave de la Biblioteca si sigue siendo la antigua (la app lo avisa en Usuarios) y las claves de departamento.
- Poner en `.env`: `GOOGLE_CLAVE` propia (y la misma en el script de Google), `ADMIN_TOKEN` propio si se usa `/api/sync`.
