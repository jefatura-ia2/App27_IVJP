/* Vista de gestión: usa el puente del kit (Modulo.pedir) → /api/m/tv-ads/… con la sesión de la app */
addEventListener('DOMContentLoaded', async () => {
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const pintar = d => {
    document.getElementById('nuevo').hidden = !d.puedeGestionar;
    document.getElementById('lista').innerHTML = d.anuncios.length ? d.anuncios.map(a =>
      `<div class="fila"><b>${esc(a.titulo)}</b> <span class="pill">${esc(a.desde)} – ${esc(a.hasta)}</span></div>`).join('') : '<p class="ayuda">Sin anuncios.</p>';
  };
  const cargar = () => Modulo.pedir('GET', '/anuncios').then(pintar).catch(e => Modulo.aviso(e.message));
  document.getElementById('f').addEventListener('submit', async ev => {
    ev.preventDefault();
    const v = id => document.getElementById(id).value;
    try { await Modulo.pedir('POST', '/anuncios', { titulo: v('t'), texto: v('x'), desde: v('d'), hasta: v('h') }); Modulo.aviso('Anuncio publicado'); ev.target.reset(); cargar(); }
    catch (e) { Modulo.aviso(e.message); }
  });
  cargar();
});
