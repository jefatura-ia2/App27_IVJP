/* Pantalla de TV (sin sesión): rota los anuncios de hoy de ESTA pantalla y los vuelve a pedir cada 5 minutos.
   ?demo=1 muestra anuncios de ejemplo (para probar la TV sin datos). */
const CAT = { jefatura: 'Jefatura de Estudios', secretaria: 'Secretaría', actividades: 'Actividades', biblioteca: 'Biblioteca', convivencia: 'Convivencia', centro: 'Centro' };
const ICO = {
  calendario: '<rect x="3.5" y="5" width="17" height="15" rx="2.5" fill="currentColor" fill-opacity=".25"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
  musica: '<path d="M9 18V6l11-2v12"/><circle cx="6.5" cy="18" r="2.5" fill="currentColor" fill-opacity=".35"/><circle cx="17.5" cy="16" r="2.5" fill="currentColor" fill-opacity=".35"/>',
  libro: '<path d="M4 5.5C7 4.5 9.5 4.8 12 6.5c2.5-1.7 5-2 8-1V19c-3-1-5.5-.7-8 1-2.5-1.7-5-2-8-1Z" fill="currentColor" fill-opacity=".2"/><path d="M12 6.5V20"/>',
  documento: '<path d="M6 3h8l4 4v14H6Z" fill="currentColor" fill-opacity=".2"/><path d="M14 3v4h4M9 12h6M9 16h6"/>',
  alarma: '<path d="M12 3 2.5 20h19Z" fill="currentColor" fill-opacity=".22"/><path d="M12 9v5M12 17.2v.3"/>',
  hoja: '<path d="M5 19c0-8 6-14 15-14-1 9-6 15-14 15" fill="currentColor" fill-opacity=".22"/><path d="M5 19 13 11"/>',
};
const svg = k => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">${ICO[k] || ICO.calendario}</svg>`;
const DIAS = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
const DEMO = {
  pantalla: 'Entrada principal',
  anuncios: [
    { titulo: 'Matrícula de FP a distancia', texto: 'Plazo abierto hasta el 30 de octubre. Presenta tu solicitud en Secretaría o por Rayuela.', categoria: 'secretaria', icono: 'documento', cuando: 'Hasta el viernes 30 de octubre', segundos: 12 },
    { titulo: 'Simulacro de evacuación', texto: 'Jueves a 3ª hora. Sigue las indicaciones del profesorado y sal por la ruta señalizada de tu aula.', categoria: 'convivencia', icono: 'alarma', cuando: 'Jueves 5 de noviembre · 3ª hora', segundos: 12 },
    { titulo: 'Concierto de Navidad', texto: 'Actuaciones del alumnado de Música y del coro del centro. ¡Os esperamos en el SUM!', categoria: 'actividades', icono: 'musica', cuando: 'Martes 22 de diciembre · 12:00 · SUM', segundos: 12 },
    { titulo: 'Club de lectura', texto: 'Cada jueves en el recreo largo. Recoge el libro del mes en el mostrador de la Biblioteca.', categoria: 'biblioteca', icono: 'libro', cuando: 'Jueves · 2º recreo · Biblioteca', segundos: 12 },
    { titulo: '1ª Evaluación', texto: 'Sesiones de evaluación del 14 al 16 de diciembre. Los boletines se publican en Rayuela el día 22.', categoria: 'jefatura', icono: 'calendario', cuando: 'Del 14 al 16 de diciembre', segundos: 12 },
    { titulo: 'Semana de la movilidad sostenible', texto: 'Ven al instituto andando o en bici. Aparcabicis junto a la puerta del gimnasio.', categoria: 'centro', icono: 'hoja', cuando: 'Del 16 al 20 de noviembre', segundos: 12 },
  ],
  proximos: [['30', 'oct', 'Fin de matrícula FP'], ['5', 'nov', 'Simulacro de evacuación'], ['16', 'nov', 'Movilidad sostenible'], ['14', 'dic', '1ª Evaluación'], ['22', 'dic', 'Concierto de Navidad']],
};
addEventListener('DOMContentLoaded', () => {
  const q = new URLSearchParams(location.search), demo = q.has('demo'), t = q.get('t') || '';
  const $ = id => document.getElementById(id);
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const reloj = () => { const d = new Date(); $('hora').textContent = d.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
    $('fecha').textContent = DIAS[d.getDay()][0].toUpperCase() + DIAS[d.getDay()].slice(1) + ', ' + d.getDate() + ' de ' + MESES[d.getMonth()]; };
  reloj(); setInterval(reloj, 10000);
  let lista = [], proximos = [], i = Number(q.get('n') || 0), temporizador;
  const mostrar = () => {
    clearTimeout(temporizador);
    if (!lista.length) { $('anuncio').innerHTML = '<div></div><h1>Bienvenidos</h1>'; return; }
    const k = i % lista.length, a = lista[k]; i++;
    const cat = CAT[a.categoria] ? a.categoria : 'centro';
    const caja = $('anuncio');
    caja.className = 'tv-anuncio cat-' + cat; caja.style.animation = 'none'; void caja.offsetWidth; caja.style.animation = '';
    caja.innerHTML = (a.imagen ? `<img class="tv-img" src="${esc(a.imagen)}" alt="">` : `<div class="tv-pict">${svg(a.icono)}</div>`) +
      `<div><span class="tv-cat">${esc(CAT[cat])}</span><h1>${esc(a.titulo)}</h1>${a.texto ? `<p>${esc(a.texto)}</p>` : ''}` +
      (a.cuando ? `<div class="tv-cuando">${svg('calendario').replace('<svg', '<svg width="1.2em" height="1.2em"')} ${esc(a.cuando)}</div>` : '') + '</div>';
    $('puntos').innerHTML = lista.map((_, j) => `<i class="${j === k ? 'on' : ''}"></i>`).join('');
    const seg = a.segundos || 12, barra = $('progreso');
    barra.style.transition = 'none'; barra.style.width = '0'; void barra.offsetWidth;
    if (!q.has('n')) { barra.style.transition = `width ${seg}s linear`; barra.style.width = '100%'; temporizador = setTimeout(mostrar, seg * 1000); }
    else barra.style.width = '40%';
  };
  const lateral = () => { $('proximos').innerHTML = proximos.map(([d, m, txt], j) =>
    `<li class="${j === 0 ? 'actual' : ''}"><div class="tv-dia"><b>${esc(d)}</b><small>${esc(m)}</small></div><div><strong>${esc(txt)}</strong></div></li>`).join(''); };
  const cargar = async () => {
    if (demo) { lista = DEMO.anuncios; proximos = DEMO.proximos; $('pantalla').textContent = 'Pantalla: ' + DEMO.pantalla; return; }
    try {
      const d = await (await fetch('../../../api/m/tv-ads/publico/pantalla?t=' + encodeURIComponent(t), { cache: 'no-store' })).json();
      if (d.ok) { lista = d.anuncios; proximos = d.proximos || []; $('pantalla').textContent = 'Pantalla: ' + d.pantalla; }
    } catch { /* sin conexión: se mantienen los anuncios que ya había */ }
  };
  cargar().then(() => { lateral(); mostrar(); });
  if (!demo) setInterval(() => cargar().then(lateral), 5 * 60 * 1000);
});
