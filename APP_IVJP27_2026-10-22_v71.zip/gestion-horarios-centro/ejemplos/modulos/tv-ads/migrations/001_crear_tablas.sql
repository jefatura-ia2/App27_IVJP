-- tv-ads 1.0.0 · anuncios. Solo objetos con el prefijo mod_tv_ads_ (lo comprueba el instalador).
CREATE TABLE IF NOT EXISTS mod_tv_ads_anuncio (
  id         SERIAL PRIMARY KEY,
  titulo     TEXT NOT NULL,
  texto      TEXT NOT NULL DEFAULT '',
  imagen     TEXT NOT NULL DEFAULT '',          -- fichero subido (en el almacén del módulo), sin datos personales
  categoria  TEXT NOT NULL DEFAULT 'centro',    -- centro | jefatura | secretaria | actividades | biblioteca | convivencia
  icono      TEXT NOT NULL DEFAULT '',          -- icono del kit (calendario, musica, libro, aviso…)
  desde      DATE NOT NULL,
  hasta      DATE NOT NULL,
  segundos   INT  NOT NULL DEFAULT 12 CHECK (segundos BETWEEN 5 AND 120),
  orden      INT  NOT NULL DEFAULT 0,
  activo     BOOLEAN NOT NULL DEFAULT TRUE,
  creado     TIMESTAMPTZ NOT NULL DEFAULT now(),
  creado_por TEXT NOT NULL DEFAULT '',
  CHECK (hasta >= desde)
);
CREATE INDEX IF NOT EXISTS mod_tv_ads_anuncio_fechas_idx ON mod_tv_ads_anuncio (desde, hasta) WHERE activo;
