/**
 * Proyector de la sala de profesores durante los recreos (y enlace «Patio y recreos»).
 * Diseño de Jefatura (boceto): cabecera con centro · día · reloj; cuadrante con las zonas en columnas
 * (Zona 1 amarilla, Zona 2 verde, Zona 3 roja, Biblioteca) y los dos recreos en filas, con los nombres en grande;
 * a la derecha, el listado del profesorado de guardia de recreo y el mapa por satélite; abajo, tres recuadros
 * (avisos, ausencias de hoy y próximas actividades). Todo se mide en vw/vh para leerse a distancia.
 */
import React from 'react';
import MAPA_ZONAS from '../img/zonas-recreo.jpg';

export const ZONAS_RECREO = [
  { k: 'zona1', l: 'Zona 1', c: '#eab308', t: '#3b2a00', s: 'Puerta y entrada principal' },
  { k: 'zona2', l: 'Zona 2', c: '#16a34a', t: '#fff', s: 'Porche interior · prohibido pinos' },
  { k: 'zona3', l: 'Zona 3', c: '#dc2626', t: '#fff', s: 'Acceso a pistas y actividades' },
  { k: 'biblioteca', l: 'Biblioteca', c: '#7c4a1d', t: '#fff', s: 'Atención a la biblioteca' },
];
const POS_MAPA = { zona1: { left: '40.8%', top: '18.5%' }, zona2: { left: '69.3%', top: '28.7%' }, zona3: { left: '66%', top: '61%' } };
const DIAS = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
const MES3 = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
const min = s => { const [h, m] = String(s).split(':'); return +h * 60 + +m; };
const fechaDe = iso => new Date(iso + 'T12:00:00');
const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
const nombreCorto = n => { const [ap, no] = String(n || '').split(',').map(s => s.trim()); return no ? no.split(/\s+/)[0] + ' ' + ap.split(/\s+/)[0] : ap || ''; };
const ordinal = t => t.tramo === 'R1' ? '1.er' : t.tramo === 'R2' ? '2.º' : '';

/* quién vigila cada zona en un recreo (los de la biblioteca pueden no ser de guardia de recreo en el horario) */
function reparto(t, ausentesHoy) {
  const zonas = t.zonas || {};
  const fueraHorario = new Set((t.guardiasAusentes || []).map(g => g.nombre));
  const ausente = n => fueraHorario.has(n) || ausentesHoy.some(a => a.profesor === n && (a.modo === 'dia' || (a.horas || []).map(String).includes(String(t.tramo))));
  const porZona = Object.fromEntries(ZONAS_RECREO.map(z => [z.k, Object.keys(zonas).filter(n => zonas[n] === z.k).map(n => ({ nombre: n, fuera: ausente(n) }))]));
  const deGuardia = [...(t.guardias || []).map(g => ({ nombre: g.nombre, fuera: false })), ...(t.guardiasAusentes || []).map(g => ({ nombre: g.nombre, fuera: true }))];
  const sinZona = deGuardia.filter(g => !zonas[g.nombre]);
  return { porZona, deGuardia, sinZona, zonaDe: n => zonas[n] || '' };
}

export default function PanelRecreo({ d, ahora, hoyIso, recreos, actual, siguiente, auto, finAuto, aviso, iAviso, proximas, err, ultima, hhmm, Logo }) {
  const mins = ahora.getHours() * 60 + ahora.getMinutes();
  const hoy = fechaDe(hoyIso);
  const ausentesHoy = (d && d.ausentes) || [];
  const estadoDe = t => t === actual ? 'ahora' : min(t.fin) <= mins ? 'pasado' : t === siguiente ? 'siguiente' : 'futuro';
  const foco = actual || siguiente || null;          /* recreo del listado y del mapa */
  const rf = foco ? reparto(foco, ausentesHoy) : null;
  const estado = !d ? '' : !d.lectivo ? 'Hoy no hay clase'
    : actual ? ordinal(actual) + ' recreo · quedan ' + (min(actual.fin) - mins) + ' min'
      : siguiente ? ordinal(siguiente) + ' recreo a las ' + siguiente.inicio : 'Ya no quedan recreos hoy';
  const progreso = actual ? (mins - min(actual.inicio)) / (min(actual.fin) - min(actual.inicio)) : 0;

  return (
    <div className="pr">
      {/* ---------- cabecera: centro · día · reloj ---------- */}
      <header className="pr-head">
        <div className="pr-marca">
          <div className="pr-logo">{Logo && <Logo />}</div>
          <div><div className="pr-ies">IES Valle del Jerte</div><div className="pr-sala">Sala de profesores</div></div>
        </div>
        <div className="pr-dia">
          <div className="pr-dia-t">{cap(DIAS[hoy.getDay()])}, {hoy.getDate()} de {MESES[hoy.getMonth()]}</div>
          <div className="pr-dia-s">Guardias de recreo{auto && finAuto ? ' · a las ' + finAuto + ' vuelve el parte de guardias' : ''}</div>
        </div>
        <div className="pr-reloj">
          <div className="pr-hora">{hhmm(ahora)}<span>{String(ahora.getSeconds()).padStart(2, '0')}</span></div>
          <div className="pr-estado">{estado}</div>
          {actual && <div className="pr-barra"><i style={{ width: Math.round(progreso * 100) + '%' }} /></div>}
        </div>
      </header>

      {d && d.mensaje && <div className="pr-mensaje">{d.mensaje}</div>}

      {/* ---------- cuadrante: zonas × recreos + lateral ---------- */}
      <main className="pr-main">
        <div className="pr-esq" />
        {ZONAS_RECREO.map(z => <div key={z.k} className="pr-zcab" style={{ '--zc': z.c, '--zt': z.t }}><b>{z.l}</b><small>{z.s}</small></div>)}

        <section className="pr-lista">
          <h2>Profesorado de guardia de recreo</h2>
          {!d ? <p className="pr-nada">Cargando…</p> : !d.lectivo ? <p className="pr-nada">Hoy no hay clase.</p> : !foco ? <p className="pr-nada">Ya no quedan recreos hoy.</p> : <>
            <div className="pr-lista-s">{foco === actual ? 'Ahora' : 'Próximo'} · {ordinal(foco)} recreo · {foco.inicio}–{foco.fin}</div>
            <ul>
              {rf.deGuardia.concat(ZONAS_RECREO.flatMap(z => rf.porZona[z.k]).filter(p => !rf.deGuardia.some(g => g.nombre === p.nombre)))
                .map(p => { const z = ZONAS_RECREO.find(x => x.k === rf.zonaDe(p.nombre)); return (
                  <li key={p.nombre} className={p.fuera ? 'fuera' : ''}>
                    <i style={{ background: z ? z.c : '#94a3b8' }} />
                    <span className="pr-lista-n">{nombreCorto(p.nombre)}</span>
                    <span className="pr-lista-z" style={z ? { color: z.c === '#eab308' ? '#a16207' : z.c } : {}}>{p.fuera ? 'Ausente' : z ? z.l : 'Sin zona'}</span>
                  </li>); })}
            </ul>
          </>}
        </section>

        {(d && d.lectivo ? recreos : [{ tramo: 'R1', vacio: true }, { tramo: 'R2', vacio: true }]).slice(0, 2).map((t, i) => {
          const st = t.vacio ? 'futuro' : estadoDe(t);
          const r = t.vacio ? null : reparto(t, ausentesHoy);
          return (
            <React.Fragment key={t.tramo}>
              <div className={'pr-rec ' + st} style={{ gridRow: 2 + i, gridColumn: 1 }}>
                <span className="pr-rec-t">{ordinal(t)} recreo</span>
                {!t.vacio && <span className="pr-rec-h">{t.inicio}–{t.fin}</span>}
                {st === 'ahora' && <span className="pr-ya">AHORA</span>}
                {st === 'siguiente' && <span className="pr-ya sig">SIGUIENTE</span>}
              </div>
              {ZONAS_RECREO.map((z, j) => {
                const l = r ? r.porZona[z.k] : [];
                const n = l.length;
                return (
                  <div key={z.k} className={'pr-celda ' + st + (n > 2 ? ' muchos' : '')} style={{ '--zc': z.c, gridRow: 2 + i, gridColumn: 2 + j }}>
                    {l.map(p => <span key={p.nombre} className={'pr-n' + (p.fuera ? ' fuera' : '')}>{nombreCorto(p.nombre)}{p.fuera && <em>ausente</em>}</span>)}
                    {r && !l.some(p => !p.fuera) && <span className="pr-sin">Sin cubrir</span>}
                  </div>
                );
              })}
            </React.Fragment>
          );
        })}

        <section className="pr-mapa">
          <img src={MAPA_ZONAS} alt="Mapa por satélite de las zonas de vigilancia" />
          {foco && ZONAS_RECREO.filter(z => POS_MAPA[z.k]).map(z => {
            const l = rf.porZona[z.k];
            return (
              <div key={z.k} className={'pr-mapa-p' + (l.some(p => !p.fuera) ? '' : ' vacia')} style={{ '--zc': z.c, ...POS_MAPA[z.k] }}>
                {l.length ? l.map(p => <span key={p.nombre} className={p.fuera ? 'fuera' : ''}>{nombreCorto(p.nombre)}</span>) : <span>Sin cubrir</span>}
              </div>
            );
          })}
          <div className="pr-mapa-l">Mapa por satélite{foco ? ' · ' + ordinal(foco) + ' recreo' : ''}</div>
        </section>
      </main>

      {/* ---------- tres recuadros inferiores ---------- */}
      <footer className="pr-pie">
        <div className={'pr-caja pr-aviso ' + (d && (d.reuniones || []).length ? 'urgente' : ((aviso && aviso.nivel) || 'info'))} key={'a' + iAviso}>
          <h3>Avisos{d && d.avisos.length > 1 && <span className="pr-puntos">{d.avisos.map((_, i) => <i key={i} className={i === iAviso % d.avisos.length ? 'on' : ''} />)}</span>}</h3>
          {d && (d.reuniones || []).slice(0, 2).map((r, i) => { const f = fechaDe(r.fecha); return (
            <div key={'r' + i} className="pr-reunion"><b>{r.nombreOrgano}</b> · {cap(DIAS[f.getDay()])} {f.getDate()} de {MESES[f.getMonth()]} · {r.hora}{r.lugar ? ' · ' + r.lugar : ''}</div>); })}
          {aviso ? <><div className="pr-aviso-t">{aviso.titulo}</div>{aviso.texto && <p>{aviso.texto}</p>}</> : <p className="pr-nada">No hay avisos.</p>}
        </div>
        <div className="pr-caja">
          <h3>Ausentes hoy <b>{ausentesHoy.length}</b></h3>
          {!ausentesHoy.length ? <p className="pr-nada">No hay ausencias registradas.</p>
            : <div className="pr-aus">{ausentesHoy.slice(0, 10).map((a, i) => <span key={i}>{nombreCorto(a.profesor)}<em>{a.modo === 'dia' ? 'todo el día' : (a.horas || []).map(h => /^R/.test(h) ? h : h + 'ª').join(' ')}</em></span>)}
              {ausentesHoy.length > 10 && <span className="pr-mas">y {ausentesHoy.length - 10} más</span>}</div>}
        </div>
        <div className="pr-caja">
          <h3>Próximas actividades</h3>
          {!proximas.length ? <p className="pr-nada">Nada en los próximos 30 días.</p>
            : <ul className="pr-act">{proximas.slice(0, 2).map(e => { const f = fechaDe(e.inicio); return <li key={e.id}><span className="pr-act-f"><b>{f.getDate()}</b>{MES3[f.getMonth()]}</span><span className="pr-act-t">{e.titulo}</span></li>; })}</ul>}
          <div className="pr-sello">{err === 'sin-conexion' ? 'Sin conexión · datos de las ' + (ultima ? hhmm(ultima) : '—') : 'Actualizado ' + (ultima ? hhmm(ultima) : '—')}</div>
        </div>
      </footer>
    </div>
  );
}
