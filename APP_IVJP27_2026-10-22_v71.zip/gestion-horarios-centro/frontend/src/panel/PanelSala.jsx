/**
 * Panel de la sala de profesores (pantalla de TV, 16:9).
 * Se abre con ?panel=<enlace secreto> sin iniciar sesión. Refresca los datos cada minuto y el reloj cada segundo.
 * Muestra: parte de guardias del turno con el tramo en curso destacado, profesorado ausente hoy y el próximo
 * día lectivo, avisos (rotando), próximas actividades de la Cronología y enlaces con código QR.
 */
import React, { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import qrcode from 'qrcode-generator';
import './panel.css';
import MAPA_ZONAS from '../img/zonas-recreo.jpg';
import PanelRecreo from './PanelRecreo.jsx';

const API = (window.__API_BASE__ || '/api').replace(/\/$/, '');
const DIAS = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
const MES3 = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
const fechaDe = iso => new Date(iso + 'T12:00:00');
const isoHoy = (d = new Date()) => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
const hhmm = d => String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
const min = s => { const [h, m] = s.split(':'); return +h * 60 + +m; };
const largo = iso => { const d = fechaDe(iso); return cap(DIAS[d.getDay()]) + ', ' + d.getDate() + ' de ' + MESES[d.getMonth()]; };
const corta = iso => { const d = fechaDe(iso); return d.getDate() + '/' + (d.getMonth() + 1); };
/* «Apellido1 Apellido2, Nombre» → «Nombre Apellido1» */
export const nombreCorto = n => {
  const [ap, no] = String(n || '').split(',').map(s => s.trim());
  if (!no) return ap || '';
  const a1 = ap.split(/\s+/)[0];
  return no + ' ' + a1;
};
/* zonas de vigilancia del recreo (mismos colores que el mapa) */
/* dónde va el nombre de quien vigila cada zona sobre el mapa (bajo la etiqueta «Zona N» de la imagen) */
const POS_MAPA = { zona1: { left: '40.8%', top: '18.5%' }, zona2: { left: '69.3%', top: '28.7%' }, zona3: { left: '66%', top: '61%' }, biblioteca: { left: '2%', bottom: '3%' } };
const ZONAS = [{ k: 'zona1', l: 'Zona 1', c: '#eab308', s: 'Puerta y entrada principal' }, { k: 'zona2', l: 'Zona 2', c: '#14b8a6', s: 'Porche interior · prohibido pinos' }, { k: 'zona3', l: 'Zona 3', c: '#ef4444', s: 'Acceso a pistas y actividades' }, { k: 'biblioteca', l: 'Biblioteca', c: '#7c4a1d', s: 'Atención a la biblioteca' }];
const lblTramo = c => /^R/.test(c) ? 'Recreo' : c + 'ª';
const lblHora = h => /^R/.test(h) ? 'R' + h.slice(1) : h + 'ª';

/* Grupos sin profesor de un tramo, juntando los del mismo profesor/a, aula y materia */
function agrupar(sinCubrir) {
  const m = new Map();
  for (const s of sinCubrir) {
    const k = [s.profesor, s.aula || '', s.materia || ''].join('|');
    const x = m.get(k) || { ...s, grupos: [] };
    if (s.grupo && !x.grupos.includes(s.grupo)) x.grupos.push(s.grupo);
    if (!x.tarea && s.tarea) x.tarea = s.tarea;
    m.set(k, x);
  }
  return [...m.values()].sort((a, b) => String(a.aula).localeCompare(String(b.aula), 'es', { numeric: true }));
}

function QR({ url, tam }) {
  const svg = useMemo(() => {
    try { const q = qrcode(0, 'M'); q.addData(url); q.make(); return q.createSvgTag({ cellSize: 4, margin: 0, scalable: true }); } catch { return ''; }
  }, [url]);
  return <div className="pn-qr-img" style={{ width: tam, height: tam }} dangerouslySetInnerHTML={{ __html: svg }} />;
}

function Logo() {
  return (
    <svg viewBox="0 0 200 200" className="pn-logo" aria-hidden="true">
      <circle cx="58" cy="52" r="7" fill="#6B2D8B" />
      <path d="M 55 65 Q 80 110 100 140 Q 120 110 175 30 Q 130 95 100 130 Q 85 105 55 65 Z" fill="#6B2D8B" />
      <path d="M 72 78 Q 90 108 100 122 Q 110 108 140 72 Q 118 100 100 118 Q 92 105 72 78 Z" fill="#fff" />
      <path d="M 85 92 Q 95 108 100 114 Q 105 108 118 92 Q 108 104 100 112 Q 95 106 85 92 Z" fill="#6B2D8B" />
    </svg>
  );
}

/* Próximas actividades: se leen de la Cronología (public/cronologia.html, bloque app-data) */
async function leerActividades() {
  try {
    const r = await fetch('cronologia.html', { cache: 'no-store' });
    const t = await r.text();
    const m = /<script id="app-data" type="application\/json">([\s\S]*?)<\/script>/.exec(t);
    return m ? (JSON.parse(m[1]).eventos || []) : [];
  } catch { return []; }
}

/* tipo de ausencia (sin el motivo concreto): DAP, actividad extraescolar/complementaria u otros */
const TIPO_AUS = { dap: ['DAP', 'Asuntos particulares'], extraescolar: ['Extraescolar', 'Actividad extraescolar'], complementaria: ['Complementaria', 'Actividad complementaria'], otros: ['Otros', 'Otros motivos'] };
function Ausente({ a }) {
  const t = TIPO_AUS[a.tipo] ? a.tipo : 'otros';
  return (
    <li className="pn-aus">
      <span className="pn-aus-n">{nombreCorto(a.profesor)}<span className={'pn-tipo pn-tipo-' + (t === 'complementaria' ? 'extraescolar' : t)} title={TIPO_AUS[t][1]}>{TIPO_AUS[t][0]}</span></span>
      <span className="pn-aus-h">
        {a.modo === 'dia' ? <span className="pn-hchip todo">Todo el día</span> : a.horas.map(h => <span key={h} className="pn-hchip">{lblHora(h)}</span>)}
        {a.hasta && <span className="pn-hasta">hasta el {corta(a.hasta)}</span>}
      </span>
    </li>
  );
}

export default function PanelSala({ token }) {
  const [ahora, setAhora] = useState(new Date());
  const [d, setD] = useState(null);
  const [err, setErr] = useState('');
  const [ultima, setUltima] = useState(null);
  const [eventos, setEventos] = useState([]);
  const [iAviso, setIAviso] = useState(0);
  const [ajuste, setAjuste] = useState(0);   /* 0 normal · 1 oculta tramos pasados · 2-4 letra cada vez menor (4 quita además la materia) */
  const cuerpo = useRef(null);
  const diaCarga = useRef(isoHoy());

  /* reloj */
  useEffect(() => { const t = setInterval(() => setAhora(new Date()), 1000); return () => clearInterval(t); }, []);
  /* datos cada minuto; al cambiar de día se recarga la página (recoge también versiones nuevas de la app) */
  useEffect(() => {
    let vivo = true;
    const cargar = async () => {
      if (isoHoy() !== diaCarga.current) { location.reload(); return; }
      try {
        /* «sesion»: lo abre el profesorado desde Guardias o Biblioteca, con su sesión de la app */
        const url = token === 'sesion' || token === 'recreo' ? API + '/panel/hoy' : token === 'biblioteca' ? API + '/panel/biblioteca-hoy' : API + '/panel/datos?t=' + encodeURIComponent(token);
        const r = await fetch(url, { cache: 'no-store', credentials: 'include' });
        const j = await r.json();
        if (!vivo) return;
        if (!j.ok) { setErr(j.error || 'Enlace no válido'); return; }
        setD(j); setErr(''); setUltima(new Date());
      } catch { if (vivo) setErr('sin-conexion'); }
    };
    cargar(); leerActividades().then(e => vivo && setEventos(e));
    const t = setInterval(cargar, 60000);
    const t2 = setInterval(() => leerActividades().then(e => vivo && setEventos(e)), 30 * 60000);
    return () => { vivo = false; clearInterval(t); clearInterval(t2); };
  }, [token]);
  /* avisos rotando */
  useEffect(() => {
    const n = d ? d.avisos.length : 0;
    if (n < 2) { setIAviso(0); return; }
    const t = setInterval(() => setIAviso(i => (i + 1) % n), (d.segundosAviso || 12) * 1000);
    return () => clearInterval(t);
  }, [d]);

  const hm = hhmm(ahora);
  const esBib = token === 'biblioteca';   /* cuadrante de la Biblioteca (módulo Biblioteca) */
  const mins = min(hm);
  /* turno visible: el de la hora actual; si no hay actividad en él, el otro */
  const base = useMemo(() => {
    if (!d || !d.lectivo) return [];
    const finManana = d.tramos.filter(t => t.turno !== 'tarde').reduce((m, t) => Math.max(m, min(t.fin)), 0);
    const turno = mins < finManana || !d.tramos.some(t => t.turno === 'tarde') ? 'mañana' : 'tarde';
    const l = d.tramos.filter(t => (t.turno === 'tarde' ? 'tarde' : 'mañana') === turno);
    return l.length ? l : d.tramos;
  }, [d, mins]);
  /* Pantalla de la sala de profesores: durante el recreo se proyecta el cuadrante de guardias de recreo
     (zonas) y al acabar vuelve sola al parte de guardias de aula */
  const esSala = !['sesion', 'recreo', 'biblioteca'].includes(token);
  const tramoAhora = base.find(t => mins >= min(t.inicio) && mins < min(t.fin));
  const recreoAuto = esSala && !!tramoAhora && tramoAhora.tipo === 'recreo';
  const esRec = token === 'recreo' || recreoAuto;   /* cuadrante de las guardias de recreo */
  const tramos = useMemo(() => esRec ? base.filter(t => t.tipo === 'recreo') : base, [base, esRec]);
  const actual = tramos.find(t => mins >= min(t.inicio) && mins < min(t.fin));
  const siguiente = tramos.find(t => min(t.inicio) > mins);
  const estadoDe = t => t === actual ? 'actual' : min(t.fin) <= mins ? 'pasado' : t === siguiente ? 'siguiente' : 'futuro';
  const visibles = ajuste >= 1 ? tramos.filter(t => estadoDe(t) !== 'pasado') : tramos;

  /* si no cabe, primero se ocultan los tramos ya pasados y después se reduce la letra */
  useLayoutEffect(() => { setAjuste(0); }, [d, actual && actual.tramo, esRec]);
  useLayoutEffect(() => {
    const el = cuerpo.current;
    if (el && el.scrollHeight > el.clientHeight + 2 && ajuste < 4) setAjuste(a => a + 1);
  });

  const totalSin = tramos.reduce((n, t) => n + agrupar(t.sinCubrir).length, 0);
  const estado = !d ? '' : !d.lectivo ? 'Hoy no hay clase'
    : actual ? (actual.tipo === 'recreo' ? 'Recreo' : lblTramo(actual.tramo) + ' hora') + ' · quedan ' + (min(actual.fin) - mins) + ' min'
      : siguiente ? 'Empieza ' + (siguiente.tipo === 'recreo' ? 'el recreo' : 'la ' + lblTramo(siguiente.tramo) + ' hora') + ' a las ' + siguiente.inicio
        : 'Jornada terminada';
  const progreso = actual ? (mins - min(actual.inicio)) / (min(actual.fin) - min(actual.inicio)) : 0;

  const hoyIso = isoHoy(ahora);
  const limite = isoHoy(new Date(ahora.getTime() + 30 * 864e5));
  /* actividades extraescolares (calendario de Google, leído por el servidor) */
  const extra = (d && d.extraescolares) || [];
  const extraHoy = extra.filter(e => e.inicio <= hoyIso && e.fin >= hoyIso);
  /* próximas actividades: Cronología + extraescolares, por fecha (las de hoy ya están en su recuadro) */
  const crono = (d && Array.isArray(d.cronologia)) ? d.cronologia : eventos;   /* cronograma grabado en el servidor; si no hay, el de fábrica */
  const proximas = crono.filter(e => (e.fin || e.inicio) >= hoyIso && e.inicio <= limite).map(e => ({ ...e, tipo: 'crono' }))
    .concat(extra.filter(e => e.inicio > hoyIso).map((e, i) => ({ ...e, id: 'x' + i, tipo: 'extra' })))
    .sort((a, b) => (a.inicio + (a.hora || '')).localeCompare(b.inicio + (b.hora || ''))).slice(0, 4);
  const aviso = d && d.avisos.length ? d.avisos[iAviso % d.avisos.length] : null;

  if (err && err !== 'sin-conexion' && !d) {
    return <div className="pn pn-error"><Logo /><h1>Panel de la sala de profesores</h1><p>{err}</p></div>;
  }

  /* guardias de recreo: diseño propio de Jefatura (zonas en columnas, recreos en filas, letra grande) */
  if (esRec) return <PanelRecreo d={d} ahora={ahora} hoyIso={hoyIso} recreos={tramos} actual={actual} siguiente={siguiente}
    auto={recreoAuto} finAuto={tramoAhora ? tramoAhora.fin : ''} aviso={aviso} iAviso={iAviso} proximas={proximas} err={err} ultima={ultima} hhmm={hhmm} Logo={Logo} />;

  return (
    <div className={'pn' + (esBib ? ' pn-bib' : '') + (esRec ? ' pn-bib pn-recreo' : '') + (ajuste >= 2 ? ' pn-mini' : '') + (ajuste >= 3 ? ' pn-micro' : '') + (ajuste >= 4 ? ' pn-nano' : '')}>
      <header className="pn-head">
        <div className="pn-marca">
          <div className="pn-logo-caja"><Logo /></div>
          <div>
            <div className="pn-ies">IES Valle del Jerte · Plasencia</div>
            <div className="pn-titulo">{esBib ? 'Biblioteca' : esRec && !recreoAuto ? 'Patio y recreos' : 'Sala de profesores'}</div>
          </div>
        </div>
        <div className="pn-fecha">
          <div className="pn-sub">{esBib ? 'Atención a biblioteca' : esRec ? 'Guardias de recreo' + (recreoAuto ? ' · el parte de guardias vuelve a las ' + tramoAhora.fin : '') : 'Parte de guardias'}</div>
          <div className="pn-dia">{largo(hoyIso)}</div>
        </div>
        <div className="pn-reloj">
          <div className="pn-hora">{hm}<span className="pn-seg">{String(ahora.getSeconds()).padStart(2, '0')}</span></div>
          <div className="pn-estado">{estado}</div>
          {actual && <div className="pn-barra"><i style={{ width: Math.round(progreso * 100) + '%' }} /></div>}
        </div>
      </header>

      {d && d.mensaje && <div className="pn-mensaje"><span className="pn-mensaje-i">!</span>{d.mensaje}</div>}

      <main className="pn-main">
        <section className="pn-tabla" aria-label={esBib ? 'Cuadrante de la biblioteca' : 'Parte de guardias'}>
          {esRec ? <div className="pn-cab pn-cab-bib">
            <span>Recreo</span>
            {ZONAS.map(z => <span key={z.k} className="pn-zcab"><i style={{ background: z.c }} />{z.l}<small>{z.s}</small></span>)}
          </div> : esBib ? <div className="pn-cab pn-cab-bib">
            <span>Tramo</span>
            <span>Atención a biblioteca <em>G.B.</em></span>
            <span className="pn-cab-sin">Mayores de 55 <em>MAY55</em></span>
          </div> : <div className="pn-cab">
            <span>Tramo</span>
            <span>De guardia</span>
            <span className="pn-cab-sin">Grupos sin profesor <em>aula · grupo · profesor/a ausente · tarea</em>
              {d && d.lectivo && <b className={'pn-total' + (totalSin ? '' : ' ok')}>{totalSin ? totalSin + ' hoy' : 'Sin incidencias'}</b>}</span>
          </div>}
          <div className="pn-cuerpo" ref={cuerpo}>
            {!d && !err && <div className="pn-vacio">Cargando…</div>}
            {d && !d.lectivo && <div className="pn-vacio"><b>Hoy no hay clase</b><span>El próximo día lectivo es el {largo(d.proximo.fecha).toLowerCase()}.</span></div>}
            {esRec && d && d.lectivo && !visibles.length && <div className="pn-vacio"><b>No quedan recreos hoy</b></div>}
            {esRec && visibles.map(t => {
              const st = estadoDe(t);
              const zonas = t.zonas || {};
              const todos = [...t.guardias.map(g => ({ ...g, fuera: false })), ...t.guardiasAusentes.map(g => ({ ...g, fuera: true }))];
              const sinZona = todos.filter(g => !zonas[g.nombre]);
              return (
                <div key={t.tramo} className={'pn-fila ' + st}>
                  <div className="pn-t">
                    <span className="pn-t-n">{t.tramo === 'R1' ? '1.er' : t.tramo === 'R2' ? '2.º' : ''} recreo</span>
                    <span className="pn-t-h">{t.inicio}–{t.fin}</span>
                    {st === 'actual' && <span className="pn-ya">Ahora</span>}
                    {st === 'siguiente' && <span className="pn-ya sig">Siguiente</span>}
                  </div>
                  {ZONAS.map(z => {
                    const l = todos.filter(g => zonas[g.nombre] === z.k);
                    return (
                      <div key={z.k} className="pn-g pn-zona" style={{ '--zc': z.c }}>
                        {l.map(g => <span key={g.nombre} className={'pn-n' + (g.fuera ? ' fuera' : '')}>{nombreCorto(g.nombre)}</span>)}
                        {!l.filter(g => !g.fuera).length && <span className="pn-sincubrir">Sin cubrir</span>}
                      </div>
                    );
                  })}
                  {sinZona.length > 0 && <div className="pn-sinzona"><span className="pn-sinzona-l">De guardia · sin zona asignada</span>{sinZona.map(g => <span key={g.nombre} className={'pn-n' + (g.fuera ? ' fuera' : '')}>{nombreCorto(g.nombre)}</span>)}</div>}
                </div>
              );
            })}
            {esBib && visibles.map(t => {
              const st = estadoDe(t);
              const Persona = ({ p }) => <span className={'pn-n' + (p.fuera ? ' fuera' : '')} title={p.fuera ? 'Ausente hoy' : ''}>{nombreCorto(p.nombre)}{p.dept && <i className="pn-dep">{p.dept}</i>}</span>;
              if (t.tipo === 'recreo') return (
                <div key={t.tramo} className={'pn-fila rec ' + st}>
                  <div className="pn-t"><span className="pn-t-n">Recreo</span><span className="pn-t-h">{t.inicio}–{t.fin}</span>{st === 'actual' && <span className="pn-ya">Ahora</span>}</div>
                  <div className="pn-rec-g">
                    <span className="pn-rec-l">Guardia de recreo en biblioteca</span>
                    {(t.bibRecreo || []).map(p => <Persona key={p.nombre} p={p} />)}
                    {!(t.bibRecreo || []).length && <span className="pn-nada">Sin asignar</span>}
                  </div>
                </div>
              );
              return (
                <div key={t.tramo} className={'pn-fila ' + st}>
                  <div className="pn-t">
                    <span className="pn-t-n">{lblTramo(t.tramo)}</span>
                    <span className="pn-t-h">{t.inicio}–{t.fin}</span>
                    {st === 'actual' && <span className="pn-ya">Ahora</span>}
                    {st === 'siguiente' && <span className="pn-ya sig">Siguiente</span>}
                  </div>
                  <div className="pn-g">{(t.gb || []).map(p => <Persona key={p.nombre} p={p} />)}{!(t.gb || []).length && <span className="pn-nada">—</span>}</div>
                  <div className="pn-g pn-g-may">{(t.may || []).map(p => <Persona key={p.nombre} p={p} />)}{!(t.may || []).length && <span className="pn-nada">—</span>}</div>
                </div>
              );
            })}
            {!esBib && !esRec && visibles.map(t => {
              const st = estadoDe(t);
              const items = agrupar(t.sinCubrir);
              if (t.tipo === 'recreo') return (
                <div key={t.tramo} className={'pn-fila rec ' + st}>
                  <div className="pn-t"><span className="pn-t-n">Recreo</span><span className="pn-t-h">{t.inicio}–{t.fin}</span>{st === 'actual' && <span className="pn-ya">Ahora</span>}</div>
                  <div className="pn-rec-g">
                    {t.guardias.map(g => <span key={g.id || g.nombre} className="pn-n">{nombreCorto(g.nombre)}{(t.biblioteca || []).includes(g.nombre) && <i className="pn-bib">Biblioteca</i>}</span>)}
                    {t.guardiasAusentes.map(g => <span key={'x' + (g.id || g.nombre)} className="pn-n fuera">{nombreCorto(g.nombre)}</span>)}
                    {!t.guardias.length && !t.guardiasAusentes.length && <span className="pn-nada">Sin guardias de recreo</span>}
                  </div>
                </div>
              );
              const faltan = items.length - t.guardias.length;
              return (
                <div key={t.tramo} className={'pn-fila ' + st}>
                  <div className="pn-t">
                    <span className="pn-t-n">{lblTramo(t.tramo)}</span>
                    <span className="pn-t-h">{t.inicio}–{t.fin}</span>
                    {st === 'actual' && <span className="pn-ya">Ahora</span>}
                    {st === 'siguiente' && <span className="pn-ya sig">Siguiente</span>}
                  </div>
                  <div className="pn-g">
                    {t.guardias.map(g => <span key={g.id || g.nombre} className="pn-n">{nombreCorto(g.nombre)}</span>)}
                    {t.guardiasAusentes.map(g => <span key={'x' + (g.id || g.nombre)} className="pn-n fuera" title="De guardia pero ausente">{nombreCorto(g.nombre)}</span>)}
                    {!t.guardias.length && !t.guardiasAusentes.length && <span className="pn-nada">—</span>}
                  </div>
                  <div className="pn-s">
                    {items.length === 0 && <span className="pn-ok">Sin grupos que cubrir</span>}
                    {items.map((x, i) => (
                      <div key={i} className="pn-item">
                        <span className="pn-aula">{x.aula || '—'}</span>
                        <div className="pn-item-txt">
                          <div><b className="pn-grupos">{x.grupos.join(', ') || 'Sin grupo'}</b><span className="pn-prof">{nombreCorto(x.profesor)}</span>{x.materia && <span className="pn-mat">{x.materia}</span>}</div>
                          {x.tarea && <div className="pn-tarea">Tarea: {x.tarea}</div>}
                        </div>
                      </div>
                    ))}
                    {faltan > 0 && <span className="pn-faltan">Faltan {faltan} de guardia</span>}
                  </div>
                </div>
              );
            })}
            {ajuste >= 1 && tramos.some(t => estadoDe(t) === 'pasado') && <div className="pn-ocultos">Se ocultan los tramos ya terminados para que quepa todo</div>}
          </div>
        </section>

        <aside className="pn-lado">
          {esRec && d && (() => {
            /* el mapa de zonas se ve siempre, también los días sin clase; los nombres, cuando hay recreo */
            const t = d.lectivo ? actual || siguiente : null;
            const ausentesRec = []; tramos.forEach(x => x.guardiasAusentes.forEach(g => { if (!ausentesRec.some(a => a.nombre === g.nombre)) ausentesRec.push({ ...g, tramo: x.tramo }); }));
            return <>
              {d.lectivo && <div className="pn-card">
                <h2>{t === actual ? 'Ahora de guardia de recreo' : t ? 'Próximo recreo' : 'Recreos de hoy'} <b className="pn-num">{t ? t.guardias.length : 0}</b></h2>
                {t ? <p className="pn-nada">{t.tramo === 'R1' ? '1.er' : '2.º'} recreo · {t.inicio}–{t.fin}</p> : <p className="pn-nada">Ya no quedan recreos hoy.</p>}
                <ul className="pn-lista">{t && t.guardias.map(g => { const z = ZONAS.find(x => x.k === (t.zonas || {})[g.nombre]); return <li key={g.id || g.nombre} className="pn-aus"><span className="pn-aus-n">{nombreCorto(g.nombre)}</span><span className="pn-hchip" style={z ? { background: z.c, color: '#fff' } : {}}>{z ? z.l : 'Sin zona'}</span></li>; })}</ul>
              </div>}
              <div className="pn-card pn-mapa">
                <h2>Zonas de vigilancia{t ? ' · ' + (t.tramo === 'R1' ? '1.er' : '2.º') + ' recreo' : ''}</h2>
                <div className="pn-mapa-img">
                  <img src={MAPA_ZONAS} alt="Mapa de las zonas de vigilancia" width="1206" height="820" />
                  {t && (() => {
                    const sz = [...t.guardias, ...t.guardiasAusentes].filter(g => !(t.zonas || {})[g.nombre]);
                    return sz.length > 0 && <div className="pn-mapa-sinzona"><b>Sin zona</b>{sz.map(g => <span key={g.nombre}>{nombreCorto(g.nombre)}</span>)}</div>;
                  })()}
                  {t && ZONAS.map(z => {
                    const quien = [...t.guardias, ...t.guardiasAusentes].filter(g => (t.zonas || {})[g.nombre] === z.k);
                    const fuera = n => t.guardiasAusentes.some(g => g.nombre === n);
                    return (
                      <div key={z.k} className={'pn-mapa-prof' + (z.k === 'biblioteca' ? ' bib' : '') + (quien.length ? '' : ' vacia')} style={{ '--zc': z.c, ...(POS_MAPA[z.k] || {}) }}>
                        {z.k === 'biblioteca' && <span className="pn-mapa-z">Biblioteca</span>}
                        {quien.length ? quien.map(g => <span key={g.nombre} className={fuera(g.nombre) ? 'fuera' : ''}>{nombreCorto(g.nombre)}</span>) : <span>Sin cubrir</span>}
                      </div>
                    );
                  })}
                </div>
                <ul className="pn-mapa-ley">{ZONAS.map(z => <li key={z.k}><i style={{ background: z.c }} /><b>{z.l}</b> {z.s}</li>)}</ul>
              </div>
              {d.lectivo && <div className="pn-card suave">
                <h2>De guardia de recreo y ausentes <b className="pn-num">{ausentesRec.length}</b></h2>
                {!ausentesRec.length ? <p className="pn-nada">Todas las guardias de recreo están cubiertas.</p>
                  : <ul className="pn-lista">{ausentesRec.map(g => <li key={g.nombre} className="pn-aus"><span className="pn-aus-n">{nombreCorto(g.nombre)}</span><span className="pn-aus-h"><span className="pn-hchip">{lblHora(g.tramo)}</span></span></li>)}</ul>}
              </div>}
            </>;
          })()}
          {esBib && d && d.lectivo && (() => {
            const t = actual || siguiente;
            const gente = t ? [...(t.gb || []), ...(t.may || []), ...(t.bibRecreo || [])] : [];
            const faltan = []; tramos.forEach(x => [...(x.gb || []), ...(x.may || []), ...(x.bibRecreo || [])].forEach(p => { if (p.fuera && !faltan.some(f => f.nombre === p.nombre)) faltan.push({ ...p, tramo: x.tramo }); }));
            return <>
              <div className="pn-card">
                <h2>{t === actual ? 'Ahora en la biblioteca' : 'Después en la biblioteca'} <b className="pn-num">{gente.filter(p => !p.fuera).length}</b></h2>
                {t && <p className="pn-nada">{t.tipo === 'recreo' ? 'Recreo' : lblTramo(t.tramo) + ' hora'} · {t.inicio}–{t.fin}</p>}
                {!gente.length && <p className="pn-nada">Nadie asignado en este tramo.</p>}
                <ul className="pn-lista">{gente.map(p => <li key={p.nombre} className="pn-aus"><span className={'pn-aus-n' + (p.fuera ? ' pn-tachado' : '')}>{nombreCorto(p.nombre)}</span>{p.fuera && <span className="pn-hchip todo">Ausente</span>}</li>)}</ul>
              </div>
              <div className="pn-card suave">
                <h2>Con turno hoy y ausentes <b className="pn-num">{faltan.length}</b></h2>
                {!faltan.length ? <p className="pn-nada">Todo el turno de biblioteca está cubierto.</p>
                  : <ul className="pn-lista">{faltan.map(p => <li key={p.nombre} className="pn-aus"><span className="pn-aus-n">{nombreCorto(p.nombre)}</span><span className="pn-aus-h"><span className="pn-hchip">{lblHora(p.tramo)}</span></span></li>)}</ul>}
              </div>
            </>;
          })()}
          {!esBib && !esRec && <div className="pn-card">
            <h2>Ausentes hoy <b className="pn-num">{d ? d.ausentes.length : '–'}</b></h2>
            {d && d.ausentes.length === 0 && <p className="pn-nada">No hay ausencias registradas.</p>}
            <ul className="pn-lista">{d && d.ausentes.map((a, i) => <Ausente key={i} a={a} />)}</ul>
          </div>}
          {d && !esBib && !esRec && (
            <div className="pn-card suave">
              <h2>{(fechaDe(d.proximo.fecha) - fechaDe(hoyIso)) === 864e5 ? 'Mañana' : cap(DIAS[fechaDe(d.proximo.fecha).getDay()])} <span className="pn-h2-s">{corta(d.proximo.fecha)}</span> <b className="pn-num">{d.proximo.ausentes.length}</b></h2>
              {d.proximo.ausentes.length === 0 ? <p className="pn-nada">Sin ausencias previstas.</p>
                : <ul className="pn-lista">{d.proximo.ausentes.map((a, i) => <Ausente key={i} a={a} />)}</ul>}
            </div>
          )}
          {extraHoy.length > 0 && !esBib && !esRec && (
            <div className="pn-card pn-extra">
              <h2>Extraescolares hoy <b className="pn-num">{extraHoy.length}</b></h2>
              <ul className="pn-lista">
                {extraHoy.slice(0, 4).map((e, i) => (
                  <li key={i} className="pn-ex">
                    <span className="pn-ex-t">{e.titulo}</span>
                    <span className="pn-ex-s">{e.todoElDia ? 'Todo el día' : e.hora + (e.horaFin ? '–' + e.horaFin : '')}{e.fin > e.inicio ? ' · hasta el ' + corta(e.fin) : ''}{e.lugar ? ' · ' + e.lugar : ''}</span>
                  </li>
                ))}
                {extraHoy.length > 4 && <li className="pn-nada">y {extraHoy.length - 4} más</li>}
              </ul>
            </div>
          )}
          {d && (d.reuniones || []).map((r, i) => (
            <div key={'reu' + i} className="pn-card pn-aviso urgente pn-reunion">
              <h2>Convocatoria · {r.nombreOrgano}</h2>
              <div className="pn-aviso-t">{largo(r.fecha)} · {r.hora}</div>
              {r.lugar && <p className="pn-aviso-x">{r.lugar}</p>}
            </div>
          ))}
          {aviso && (
            <div className={'pn-card pn-aviso ' + (aviso.nivel || 'info')} key={iAviso}>
              <h2>Aviso{d.avisos.length > 1 && <span className="pn-puntos">{d.avisos.map((_, i) => <i key={i} className={i === iAviso % d.avisos.length ? 'on' : ''} />)}</span>}</h2>
              <div className="pn-aviso-t">{aviso.titulo}</div>
              {aviso.texto && <p className="pn-aviso-x">{aviso.texto}</p>}
            </div>
          )}
        </aside>
      </main>

      <footer className="pn-pie">
        <div className="pn-act">
          <h2>Próximas actividades</h2>
          <div className="pn-act-l">
            {proximas.length === 0 && <span className="pn-nada">No hay actividades en los próximos 30 días.</span>}
            {proximas.map(e => {
              const ini = fechaDe(e.inicio), hoyEs = e.inicio <= hoyIso && (e.fin || e.inicio) >= hoyIso;
              return (
                <div key={e.id} className={'pn-ev' + (hoyEs ? ' hoy' : '') + (e.tipo === 'extra' ? ' extra' : '')}>
                  <div className="pn-ev-f"><b>{ini.getDate()}</b><span>{MES3[ini.getMonth()]}</span></div>
                  <div className="pn-ev-t">
                    <div className="pn-ev-n">{e.titulo}</div>
                    <div className="pn-ev-s">{e.tipo === 'extra' && <i className="pn-ev-tag">Extraescolar</i>}{hoyEs ? 'Hoy' : cap(DIAS[ini.getDay()])}{e.fin && e.fin !== e.inicio ? ' – ' + DIAS[fechaDe(e.fin).getDay()] + ' ' + fechaDe(e.fin).getDate() : ''}{e.tipo === 'extra' && e.hora ? ' · ' + e.hora : ''}{(e.grupos || []).length ? ' · ' + e.grupos.length + ' sesiones' : ''}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
        {d && d.enlaces.length > 0 && (
          <div className="pn-qrs">
            {d.enlaces.map((e, i) => <div key={i} className="pn-qr"><QR url={e.url} tam="var(--qr)" /><span>{e.titulo}</span></div>)}
          </div>
        )}
        <div className="pn-sello">
          {err === 'sin-conexion' ? <span className="pn-off">Sin conexión · datos de las {ultima ? hhmm(ultima) : '—'}</span> : <span>Actualizado {ultima ? hhmm(ultima) : '—'}</span>}
        </div>
      </footer>
    </div>
  );
}
