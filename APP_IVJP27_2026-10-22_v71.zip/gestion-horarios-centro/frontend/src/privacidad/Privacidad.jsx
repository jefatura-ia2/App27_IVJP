/**
 * Protección de datos (RGPD art. 13 · LOPDGDD art. 11): primera capa breve en cada formulario («CapaRGPD») y
 * segunda capa completa («ModalPrivacidad»).
 * Los datos variables (responsable, DPD, contacto y plazos) vienen de GET /api/privacidad (pública).
 */
import React, { useEffect, useState } from 'react';
import { pedir } from '../acceso/Acceso.jsx';

const MORADO = '#6B2D8B';
let abrirGlobal = null;
/** Abre la información completa desde cualquier sitio */
export const verPrivacidad = (pestana = 'datos') => abrirGlobal && abrirGlobal(pestana);

/** Monta una vez (en la app y en la pantalla de entrada) el visor de la información completa */
export function VisorPrivacidad() {
  const [p, setP] = useState(null);
  useEffect(() => { abrirGlobal = setP; return () => { abrirGlobal = null; }; }, []);
  return p ? <ModalPrivacidad pestana={p} onClose={() => setP(null)} /> : null;
}

/** Primera capa: texto breve + enlace a la información completa */
export function CapaRGPD({ children, className = '' }) {
  return (
    <div className={'rounded-lg px-3 py-2 text-[11px] leading-snug text-ink-soft ' + className} style={{ background: '#F5EEF9' }}>
      <b style={{ color: MORADO }}>Protección de datos.</b> {children}{' '}
      <button type="button" className="font-semibold underline underline-offset-2" style={{ color: MORADO }} onClick={() => verPrivacidad('datos')}>Más información</button>
    </div>
  );
}

const TRATAMIENTOS = [
  ['Cuentas de acceso', 'Usuario, nombre, contraseña cifrada, perfiles y último acceso', 'Dar acceso a la app a cada persona', 'Misión de interés público (RGPD art. 6.1.e)'],
  ['Datos de contacto', 'Correo de Educarex, móvil (voluntario) y años trabajados', 'Comunicarse con el docente y calcular sus días de asuntos particulares', 'Art. 6.1.e; el móvil, consentimiento (art. 6.1.a)'],
  ['Horarios, guardias, reservas e incidencias', 'Horario, materias, grupos, aulas', 'Organizar el centro', 'Art. 6.1.e'],
  ['Ausencias y justificaciones', 'Fechas, motivo (puede ser de salud) y justificantes en PDF', 'Gestionar las ausencias y su justificación (Orden de 29/08/2024)', 'Art. 6.1.c y e; datos de salud: art. 9.2.b'],
  ['Días de asuntos particulares (DAP)', 'Solicitudes y resoluciones', 'Tramitar los DAP', 'Art. 6.1.c y e'],
  ['Firmas de las guardias', 'Guardia, fecha y hora de la firma', 'Comprobar que se cubren las guardias', 'Art. 6.1.e'],
  ['Partes de disciplina', 'Alumno/a, grupo, conductas y observaciones', 'Convivencia del centro (Decreto 50/2007)', 'Art. 6.1.e · LOE, disposición adicional 23.ª'],
  ['CCP y Consejo Escolar', 'Convocatorias y confirmaciones', 'Funcionamiento de los órganos del centro', 'Art. 6.1.e'],
  ['Registro de accesos', 'Quién consulta datos sensibles y cuándo', 'Seguridad y responsabilidad proactiva', 'Art. 6.1.c y 32 · ENS'],
];

export function ModalPrivacidad({ pestana = 'datos', onClose }) {
  const [d, setD] = useState(null);
  useEffect(() => { pedir('GET', '/privacidad').then(setD).catch(() => setD({ error: true })); }, []);
  useEffect(() => { const k = e => { if (e.key === 'Escape') onClose(); }; addEventListener('keydown', k); return () => removeEventListener('keydown', k); }, [onClose]);
  const H = ({ children }) => <h3 className="font-display font-bold text-[15px] mt-5 mb-1.5" style={{ color: '#522270' }}>{children}</h3>;
  const plazo = n => n === 0 ? 'durante el curso actual' : `el curso actual y ${n} curso${n > 1 ? 's' : ''} más`;
  return (
    <div className="fixed inset-0 z-[70] bg-black/50 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6" role="dialog" aria-modal="true" aria-label="Protección de datos" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[92dvh] flex flex-col fade-in">
        <div className="flex items-center gap-3 px-5 py-3.5 rounded-t-2xl text-white" style={{ background: MORADO }}>
          <div className="flex-1"><div className="text-[10px] font-bold tracking-[.16em] opacity-80">IES VALLE DEL JERTE</div>
            <div className="font-display font-bold text-lg leading-tight">Protección de datos</div></div>
          <button className="w-9 h-9 rounded-lg bg-white/15 hover:bg-white/25 text-xl leading-none" onClick={onClose} aria-label="Cerrar">×</button>
        </div>
        <div className="overflow-y-auto px-5 pb-5 text-sm text-ink leading-relaxed">
          {!d ? <p className="py-6 text-ink-soft">Cargando…</p> : <>
            <H>Quién trata tus datos</H>
            <p><b>Responsable:</b> {d.responsable}</p>
            <p><b>Delegado/a de Protección de Datos:</b> {d.dpd}</p>
            <p><b>Contacto en el centro:</b> {d.contacto}</p>
            <H>Qué datos, para qué y con qué base jurídica</H>
            <div className="overflow-x-auto"><table className="w-full text-xs border-collapse min-w-[560px]"><thead><tr style={{ background: '#F5EEF9', color: '#522270' }}>
              {['Tratamiento', 'Datos', 'Finalidad', 'Base jurídica'].map(x => <th key={x} className="text-left p-2 font-bold">{x}</th>)}</tr></thead>
              <tbody>{TRATAMIENTOS.map(r => <tr key={r[0]} className="border-b border-divider align-top">{r.map((c, i) => <td key={i} className={'p-2 ' + (i ? '' : 'font-semibold')}>{c}</td>)}</tr>)}</tbody></table></div>
            <H>Quién puede verlos</H>
            <p>Solo el personal del centro que los necesita para su función: cada docente ve sus propios datos; Jefatura de Estudios y Dirección, los que gestionan. Los motivos de las ausencias y los justificantes solo los ven la persona interesada y Jefatura. Los partes de disciplina los ven quien los pone y el Jefe/a de Estudios de la etapa; el tutor/a recibe solo un aviso, sin datos del alumno/a. Todo el personal tiene deber de sigilo. No se ceden datos a terceros salvo obligación legal. La hoja de ausencias y el calendario de DAP se sincronizan con servicios de Google de las cuentas institucionales del centro.</p>
            <H>Cuánto tiempo se guardan</H>
            <ul className="list-disc pl-5 space-y-0.5">{(d.categorias || []).map(c => <li key={c.k}><b>{c.l}:</b> {plazo(d.plazos[c.k])}; después se borran en el cierre de curso.</li>)}</ul>
            <p className="mt-1">Los PDF de los partes de disciplina se borran de la carpeta del servidor en cuanto Jefatura los recibe.</p>
            <H>Tus derechos</H>
            <p>Puedes pedir el <b>acceso</b> a tus datos, su <b>rectificación</b> o <b>supresión</b>, la <b>limitación</b> del tratamiento y <b>oponerte</b> a él (RGPD arts. 15–22), dirigiéndote al contacto del centro o al Delegado/a de Protección de Datos. Tus datos de contacto los puedes corregir tú mismo/a en «Mi cuenta». Si crees que no se han respetado tus derechos, puedes reclamar ante la Agencia Española de Protección de Datos (www.aepd.es).</p>
            <H>Seguridad y almacenamiento en tu dispositivo</H>
            <p>Acceso con cuenta personal y contraseña cifrada, bloqueo tras varios intentos fallidos, modo administrador con la contraseña de cada persona, registro de accesos a los datos sensibles y conexión cifrada. La app solo guarda en tu navegador lo técnico necesario para funcionar (sesión y preferencias); no usa cookies de publicidad ni de terceros. En un ordenador compartido, marca «Equipo compartido» al entrar y cierra la sesión al terminar.</p>
          </>}
        </div>
      </div>
    </div>
  );
}
