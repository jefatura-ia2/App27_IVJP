/* CSS de Tailwind de cronologia.html, compilado en el servidor (antes se cargaba de cdn.tailwindcss.com).
   Regenerar si cambian las clases: npx tailwindcss -c tools/tailwind-cronologia.config.cjs -i tools/tailwind-cronologia.css -o public/vendor/cronologia-tailwind.css --minify */
module.exports = {
  content: ['./public/cronologia.html'],
  theme: { extend: {
    colors: { 'ink': '#1a2332', 'ink-soft': '#3d4a5c', 'paper': '#FBFBFA', 'paper-warm': '#F5F3EE', 'olive': '#5c6b4f', 'olive-light': '#e8ebe3',
      'terracotta': '#a85a3f', 'terracotta-light': '#f5ebe6', 'ink-blue': '#2d4a6b', 'ink-blue-light': '#e4ecf4',
      'divider': '#e5e2db', 'primary': '#6366f1', 'primary-dark': '#4f46e5' },
    fontFamily: { display: ['Montserrat', 'system-ui', 'sans-serif'], body: ['Montserrat', 'system-ui', 'sans-serif'] },
  } },
  plugins: [],
};
